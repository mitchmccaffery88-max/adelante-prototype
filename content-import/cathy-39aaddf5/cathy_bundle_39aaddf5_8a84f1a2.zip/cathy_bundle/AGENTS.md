<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

- Shared Adel and module controls accept optional Library-only teaching and suggestions; absent inputs retain Recovery Journey behavior.
- Employment uses Public Assistance's renderer via getEmploymentSections; unknown sections go in the final group. Why: no resources disappear.
- Validate conversational tool suggestions against real options and maxPicks before display, persistence, and member-triggered application to prevent invented or excessive picks.
- lesson-flow projects five steps/two Part B screens, migrates old positions and copies member answers; exercise-control normalizes practice; talk records finished exercises. Why: resume, saves and private outcomes agree.
- Library session answers and durable libraryInProgress restore before rendering; library-progress resolves next/helped items. Overlay Back preserves inline Adel talks.
- Library restart clears the keyed talk record and remounts run-local views; Adel responses must not persist after their conversation unmounts, preventing late replies from restoring cleared chats.
- If–Then plan content comes from skill.ifThen or if-then-defaults.ts; plan lines live in flow picks/own under ifthen-* ids so SUGGEST validation can draft them. Why: one suggestion path.
- Saved if-then plans have Use-it-now and edit screens; planLogs drive check-in follow-up. Why: plans work in hard moments.
- Saved-plan backup actions resolve through backupAction with the item context; lesson exercise backups use the topic's Part A id. Why: one mapping keeps action destinations consistent without generic exercise substitutions.
- Shared care notes render all assigned notes in Welcome/Part B/Adel; resource-aliases resolves retired IDs and narrowly corrects legacy demo state. Why: safety notes and saved destinations survive audits.
- Lesson SAFETYCHECK replies use the fixed question and once-per-talk gate in lesson-safety-check.ts with shared safety chips. Why: safety answers must never answer an unrelated coaching question.
- Plan-confidence help (adel-plan-help.tsx, TALK_PLAN) is unpersisted; only validated SUGGEST fixes applied by tap persist. Hopeless language stops it with the crisis card.
- SUD Recovery Journey lessons render through SelfHelpModuleTemplate with host.recovery (saves via saveRecoveryTool, plans resolve via "recovery:<moduleId>" → RECOVERY_IF_THEN_CONTENT/DEFAULTS). Why: one lesson template, no Library-category bleed.
- SUD lesson-level plan content lives in recovery-if-then-content.ts and overrides module defaults; updateToolkitItem synchronizes existing matching Recovery Toolkit plan text through syncRecoveryPlan. Why: every plan edit path keeps both saved copies consistent without changing Library plans.
- /toolkit holds all saved items in ?tab= tabs; /my-plans and /sud-recovery-journey/toolkit redirect there; /start/toolkit stays the reentry save step. Why: one place for saved items.
- Toolkit tool cards store title in label and newline-separated details in optional content; toolkitCard reads legacy joined labels without migrating them. Why: structured cards remain compatible with existing saves.
- Forward Step uses a pure ladder selector, dated outcomes and stable action keys; today-step bridges saved state, while Adel explains the app-selected activity. Both feedback surfaces use finishStep; agreed exercise keys normalize to exercise ids. Weekly summaries and focus use the same private history. Why: safety, progression and future picks share one source of truth.
- Lesson routes consume part=build through the shared template after hydration to open Part B. Why: ladder plans reuse existing lesson tools and saved progress.
- One grouped nav list feeds desktop sidebar and mobile More sheet; /learn is the Learn hub. Members see "Recovery Journey"/"peer specialist"; code keeps "sud-recovery-journey"/"peer". Why: one vocabulary, stable internals.
- Welcome progress and editable draft persist in welcome-store; saved dayPlan/checks remain in app state, with pure reentry flow rules and shared contact-numbers. Why: draft edits cannot change saved plans until Review & Save.
- Welcome resource selection shares plan-resources mapping; resource pages carry from/action/returnTo and plan returns restore the action sub-step. Why: in-place picks and browsing retain the same draft, including saved-plan edits.
- Adel reads member facts only through src/lib/member-context.ts (getMemberContext); main /adel uses mode "guide" and the app, not Adel, picks "What should I do next?" via pickNextStep. Why: one swap point for the EHR and deterministic next steps.
- "Back to Adel" state and the shared "What can I help you with today?" choices live in src/lib/adel-return.ts; /adel takes ?help=<intent>, ?ask=<text>, ?back=1 and clears them after use. Why: Home and the chat share one choice list and one return path.
- Daily check-in is one DailyCheckIn component (Home + /adel opener) gated by checkInDue in daily-check-in.ts; Home step 2 navigates to /adel?help|ask without recording feelings. Why: one check-in, no keyword guessing.
- Resolve related ids centrally for Insight/Adel; history links and session flow restore Back. Keep legacy redirects/exercises safe.
- pathway.ts owns stage math; usePathway reads Welcome and both libraries. State actions log real moments; one shell tracker logs reached stages. Why: all screens share computed progress without synthetic milestones.
- AdelActionButton owns source-aware exercise returns; ExercisePlayer finishes once and bounds breathing. Inline onExercise bypasses follow-up. Why: consistent check-ins without lesson/Toolkit cards.
- Lesson tools: ToolFlowStep.shared reads/writes sharedAnswers (lib/shared-answers), feeds drives If–Then prefill before title matching, lib/lesson-tools resolves toolName for Adel ACTION tool: and plan "Use it now". Why: content batches plug in as data only.
