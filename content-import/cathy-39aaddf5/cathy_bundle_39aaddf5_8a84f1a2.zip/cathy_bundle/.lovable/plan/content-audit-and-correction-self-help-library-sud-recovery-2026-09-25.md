# Content audit and correction: Self Help Library + SUD Recovery Journey

## What the first audit found

180 submodules in total: 90 in the library (9 collections x 10) and 90 in the Recovery Journey (9 missions x 10). Only 7 have content written for their topic (Finding My Footing, plus 6 library modules with extra content). Everything else is filled in automatically from shared stock text. That causes the repeated wording the spec describes.

**Understand My Challenge**
- Library: the same three lines run in every module ("When everything feels important...", "That doesn't mean you're failing...", "You don't have to have this figured out today..."). Every module ends with the same "you're not alone" line. Where a module had no list of its own, it shows one shared 7-item checklist. The "Why this feels so hard" bullets are the same 5 items everywhere.
- Recovery: every lesson opens "Have you ever asked yourself, '[topic]'..." followed by the same two lines ("Coming home means handling a lot at once..."). All 90 share one "which sound like you" list.
- Recovery peer stories: one quote per mission with only the name swapped, so 10 lessons in a row tell the same story.

**Check In With Myself**
- Library: "How much is '[title]' weighing on you" for every module, plus the same confidence and hope questions.
- Recovery: "How much is '[focus]' a struggle", the same confidence question, and one support question used everywhere.

**Talk It Through With Adel**
- Library: questions 2 and 3 are the same in all 90 ("What strengths have already helped...", "If someone believed in you...").
- Recovery: all three questions are the same template in every lesson.

**Build My Skills, Part A**
- Part A is picked by keyword from only 11 shared exercises. Most modules end up on Box Breathing, Thought Record, Support Circle or Trigger Map.
- 7 of the 11 need typing or filling in a form before the member can start (Thought Record, Trigger Map, Support Circle, Budget, Communication Script, If-I-Slip Plan, Milestone Reward). That breaks the plug-and-play rule.

**Build My Skills, Part B**
- Library modules without their own content get the same 4 generic steps: "Where am I / What has changed / What matters / Next step". The value chips are the same everywhere.
- Recovery: steps 2 to 4 (warning signs, support people, next move) are identical in all 90. Only step 1 changes, and it changes once per mission, not per lesson.

**Insight and Check My Progress**
- Recovery: one insight line is used everywhere ("Recovery is built through small choices...").
- The progress re-check repeats the generic check-in questions, so it doesn't measure the lesson's actual skill.

**Already topic-specific, and staying as is:** titles, the problem line, the main teaching paragraph, the original interactive activity, each module's own Adel question, insight and action, the 6 enriched modules, Finding My Footing, and all lesson "learn" points in the Recovery Journey.

## How it will be corrected

1. **One written entry per submodule** covering only the generic parts: 3 or 4 opening lines, a checklist, the closing "you're not alone" line, a short "why it's hard" with its own bullets, the reframe, check-in questions and their end labels, Adel questions 2 and 3, the insight prompt, and Part B steps. Recovery lessons also get their own peer story and practice scene. Anything already topic-specific stays word for word.
2. **Part A becomes real plug-and-play.** The shared Exercise Library gets about 40 new guided exercises: tap Start and follow timed steps, with nothing to type, lasting 30 seconds to 2 minutes. Formats vary: mental rehearsal, a body action, saying a line out loud, picturing a moment, riding out an urge, perspective shifts, decision practice. Each submodule is assigned a specific exercise instead of a keyword guess. An exercise is shared only between truly related topics, and breathing or grounding is used only where the topic is about calming down. They stay in the one shared library and can still be opened by Adel and from the exercise page.
3. **The 7 form-style exercises stay in the library** and keep working from My Toolkit and Adel. They're no longer used as Part A. Where they fit the topic, that content moves into Part B.
4. **Part B keeps its step-by-step pick-and-save design**, with topic-specific steps and choices for each submodule. Save to My Toolkit works the same. Existing saved Toolkit items are kept.
5. **No design or layout changes:** the 6 steps, navigation, crisis handling, progress and resume stay exactly as they are.

## Order of work (review checkpoints)

- **Batch 1:** Starting Strong (library) and My First Days Out (recovery), plus the new guided exercises they need. Then I stop so you can review.
- **Batches 2 to 9:** the remaining 8 collections and 8 missions, two per batch.
- **Final pass:** a second audit against the spec's checklist, and a check that no Part A needs typing before it starts and no paragraph repeats across submodules. I'll give you a short report with it.

## Technical details

- New content lives in `src/data/topic-content/` with one file per collection or mission, keyed by submodule id. `derive()` in `module-schema.ts` and `recovery-submodule.ts` uses these entries first. The generic fallback arrays stay only as a safety net, and a dev check lists any submodule still falling back to them.
- `exercises.ts` gets a new `guided` type (a list of timed steps, no inputs), played by the existing exercise player. Every module gets an explicit `exerciseId`, so `matchExercise` is no longer the main path.
- Toolkit keys (`library:<id>`, `recovery:<id>`) don't change, so saved items and resume points are kept.
- Content rules: 6th to 8th grade reading level, trauma-informed, shame-free, no diagnoses as identity, Tulare County only, crisis language stays hardcoded.
