# Restructure Self-Help Library to 6 Steps

## Goal
Replace the 10-step submodule architecture in the **Adelante Self-Help Learning Library** with a tighter 6-step flow, then condense Module 1's first step as the exemplar before rolling the rest out.

## New 6-step flow
1. **Understanding My Challenge** — merged welcome checklist + condensed "What's happening" content
2. **Check In With Myself** — unchanged rating sliders + optional reflection
3. **Talk It Through With Adel** — moved up; same behavior, crisis keyword bypass preserved
4. **Build My Skill** — Part A exercise + Part B helpful tool, ending with a **Save to My Toolkit** button
5. **Insight** — current "My Insight"
6. **Checking My Progress** — current re-rate + change framing

Removed: Learn What's Happening (merged), Practice in Real Life, My Next Step Today, standalone Save to My Toolkit.

## Scope guardrails
- **Only the Self-Help Library** changes. The Recovery Journey also uses `ModuleTemplate`, so we'll create a dedicated `SelfHelpModuleTemplate` and wire the library route to it, leaving Recovery Journey untouched.
- No changes to crisis/safety features, dashboard, Resources, Progress, journey stages, Recovery Support button, nav shell, or module/submodule titles.
- Do not delete existing user Toolkit items. Map anyone mid-module to the closest new step rather than resetting progress.

---

## Pass 1 — Structure (all modules)

### 1. Schema: new `SelfHelpModule` type
**Files:** `src/data/module-schema.ts`
- Add a new `SelfHelpModule` shape with the 6 fields above.
- Keep `CanonicalModule` and `buildCanonicalModule` as-is for Recovery Journey compatibility.
- Add a `toSelfHelpModule(canonical: CanonicalModule): SelfHelpModule` function that reorders/strips content:
  - Step 1 merges `challenge` + condensed `learn` into a new `understanding` step (drop `didYouKnow` and `keyTakeaway`).
  - Step 2 keeps `checkIn`.
  - Step 3 keeps `adel`.
  - Step 4 keeps `skill`.
  - Step 5 keeps `insight`.
  - Step 6 keeps `checkIn` dimensions for re-rating + `progressNote`.
- Replace `MODULE_STEP_LABELS` with a `SELF_HELP_STEP_LABELS` array of 6 labels, using the user's exact names.
- Update route head copy in `src/routes/_shell.library.$category.$itemId.tsx` from "10-step" to "6-step".

### 2. UI: new `SelfHelpModuleTemplate` component
**Files:** `src/components/self-help-module-template.tsx` (new), `src/components/module/shared.tsx`
- Fork the current `ModuleTemplate` into `SelfHelpModuleTemplate` so Recovery Journey keeps the existing 10-step template untouched.
- Reorder the `switch`/`if` blocks to the 6-step sequence:
  - Step 0 = merged understanding screen
  - Step 1 = `RatingCheckIn`
  - Step 2 = `AdelConversation`
  - Step 3 = exercise (sub 0) + `GuidedToolFlow` (sub 1+) with new Save button
  - Step 4 = insight
  - Step 5 = re-rate + change deltas
- Update the stepper label and progress dots to "Step X of 6".
- Remove state, handlers, and render paths for practice scenario, If–Then plan, confidence check, next-step selection, and standalone toolkit save.

### 3. Step 1 condensed renderer
**Files:** `src/components/module/shared.tsx`
- Create a `CondensedUnderstanding` component that renders:
  - Welcome block (3–5 short lines from `challenge.welcome`)
  - "Which of these sound like you?" checklist
  - A short "What's happening" section: 2–3 essential ideas pulled from `learn.whyHappening` and `learn.whyHard`, 1–2 plain sentences each
  - Keep `learn.stages` visual only if it exists and is core to the module
  - Drop `didYouKnow`, `keyTakeaway`, long multi-part explainers, and diagrams
- Use the existing `ChecklistCard` for the checklist.

### 4. Step 4 Save-to-Toolkit button
**Files:** `src/components/module/shared.tsx`, `src/components/self-help-module-template.tsx`
- Add a **Save to My Toolkit** button at the end of `GuidedToolFlow` (after the tool summary), replacing the old static "Create My Toolkit" display block.
- On click, persist the same items the old step 10 saved: skill output lines, the module reminder/insight, and selected supports.
- Button flips to a saved state (e.g., "Saved to My Toolkit" with checkmark) and shows a confirmation message.
- Ensure saved items appear in the existing **My Toolkit** list and carry enough metadata (module title + skill name) to be viewable.
- *Open question:* make Toolkit items reopenable by adding a route field. This is low-risk and will be included if the existing Toolkit UI supports it; otherwise it remains view-only for Pass 1.

### 5. Data migration for mid-module users
**Files:** `src/components/self-help-module-template.tsx`
- Store the user's last visited step under the existing persistence key, but map old 10-step indices to new 6-step indices on first load:
  - old 0 → new 0
  - old 1 → new 1
  - old 2,3,5 → new 0 (understanding/Adel clusters)
  - old 4 → new 3 (skill)
  - old 6 → new 4 (insight)
  - old 7 → new 5 (progress)
  - old 8,9 → new 5 (progress/save already complete)
- This avoids resetting anyone mid-module.

### 6. Cleanup stale references
- Search the codebase for "10-step", old step names ("Practice in Real Life", "My Next Step Today", "Save to My Toolkit" as a standalone), and step-number mentions in copy.
- Update `src/routes/_shell.library.$category.$itemId.tsx` head metadata.
- Do **not** touch Recovery Journey routes or `ModuleTemplate`.

---

## Pass 2 — Condense Module 1 (Finding My Footing)

**Files:** `src/data/module-schema.ts` (`OVERRIDES`)
- After Pass 1 lands, add a `SelfHelpModule`-shaped override for `finding-footing` that supplies the condensed Step 1 content.
- Merge the current `challenge.welcome` and the most essential ideas from `learn.whyHappening` / `learn.whyHard` / `learn.reframe`.
- Keep the Reentry Adjustment Curve visual because it is core to the module.
- Remove `didYouKnow` and `keyTakeaway`.
- Keep reading level at 6th–8th grade, warm, non-clinical, shame-free.
- Verify the module end-to-end before moving to Modules 2–9.

---

## Verification
After each pass, confirm:
1. Every Self-Help submodule renders exactly 6 steps in the correct order.
2. No "Did You Know?" or "Key Takeaway" appears in Step 1.
3. The Save to My Toolkit button in Step 4 works and items appear in My Toolkit.
4. No references to removed steps remain in library copy.
5. Recovery Journey still renders its 10-step flow unchanged.
6. Typecheck and build pass.
