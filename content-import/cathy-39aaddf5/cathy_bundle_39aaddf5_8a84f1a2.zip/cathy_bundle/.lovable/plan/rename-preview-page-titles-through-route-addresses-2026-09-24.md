# Rename Preview Page Titles Through Route Addresses

## Goal
Make Lovable’s top preview page dropdown show the five new section names by renaming the route addresses it reads.

## Changes
- Rename the five route families:
  - `/library` → `/self-help-library`
  - `/resources` → `/community-resources`
  - `/recovery` → `/sud-recovery-journey`
  - `/journey` → `/re-entry-pathway`
  - `/obligations` → `/week-at-a-glance`
- Rename all related route files, including category, detail, lesson, saved, and toolkit pages.
- Update navigation, dashboard cards, Adel actions, recovery support, check-ins, exercises, toolkit links, and stored route references to use the new addresses.
- Add one fallback redirect handler for the former addresses so older bookmarks and saved links still reach the equivalent renamed page without adding the old page families back to the preview menu.
- Preserve all page content, styling, progress, safety behavior, and saved member data.

## Verification
- Confirm every renamed page and representative nested page opens directly.
- Confirm sidebar, dashboard, Adel/resource, lesson, and toolkit links use the new addresses.
- Confirm each former address redirects to its exact renamed equivalent.
- Confirm the five visible headings and browser titles still match the new names.
