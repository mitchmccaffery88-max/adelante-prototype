// PRE-MODULE: I Just Got Out ("Welcome to Adelante")
// A same-day stabilization / immediate-needs triage flow. Deliberately NOT the
// canonical 10-step skill-building architecture — one question per screen,
// low reading burden, every answer routes to real help.
//
// All safety and plan wording here is hardcoded, never AI-generated.

export type ReentryLessonId =
  | "welcome" | "needs" | "urge" | "shelter" | "food" | "meds"
  | "logistics" | "quick" | "support" | "plan" | "toolkit";

export type ReentryLesson = {
  id: ReentryLessonId;
  title: string;
  /** One short line under the title. Plain language, no clinical framing. */
  blurb: string;
  minutes: number;
};

export const REENTRY_MODULE = {
  id: "just-got-out",
  internalName: "PRE-MODULE: I Just Got Out",
  name: "Welcome to Adelante",
  subtitle: "What do I need right now?",
  intro: "Before anything else — let's make sure you're okay today.",
  lessons: [
    { id: "welcome", title: "Welcome — You're Not Alone", blurb: "You don't have to figure everything out today.", minutes: 1 },
    { id: "needs", title: "My Immediate Needs", blurb: "Check anything you need help with right now.", minutes: 1 },
    { id: "urge", title: "I'm Thinking About Using Right Now", blurb: "Two quick questions. Then real help.", minutes: 1 },
    { id: "shelter", title: "Do I Have a Safe Place Tonight?", blurb: "One question. Then real options.", minutes: 1 },
    { id: "food", title: "Food, Water & Basic Needs", blurb: "Have you eaten today?", minutes: 1 },
    { id: "meds", title: "Medications & My Health", blurb: "Do you have what you need?", minutes: 1 },
    { id: "logistics", title: "Phone, ID & Transportation", blurb: "The practical stuff that unlocks everything else.", minutes: 1 },
    { id: "quick", title: "Quick Check", blurb: "Just yes or no.", minutes: 1 },
    { id: "support", title: "Who Can Help Me Today?", blurb: "Ways to reach a real person.", minutes: 1 },
    { id: "plan", title: "My Next 24 Hours", blurb: "Things I will do. Tonight and tomorrow only.", minutes: 3 },
    { id: "toolkit", title: "Review & Save", blurb: "Save it so it's here when you need it.", minutes: 1 },
  ] satisfies ReentryLesson[] as ReentryLesson[],
};

export const NEEDS = {
  shelter: "I need a safe place to sleep tonight",
  food: "I need food or water",
  meds: "I need medications",
  logistics: "I need a phone, ID, or a ride",
  urge: "I'm having urges to use",
  talk: "I need someone to talk to",
  probation: "I need to check in with probation or parole",
};

export const IMMEDIATE_NEEDS = [
  NEEDS.shelter, NEEDS.food, NEEDS.meds, NEEDS.logistics, NEEDS.urge, NEEDS.talk, NEEDS.probation,
];

/** Needs with their own screen, in screen order. */
const NEED_SCREENS: { need: string; screen: ReentryLessonId }[] = [
  { need: NEEDS.shelter, screen: "shelter" },
  { need: NEEDS.food, screen: "food" },
  { need: NEEDS.meds, screen: "meds" },
  { need: NEEDS.logistics, screen: "logistics" },
];

/** The four things the Quick Check asks about when they weren't checked. */
export const QUICK_CHECKS: { key: string; need: string; question: string }[] = [
  { key: "quick-shelter", need: NEEDS.shelter, question: "Do you have a safe place to sleep tonight?" },
  { key: "quick-food", need: NEEDS.food, question: "Do you have food for today?" },
  { key: "quick-meds", need: NEEDS.meds, question: "Do you have the medications you need?" },
  { key: "quick-logistics", need: NEEDS.logistics, question: "Do you have a phone, your ID, and a way to get around?" },
];

export type FlowInput = { needs: string[]; answers: Record<string, string> };

/** Needs the member has: checked on the needs screen, plus any "no" on Quick Check. */
export function effectiveNeeds({ needs, answers }: FlowInput): string[] {
  const out = [...needs];
  for (const q of QUICK_CHECKS) if (answers[q.key] === "no" && !out.includes(q.need)) out.push(q.need);
  return out;
}

/**
 * Risk stacks up: urges AND (no safe place tonight, OR no food, OR no one to talk to).
 */
export function isEscalated(input: FlowInput): boolean {
  const n = effectiveNeeds(input);
  const a = input.answers;
  if (!n.includes(NEEDS.urge)) return false;
  return (
    n.includes(NEEDS.shelter) || a.shelter === "no" ||
    n.includes(NEEDS.food) || a.food === "no" ||
    n.includes(NEEDS.talk)
  );
}

/** The member's actual screens, in order. Screens not listed count as done. */
export function visibleScreens(input: FlowInput): ReentryLessonId[] {
  const checked = input.needs;
  const all = effectiveNeeds(input);
  const out: ReentryLessonId[] = ["welcome", "needs"];
  if (checked.includes(NEEDS.urge) || isEscalated(input)) out.push("urge");
  for (const s of NEED_SCREENS) if (checked.includes(s.need)) out.push(s.screen);
  if (QUICK_CHECKS.some((q) => !checked.includes(q.need))) out.push("quick");
  for (const s of NEED_SCREENS) if (!checked.includes(s.need) && all.includes(s.need)) out.push(s.screen);
  out.push("support", "plan", "toolkit");
  return out;
}

export function findReentryLesson(id: string) {
  return REENTRY_MODULE.lessons.find((l) => l.id === id) ?? null;
}

/* ----------------------------- Urge triage ----------------------------- */

export type UrgeStrength = "ok" | "strong" | "about";
export const URGE_Q1 = {
  question: "How strong is it right now?",
  options: [
    { id: "ok" as const, label: "It's there, but I'm okay" },
    { id: "strong" as const, label: "It's strong" },
    { id: "about" as const, label: "I'm about to use, or I already did" },
  ],
};
export const URGE_Q2 = { question: "Is there someone you can reach right now?" };

/** 1 = self-help + peer, 2 = a real person now, 3 = stay-alive safety first. */
export function urgeLevel(strength: UrgeStrength | undefined, reach: "yes" | "no" | undefined, escalated: boolean): 1 | 2 | 3 | null {
  if (strength === "about") return 3;
  if (escalated || strength === "strong" || reach === "no") return 2;
  if (strength === "ok" && reach === "yes") return 1;
  return null;
}

/** Hardcoded, pre-written support language. Never AI-generated. */
export const URGE_SCRIPT = [
  "You're here instead of using. That already counts.",
  "A craving is a wave. It peaks and it passes — usually inside 20 minutes if you don't feed it.",
  "You don't have to white-knuckle this alone. Pick any one of the options below right now.",
];

export const LEVEL2_HEADING = "Let's get a real person on this now.";
export const LEVEL3_SAFETY =
  "After time inside, your body can't handle what it used to. Even a small amount can stop your breathing.";
export const SIGNS_911 = ["They can't be woken up", "Breathing is slow or stopped", "Lips are blue or gray"];
export const ESCALATION_BANNER = "You told us tonight is really hard. Let's get a real person on this now.";

/* --------------------------- 24-hour action plan --------------------------- */

export type PlanWhen = "Now" | "Today" | "Before 3 pm" | "Tonight" | "Tomorrow morning" | "Tomorrow afternoon" | string;
export const WHEN_CHIPS = ["Now", "Before 3 pm", "Tonight", "Tomorrow morning", "Tomorrow afternoon"];

export type PlanAction = {
  id: string;
  kind: "devon" | "meeting" | "shelter" | "meds" | "food" | "probation" | "phone" | "id" | "ride";
  /** What I'll do — a verb, editable. */
  what: string;
  /** Resource category to pick an organization from, if this is a service. */
  category?: string;
  /** "person" = member types a name + phone. */
  whoKind: "service" | "person" | "devon";
  who?: { orgId?: string; name: string; phone?: string; address?: string; hours?: string };
  when: PlanWhen;
  backup: string;
  backupOptions: string[];
  /** Standing actions are always first and can't be deleted, only rescheduled. */
  standing?: boolean;
  note?: string;
};

export const STANDING_ACTIONS: PlanAction[] = [
  {
    id: "devon", kind: "devon", what: "Connect with Devon", whoKind: "devon",
    who: { name: "Devon, peer specialist" }, when: "Today",
    backup: "If no answer: call the Warm Line or 988",
    backupOptions: ["If no answer: call the Warm Line or 988"], standing: true,
  },
  {
    id: "meeting", kind: "meeting", what: "Go to a meeting", whoKind: "service", category: "recovery",
    when: "Tomorrow morning", backup: "If I can't make it: join an online meeting tonight",
    backupOptions: ["If I can't make it: join an online meeting tonight"], standing: true,
    note: "Online meetings count.",
  },
];

const NEED_ACTIONS: { kind: PlanAction["kind"]; need?: string; logistics?: "phone" | "id" | "ride"; make: () => PlanAction }[] = [
  { kind: "shelter", need: NEEDS.shelter, make: () => ({
    id: "shelter", kind: "shelter", what: "Call about a bed", whoKind: "service", category: "shelter", when: "Now",
    backup: "Call 211", backupOptions: ["Call 211", "Ask Devon to call with me", "Try the next shelter on the list"] }) },
  { kind: "meds", need: NEEDS.meds, make: () => ({
    id: "meds", kind: "meds", what: "Call to get my medication started or refilled", whoKind: "service", category: "healthcare", when: "Before 3 pm",
    backup: "Ask Devon to call with me", backupOptions: ["Ask Devon to call with me", "Try another clinic on the list"] }) },
  { kind: "food", need: NEEDS.food, make: () => ({
    id: "food", kind: "food", what: "Go to or call the food bank", whoKind: "service", category: "food", when: "Before 3 pm",
    backup: "Call 211", backupOptions: ["Call 211", "Ask Devon where to eat tonight", "Go to a shelter meal"] }) },
  { kind: "probation", need: NEEDS.probation, make: () => ({
    id: "probation", kind: "probation", what: "Check in with my officer", whoKind: "person", when: "Tomorrow morning",
    backup: "Call ahead and say why", backupOptions: ["Call ahead and say why", "Ask Devon to help me call"] }) },
  { kind: "phone", logistics: "phone", make: () => ({
    id: "phone", kind: "phone", what: "Apply for a free phone (California LifeLine)", whoKind: "service", category: "financial", when: "Tomorrow morning",
    backup: "Ask Devon to help me apply", backupOptions: ["Ask Devon to help me apply", "Call 211"] }) },
  { kind: "id", logistics: "id", make: () => ({
    id: "id", kind: "id", what: "Start getting my ID", whoKind: "service", category: "legal", when: "Tomorrow afternoon",
    backup: "Ask Devon what papers I need", backupOptions: ["Ask Devon what papers I need", "Call 211"] }) },
  { kind: "ride", logistics: "ride", make: () => ({
    id: "ride", kind: "ride", what: "Set up a ride", whoKind: "service", category: "transportation", when: "Tomorrow morning",
    backup: "Ask Devon about a bus pass", backupOptions: ["Ask Devon about a bus pass", "Call 211"] }) },
];

/** Which logistics items the member is missing. If none were picked, all three. */
function missingLogistics(answers: Record<string, string>): ("phone" | "id" | "ride")[] {
  const picked = (["phone", "id", "ride"] as const).filter((k) => answers[`logistics-${k}`] === "missing");
  return picked.length ? picked : ["phone", "id", "ride"];
}

/**
 * Build the plan: two standing actions first, then one action per need.
 * Actions already in `existing` (same id) keep the member's edits.
 */
export function buildPlanActions(input: FlowInput, existing: PlanAction[] = []): PlanAction[] {
  const needs = effectiveNeeds(input);
  const keep = (a: PlanAction) => existing.find((e) => e.id === a.id) ?? a;
  const out: PlanAction[] = STANDING_ACTIONS.map((a) => ({ ...keep(a), standing: true }));
  const logistics = needs.includes(NEEDS.logistics) ? missingLogistics(input.answers) : [];
  for (const n of NEED_ACTIONS) {
    const wanted = n.need ? needs.includes(n.need) : logistics.includes(n.logistics!);
    if (wanted) out.push(keep(n.make()));
  }
  // Carry over any other unfinished actions the member already had.
  for (const e of existing) if (!out.some((a) => a.id === e.id)) out.push(e);
  return out;
}

export function safetyLines(person?: string) {
  return {
    urge: `If an urge hits: Craving right now · ${person?.trim() || "Devon"} · 988`,
    useAnyway: "If I use anyway: don't use alone (Never Use Alone) · naloxone · call 911 if someone won't wake up",
  };
}

export const PLAN_HOURS = 24;

export type PlanPerson = { name: string; phone: string };
export type DayPlan = { savedAt: string; actions: PlanAction[]; person: PlanPerson; checks: Record<string, "done" | "failed"> };

export function planExpired(plan: DayPlan, now = Date.now()) {
  return now - new Date(plan.savedAt).getTime() >= PLAN_HOURS * 3600e3;
}
export function allChecked(plan: DayPlan) {
  return plan.actions.every((a) => plan.checks[a.id] === "done");
}
export function checkDayPlan(plan: DayPlan, id: string, value: "done" | "failed" | null): DayPlan {
  if (!plan.actions.some((a) => a.id === id)) return plan;
  const checks = { ...plan.checks };
  if (value) checks[id] = value; else delete checks[id];
  return { ...plan, checks };
}
export function nextDayActions(plan: DayPlan): PlanAction[] {
  return [...STANDING_ACTIONS.map((a) => ({ ...a })), ...plan.actions.filter((a) => !a.standing && plan.checks[a.id] !== "done")];
}
