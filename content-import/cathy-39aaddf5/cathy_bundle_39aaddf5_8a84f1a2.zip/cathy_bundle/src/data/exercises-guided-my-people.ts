// Plug-and-play guided exercises for the "Finding My People" recovery mission.
// Tap Start, follow timed steps, nothing to type.
import type { Exercise } from "./exercises";

type G = Omit<Exercise, "type" | "content"> & {
  steps: [string, number][];
  closing: string;
};

const g = ({ steps, closing, ...rest }: G): Exercise => ({
  ...rest,
  type: "guided",
  content: { kind: "guided", steps: steps.map(([say, secs]) => ({ say, secs })), closing },
});

export const GUIDED_MY_PEOPLE: Exercise[] = [
  g({
    id: "picture-your-corner",
    title: "Picture Your Corner",
    subtitle: "See who's already showing up",
    minutes: 1, tags: ["support"],
    purpose: "Isolation convinces you nobody's there. This practice pictures the people already in your corner, even a small number.",
    steps: [
      ["Close your eyes or look down. Picture one person who has checked on you recently.", 12],
      ["See their face. Notice what it felt like when they reached out.", 12],
      ["Now picture one more person, even someone you haven't talked to in a while.", 12],
      ["Put both of them standing near you, like they're in your corner.", 10],
      ["Say out loud: \"I don't need many people. I need real ones.\"", 10],
    ],
    closing: "That's your corner. It's smaller than a crowd, and it's enough to start with.",
  }),
  {"id": "sample-three-rooms", "title": "Sample Three Rooms", "subtitle": "Try three meetings before you decide", "minutes": 1, "tags": ["support"], "type": "guided", "purpose": "Meetings are all different. One bad fit doesn't mean meetings aren't for you.", "content": {"kind": "guided", "steps": [{"say": "There are lots of kinds: AA, NA, SMART Recovery, Celebrate Recovery, online, Spanish, men's, women's.", "secs": 15}, {"say": "One meeting isn't all meetings.", "secs": 6}, {"say": "Picture the first room. Maybe it's too big.", "secs": 10}, {"say": "The second. Maybe the people feel closer to your age or story.", "secs": 10}, {"say": "The third. Maybe this one feels like it could be yours.", "secs": 10}, {"say": "Pick three to try in the next two weeks.", "secs": 10}, {"say": "Say: \"Try three before you decide.\"", "secs": 6}], "why": "Meetings are all different. One bad fit doesn't mean meetings aren't for you.", "closing": "Give each kind of meeting a fair shot. Your home group is out there.", "tagline": "Try three before you decide."}},
  g({
    id: "small-promise-practice",
    title: "Keep One Small Promise",
    subtitle: "Build trust with yourself first",
    minutes: 1, tags: ["support", "goal-setting"],
    purpose: "Trust in other people grows slowly. Trust in yourself can grow today, one small kept promise at a time.",
    steps: [
      ["Think of one small promise you could keep today — nothing big.", 12],
      ["Say it out loud: \"I will ___ today.\" Fill in something doable in the next hour.", 15],
      ["Picture yourself doing it, start to finish.", 12],
      ["Picture the moment it's done. Notice that feeling.", 10],
      ["Say: \"That's proof. I keep my word to myself.\"", 10],
    ],
    closing: "One small kept promise is real evidence. Trust is built exactly like that, over and over.",
  }),
  g({
    id: "picture-the-week",
    title: "Picture Your Recovery Week",
    subtitle: "See it before you schedule it",
    minutes: 2, tags: ["support", "goal-setting"],
    purpose: "A week is easier to plan once you've pictured it. Walk through the next seven days before writing anything down.",
    steps: [
      ["Picture Monday. See yourself going to one meeting or check-in.", 12],
      ["Picture the middle of the week. See yourself doing one healthy thing, like a walk or a call.", 12],
      ["Picture the weekend. See yourself connecting with one person in person.", 12],
      ["Notice: this week already has people in it, not just tasks.", 10],
      ["Say out loud: \"Recovery lives in my calendar.\"", 10],
    ],
    closing: "You just previewed a connected week. Writing it down now will feel easier.",
  }),
  {"id": "sunday-review", "title": "Sunday Night Review", "subtitle": "Look back, then look ahead", "minutes": 1, "tags": ["goal-setting"], "type": "guided", "purpose": "A few minutes each Sunday keeps your recovery on purpose instead of on autopilot.", "content": {"kind": "guided", "steps": [{"say": "It's Sunday night. Look back at the week.", "secs": 8}, {"say": "What went well? One thing.", "secs": 12}, {"say": "What was hard? One thing.", "secs": 12}, {"say": "What did you learn?", "secs": 10}, {"say": "Now look ahead. What matters most this week?", "secs": 12}, {"say": "Who will you lean on?", "secs": 10}, {"say": "Say: \"Look back, then look ahead.\"", "secs": 6}], "why": "A few minutes each Sunday keeps your recovery on purpose instead of on autopilot.", "closing": "Do this every Sunday. It only takes a few minutes, and it keeps your week on track.", "tagline": "Look back, then look ahead."}},
  g({
    id: "trust-radar",
    title: "Trust Radar Check",
    subtitle: "Notice who's shown up, not who might",
    minutes: 1, tags: ["support"],
    purpose: "Trust is easier to rebuild by looking at real evidence instead of guessing. This scans recent actions, not old fears.",
    steps: [
      ["Think of someone new in your life since you've been home.", 10],
      ["Ask yourself: has this person shown up when they said they would?", 12],
      ["Picture one specific time they followed through, even something small.", 12],
      ["Notice: that's real evidence, not a feeling.", 10],
      ["Say out loud: \"I trust actions, one proof at a time.\"", 10],
    ],
    closing: "Your radar just picked up real evidence. Trust can grow from proof like that.",
  }),
  g({
    id: "first-name-basis",
    title: "First Name Basis",
    subtitle: "Rehearse meeting your peer specialist",
    minutes: 1, tags: ["support"],
    purpose: "Reaching out to a peer specialist is easier once you've pictured the conversation. Walk through a first message before sending it.",
    steps: [
      ["Picture opening a message to your peer specialist.", 10],
      ["Say out loud what you'd type: \"Hi, I could use some support this week.\"", 15],
      ["Picture them writing back, glad you reached out.", 12],
      ["Picture your first conversation, and notice it doesn't have to be perfect.", 12],
      ["Say: \"They're trained for exactly this.\"", 10],
    ],
    closing: "You've rehearsed the message once. Sending the real one is the same words.",
  }),
  g({
    id: "boundary-with-love",
    title: "Say a Boundary Out Loud",
    subtitle: "Practice a kind, clear no",
    minutes: 1, tags: ["support", "communication"],
    purpose: "Boundaries with new or old relationships protect trust, not damage it. Practicing the words out loud makes them easier to say for real.",
    steps: [
      ["Picture someone asking something that isn't good for your recovery right now.", 10],
      ["Say out loud: \"I can't do that right now.\"", 12],
      ["Say it again, calmer this time, with a small breath first.", 12],
      ["Picture them accepting it, even if they're a little disappointed.", 12],
      ["Say: \"A boundary protects this relationship, not just me.\"", 10],
    ],
    closing: "You just said the hard sentence twice. It gets easier every time you practice it out loud.",
  }),
];
