// Plug-and-play guided exercises for the "Changing My Everyday Life" Recovery
// Journey mission. Tap Start, follow timed steps, nothing to type.
import type { Exercise } from "./exercises";

type G = Omit<Exercise, "type" | "content"> & {
  steps: [string, number][];
  closing: string;
};

const g = ({ steps, closing, ...rest }: G): Exercise => ({
  ...rest,
  type: "guided",
  content: { kind: "guided", steps: steps.map(([say, secs]) => ({ say, secs })), closing },
});

export const GUIDED_EVERYDAY_LIFE: Exercise[] = [
  g({
    id: "wind-down-rehearsal",
    title: "Wind-Down Rehearsal",
    subtitle: "Practice the hour before sleep",
    minutes: 2, tags: ["anxiety"],
    purpose: "Your body sleeps better when the hour before bed looks the same every night. Rehearse it now, lying down if you can.",
    steps: [
      ["Picture the clock showing 30 minutes before your bedtime.", 10],
      ["See yourself putting your phone somewhere out of reach.", 12],
      ["Picture the room getting darker — a lamp off, blinds closed.", 12],
      ["Feel your body settle into the bed, heavy and still.", 15],
      ["Take one slow breath out, longer than the breath in.", 12],
      ["Say quietly: \"My body knows what comes next.\"", 10],
    ],
    closing: "You just rehearsed the wind-down. Do the real version tonight in the same order.",
  }),
  g({
    id: "move-for-two-minutes",
    title: "Move for Two Minutes",
    subtitle: "Change your body chemistry on purpose",
    minutes: 2, tags: ["goal-setting"],
    purpose: "You don't need a workout to shift your mood — you need movement. This gets your body going right now.",
    steps: [
      ["Stand up wherever you are.", 8],
      ["Roll your shoulders back five times.", 12],
      ["March in place, lifting your knees, for 20 seconds.", 20],
      ["Reach both arms up high, then swing them down loose.", 12],
      ["Shake out your hands and legs like you're shaking off water.", 15],
      ["Notice anything different in your chest or your head.", 10],
    ],
    closing: "That's two minutes of real movement. Your mood chemistry just shifted a little.",
  }),
  g({
    id: "walk-my-whole-day",
    title: "Walk My Whole Day",
    subtitle: "See the plan before you live it",
    minutes: 2, tags: ["goal-setting", "relapse-prevention"],
    purpose: "A daily recovery plan sticks better once your mind has already walked through it. This is a full run-through, start to finish.",
    steps: [
      ["Picture waking up and doing your morning anchor.", 12],
      ["See yourself eating and moving your body sometime in the day.", 12],
      ["Picture one recovery tool or person you'll lean on today.", 12],
      ["See yourself handling one hard moment using something you already know.", 15],
      ["Picture closing the day the way you planned — same time, same steps.", 12],
      ["Say out loud: \"That's my day. I already know the shape of it.\"", 10],
    ],
    closing: "You just walked the whole day once in your mind. Living it will feel more familiar now.",
  }),
];
