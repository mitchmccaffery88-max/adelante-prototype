import { LIBRARY } from "./library";
import { RECOVERY_MODULES } from "./recovery";

export const RELATED_LESSON_PAIRS: readonly (readonly [string, string])[] = [
  ["daily-rhythm", "everyday-life-1"],
  ["grounding", "first-days-1"],
  ["big-feelings", "everyday-life-6"],
  ["one-bad-day", "first-days-5"],
  ["first-days-5", "when-hard-5"],
  ["housing", "life-that-works-1"],
  ["work", "life-that-works-2"],
  ["money-basics", "life-that-works-3"],
  ["transportation", "life-that-works-5"],
  ["healthcare-support", "life-that-works-6"],
  ["letting-go-shame", "relationships-9"],
  ["boundaries", "relationships-3"],
  ["rebuild-trust", "relationships-1"],
  ["my-strengths", "someone-new-1"],
  ["my-vision", "someone-new-9"],
  ["managing-worry", "worry-cycle"],
];

export const RELATED_LESSONS: Record<string, string[]> = {};
for (const [a, b] of RELATED_LESSON_PAIRS) {
  for (const [id, related] of [[a, b], [b, a]]) {
    const list = RELATED_LESSONS[id] ?? [];
    if (!list.includes(related)) list.push(related);
    RELATED_LESSONS[id] = list;
  }
}

export type RelatedLesson =
  | { id: string; title: string; kind: "library"; category: string; action: string }
  | { id: string; title: string; kind: "recovery"; moduleId: string; action: string };

/** Catalog lookup shared by Insight and Adel; never infer destinations from an id. */
export function resolveRelatedLesson(id: string): RelatedLesson | undefined {
  for (const category of LIBRARY) {
    const item = category.items.find((item) => item.id === id);
    if (item) return { id, title: item.title, kind: "library", category: category.id, action: `module:${item.title}` };
  }
  for (const mod of RECOVERY_MODULES) {
    const lesson = mod.lessons.find((lesson) => lesson.id === id);
    if (lesson) return { id, title: lesson.title, kind: "recovery", moduleId: mod.id, action: `lesson:${lesson.title}` };
  }
}

export function resolveRelatedLessons(ids: string[] = []): RelatedLesson[] {
  return [...new Set(ids)].flatMap((id) => {
    const lesson = resolveRelatedLesson(id);
    return lesson ? [lesson] : [];
  });
}