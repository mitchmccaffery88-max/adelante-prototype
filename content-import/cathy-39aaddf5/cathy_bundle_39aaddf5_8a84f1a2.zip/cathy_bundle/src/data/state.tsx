import type { LessonOutcome, LessonOutcomeRun, LessonFollowUp } from "@/lib/lesson-outcomes";
import { mergeShared, type SharedAnswers, type SharedKey } from "@/lib/shared-answers";
import { mergeStepRecord } from "@/lib/step-history";
import { normalizeSavedResourceIds, correctPrototypeMeds, correctPrototypeObligations } from "@/lib/resource-aliases";
import type { AgreedStep, StepRecord, StepExplanation, StepOutcome, WeeklyFocus, WeeklyLookBack } from "@/lib/forward-step-types";
import { useWelcome, resetWelcome, type WelcomeState } from "@/lib/welcome-store";
import { replaceDailyEntry } from "@/lib/daily-check-in";
import { checkDayPlan, type DayPlan } from "./reentry";
import { clearNavState } from "@/lib/nav-history";
import { syncRecoveryPlan } from "@/lib/plans";
import { clearCompletedLibraryProgress, type LibraryInProgress } from "@/lib/library-progress";
import { prependPathwayEvent, type PathwayEvent } from "@/lib/pathway";
import { LIBRARY } from "./library";
import { RECOVERY_MODULES } from "./recovery";
import { getExercise } from "./exercises";
import { createContext, useContext, useState, useEffect, type ReactNode } from "react";
import {
  SAVED_RESOURCE_IDS, MEDS, OBLIGATIONS, PEER_HISTORY, SETUP_TASKS,
  DEFAULT_SAFETY_PLAN, DEFAULT_CONSENT,
  type ChatMessage, type Emotion, type MedDose,
  type Obligation, type PeerMessage, type SafetyPlan, type ConsentMatrix, type ConsentTopic, type ConsentAudience,
} from "./mock";

export type AdelActionTag = string;
export type AdelSuggestion = { text: string; actions: AdelActionTag[]; fallback?: boolean; at: string };
export type CheckIn = { emotions: Emotion[]; reason?: string; date: string; adelSuggestion?: AdelSuggestion; source?: "daily" };
export type AdelTalkMessage = { role: "user" | "assistant"; text: string; crisis?: boolean; overdose?: boolean; delivered?: boolean };
export type AdelTalkRecord = {
  messages: AdelTalkMessage[];
  covered: number[];
  completed: boolean;
  summary?: string;
  updatedAt: string;
  /** Self-Help Step 1 "Which of these sound like you?" picks. */
  picks?: string[];
  /** Library-only, exact tool options suggested in the completed talk. */
  suggestions?: Record<string, string[]>;
  /** Library-only: the member's own words from the Welcome write-in. */
  ownWords?: string;
  /** Library-only: indexes of lesson ideas Adel has taught. */
  taught?: number[];
  completedExercises?: string[];
};
export type WeeklyMeasure = { date: string; phq2: number; gad2: number };
export type IfThenPlan = { type: "if-then"; lessonId: string; cue: string; move: string; backup: string; confidence: number; createdAt: string };
export type ToolkitItem = { id: string; label: string; content?: string; from: string; route?: string; plan?: IfThenPlan; retired?: boolean };
/** Follow-up log for a saved if-then plan. */
export type PlanLogEntry = { date: string; outcome: "used" | "came-up-used" | "came-up-didnt-use" | "didnt-come-up"; helped?: "a-lot" | "a-little" | "not-yet" };
export type SkillActivity = { date: string; kind: "exercise" | "save" | "reopen" | "launch" | "rating"; ref: string; answer?: string };
export type CravingLogEntry = { date: string; before: number; after?: number };
export type LapseEntry = { date: string; what: string; helped: string; nextStep: string };
export type HandoffEntry = {
  date: string;
  kind: "measures" | "craving" | "daily-checkin" | "reentry";
  outcome: "accepted" | "declined";
  to?: "peer" | "therapy" | "clinic" | "care-team";
};
export type TherapyBooking = { id: string; when: string; with: string; bookedAt: string };
export type RecoveryTool = {
  id: string;
  label: string;
  moduleId: string;
  moduleName: string;
  lessonTitle: string;
  content: string;
  ifThen?: string;
  createdAt: string;
  /** Present on newly saved tools so they can reopen their source lesson. */
  lessonId?: string;
};
export type RecoveryLessonProgress = {
  step: number;
  sub: number;
  updatedAt: number;
  version: 2;
  flowVersion?: 18 | 20;
};

export type LastTouched = {
  section: "library" | "recovery";
  /** route params needed to link straight back in */
  a: string;
  b: string;
  title: string;
  at: number;
};

export type ForwardStepDay = {
  done?: boolean; skipped?: string[]; shown?: string;
  started?: string; feedback?: "helped" | "a-little" | "not-really";
  preference?: { reason: string; shortest: boolean };
  step?: StepRecord;
};
export type ExerciseFeedback = { notForMe?: boolean; notReally?: number };

/* ------------------------------------------------------------------ */
/* Persistence                                                         */
/* Device-local cache so a reinstall-free reopen keeps the member's     */
/* work. Central (account-backed) sync is wired separately.             */
/* ------------------------------------------------------------------ */
const STORE_PREFIX = "adelante:";

const PERSIST_KEYS = [
  "lessonOutcomes", "lessonOutcomeHistory", "lessonFollowUpBlockedAt", "welcome", "checkInSkippedOn", "checkInSafetyAskedOn", "checkedInToday", "lastCheckIn", "checkInHistory", "savedResourceIds", "meds",
  "completedLibraryItems", "obligations", "completedSetupTasks", "safetyPlan", "consent",
  "lastWeeklyMeasure", "measureHistory", "toolkit", "sharedAnswers", "completedRecoveryLessons",
  "recoveryToolkit", "recoveryBadges", "sobrietyStart", "lastTouched", "reentryDone",
  "recoveryLessonProgress",
  "reentryNeeds", "reentryAnswers", "reentryPlan", "reentryRoutes", "reentrySaved",
  "skillActivity", "cravingLogs", "lapses", "handoffs", "therapyBookings", "peerChat", "chat",
  "dayPlan", "medHistory", "adelTalks", "planLogs", "planNumbers", "forwardStepDays", "helpedExercises",
  "adelGuideActivity", "exerciseFeedback", "lessonCompletedAt", "appointmentPrep",
  "stepHistory", "guideHistory", "adelAgreedStep", "weeklyFocus", "weeklyLookBack", "stepExplanation", "libraryInProgress", "pathwayEvents", "lastSeenStage", "lastReachedStage",
];

/** Local calendar-day key (YYYY-M-D) for per-day tracking. */
export function localDayKey(d = new Date()) {
  return `${d.getFullYear()}-${d.getMonth() + 1}-${d.getDate()}`;
}

function read<T>(key: string, fallback: T, session = false): T {
  if (typeof window === "undefined") return fallback;
  try {
    const raw = (session ? window.sessionStorage : window.localStorage).getItem(STORE_PREFIX + key);
    return raw === null ? fallback : (JSON.parse(raw) as T);
  } catch {
    return fallback;
  }
}

/** useState + device-local cache under one key. */
function usePersistent<T>(key: string, initial: T, session = false, normalize?: (value: T) => T) {
  const [value, setValue] = useState<T>(initial);
  const [hydrated, setHydrated] = useState(false);

  // Hydrate after mount so SSR and the first client render match.
  useEffect(() => {
    const stored = read(key, initial, session);
    setValue(normalize ? normalize(stored) : stored);
    setHydrated(true);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (!hydrated || typeof window === "undefined") return;
    try {
      (session ? window.sessionStorage : window.localStorage).setItem(STORE_PREFIX + key, JSON.stringify(value));
    } catch {
      /* quota / private mode — in-memory state still works */
    }
  }, [key, value, hydrated]);

  return [value, setValue, hydrated] as const;
}

type State = {
  lessonOutcomes: Record<string, LessonOutcome>;
  lessonOutcomeHistory: LessonOutcomeRun[];
  lessonFollowUpBlockedAt: string;
  blockLessonFollowUp: () => void;
  saveLessonOutcome: (id: string, outcome: LessonOutcome) => void;
  saveLessonFollowUp: (id: string, followUp: LessonFollowUp) => void;
  moveLastLessonBack: () => boolean;
  stepHistory: StepRecord[];
  guideHistory: { date: string; text: string }[];
  adelAgreedStep: AgreedStep | null;
  agreeAdelStep: (step: AgreedStep) => void;
  recordStep: (step: StepRecord) => void;
  finishStep: (key: string, outcome: StepOutcome) => void;
  weeklyFocus: WeeklyFocus | null;
  chooseWeeklyFocus: (tag: WeeklyFocus["tag"], label: string) => void;
  weeklyLookBack: WeeklyLookBack;
  setWeeklyLookBack: (v: WeeklyLookBack) => void;
  stepExplanation: StepExplanation | null;
  setStepExplanation: (v: StepExplanation | null) => void;
  welcomeProgress: WelcomeState;
  checkInSkippedOn: string;
  skipCheckIn: () => void;
  /** Testing helper: clears today's daily check-in and today's skip. */
  clearTodaysCheckIn: () => void;
  checkInSafetyAskedOn: string;
  markCheckInSafetyAsked: () => void;
  checkInReady: boolean;
  pathwayEvents: PathwayEvent[];
  lastSeenStage: number;
  lastReachedStage: number;
  setLastReachedStage: (stage: number) => void;
  pathwayReady: boolean;
  setLastSeenStage: (stage: number) => void;
  recordPathwayEvent: (event: Omit<PathwayEvent, "at">) => void;
  libraryInProgress: LibraryInProgress | null;
  libraryProgressReady: boolean;
  setLibraryInProgress: (progress: LibraryInProgress | null) => void;
  dayPlan: DayPlan | null;
  setDayPlan: (plan: DayPlan | null) => void;
  checkDayAction: (id: string, value: "done" | "failed" | null) => void;
  checkedInToday: boolean;
  lastCheckIn?: CheckIn;
  checkInHistory: CheckIn[];
  savedResourceIds: string[];
  chat: ChatMessage[];
  meds: MedDose[];
  /** Local date keys (YYYY-M-D) each medication was marked taken. */
  medHistory: Record<string, string[]>;
  completedLibraryItems: string[];
  obligations: Obligation[];
  completedSetupTasks: string[];
  peerChat: PeerMessage[];
  safetyPlan: SafetyPlan;
  consent: ConsentMatrix;
  lastWeeklyMeasure?: WeeklyMeasure;
  measureHistory: WeeklyMeasure[];
  toolkit: ToolkitItem[];
  /** Per-member answers shared between lesson tools (Batch 21). */
  sharedAnswers: SharedAnswers;
  saveSharedAnswers: (key: SharedKey, values: string[]) => void;
  completedRecoveryLessons: string[];
  recoveryToolkit: RecoveryTool[];
  recoveryBadges: string[];
  recoveryLessonProgress: Record<string, RecoveryLessonProgress>;
  /** ISO date (yyyy-mm-dd) the member set as their sobriety start. */
  sobrietyStart?: string;
  setSobrietyStart: (date: string | undefined) => void;
  /* --- Safety signals (private to the member) --- */
  /** Skills the member actually used (not just viewed). */
  skillActivity: SkillActivity[];
  logSkill: (kind: SkillActivity["kind"], ref: string, answer?: string) => void;
  cravingLogs: CravingLogEntry[];
  logCraving: (before: number, after?: number) => void;
  lapses: LapseEntry[];
  logLapse: (l: Omit<LapseEntry, "date">) => void;
  handoffs: HandoffEntry[];
  recordHandoff: (h: Omit<HandoffEntry, "date">) => void;
  therapyBookings: TherapyBooking[];
  bookTherapy: (b: Omit<TherapyBooking, "bookedAt">) => void;
  /** Wipes every trace of this member's data from the device. */
  deleteAllMyData: () => void;
  /* --- PRE-MODULE: I Just Got Out (same-day stabilization) --- */
  reentryDone: string[];
  reentryNeeds: string[];
  /** yes/no + branch answers keyed by lesson id. */
  reentryAnswers: Record<string, string>;
  /** Picks for the 24-hour plan guided tool. */
  reentryPlan: Record<string, string[]>;
  /** Resources / screens this member was routed to during the flow. */
  reentryRoutes: string[];
  reentrySaved: boolean;
  completeReentryLesson: (id: string) => void;
  setReentryNeeds: (needs: string[]) => void;
  answerReentry: (lessonId: string, answer: string) => void;
  setReentryPlan: (stepId: string, value: string, maxPicks: number) => void;
  noteReentryRoute: (label: string) => void;
  saveReentryToolkit: () => void;
  /** Most recent lesson the member opened, across sections. */
  lastTouched?: LastTouched;
  touchLesson: (t: LastTouched) => void;
  completeRecoveryLesson: (lessonId: string, badge?: string) => void;
  saveRecoveryTool: (t: RecoveryTool) => void;
  removeRecoveryTool: (id: string) => void;
  saveRecoveryLessonProgress: (lessonId: string, progress: RecoveryLessonProgress) => void;
  toggleSaved: (id: string) => void;
  addToToolkit: (t: ToolkitItem) => void;
  removeToolkitItem: (id: string) => void;
  /** Move a plan to the collapsed Retired list (or restore it). */
  retireToolkitItem: (id: string, retired: boolean) => void;
  /** Replace a toolkit item in place (same id). */
  updateToolkitItem: (t: ToolkitItem) => void;
  /** Per-plan follow-up log, keyed by toolkit item id. */
  planLogs: Record<string, PlanLogEntry[]>;
  logPlanUse: (planId: string, entry: Omit<PlanLogEntry, "date">) => void;
  /** Phone numbers the member saved for plan backups, keyed by backup text. Device-private. */
  planNumbers: Record<string, string>;
  savePlanNumber: (backupText: string, phone: string) => void;
  /** Today's Forward Step per-day state, keyed by local day (YYYY-M-D). `shown` = the exercise shown, so it isn't repeated tomorrow. */
  forwardStepDays: Record<string, ForwardStepDay>;
  setForwardStepDay: (day: string, v: ForwardStepDay) => void;
  adelGuideActivity: { date: string; words: string[] } | null;
  recordAdelGuideMessage: (text: string) => void;
  exerciseFeedback: Record<string, ExerciseFeedback>;
  setExerciseFeedback: (id: string, feedback: ExerciseFeedback) => void;
  lessonCompletedAt: Record<string, string>;
  appointmentPrep: Record<string, string>;
  saveAppointmentPrep: (id: string, summary: string) => void;
  /** Exercises the member said helped ("I tried it and it helped"), most recent first. */
  helpedExercises: string[];
  markExerciseHelped: (exerciseId: string) => void;
  completeCheckIn: (c: CheckIn) => void;
  /** Attach Adel's suggestion to the most recent check-in record. */
  saveCheckInSuggestion: (s: AdelSuggestion) => void;
  /** Private Talk It Through conversations, keyed by submodule id. */
  adelTalks: Record<string, AdelTalkRecord>;
  saveAdelTalk: (key: string, rec: AdelTalkRecord) => void;
  clearAdelTalk: (key: string) => void;
  sendMessage: (text: string) => void;
  sendPeerMessage: (text: string) => void;
  toggleMed: (id: string) => void;
  markLibraryComplete: (id: string) => void;
  completeObligation: (id: string) => void;
  toggleSetupTask: (id: string) => void;
  updateSafetyPlan: (patch: Partial<SafetyPlan>) => void;
  setConsent: (topic: ConsentTopic, audience: ConsentAudience, value: boolean) => void;
  saveWeeklyMeasure: (m: WeeklyMeasure) => void;
};

const StateCtx = createContext<State | null>(null);

export function StateProvider({ children }: { children: ReactNode }) {
  const [lessonOutcomes, setLessonOutcomes] = usePersistent<Record<string, LessonOutcome>>("lessonOutcomes", {});
  const [lessonOutcomeHistory, setLessonOutcomeHistory] = usePersistent<LessonOutcomeRun[]>("lessonOutcomeHistory", []);
  const [lessonFollowUpBlockedAt, setLessonFollowUpBlockedAt] = usePersistent("lessonFollowUpBlockedAt", "");
  const welcomeProgress = useWelcome();
  const [checkInSkippedOn, setCheckInSkippedOn] = usePersistent("checkInSkippedOn", "");
  const [checkInSafetyAskedOn, setCheckInSafetyAskedOn] = usePersistent("checkInSafetyAskedOn", "");
  const [pathwayEvents, setPathwayEvents, pathwayReady] = usePersistent<PathwayEvent[]>("pathwayEvents", []);
  const [lastSeenStage, setLastSeenStage] = usePersistent("lastSeenStage", 0);
  const [lastReachedStage, setLastReachedStage] = usePersistent("lastReachedStage", 0);
  const recordPathwayEvent = (event: Omit<PathwayEvent, "at">) => setPathwayEvents((cur) => prependPathwayEvent(cur, { ...event, at: Date.now() }));
  const [libraryInProgress, setLibraryInProgress, libraryProgressReady] = usePersistent<LibraryInProgress | null>("libraryInProgress", null);
  const [checkedInToday, setChecked] = usePersistent("checkedInToday", false);
  const [lastCheckIn, setLast] = usePersistent<CheckIn | undefined>("lastCheckIn", {
    emotions: ["stressed", "hopeful"],
    reason: "I'm around old triggers",
    date: new Date(Date.now() - 864e5).toISOString(),
  });
  const [checkInHistory, setCheckInHistory, checkInReady] = usePersistent<CheckIn[]>("checkInHistory", []);
  const [savedResourceIds, setSaved] = usePersistent<string[]>("savedResourceIds", SAVED_RESOURCE_IDS, false, normalizeSavedResourceIds);
  const [chat, setChat] = usePersistent<ChatMessage[]>("chat", []);
  const [meds, setMeds] = usePersistent<MedDose[]>("meds", MEDS, false, correctPrototypeMeds);
  const [medHistory, setMedHistory] = usePersistent<Record<string, string[]>>("medHistory", {});
  const [completedLibraryItems, setCompleted] = usePersistent<string[]>("completedLibraryItems", ["box-breath", "gratitude-3", "sleep-anchor"]);
  const [obligations, setObligations] = usePersistent<Obligation[]>("obligations", OBLIGATIONS, false, correctPrototypeObligations);
  const [completedSetupTasks, setSetup] = usePersistent<string[]>("completedSetupTasks", ["s-ben-food", "s-conn-2"]);
  const [peerChat, setPeerChat] = usePersistent<PeerMessage[]>("peerChat", PEER_HISTORY);
  const [safetyPlan, setSafetyPlan] = usePersistent<SafetyPlan>("safetyPlan", DEFAULT_SAFETY_PLAN);
  const [consent, setConsentState] = usePersistent<ConsentMatrix>("consent", DEFAULT_CONSENT);
  const [lastWeeklyMeasure, setLastMeasure] = usePersistent<WeeklyMeasure | undefined>("lastWeeklyMeasure", undefined);
  const [measureHistory, setMeasureHistory] = usePersistent<WeeklyMeasure[]>("measureHistory", []);
  const [dayPlan, setDayPlan] = usePersistent<DayPlan | null>("dayPlan", null);
  const [toolkit, setToolkit] = usePersistent<ToolkitItem[]>("toolkit", []);
  const [sharedAnswers, setSharedAnswers] = usePersistent<SharedAnswers>("sharedAnswers", {});
  const [completedRecoveryLessons, setRecoveryDone] = usePersistent<string[]>("completedRecoveryLessons", []);
  const [recoveryToolkit, setRecoveryToolkit] = usePersistent<RecoveryTool[]>("recoveryToolkit", []);
  const [recoveryBadges, setRecoveryBadges] = usePersistent<string[]>("recoveryBadges", []);
  const [recoveryLessonProgress, setRecoveryLessonProgress] = usePersistent<Record<string, RecoveryLessonProgress>>("recoveryLessonProgress", {});
  const [sobrietyStart, setSobrietyStart] = usePersistent<string | undefined>("sobrietyStart", undefined);
  const [lastTouched, setLastTouched] = usePersistent<LastTouched | undefined>("lastTouched", undefined);
  const [reentryDone, setReentryDone] = usePersistent<string[]>("reentryDone", [], true);
  const [reentryNeeds, setNeeds] = usePersistent<string[]>("reentryNeeds", []);
  const [reentryAnswers, setAnswers] = usePersistent<Record<string, string>>("reentryAnswers", {});
  const [reentryPlan, setPlan] = usePersistent<Record<string, string[]>>("reentryPlan", {});
  const [reentryRoutes, setRoutes] = usePersistent<string[]>("reentryRoutes", []);
  const [reentrySaved, setReentrySaved] = usePersistent("reentrySaved", false);
  const [skillActivity, setSkillActivity] = usePersistent<SkillActivity[]>("skillActivity", []);
  const [cravingLogs, setCravingLogs] = usePersistent<CravingLogEntry[]>("cravingLogs", []);
  const [lapses, setLapses] = usePersistent<LapseEntry[]>("lapses", []);
  const [handoffs, setHandoffs] = usePersistent<HandoffEntry[]>("handoffs", []);
  const [therapyBookings, setTherapyBookings] = usePersistent<TherapyBooking[]>("therapyBookings", []);
  const [adelTalks, setAdelTalks] = usePersistent<Record<string, AdelTalkRecord>>("adelTalks", {});
  const [planLogs, setPlanLogs] = usePersistent<Record<string, PlanLogEntry[]>>("planLogs", {});
  const [planNumbers, setPlanNumbers] = usePersistent<Record<string, string>>("planNumbers", {});
  const [forwardStepDays, setForwardStepDays] = usePersistent<Record<string, ForwardStepDay>>("forwardStepDays", {});
  const [helpedExercises, setHelpedExercises] = usePersistent<string[]>("helpedExercises", []);
  const [adelGuideActivity, setAdelGuideActivity] = usePersistent<{ date: string; words: string[] } | null>("adelGuideActivity", null);
  const [exerciseFeedback, setFeedback] = usePersistent<Record<string, ExerciseFeedback>>("exerciseFeedback", {});
  const [lessonCompletedAt, setLessonCompletedAt] = usePersistent<Record<string, string>>("lessonCompletedAt", {});
  const [appointmentPrep, setAppointmentPrep] = usePersistent<Record<string, string>>("appointmentPrep", {});

  const [stepHistory, setStepHistory] = usePersistent<StepRecord[]>("stepHistory", []);
  const [guideHistory, setGuideHistory] = usePersistent<{ date: string; text: string }[]>("guideHistory", []);
  const [adelAgreedStep, setAdelAgreedStep] = usePersistent<AgreedStep | null>("adelAgreedStep", null);
  const [weeklyFocus, setWeeklyFocus] = usePersistent<WeeklyFocus | null>("weeklyFocus", null);
  const [weeklyLookBack, setWeeklyLookBack] = usePersistent<WeeklyLookBack>("weeklyLookBack", {});
  const [stepExplanation, setStepExplanation] = usePersistent<StepExplanation | null>("stepExplanation", null);
  const recordStep = (step: StepRecord) => setStepHistory((h) => mergeStepRecord(h, step));
  const finishStep = (key: string, outcome: StepOutcome) => {
    const day = localDayKey();
    const current = forwardStepDays[day];
    const agreed = adelAgreedStep && localDayKey(new Date(adelAgreedStep.at)) === day && adelAgreedStep.actionTag.toLowerCase().replace(/^exercise:\s*/, "") === key.toLowerCase();
    if (current?.step?.key !== key && current?.started !== key && !agreed) return;
    const rec = current?.step?.key === key ? current.step : { key, title: agreed ? adelAgreedStep?.label ?? key : key, date: new Date().toISOString() };
    recordStep({ ...rec, outcome });
    setStepHistory((h) => h.map((s) => s.key === key && localDayKey(new Date(s.date)) === day ? { ...s, outcome } : s));
    setForwardStepDays((days) => ({ ...days, [day]: { ...days[day], done: true, started: key, step: { ...rec, outcome }, feedback: outcome === "hard" ? "not-really" : outcome } }));
    if ((outcome === "helped" || outcome === "a-little") && getExercise(key)) setHelpedExercises((h) => [key, ...h.filter((id) => id !== key)].slice(0, 20));
    if (outcome === "hard" || outcome === "not-really") setFeedback((f) => ({ ...f, [key]: { ...f[key], notReally: (f[key]?.notReally ?? 0) + 1 } }));
  };

  const value: State = {
    sharedAnswers,
    saveSharedAnswers: (key, values) => setSharedAnswers((all) => ({ ...all, [key]: mergeShared(all[key] ?? [], values) })),
    lessonOutcomes, lessonOutcomeHistory, lessonFollowUpBlockedAt,
    blockLessonFollowUp: () => setLessonFollowUpBlockedAt(new Date().toISOString()),
    saveLessonOutcome: (id, outcome) => {
      setLessonOutcomes((h) => ({ ...h, [id]: outcome }));
      setLessonOutcomeHistory((h) => [...h, { ...outcome, lessonId: id }]);
    },
    saveLessonFollowUp: (id, followUp) => {
      const current = lessonOutcomes[id];
      if (!current) return;
      const next = { ...followUp, retry: !!current.followUp };
      setLessonOutcomes((h) => ({ ...h, [id]: { ...current, followUp: next } }));
      setLessonOutcomeHistory((h) => h.map((r) => r.lessonId === id && r.finishedAt === current.finishedAt ? { ...r, followUp: next } : r));
      if (current.planId && followUp.cameUp !== "not-yet") {
        setPlanLogs((h) => ({ ...h, [current.planId ?? ""]: [...(h[current.planId ?? ""] ?? []), {
          date: followUp.at, outcome: followUp.cameUp === "used" ? "came-up-used" as const : "came-up-didnt-use" as const,
          helped: followUp.helped === "yes" ? "a-lot" as const : followUp.helped === "a-little" ? "a-little" as const : followUp.helped === "not-really" ? "not-yet" as const : undefined,
        }].slice(-60) }));
        if (followUp.helped) for (const tag of current.tags) recordStep({
          key: `lesson-follow-up:${id}:${tag}`, title: current.title, date: followUp.at, lessonId: id, tag, rung: "PRACTICE",
          outcome: followUp.helped === "yes" ? "helped" : followUp.helped === "a-little" ? "a-little" : "not-really",
        });
      }
    },
    moveLastLessonBack: () => {
      const last = Object.entries(lessonOutcomes).sort((a, b) => Date.parse(b[1].finishedAt) - Date.parse(a[1].finishedAt))[0];
      if (!last) return false;
      const [id, outcome] = last;
      const date = new Date(); date.setDate(date.getDate() - 3);
      const moved = { ...outcome, finishedAt: date.toISOString(), followUp: undefined };
      setLessonOutcomes((h) => ({ ...h, [id]: moved }));
      setLessonOutcomeHistory((h) => h.map((r) => r.lessonId === id && r.finishedAt === outcome.finishedAt ? { ...moved, lessonId: id } : r));
      return true;
    },
    stepHistory, guideHistory, adelAgreedStep, recordStep, finishStep, weeklyFocus, weeklyLookBack, setWeeklyLookBack, stepExplanation, setStepExplanation,
    agreeAdelStep: (step) => { setAdelAgreedStep(step); setForwardStepDays((h) => ({ ...h, [localDayKey()]: { ...h[localDayKey()], done: false, started: step.actionTag.toLowerCase().replace(/^exercise:\s*/, "") } })); },
    chooseWeeklyFocus: (tag, label) => { setWeeklyFocus({ tag, setAt: new Date().toISOString() }); setWeeklyLookBack({ completedAt: new Date().toISOString() }); recordPathwayEvent({ type: "focus", label: `Picked a focus: ${label}` }); },
    welcomeProgress, checkInSkippedOn, skipCheckIn: () => setCheckInSkippedOn(localDayKey()),
    clearTodaysCheckIn: () => {
      setCheckInHistory((h) => h.filter((c) => !(c.source === "daily" && localDayKey(new Date(c.date)) === localDayKey())));
      setCheckInSkippedOn("");
      setLessonFollowUpBlockedAt("");
      setChecked(false);
    },
    checkInSafetyAskedOn, markCheckInSafetyAsked: () => setCheckInSafetyAskedOn(localDayKey()), checkInReady,
    pathwayEvents, lastSeenStage, lastReachedStage, setLastReachedStage, pathwayReady, setLastSeenStage, recordPathwayEvent,
    libraryInProgress, setLibraryInProgress, libraryProgressReady,
    dayPlan, setDayPlan,
    checkDayAction: (id, value) => setDayPlan((cur) => cur ? checkDayPlan(cur, id, value) : cur),
    checkedInToday, lastCheckIn, checkInHistory, savedResourceIds, chat, meds, completedLibraryItems,
    obligations, completedSetupTasks, peerChat, safetyPlan, consent, lastWeeklyMeasure, measureHistory, toolkit,
    completedRecoveryLessons, recoveryToolkit, recoveryBadges, recoveryLessonProgress, sobrietyStart, lastTouched,
    reentryDone, reentryNeeds, reentryAnswers, reentryPlan, reentryRoutes, reentrySaved,
    cravingLogs, lapses, handoffs, therapyBookings, skillActivity, medHistory, adelTalks,
    planLogs, planNumbers, forwardStepDays, helpedExercises,
    adelGuideActivity, exerciseFeedback, lessonCompletedAt, appointmentPrep,
    recordAdelGuideMessage: (text) => {
      setGuideHistory((h) => [...h, { date: new Date().toISOString(), text }].slice(-300));
      setAdelGuideActivity((cur) => ({
      date: new Date().toISOString(),
      words: [...(cur && localDayKey(new Date(cur.date)) === localDayKey() ? cur.words : []), text].slice(-20),
    })); },
    setExerciseFeedback: (id, feedback) => setFeedback((cur) => ({ ...cur, [id]: { ...cur[id], ...feedback } })),
    saveAppointmentPrep: (id, summary) => setAppointmentPrep((cur) => ({ ...cur, [id]: summary })),
    setForwardStepDay: (day, v) => setForwardStepDays((cur) => ({ ...cur, [day]: v })),
    markExerciseHelped: (exerciseId) => {
      setHelpedExercises((cur) => [exerciseId, ...cur.filter((x) => x !== exerciseId)].slice(0, 20));
      const exercise = getExercise(exerciseId);
      if (exercise) recordPathwayEvent({ type: "exercise", label: `Found a tool that helps: ${exercise.title}.` });
    },
    logPlanUse: (planId, entry) =>
      setPlanLogs((cur) => ({ ...cur, [planId]: [...(cur[planId] ?? []), { ...entry, date: new Date().toISOString() }].slice(-60) })),
    savePlanNumber: (backupText, phone) => setPlanNumbers((cur) => ({ ...cur, [backupText]: phone })),
    saveAdelTalk: (key, rec) => setAdelTalks((cur) => ({ ...cur, [key]: { ...cur[key], ...rec } })),
    clearAdelTalk: (key) => setAdelTalks((cur) => {
      const next = { ...cur };
      delete next[key];
      return next;
    }),
    saveCheckInSuggestion: (sg) => {
      setLast((c) => (c ? { ...c, adelSuggestion: sg } : c));
      setCheckInHistory((h) => h.length ? [...h.slice(0, -1), { ...h[h.length - 1], adelSuggestion: sg }] : h);
    },
    logSkill: (kind, ref, answer) =>
      setSkillActivity((cur) => [...cur, { date: new Date().toISOString(), kind, ref, ...(answer ? { answer } : {}) }].slice(-200)),
    logCraving: (before, after) =>
      setCravingLogs((l) => [...l, { date: new Date().toISOString(), before, after }]),
    logLapse: (l) => setLapses((cur) => [...cur, { ...l, date: new Date().toISOString() }]),
    recordHandoff: (h) => setHandoffs((cur) => [...cur, { ...h, date: new Date().toISOString() }]),
    bookTherapy: (b) => setTherapyBookings((cur) => [...cur, { ...b, bookedAt: new Date().toISOString() }]),
    deleteAllMyData: () => {
      setLessonOutcomes({}); setLessonOutcomeHistory([]); setLessonFollowUpBlockedAt("");
      clearNavState();
      resetWelcome();
      setCheckInSkippedOn(""); setCheckInSafetyAskedOn("");
      if (typeof window !== "undefined") {
        for (const k of PERSIST_KEYS) window.localStorage.removeItem(STORE_PREFIX + k);
      }
      setChecked(false); setLast(undefined); setCheckInHistory([]); setSaved([]); setChat([]);
      setMeds(MEDS.map((m) => ({ ...m, takenToday: false }))); setCompleted([]);
      setLibraryInProgress(null);
      setPathwayEvents([]); setLastSeenStage(0); setLastReachedStage(0);
      setObligations(OBLIGATIONS); setSetup([]); setPeerChat([]);
      setSafetyPlan(DEFAULT_SAFETY_PLAN); setConsentState(DEFAULT_CONSENT);
      setLastMeasure(undefined); setMeasureHistory([]); setToolkit([]);
      setRecoveryDone([]); setRecoveryToolkit([]); setRecoveryBadges([]); setRecoveryLessonProgress({});
      setSobrietyStart(undefined); setLastTouched(undefined);
      setReentryDone([]); setNeeds([]); setAnswers({}); setPlan({}); setRoutes([]); setReentrySaved(false);
      setSkillActivity([]); setCravingLogs([]); setLapses([]); setHandoffs([]); setTherapyBookings([]);
      setMedHistory({}); setAdelTalks({}); setPlanLogs({}); setPlanNumbers({}); setForwardStepDays({});
      setHelpedExercises([]); setDayPlan(null);
      setStepHistory([]); setGuideHistory([]); setAdelAgreedStep(null); setWeeklyFocus(null); setWeeklyLookBack({}); setStepExplanation(null);
      setAdelGuideActivity(null); setFeedback({}); setLessonCompletedAt({}); setAppointmentPrep({});
    },
    completeReentryLesson: (id) => setReentryDone((c) => (c.includes(id) ? c : [...c, id])),
    setReentryNeeds: (needs) => setNeeds(needs),
    answerReentry: (lessonId, answer) => setAnswers((a) => ({ ...a, [lessonId]: answer })),
    setReentryPlan: (stepId, value, maxPicks) =>
      setPlan((cur) => {
        const list = cur[stepId] ?? [];
        if (list.includes(value)) return { ...cur, [stepId]: list.filter((v) => v !== value) };
        if (maxPicks === 1) return { ...cur, [stepId]: [value] };
        if (list.length >= maxPicks) return { ...cur, [stepId]: [...list.slice(1), value] };
        return { ...cur, [stepId]: [...list, value] };
      }),
    noteReentryRoute: (label) => setRoutes((r) => (r.includes(label) ? r : [...r, label])),
    saveReentryToolkit: () => setReentrySaved(true),
    setSobrietyStart,
    touchLesson: (t) => setLastTouched(t),
    completeRecoveryLesson: (lessonId, badge) => {
      if (!completedRecoveryLessons.includes(lessonId)) {
        const lesson = RECOVERY_MODULES.flatMap((m) => m.lessons).find((l) => l.id === lessonId);
        if (lesson) recordPathwayEvent({ type: "lesson", label: `Finished '${lesson.title}'.` });
      }
      setRecoveryDone((c) => (c.includes(lessonId) ? c : [...c, lessonId]));
      setRecoveryLessonProgress((cur) => { const next = { ...cur }; delete next[lessonId]; return next; });
      setLessonCompletedAt((cur) => cur[lessonId] ? cur : { ...cur, [lessonId]: new Date().toISOString() });
      if (badge) setRecoveryBadges((b) => (b.includes(badge) ? b : [...b, badge]));
    },
    saveRecoveryTool: (t) =>
      setRecoveryToolkit((cur) => (cur.some((x) => x.id === t.id) ? cur.map((x) => (x.id === t.id ? t : x)) : [...cur, t])),
    removeRecoveryTool: (id) => setRecoveryToolkit((cur) => cur.filter((x) => x.id !== id)),
    saveRecoveryLessonProgress: (lessonId, progress) =>
      setRecoveryLessonProgress((cur) => ({ ...cur, [lessonId]: progress })),
    addToToolkit: (t) => {
      if (t.plan?.type === "if-then" && !toolkit.some((x) => x.id === t.id)) recordPathwayEvent({ type: "plan", label: "Made a plan." });
      setToolkit((cur) => cur.some((x) => x.id === t.id) ? cur : [...cur, t]);
    },
    removeToolkitItem: (id) => setToolkit((cur) => cur.filter((x) => x.id !== id)),
    retireToolkitItem: (id, retired) => setToolkit((cur) => cur.map((x) => (x.id === id ? { ...x, retired } : x))),
    updateToolkitItem: (t) => {
      setToolkit((cur) => cur.map((x) => (x.id === t.id ? t : x)));
      setRecoveryToolkit((cur) => syncRecoveryPlan(cur, t));
    },
    toggleSaved: (id) => setSaved((s) => s.includes(id) ? s.filter((x) => x !== id) : [...s, id]),
    completeCheckIn: (c) => {
      setChecked(true);
      setLast(c);
      setCheckInHistory((h) => replaceDailyEntry(h, c));
    },
    sendMessage: (text) => {
      const now = "Now";
      const mine: ChatMessage = { id: `u-${Date.now()}`, from: "member", text, time: now };
      const reply: ChatMessage = {
        id: `a-${Date.now() + 1}`, from: "adel", time: now,
        text: "Thanks for telling me. I'm here. Want to try one small thing — a quick breathing exercise or just keep talking?",
      };
      setChat((c) => [...c, mine, reply]);
    },
    sendPeerMessage: (text) => {
      const now = "Now";
      const mine: PeerMessage = { id: `pu-${Date.now()}`, from: "member", text, time: now };
      const reply: PeerMessage = {
        id: `pp-${Date.now() + 1}`, from: "peer", time: now,
        text: "Copy that. I hear you. Give me a bit and I'll come back with something real, not a script." };
      setPeerChat((c) => [...c, mine, reply]);
    },
    toggleMed: (id) => {
      setMeds((m) => m.map((d) => {
        if (d.id !== id) return d;
        const nowTaken = !d.takenToday;
        const key = localDayKey();
        setMedHistory((h) => {
          const days = new Set(h[id] ?? []);
          if (nowTaken) days.add(key); else days.delete(key);
          return { ...h, [id]: [...days].slice(-60) };
        });
        return { ...d, takenToday: nowTaken };
      }));
    },
    markLibraryComplete: (id) => {
      if (!completedLibraryItems.includes(id)) {
        const item = LIBRARY.flatMap((c) => c.items).find((i) => i.id === id);
        if (item) recordPathwayEvent({ type: "lesson", label: `Finished '${item.title}'.` });
      }
      setLibraryInProgress((current) => clearCompletedLibraryProgress(current, id));
      setCompleted((c) => c.includes(id) ? c : [...c, id]);
      setLessonCompletedAt((cur) => cur[id] ? cur : { ...cur, [id]: new Date().toISOString() });
    },
    completeObligation: (id) => setObligations((os) => os.map((o) => o.id === id ? { ...o, completed: !o.completed } : o)),
    toggleSetupTask: (id) => {
      if (!completedSetupTasks.includes(id)) {
        const task = SETUP_TASKS.find((t) => t.id === id);
        if (task) recordPathwayEvent({ type: "setup", label: `Checked off: ${task.title}.` });
      }
      setSetup((s) => s.includes(id) ? s.filter((x) => x !== id) : [...s, id]);
    },
    updateSafetyPlan: (patch) => setSafetyPlan((p) => ({ ...p, ...patch })),
    setConsent: (topic, audience, val) =>
      setConsentState((c) => ({ ...c, [topic]: { ...c[topic], [audience]: val } })),
    saveWeeklyMeasure: (m) => {
      setLastMeasure(m);
      setMeasureHistory((h) => [...h, m].slice(-26));
    },
  };

  return <StateCtx.Provider value={value}>{children}</StateCtx.Provider>;
}

export function useAppState() {
  const ctx = useContext(StateCtx);
  if (!ctx) throw new Error("StateProvider missing");
  return ctx;
}
