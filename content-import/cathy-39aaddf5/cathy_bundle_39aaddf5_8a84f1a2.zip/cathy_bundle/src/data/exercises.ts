// Shared, reusable Exercise Library.
//
// Exercises are standalone: they can be launched from Step 4 Part A of any
// submodule (self-help library OR Recovery Journey), or directly from Adel in
// open conversation (ACTION: exercise:<id>) — same component, same toolkit save.

export type ExerciseTag =
  | "craving"
  | "emotions"
  | "triggers"
  | "anger"
  | "cbt"
  | "anxiety"
  | "support"
  | "goal-setting"
  | "communication"
  | "relapse-prevention"
  | "money";

export type ExerciseType =
  | "timer"
  | "breathing"
  | "checklist"
  | "worksheet"
  | "mapper"
  | "calculator"
  | "scale"
  | "guided";

export type TimerContent = {
  seconds: number;
  prompts: string[];          // rotated across the countdown
  closing: string;
};

export type BreathingContent = {
  rounds?: number;
  inhale: number; hold: number; exhale: number; holdOut: number;
  instruction: string;
};

export type ChecklistContent = {
  prompt: string;
  items: string[];
  closing: string;
};

export type WorksheetField = {
  id: string;
  label: string;
  placeholder: string;
  long?: boolean;
  options?: string[];         // optional quick-pick chips
};

export type WorksheetContent = { prompt: string; fields: WorksheetField[] };

export type MapperZone = { id: string; label: string; hint: string; suggestions: string[] };
export type MapperContent = { prompt: string; zones: MapperZone[] };

export type CalculatorContent = {
  prompt: string;
  incomeRows: string[];
  expenseRows: string[];
  closing: string;
};

export type ScaleContent = {
  prompt: string;
  left: string;
  right: string;
  levels: { upTo: number; name: string; plan: string[] }[];
};

export type GuidedContent = {
  steps: { say: string; secs: number }[];
  closing: string;
  /** One line under the title. */
  why?: string;
  /** Up to 3 sentences, shown as a "Picture this" card before step 1. */
  scene?: string;
  /** Closing card "Take it with you: …"; auto-saved to My Toolkit. */
  tagline?: string;
};

export type ExerciseContent =
  | ({ kind: "guided" } & GuidedContent)
  | ({ kind: "timer" } & TimerContent)
  | ({ kind: "breathing" } & BreathingContent)
  | ({ kind: "checklist" } & ChecklistContent)
  | ({ kind: "worksheet" } & WorksheetContent)
  | ({ kind: "mapper" } & MapperContent)
  | ({ kind: "calculator" } & CalculatorContent)
  | ({ kind: "scale" } & ScaleContent);

/** How Adel recognizes when this exercise may help. Never diagnostic. */
export type ExerciseAdelMeta = {
  /** The one skill this exercise practices, in plain words. */
  skill: string;
  /** Things a member might naturally say when this could help (first person). */
  needs: string[];
  /** Emotional / behavioral states it supports, e.g. "worried", "stuck". */
  states: string[];
  /** When Adel should consider offering it. */
  when: string;
};

export type Exercise = {
  id: string;
  title: string;
  subtitle: string;
  minutes: number;
  type: ExerciseType;
  tags: ExerciseTag[];
  purpose: string;
  content: ExerciseContent;
  adel?: ExerciseAdelMeta;
};

import { SCHEDULE_EXERCISES } from "./exercises-schedule";
import { GUIDED_EXERCISES } from "./exercises-guided";
import { GUIDED_MY_PEOPLE } from "./exercises-guided-my-people";
import { GUIDED_UNDERSTANDING } from "./exercises-guided-understanding";
import { GUIDED_EVERYDAY_LIFE } from "./exercises-guided-everyday-life";
import { GUIDED_RELATIONSHIPS } from "./exercises-guided-relationships";
import { GUIDED_LIFE_THAT_WORKS } from "./exercises-guided-life-that-works";
import { GUIDED_WHEN_HARD } from "./exercises-guided-when-hard";
import { GUIDED_SOMEONE_NEW } from "./exercises-guided-someone-new";
import { GUIDED_LIVING_RECOVERY } from "./exercises-guided-living-recovery";
import { PARTA_A } from "./exercises-parta-a";
import { PARTA_B } from "./exercises-parta-b";
import { PARTA_C } from "./exercises-parta-c";
import { PARTA_D } from "./exercises-parta-d";
import { PARTA_EF } from "./exercises-parta-ef";
import { PARTA_FIXES } from "./exercises-parta-fixes";
import { BUILD_SKILL_SH1 } from "./exercises-build-skill-sh1";
import { BUILD_SKILL_SH2 } from "./exercises-build-skill-sh2";
import { BUILD_SKILL_SH3 } from "./exercises-build-skill-sh3";
import { BUILD_SKILL_SUD1 } from "./exercises-build-skill-sud1";
import { BUILD_SKILL_SUD2 } from "./exercises-build-skill-sud2";
import { BUILD_SKILL_SUD3 } from "./exercises-build-skill-sud3";
import { controlledExercise } from "@/lib/exercise-control";

export const EXERCISES: Exercise[] = ([
  ...SCHEDULE_EXERCISES,
  {
    id: "urge-surfing-timer",
    title: "Urge Surfing Timer",
    subtitle: "Ride the wave without acting on it",
    minutes: 3,
    type: "timer",
    tags: ["craving", "relapse-prevention", "triggers"],
    purpose: "Cravings rise, peak, and pass. This timer keeps you company while it passes.",
    content: {
      kind: "timer",
      seconds: 180,
      prompts: [
        "Notice where you feel it in your body. Don't fight it — just find it.",
        "Give it a number, 1 to 10. Watch whether it moves.",
        "Breathe out longer than you breathe in.",
        "The wave is cresting. You don't have to do anything about it.",
        "Still here. Still not using. That's the whole skill.",
        "Feel it start to drop. This is what passing looks like.",
      ],
      closing: "You rode it out. Cravings don't last — you just proved it to yourself.",
    },
  },
  {
    id: "box-breathing",
    title: "Box Breathing Timer",
    subtitle: "Four counts in, four hold, four out",
    minutes: 2,
    type: "breathing",
    tags: ["anxiety", "anger", "craving"],
    purpose: "Slows your body down when your head is moving too fast.",
    content: {
      kind: "breathing",
      inhale: 4, hold: 4, exhale: 4, holdOut: 4,
      instruction: "Follow the circle. If you lose the count, just start again.",
    },
  },
  {
    id: "trigger-map",
    title: "Trigger Map",
    subtitle: "People, places, feelings, times",
    minutes: 5,
    type: "mapper",
    tags: ["triggers", "craving", "relapse-prevention"],
    purpose: "You can't dodge what you haven't named. Map yours so you see them coming.",
    content: {
      kind: "mapper",
      prompt: "Add what belongs in each zone. Tap a suggestion or type your own.",
      zones: [
        { id: "people", label: "People", hint: "Who makes it harder?", suggestions: ["Old running partner", "Family member", "Someone I owe", "A dealer's number still in my phone"] },
        { id: "places", label: "Places", hint: "Where does it get loud?", suggestions: ["Old neighborhood", "Certain corner store", "Parties", "Alone in my room"] },
        { id: "feelings", label: "Feelings", hint: "What sets it off inside?", suggestions: ["Boredom", "Anger", "Shame", "Loneliness", "Being disrespected"] },
        { id: "times", label: "Times", hint: "When is it worst?", suggestions: ["Late night", "Payday", "Weekends", "After a hard call"] },
      ],
    },
  },
  {
    id: "thought-record",
    title: "Thought Record",
    subtitle: "Catch it, check it, change it",
    minutes: 6,
    type: "worksheet",
    tags: ["cbt", "anxiety"],
    purpose: "Thoughts feel like facts. Writing them down is how you tell the difference.",
    content: {
      kind: "worksheet",
      prompt: "Take one thought that's been running you today.",
      fields: [
        { id: "situation", label: "What happened?", placeholder: "Just the facts — what a camera would see." },
        { id: "thought", label: "What did I think?", placeholder: "The exact sentence in your head." },
        { id: "feeling", label: "What did I feel?", placeholder: "One or two words", options: ["Angry", "Ashamed", "Scared", "Hopeless", "Numb", "Anxious"] },
        { id: "evidence", label: "What says it's not the whole story?", placeholder: "One fact that doesn't fit.", long: true },
        { id: "reframe", label: "A fairer way to say it", placeholder: "Not fake-positive. Just fair.", long: true },
      ],
    },
  },
  {
    id: "anger-thermometer",
    title: "Anger Thermometer + De-escalation Plan",
    subtitle: "Know your number, know your move",
    minutes: 4,
    type: "scale",
    tags: ["anger", "communication"],
    purpose: "Anger is easier to steer early. This sets a move for each level.",
    content: {
      kind: "scale",
      prompt: "Where's your anger right now?",
      left: "Calm",
      right: "About to blow",
      levels: [
        { upTo: 3, name: "Cool", plan: ["Name what bothered me", "Say it plain before it builds", "Keep doing what I'm doing"] },
        { upTo: 6, name: "Heating up", plan: ["Step outside for two minutes", "Slow my breathing out", "Text someone on my list", "Drink water, eat something"] },
        { upTo: 8, name: "Hot", plan: ["Leave the room — no explanation needed", "Walk until my hands unclench", "Call my peer specialist", "No decisions until I'm under 5"] },
        { upTo: 10, name: "Boiling", plan: ["Get physically away from the person", "No phone, no texts, no driving", "Call someone who can talk me down", "Come back to it tomorrow"] },
      ],
    },
  },
  {
    id: "support-circle",
    title: "Support Circle Mapper",
    subtitle: "Who's actually in your corner",
    minutes: 5,
    type: "mapper",
    tags: ["support", "communication"],
    purpose: "Most people have more support than they can name under pressure. Name it now.",
    content: {
      kind: "mapper",
      prompt: "Put real names or roles in each ring.",
      zones: [
        { id: "inner", label: "Call any hour", hint: "The 2am people.", suggestions: ["Sponsor", "Peer specialist", "Mom", "Best friend"] },
        { id: "steady", label: "Steady support", hint: "Reliable, not urgent.", suggestions: ["Case manager", "Therapist", "Sibling", "Coworker"] },
        { id: "pro", label: "Professional", hint: "Paid to help — use them.", suggestions: ["Doctor", "Counselor", "Parole officer", "Housing navigator"] },
        { id: "group", label: "Group support", hint: "Rooms where you're not alone.", suggestions: ["AA/NA meeting", "Church", "Peer group", "Gym"] },
      ],
    },
  },
  {
    id: "budget-basics",
    title: "Budget Basics Calculator",
    subtitle: "What's coming in, what's going out",
    minutes: 6,
    type: "calculator",
    tags: ["money", "goal-setting"],
    purpose: "Money stress is a relapse risk. Seeing the real number lowers the noise.",
    content: {
      kind: "calculator",
      prompt: "Rough monthly numbers are fine. Guessing beats avoiding.",
      incomeRows: ["Job / wages", "Benefits (CalFresh, SSI, GA)", "Family help", "Other"],
      expenseRows: ["Rent / sober living", "Food", "Phone", "Transportation", "Court fees / restitution", "Other"],
      closing: "If the number is negative, that's information — not failure. Bring it to your case manager.",
    },
  },
  {
    id: "communication-script",
    title: "Communication Script Builder",
    subtitle: "Say the hard thing, calmly",
    minutes: 5,
    type: "worksheet",
    tags: ["communication", "support", "anger"],
    purpose: "Hard conversations go better with a script you wrote when you were calm.",
    content: {
      kind: "worksheet",
      prompt: "Build one sentence you can actually say out loud.",
      fields: [
        { id: "who", label: "Who is this for?", placeholder: "Name or role" },
        { id: "when", label: "When I…", placeholder: "The situation — no blame words.", long: true },
        { id: "feel", label: "I feel…", placeholder: "One feeling word", options: ["Frustrated", "Hurt", "Worried", "Disrespected", "Overwhelmed"] },
        { id: "need", label: "What I need is…", placeholder: "One clear, doable ask.", long: true },
        { id: "backup", label: "If it goes sideways, I'll…", placeholder: "Your exit plan.", options: ["Take a walk", "End the call politely", "Come back to it tomorrow", "Text my sponsor"] },
      ],
    },
  },
  {
    id: "if-i-slip-plan",
    title: '"If I Slip" Plan',
    subtitle: "Decided ahead of time, not in the moment",
    minutes: 5,
    type: "worksheet",
    tags: ["relapse-prevention", "craving"],
    purpose: "A slip is not the end. What happens in the next hour is what matters.",
    content: {
      kind: "worksheet",
      prompt: "Write this while you're steady, so it's ready if you're not.",
      fields: [
        { id: "first", label: "First person I tell", placeholder: "Name and number" },
        { id: "hour", label: "What I do in the first hour", placeholder: "Get safe, get honest.", options: ["Stop and get somewhere safe", "Call my sponsor", "Go to a meeting", "Tell my peer specialist", "Eat and sleep"] },
        { id: "avoid", label: "What I will NOT do", placeholder: "The spiral move you know.", options: ["Disappear on everyone", "Say it's over", "Keep using to fix the shame", "Skip my next appointment"] },
        { id: "words", label: "What I'll tell myself", placeholder: "In your own words.", long: true },
      ],
    },
  },
  {
    id: "warning-signs",
    title: "Relapse Warning Signs Checklist",
    subtitle: "The stuff that shows up before the using does",
    minutes: 4,
    type: "checklist",
    tags: ["relapse-prevention", "triggers"],
    purpose: "Relapse starts long before the substance. These are your early flags.",
    content: {
      kind: "checklist",
      prompt: "Check anything that's true in the last week.",
      items: [
        "Skipping meetings", "Isolating from people who care", "Not sleeping",
        "Skipping meals", "Stopped taking my meds", "Keeping secrets",
        "Hanging around old people or places", "Romanticizing using",
        "Anger on a short fuse", "Letting appointments slide",
        "Telling people I'm fine when I'm not", "Money disappearing",
      ],
      closing: "Three or more is a signal to reach out today — not a verdict on you.",
    },
  },
  {
    id: "milestone-reward",
    title: "Milestone Reward Planner",
    subtitle: "Something to walk toward",
    minutes: 4,
    type: "worksheet",
    tags: ["goal-setting", "support"],
    purpose: "Recovery needs something to move toward, not just something to avoid.",
    content: {
      kind: "worksheet",
      prompt: "Pick one milestone that's close enough to feel real.",
      fields: [
        { id: "milestone", label: "My next milestone", placeholder: "30 days, first paycheck, first month housed…", options: ["7 days", "30 days", "90 days", "First paycheck", "Own place"] },
        { id: "date", label: "Roughly when", placeholder: "A date or a week" },
        { id: "reward", label: "How I'll mark it", placeholder: "Free or cheap counts.", options: ["Good meal", "New shoes", "Day at the lake", "Call my kids", "Share at a meeting"] },
        { id: "who", label: "Who I'll tell", placeholder: "Name" },
      ],
    },
  },
  ...GUIDED_EXERCISES,
  ...GUIDED_MY_PEOPLE,
  ...GUIDED_UNDERSTANDING,
  ...GUIDED_EVERYDAY_LIFE,
  ...GUIDED_RELATIONSHIPS,
  ...GUIDED_LIFE_THAT_WORKS,
  ...GUIDED_WHEN_HARD,
  ...GUIDED_SOMEONE_NEW,
  ...GUIDED_LIVING_RECOVERY,
  ...PARTA_A,
  ...PARTA_B,
  ...PARTA_C,
  ...PARTA_D,
  ...PARTA_EF,
  ...PARTA_FIXES,
  ...BUILD_SKILL_SH1,
  ...BUILD_SKILL_SH2,
  ...BUILD_SKILL_SH3,
  ...BUILD_SKILL_SUD1,
  ...BUILD_SKILL_SUD2,
  ...BUILD_SKILL_SUD3,
] satisfies Exercise[]).map(controlledExercise);

export function getExercise(id: string): Exercise | undefined {
  return EXERCISES.find((e) => e.id === id);
}

export function exercisesByTag(tag: ExerciseTag): Exercise[] {
  return EXERCISES.filter((e) => e.tags.includes(tag));
}

/* ------------------------- theme → exercise matching ---------------------- */

const TAG_KEYWORDS: Record<ExerciseTag, string[]> = {
  emotions: ["grief", "loss", "grieving", "sadness", "miss", "goodbye"],
  craving: ["crav", "urge", "want to use", "using", "surf", "high", "drink"],
  triggers: ["trigger", "people places", "cue", "temptation", "risky"],
  anger: ["anger", "angry", "explode", "rage", "react", "conflict", "temper", "frustrat"],
  cbt: ["thought", "thinking", "belief", "inner voice", "worry", "rumina", "story", "mind"],
  anxiety: ["anxiety", "anxious", "panic", "calm", "overwhelm", "high alert", "stress", "sleep", "fear"],
  support: ["support", "trust", "help", "count on", "boundar", "relationship", "family", "peer", "communit", "alone", "lonely"],
  "goal-setting": ["goal", "plan", "future", "purpose", "milestone", "30 days", "success", "become", "identity"],
  communication: ["talk", "say", "ask", "communicat", "conversation", "repair", "apolog"],
  "relapse-prevention": ["relapse", "slip", "setback", "warning", "toolbox", "emergency", "recovery plan", "bad day"],
  money: ["money", "budget", "benefit", "financ", "job", "work", "pay", "bills", "housing"],
};

/** Score a free-text theme against every exercise and return the best match. */
export function matchExercise(theme: string, fallbackId = "box-breathing"): Exercise {
  const text = theme.toLowerCase();
  let best: { ex: Exercise; score: number } | null = null;
  for (const ex of EXERCISES) {
    let score = 0;
    for (const tag of ex.tags) {
      for (const kw of TAG_KEYWORDS[tag]) if (text.includes(kw)) score += 1;
    }
    if (score > 0 && (!best || score > best.score)) best = { ex, score };
  }
  return best?.ex ?? getExercise(fallbackId)!;
}
