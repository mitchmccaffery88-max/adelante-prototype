import { test } from "node:test";
import assert from "node:assert/strict";
import { NEEDS, visibleScreens, isEscalated, urgeLevel, buildPlanActions, effectiveNeeds } from "./reentry";

test("urges checked: urge screen comes right after needs", () => {
  const s = visibleScreens({ needs: [NEEDS.urge], answers: {} });
  assert.equal(s[2], "urge");
});

test("safe place + urges escalates", () => {
  assert.equal(isEscalated({ needs: [NEEDS.shelter, NEEDS.urge], answers: {} }), true);
  assert.equal(isEscalated({ needs: [NEEDS.urge], answers: {} }), false);
  assert.equal(isEscalated({ needs: [NEEDS.urge, NEEDS.talk], answers: {} }), true);
  assert.equal(isEscalated({ needs: [NEEDS.urge], answers: { "quick-food": "no" } }), true);
  assert.equal(isEscalated({ needs: [NEEDS.shelter], answers: {} }), false);
});

test("only checked needs get screens; unchecked ones share one Quick check", () => {
  const s = visibleScreens({ needs: [NEEDS.food], answers: {} });
  assert.deepEqual(s, ["welcome", "needs", "food", "quick", "support", "plan", "toolkit"]);
});

test("Quick check 'no' adds that need", () => {
  assert.ok(effectiveNeeds({ needs: [], answers: { "quick-shelter": "no" } }).includes(NEEDS.shelter));
});

test("triage levels", () => {
  assert.equal(urgeLevel("ok", "yes", false), 1);
  assert.equal(urgeLevel("ok", "no", false), 2);
  assert.equal(urgeLevel("strong", "yes", false), 2);
  assert.equal(urgeLevel("ok", "yes", true), 2);
  assert.equal(urgeLevel("about", undefined, false), 3);
});

test("plan: Devon and a meeting are always first and standing", () => {
  const plan = buildPlanActions({ needs: [NEEDS.shelter, NEEDS.probation], answers: {} });
  assert.deepEqual(plan.slice(0, 2).map((a) => a.id), ["devon", "meeting"]);
  assert.ok(plan[0].standing && plan[1].standing);
  assert.deepEqual(plan.slice(2).map((a) => a.id), ["shelter", "probation"]);
  assert.ok(plan.every((a) => a.when && a.backup));
});

test("plan keeps member edits when rebuilt", () => {
  const first = buildPlanActions({ needs: [NEEDS.shelter], answers: {} });
  first[2] = { ...first[2], when: "Tonight" };
  const again = buildPlanActions({ needs: [NEEDS.shelter], answers: {} }, first);
  assert.equal(again[2].when, "Tonight");
});
