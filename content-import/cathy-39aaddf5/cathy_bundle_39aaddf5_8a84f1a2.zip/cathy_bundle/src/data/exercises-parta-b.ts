// Plug-and-play NEW Part A guided exercises replacing duplicated ones.
// Group B palette: self-talk swaps out loud, perspective shifts, thought
// pattern spotting, urge delay / "not now" practice, values tap.
import type { Exercise, ExerciseAdelMeta } from "./exercises";

type G = Omit<Exercise, "type" | "content"> & {
  steps: [string, number][];
  closing: string;
  adel?: ExerciseAdelMeta;
};

const g = ({ steps, closing, ...rest }: G): Exercise => ({
  ...rest,
  type: "guided",
  content: { kind: "guided", steps: steps.map(([say, secs]) => ({ say, secs })), closing },
});

export const PARTA_B: Exercise[] = [
  g({
    id: "someone-elses-problem",
    title: "Picture It as Someone Else's Problem",
    subtitle: "Borrow the clarity that comes from stepping outside it",
    minutes: 1,
    tags: ["cbt", "goal-setting"],
    purpose: "It's easier to think clearly about someone else's problem than your own. Borrow that outside view on purpose.",
    steps: [
      ["Think of the problem you're stuck on right now.", 10],
      ["Picture a friend telling you this exact same problem, word for word.", 12],
      ["Ask: what's the very first step I'd tell them to try?", 15],
      ["Say that first step out loud, as advice to them.", 12],
      ["Notice: that advice is just as true for you.", 10],
      ["Say: \"I can see this clearly. It's a problem, not a wall.\"", 12],
    ],
    closing: "You just gave yourself the advice you'd give a friend. That's usually the clearest answer you have.",
    adel: {
      skill: "gaining outside clarity by picturing a problem as someone else's",
      needs: ["I don't know where to even start", "This problem feels too big", "I keep going in circles on this"],
      states: ["stuck", "overwhelmed", "frustrated"],
      when: "Offer when a member feels stuck on a problem and can't find a first step on their own.",
    },
  }),
  g({
    id: "not-now-craving-choice",
    title: "Tell the Craving \"Not Right Now\"",
    subtitle: "Practice delaying, not deciding forever",
    minutes: 1,
    tags: ["craving", "relapse-prevention"],
    purpose: "You don't have to win the whole fight at once. Delaying the choice by a few minutes is often enough.",
    steps: [
      ["Notice the pull toward using that's showing up right now.", 10],
      ["Say out loud: \"Not right now.\"", 10],
      ["Notice you're not saying never — just not this minute.", 12],
      ["Pick one thing you'll do in the next five minutes instead.", 12],
      ["Say: \"I only have to win the next five minutes.\"", 10],
      ["Picture yourself five minutes from now, still here, still deciding.", 12],
    ],
    closing: "You practiced the delay. Every \"not right now\" is a real choice, and it counts.",
    adel: {
      skill: "delaying a craving-driven choice in the moment",
      needs: ["I want to use right now", "The urge is really strong today", "I don't know if I can say no"],
      states: ["craving", "tempted", "on edge"],
      when: "Offer when a member describes an active urge to use and needs a way to buy time.",
    },
  }),
  g({
    id: "name-the-tool-out-loud",
    title: "Name Your Go-To Tool Out Loud",
    subtitle: "Say it now so it's ready later",
    minutes: 1,
    tags: ["relapse-prevention", "goal-setting"],
    purpose: "A tool you've said out loud is easier to reach for under pressure than one you've only thought about.",
    steps: [
      ["Think back to a hard moment you actually got through without using.", 12],
      ["Notice what you did that helped, even a small thing.", 12],
      ["Say it out loud, plainly: \"When it's hard, I ___.\"", 12],
      ["Picture using that exact tool the next time it's hard.", 12],
      ["Say it once more, like you're reminding a friend.", 10],
      ["Say: \"This one is mine. It's worked before.\"", 10],
    ],
    closing: "You named your tool out loud. Saying it now makes it easier to grab when you need it.",
    adel: {
      skill: "naming a proven coping tool out loud so it's ready to use",
      needs: ["I don't know what to do when it gets hard", "I forget my tools when I need them", "I need something that actually works for me"],
      states: ["uncertain", "stuck", "anxious"],
      when: "Offer when a member is building or reviewing their set of coping tools for hard moments.",
    },
  }),
];
