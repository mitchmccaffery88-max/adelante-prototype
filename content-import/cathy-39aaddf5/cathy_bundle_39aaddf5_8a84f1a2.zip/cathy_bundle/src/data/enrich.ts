// Rich content overlay for library modules. Merged at read-time so we don't
// have to rewrite the whole mock.ts. Every field is OPTIONAL — modules
// without an entry keep working with the existing Learn/Try It/etc.

export type LearnParts = {
  // Part 1 — What's happening (brain/body/emotions/behavior in plain words)
  happening: { headline: string; body: string; visual?: string };
  // Part 2 — Why it happens (invisible psychology, plain language)
  why: { headline: string; body: string; approach?: string };
  // Part 3 — What can change (hope, not shame)
  canChange: { headline: string; body: string };
  // Part 4 — Before moving on (takeaway + one reflection question)
  takeaway: string;
  reflection: string;
};

export type BuildToolSlot = {
  id: string;
  label: string;
  hint?: string;
  options: string[];
  pickMax?: number; // default 1
};

export type BuildTool = {
  name: string;            // e.g. "Craving Rescue Plan"
  intro: string;
  slots: BuildToolSlot[];
  saveAs: string;          // what shows up in My Toolkit
};

export type PracticeScenario = {
  title: string;           // "It's 2:00 AM..."
  scene: string;           // the moment
  prompt: string;          // "What do you do next?"
  choices: {
    label: string;
    consequence: string;   // what likely happens
    healthy?: boolean;     // subtle reinforcement, not "right/wrong"
  }[];
  ifOptions: string[];     // triggers to pick from
  thenOptions: string[];   // responses to pick from
};

export type Enrichment = {
  learnParts?: LearnParts;
  buildTool?: BuildTool;
  practice?: PracticeScenario;
};

const ENRICH: Record<string, Enrichment> = {
  // ---- Starting Strong / My Mind Won't Slow Down ------------------------
  "mind-wont-slow": {
    learnParts: {
      happening: {
        headline: "Your brain is scanning, not spiraling",
        body: "When your mind races, your brain is running through every 'what if' at once, trying to keep you safe. Your chest tightens, your jaw locks, sleep won't come. It feels like thinking — it's actually your body's alarm firing under the surface.",
        visual: "🧠 → ⚡ → 💨",
      },
      why: {
        headline: "Old danger, new day",
        body: "After hard experiences, your brain learns to expect the next hit. That scanning becomes its default setting. It's not weakness — it's protection that hasn't been told it's safe yet.",
        approach: "Trauma-informed care · Nervous system regulation",
      },
      canChange: {
        headline: "Your body can learn quiet again",
        body: "Every time you slow your breath, cool your skin, or ground your feet, you send your brain proof: 'we're okay right now.' Do that enough times and the default shifts. This isn't hope — it's how nervous systems work.",
      },
      takeaway: "You can't out-think a racing mind. You out-breathe it.",
      reflection: "When your thoughts race, where do you feel it in your body first?",
    },
    buildTool: {
      name: "Personal Calm Card",
      intro: "Pick what actually works for you. This becomes your go-to when your mind is loud.",
      saveAs: "My Calm Card",
      slots: [
        {
          id: "breath",
          label: "My breath move",
          options: ["4-in / 4-hold / 6-out", "Box breathing (4/4/4/4)", "One long slow exhale", "Sigh out through pursed lips"],
        },
        {
          id: "body",
          label: "My body reset",
          options: ["Cold water on my face", "Hold an ice cube", "Feet flat, press into the floor", "Shoulders down, jaw loose"],
        },
        {
          id: "phrase",
          label: "One line I tell myself",
          options: ["This is my alarm, not a fire", "My body is safe right now", "This will pass", "I've done this before"],
        },
      ],
    },
    practice: {
      title: "It's 2:00 AM",
      scene: "You're in bed. Your mind starts replaying a conversation from earlier — every wrong thing you said. Your heart picks up. Sleep is gone.",
      prompt: "What do you try first?",
      choices: [
        { label: "Grab your phone and scroll", consequence: "The scrolling numbs it for a minute — but the racing usually comes back stronger, and you lose another hour of sleep." },
        { label: "Slow your exhale for 6 rounds", consequence: "Your heart rate starts to come down. The thoughts are still there, but they lose their edge.", healthy: true },
        { label: "Get up and splash cold water on your face", consequence: "The cold flips a physical switch. Within a minute your body is calmer — now the breathing works.", healthy: true },
        { label: "Fight the thoughts back with logic", consequence: "You end up in a debate with your own head. The alarm gets louder, not quieter." },
      ],
      ifOptions: ["I wake up with my mind racing", "I can't fall asleep", "I catch myself replaying a conversation", "I feel my chest tighten at night"],
      thenOptions: ["I do 6 rounds of slow breathing", "I splash cold water on my face", "I say my one line out loud", "I get up and stretch for 2 minutes"],
    },
  },

  // ---- Starting Strong / I Feel Overwhelmed -----------------------------
  "overwhelmed": {
    learnParts: {
      happening: {
        headline: "Your brain is trying to solve everything at once",
        body: "Overwhelm feels like fog. You know things need doing, but you can't move. That's not laziness — your brain's decision-making system is stuck in traffic.",
        visual: "🌀",
      },
      why: {
        headline: "Too many open tabs",
        body: "When every problem feels equally urgent, your brain can't sort them. It shuts down. This is a normal response to load, not a personal failure.",
        approach: "CBT · Cognitive load theory",
      },
      canChange: {
        headline: "Shrink the frame",
        body: "You don't get out of overwhelm by doing more — you get out by doing the very next small thing. One small win tells your brain: we can move. Then the next one comes easier.",
      },
      takeaway: "You don't have to do everything. You have to do the next thing.",
      reflection: "What's one thing that would give you the most relief if it was done today?",
    },
    buildTool: {
      name: "Next-Thing Plan",
      intro: "Build the shortest path forward. Pick one — that's it.",
      saveAs: "My Next-Thing Plan",
      slots: [
        {
          id: "next",
          label: "The very next thing I'll do",
          options: ["Send one text", "Make one phone call", "Wash my face and eat something", "Walk outside for 5 minutes", "Write down the top 3 things"],
        },
        {
          id: "when",
          label: "When",
          options: ["Right now", "In the next hour", "Before lunch", "Tonight before bed"],
        },
        {
          id: "reward",
          label: "How I'll mark it done",
          options: ["Cross it off out loud", "Text someone: 'Done.'", "Sit for 60 seconds and breathe", "Give myself a small break"],
        },
      ],
    },
    practice: {
      title: "The morning list",
      scene: "You wake up. Six things are on your mind: an appointment, a bill, a call you've been avoiding, groceries, laundry, and 'figuring out your whole life.' Your chest tightens.",
      prompt: "What's your first move?",
      choices: [
        { label: "Try to do all of them", consequence: "You spin between tasks and finish none. By noon you're exhausted and nothing changed." },
        { label: "Pick the one that gives you the most relief", consequence: "You finish it. The list feels lighter. You have energy for one more.", healthy: true },
        { label: "Go back to bed", consequence: "The list is still there when you get up. Now it feels bigger." },
        { label: "Text one person and say 'today's a lot'", consequence: "Just naming it drops the pressure. Now you can pick the next thing.", healthy: true },
      ],
      ifOptions: ["I open my eyes to a full list", "I catch myself frozen on the couch", "My chest tightens looking at my phone"],
      thenOptions: ["I pick the ONE thing that gives the most relief", "I do it for 10 minutes and stop", "I text someone: 'today's a lot'", "I cross it off out loud"],
    },
  },

  // ---- Understanding / Depression --------------------------------------
  "depression": {
    learnParts: {
      happening: {
        headline: "Depression changes how your brain uses energy",
        body: "Things that used to matter don't. Getting out of bed takes twice as long. Your body feels heavy. This isn't you being lazy — it's a real change happening in the wiring.",
        visual: "🔋 → ▁▁▂",
      },
      why: {
        headline: "The reward system dims down",
        body: "Depression lowers the brain chemicals that make ordinary things feel worth doing. Motivation doesn't come first — action does. Waiting to 'feel like it' is the trap.",
        approach: "CBT · Behavioral activation",
      },
      canChange: {
        headline: "Small moves rewire the system",
        body: "One shower. One walk to the mailbox. One text sent. Small actions before motivation is how the reward system comes back online. It's not fast. It's real.",
      },
      takeaway: "Depression lies with your own voice. Action comes before motivation.",
      reflection: "What's one small thing you used to do that you'd want back first?",
    },
    buildTool: {
      name: "One-Small-Move Card",
      intro: "Build a tiny daily move you can do even on your worst day. Small enough that it's almost impossible to skip.",
      saveAs: "My One-Small-Move",
      slots: [
        {
          id: "move",
          label: "My one move",
          options: ["Sit up and put my feet on the floor", "Open the curtains", "Drink one glass of water", "Walk to the mailbox and back", "Send one text to someone I trust"],
        },
        {
          id: "when",
          label: "When I'll do it",
          options: ["First thing when I wake up", "After I brush my teeth", "Before I eat", "When the sun comes up"],
        },
        {
          id: "voice",
          label: "What I say when depression tells me not to",
          options: ["'That's the depression, not the facts'", "'Small counts'", "'I don't have to feel like it'", "'One move, then I can rest'"],
        },
      ],
    },
    practice: {
      title: "The first thought of the day",
      scene: "You wake up. Before your feet hit the floor, the thought lands: 'What's the point?' Your body feels like concrete.",
      prompt: "What do you try?",
      choices: [
        { label: "Roll over and stay in bed", consequence: "The thought gets louder in the dark. By afternoon you feel worse, not rested." },
        { label: "Say back: 'That's the depression, not the facts'", consequence: "The thought is still there, but it loses some weight. You can move a little.", healthy: true },
        { label: "Sit up and put your feet on the floor for 60 seconds", consequence: "The body moves before the mind agrees. Sometimes that's all it takes to break the freeze.", healthy: true },
        { label: "Scroll your phone until you feel something", consequence: "You feel a little more numb, a little more behind. The heaviness doesn't lift." },
      ],
      ifOptions: ["I wake up thinking 'what's the point'", "I can't get out of bed", "Nothing feels worth doing", "I catch myself scrolling for an hour"],
      thenOptions: ["I sit up and put my feet on the floor", "I say 'that's the depression, not the facts'", "I do my one small move", "I text one person"],
    },
  },

  // ---- Train Your Mind / My Thoughts Won't Stop -------------------------
  "thoughts-wont-stop": {
    learnParts: {
      happening: {
        headline: "You're stuck in a thought loop",
        body: "The same worry, the same replay, over and over. It feels like you're solving something — but you're going in circles. That's a loop, not thinking.",
        visual: "🔁",
      },
      why: {
        headline: "Your brain thinks it's helping",
        body: "The loop is your brain trying to prevent a bad outcome by rehearsing it. Fighting the thought makes it stickier. Watching it — like a car passing — is what loosens it.",
        approach: "CBT · Mindfulness · ACT (cognitive defusion)",
      },
      canChange: {
        headline: "You can step out of the loop",
        body: "You don't need the thought to leave. You need to stop chasing it. Naming it ('there's the loop again'), grounding in the present, or doing one small action all break the cycle.",
      },
      takeaway: "You're not your thoughts. You're the one noticing them.",
      reflection: "What's the thought that keeps coming back for you lately?",
    },
    buildTool: {
      name: "Thought Reframe Card",
      intro: "Turn a sticky thought into a healthier one you can actually believe.",
      saveAs: "My Thought Reframe Card",
      slots: [
        {
          id: "hook",
          label: "The thought that hooks me",
          options: ["'I'm going to fail'", "'Nobody actually likes me'", "'I'll never get past this'", "'I ruined it'", "'Something bad is about to happen'"],
        },
        {
          id: "notice",
          label: "How I'll notice it",
          options: ["'There's that thought again'", "'That's the loop'", "'My brain is trying to protect me'", "Say it out loud with a silly voice"],
        },
        {
          id: "swap",
          label: "The healthier line I'll swap in",
          options: ["'This is a thought, not a fact'", "'One moment doesn't define me'", "'I've handled hard before'", "'What would I tell a friend?'"],
        },
      ],
    },
    practice: {
      title: "The replay",
      scene: "You said something at a family dinner. It didn't land right. It's been 3 hours and your brain keeps replaying it — every word, every look.",
      prompt: "What do you do?",
      choices: [
        { label: "Keep replaying, trying to figure out what you 'should' have said", consequence: "The loop gets louder. You lose the evening to a scene that's already over." },
        { label: "Name it: 'there's the loop again'", consequence: "Just naming it loosens the grip. The thought is still there, but you're outside it now.", healthy: true },
        { label: "Do one thing with your hands for 5 minutes", consequence: "Washing dishes, folding laundry, anything physical pulls your brain out of the loop.", healthy: true },
        { label: "Text the person to fix it right now", consequence: "Sometimes helpful — sometimes the loop is talking. Wait until you're grounded before you decide." },
      ],
      ifOptions: ["I catch myself replaying a conversation", "I'm stuck in a 'what if' loop", "I've been on the same thought for 30+ minutes"],
      thenOptions: ["I name it: 'that's the loop'", "I do one thing with my hands for 5 minutes", "I open my Thought Reframe Card", "I text Adel and talk it through"],
    },
  },

  // ---- Strengthen Recovery / I Want to Use ------------------------------
  "want-to-use": {
    learnParts: {
      happening: {
        headline: "A craving is a wave, not a command",
        body: "Your chest gets tight. Your mind narrows. Every path seems to lead back to using. It feels like it will never stop unless you give in — that's the wave at its peak.",
        visual: "🌊",
      },
      why: {
        headline: "Your brain learned a shortcut",
        body: "Using taught your brain: 'this is how we get relief.' That pathway is deep. A craving isn't a moral failure — it's a learned reflex firing exactly the way it was trained to.",
        approach: "Addiction recovery · CBT · Motivational Interviewing",
      },
      canChange: {
        headline: "Every wave you ride weakens the pathway",
        body: "Cravings crest and pass — usually inside 20 minutes if you don't feed them. Each time you ride one out instead of using, the pathway gets a little quieter. This is how brains heal.",
      },
      takeaway: "Cravings pass. You don't have to.",
      reflection: "What usually makes the wave hit hardest — a place, a person, a feeling, a time of day?",
    },
    buildTool: {
      name: "Craving Rescue Plan",
      intro: "Build your go-to plan for when a craving hits. Pick what's realistic for YOUR life.",
      saveAs: "My Craving Rescue Plan",
      slots: [
        {
          id: "person",
          label: "The person I text first",
          options: ["My sponsor", "A sober friend", "My case manager", "A family member who gets it", "Adel"],
        },
        {
          id: "delay",
          label: "My 20-minute delay move",
          options: ["Go for a walk", "Cold shower", "Drive to a meeting", "Call the hotline", "Eat something and drink water"],
        },
        {
          id: "reroute",
          label: "Where I'll physically go",
          options: ["A meeting", "The gym", "A friend's place", "A coffee shop", "Home with the door locked"],
        },
        {
          id: "line",
          label: "The line I tell myself",
          options: ["'This wave will crest and pass'", "'I don't have to answer this feeling'", "'One phone call before one drink'", "'20 minutes changes everything'"],
        },
      ],
    },
    practice: {
      title: "The text",
      scene: "Your phone buzzes. An old friend from before you got sober: 'I'm heading over to the old spot. Want to come?' Your body reacts before your mind does.",
      prompt: "What do you do in the next 60 seconds?",
      choices: [
        { label: "Text back 'maybe' to buy time", consequence: "'Maybe' keeps the door open — and cravings walk through open doors. The pull gets stronger the longer you sit with it." },
        { label: "Put the phone face-down and text your sponsor", consequence: "You interrupt the pathway. Within a few minutes your sponsor is on the line and the wave starts to lose power.", healthy: true },
        { label: "Delete the thread and get out of the house", consequence: "Physical distance from the trigger is one of the strongest moves you can make.", healthy: true },
        { label: "Respond: 'Not tonight, I'm out.'", consequence: "Clean and clear. No door left open. The craving is still there — but you're already on the other side of the decision.", healthy: true },
      ],
      ifOptions: ["An old contact reaches out", "I drive past the old spot", "I have unstructured time on a weekend", "I feel a strong urge for no clear reason"],
      thenOptions: ["I text my person first — before anyone else", "I open my Craving Rescue Plan", "I go somewhere with people", "I say my line out loud"],
    },
  },

  // ---- Big Emotions / I'm About to Explode ------------------------------
  "explode": {
    learnParts: {
      happening: {
        headline: "Your body hit the gas before your mind did",
        body: "Jaw clenched. Chest hot. Words already forming. In 3 seconds your amygdala took over and your thinking brain went offline. This is fight mode — real and fast.",
        visual: "🔥",
      },
      why: {
        headline: "Anger is usually a cover",
        body: "Under most anger is something else — hurt, fear, feeling disrespected, feeling powerless. Anger feels stronger, so your brain reaches for it first. The trick isn't to stop anger. It's to see what's under it.",
        approach: "DBT · Emotional intelligence · Anger iceberg",
      },
      canChange: {
        headline: "6 seconds is enough",
        body: "The chemical surge of anger peaks and starts to drop in about 6 seconds — IF you don't feed it. One breath, one step back, one 'not yet' gives your thinking brain time to come back online.",
      },
      takeaway: "Anger is data, not a directive.",
      reflection: "The last time you exploded, what was actually underneath — hurt? fear? feeling small?",
    },
    buildTool: {
      name: "Anger Reset Plan",
      intro: "Build your Pause Plan for when you feel the surge. This one gets used a lot.",
      saveAs: "My Anger Reset Plan",
      slots: [
        {
          id: "signal",
          label: "My first warning sign",
          options: ["Jaw clenches", "Chest gets hot", "Voice gets louder", "Fists tighten", "I feel my face flush"],
        },
        {
          id: "pause",
          label: "My 6-second move",
          options: ["One long exhale", "Count backwards 6-5-4-3-2-1", "Take one physical step back", "Put my hand on something cold", "Say 'give me a minute' out loud"],
        },
        {
          id: "under",
          label: "What I'll ask myself",
          options: ["'What am I actually feeling under this?'", "'Am I hurt or scared right now?'", "'What do I need in this moment?'", "'Will this matter tomorrow?'"],
        },
        {
          id: "repair",
          label: "If I lose it anyway",
          options: ["I'll come back and own it within 24 hours", "I'll write it out before I speak", "I'll call my sponsor first", "I'll walk before I text"],
        },
      ],
    },
    practice: {
      title: "The line",
      scene: "You've been waiting 20 minutes. Someone cuts in front of you at the counter and mutters something about 'people like you.' Your body lights up before your brain catches up.",
      prompt: "What's your next move?",
      choices: [
        { label: "Say something back — loud", consequence: "It feels satisfying for 3 seconds. Then everyone's staring. You leave more activated than when you got there, and the day's off." },
        { label: "One long exhale, then step back from the counter", consequence: "The surge starts to drop. You still feel the anger — but now you get to choose what to do with it.", healthy: true },
        { label: "Put your hand on something cold and count backwards from 6", consequence: "The physical anchor pulls your thinking brain back online. In 10 seconds you can make a real choice.", healthy: true },
        { label: "Bottle it and stew all day", consequence: "You didn't blow up — but the anger sits in your body. By evening it's coming out sideways at people who didn't do anything." },
      ],
      ifOptions: ["Someone disrespects me in public", "I feel my jaw clench in traffic", "Someone I love says something that stings", "I'm hungry, tired, AND someone pushes a button"],
      thenOptions: ["I take one long exhale first", "I step back one physical step", "I say 'give me a minute' out loud", "I ask myself what's under this"],
    },
  },
};

export function getEnrichment(itemId: string): Enrichment {
  return ENRICH[itemId] ?? {};
}
