import test from "node:test";
import assert from "node:assert/strict";
import { getExercise } from "./exercises";
import { LIBRARY_TOPICS } from "./topic-content";
import { IF_THEN_CONTENT } from "./if-then-content";
import { namedLessonTarget } from "@/lib/lesson-tools";

const lessons: { id: string; exerciseId: string; toolName: string; partB: string | null; limits: number[] }[] = [{"id": "count-on", "exerciseId": "show-up-test", "toolName": "Support Circle Mapper", "partB": "support-circle", "limits": []}, {"id": "ask-help", "exerciseId": "small-specific-soon", "toolName": "Ask List", "partB": null, "limits": [3, 3, 2, 1]}, {"id": "rebuild-trust", "exerciseId": "their-side-of-the-table", "toolName": "Trust Deposits", "partB": null, "limits": [1, 3, 1, 1]}, {"id": "boundaries", "exerciseId": "broken-record", "toolName": "Line in the Sand", "partB": null, "limits": [1, 1, 1, 2, 2]}, {"id": "communicating-needs", "exerciseId": "need-statement", "toolName": "Need It, Say It", "partB": null, "limits": [3, 2, 1, 1]}, {"id": "difficult-relationships", "exerciseId": "serenity-sort", "toolName": "Distance Dial", "partB": null, "limits": [1, 1, 3, 3, 1]}, {"id": "positive-connections", "exerciseId": "give-it-three-visits", "toolName": "New Rooms", "partB": null, "limits": [3, 1, 1, 2]}, {"id": "my-community", "exerciseId": "early-and-useful", "toolName": "Belonging Blueprint", "partB": null, "limits": [2, 2, 3, 1]}, {"id": "give-receive", "exerciseId": "just-say-thanks", "toolName": "Give and Get", "partB": null, "limits": [3, 2, 1, 2]}, {"id": "support-plan", "exerciseId": "picture-the-call", "toolName": "The 2 A.M. Plan", "partB": null, "limits": [3, 1, 3, 1, 1]}, {"id": "housing", "exerciseId": "openings-requirements-next", "toolName": "Home Base Tracker", "partB": null, "limits": [5, 3, 3, 1]}, {"id": "work", "exerciseId": "practice-the-line-eyes-up", "toolName": "Second-Chance Pitch", "partB": null, "limits": [1, 3, 3, 2, 2]}, {"id": "money-basics", "exerciseId": "payday-order", "toolName": "Budget Basics Calculator", "partB": "budget-basics", "limits": []}, {"id": "food-resources", "exerciseId": "pantry-call", "toolName": "Pantry Finder", "partB": null, "limits": [1, 3, 1, 2]}, {"id": "healthcare-support", "exerciseId": "three-question-pocket-card", "toolName": "Health Home Base", "partB": null, "limits": [1, 2, 3, 1]}, {"id": "my-benefits", "exerciseId": "see-it-from-the-workers-side", "toolName": "Paperwork Tracker", "partB": null, "limits": [4, 1, 3, 1, 1]}, {"id": "transportation", "exerciseId": "plan-b-rehearsed", "toolName": "Plan B Ride Card", "partB": null, "limits": [3, 1, 1, 1, 2]}, {"id": "community-connections", "exerciseId": "know-three-names", "toolName": "Local Lowdown", "partB": null, "limits": [1, 2, 1, 2, 3]}, {"id": "legal-responsibilities", "exerciseId": "call-ahead-out-loud", "toolName": "Court & PO Calendar", "partB": null, "limits": [4, 2, 3, 1, 1]}, {"id": "resource-plan", "exerciseId": "write-it-for-future-you", "toolName": "One-Page Lifeline", "partB": null, "limits": [2, 2, 2, 2, 2]}, {"id": "my-vision", "exerciseId": "best-possible-self", "toolName": "Future Snapshot", "partB": null, "limits": [1, 2, 3, 2, 1]}, {"id": "goals-that-matter", "exerciseId": "woop", "toolName": "Goal Card", "partB": null, "limits": [1, 1, 2, 1, 1]}, {"id": "breaking-goals", "exerciseId": "smallest-step", "toolName": "Step Ladder", "partB": null, "limits": [1, 5, 1, 1, 1]}, {"id": "action-plan", "exerciseId": "step-day-time", "toolName": "Action Board", "partB": null, "limits": [3, 3, 1, 3]}, {"id": "habits-goals", "exerciseId": "habit-rehearsal", "toolName": "Never Miss Twice", "partB": null, "limits": [1, 1, 1, 1]}, {"id": "staying-motivated", "exerciseId": "shrink-it", "toolName": "Hard-Day Minimum", "partB": null, "limits": [3, 3, 1, 1]}, {"id": "setbacks", "exerciseId": "cope-ahead", "toolName": "Cope-Ahead Card", "partB": null, "limits": [1, 2, 3, 2, 1]}, {"id": "success-system", "exerciseId": "daily-ritual-run", "toolName": "Success System", "partB": null, "limits": [3, 3, 3, 3]}, {"id": "celebrating-progress", "exerciseId": "savor-the-win", "toolName": "Wins Wall", "partB": null, "limits": [4, 2, 2, 2]}, {"id": "future-roadmap", "exerciseId": "walk-the-horizon", "toolName": "The Roadmap", "partB": null, "limits": [2, 2, 2, 2, 1]}];

for (const expected of lessons) {
  test(`${expected.id}: Part A and Part B content`, () => {
    const topic = LIBRARY_TOPICS[expected.id];
    assert.ok(topic);
    assert.equal(topic.exerciseId, expected.exerciseId);
    const exercise = getExercise(expected.exerciseId);
    assert.ok(exercise && exercise.content.kind === "guided");
    if (exercise.content.kind !== "guided") return;
    assert.ok(exercise.content.tagline);
    assert.ok(exercise.content.steps.reduce((t, s) => t + s.secs, 0) <= 120);
    assert.equal(topic.toolName, expected.toolName);
    assert.ok(topic.toolIntro);
    if (expected.partB) {
      assert.equal(topic.partBExerciseId, expected.partB);
      assert.ok(getExercise(expected.partB));
      return;
    }
    const steps = topic.skillSteps!;
    assert.ok(steps.length >= 3 && steps.length <= 5);
    assert.deepEqual(steps.map((s) => s.maxPicks), expected.limits);
    for (const step of steps) {
      if (step.optionsFrom) assert.deepEqual(step.options, steps.find((s) => s.id === step.optionsFrom)?.options);
      else assert.ok(step.options.length >= 3, `${expected.id}/${step.id}`);
    }
  });
  test(`${expected.id}: first move opens its Part A exercise`, () => {
    const topic = LIBRARY_TOPICS[expected.id]!;
    const plan = IF_THEN_CONTENT[expected.id];
    assert.equal(plan?.moves.length, 5);
    const target = namedLessonTarget(plan!.moves[0]!, { ...topic, lessonId: expected.id });
    assert.equal(target?.kind, "exercise");
    if (target?.kind === "exercise") assert.equal(target.exercise.id, expected.exerciseId);
  });
}

test("named matches from the batch", () => {
  const at = (id: string, move: string) => namedLessonTarget(move, { ...LIBRARY_TOPICS[id]!, lessonId: id });
  assert.equal(at("goals-that-matter", "Run WOOP")?.kind, "exercise");
  assert.equal(at("money-basics", "Pay in Payday Order")?.kind, "exercise");
  assert.equal(at("money-basics", "Check my Budget Basics Calculator")?.kind, "tool");
  assert.equal(at("count-on", "Look at my Support Circle Mapper")?.kind, "tool");
  assert.equal(at("transportation", "Go to Plan B, Rehearsed")?.kind, "exercise");
});

