import test from "node:test";
import assert from "node:assert/strict";
import { FIRST_DAYS } from "./topic-content/recovery-first-days";
import { MY_PEOPLE } from "./topic-content/recovery-my-people";
import { UNDERSTANDING_ADDICTION } from "./topic-content/recovery-understanding";
import { EVERYDAY_LIFE } from "./topic-content/recovery-everyday-life";
import { RELATIONSHIPS } from "./topic-content/recovery-relationships";
import { LIFE_THAT_WORKS } from "./topic-content/recovery-life-that-works";
import { WHEN_HARD } from "./topic-content/recovery-when-hard";
import { SOMEONE_NEW } from "./topic-content/recovery-someone-new";
import { LIVING_RECOVERY } from "./topic-content/recovery-living-recovery";

const common = ["Marcus", "Rosa", "Danny", "Tasha", "Luis", "Kim", "Ray", "Yolanda", "Andre", "Bea"];
const modules = [
  { id: "first-days", content: FIRST_DAYS, cast: common },
  { id: "my-people", content: MY_PEOPLE, cast: common },
  { id: "understanding", content: UNDERSTANDING_ADDICTION, cast: ["Ray", "Kim", "Danny", "Luis", "Tasha", "Yolanda", "Marcus", "Rosa", "Andre", "Bea"] },
  { id: "everyday-life", content: EVERYDAY_LIFE, cast: ["Danny", "Yolanda", "Kim", "Andre", "Marcus", "Tasha", "Luis", "Rosa", "Bea", "Ray"] },
  { id: "relationships", content: RELATIONSHIPS, cast: common },
  { id: "life-that-works", content: LIFE_THAT_WORKS, cast: common },
  { id: "when-hard", content: WHEN_HARD, cast: ["Kim", "Ray", "Rosa", "Luis", "Danny", "Marcus", "Yolanda", "Andre", "Tasha", "Bea"] },
  { id: "someone-new", content: SOMEONE_NEW, cast: ["Yolanda", "Andre", "Rosa", "Marcus", "Kim", "Luis", "Danny", "Tasha", "Ray", "Bea"] },
  { id: "living-recovery", content: LIVING_RECOVERY, cast: ["Andre", "Danny", "Marcus", "Tasha", "Luis", "Kim", "Yolanda", "Ray", "Bea", "Rosa"] },
];
const baselineMonths: Record<string, number> = { Danny: 4, Kim: 8, Rosa: 10, Yolanda: 12, Marcus: 14, Tasha: 18, Luis: 26 };
const fixedTimes: Record<string, string> = { Ray: "6 years", Bea: "9 years", Andre: "3 years" };

modules.forEach(({ id, content, cast }, moduleIndex) => {
  test(`${id} assigns the specified narrator to each lesson, once per person`, () => {
    const actual = Array.from({ length: 10 }, (_, i) => content[`${id}-${i + 1}`]?.story?.name?.split(",")[0]);
    assert.deepEqual(actual, cast);
    assert.deepEqual([...actual].sort(), [...common].sort());
  });
  test(`${id} uses the specified recovery time for every narrator`, () => {
    cast.forEach((name, lessonIndex) => {
      const months = baselineMonths[name];
      const time = months === undefined ? fixedTimes[name] : `${months + moduleIndex} months`;
      assert.equal(content[`${id}-${lessonIndex + 1}`]?.story?.name, `${name}, ${time} in recovery`);
    });
  });
});

test("Marcus advances from 14 to 22 months across the nine modules", () => {
  assert.deepEqual(modules.map(({ id, content, cast }) => content[`${id}-${cast.indexOf("Marcus") + 1}`]?.story?.name),
    [14, 15, 16, 17, 18, 19, 20, 21, 22].map(months => `Marcus, ${months} months in recovery`));
});