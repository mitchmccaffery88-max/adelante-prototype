// Part A guided exercises — Group C replacement set.
// Palette: communication-line rehearsal, role-flip, emotion-regulation body
// moves, playful challenges, decision rehearsal (two doors).
import type { Exercise } from "./exercises";

type G = Omit<Exercise, "type" | "content"> & { steps: [string, number][]; closing: string; why?: string; scene?: string; tagline?: string };

const g = ({ steps, closing, why, scene, tagline, ...rest }: G): Exercise => ({
  ...rest,
  type: "guided",
  content: { kind: "guided", why, scene, tagline, steps: steps.map(([say, secs]) => ({ say, secs })), closing },
});

export const PARTA_C: Exercise[] = [
  // 1. understanding-emotions (Managing Big Emotions)

  // 2. anger-signs (Managing Big Emotions)
  g({
    id: "push-the-wall-check",
    title: "Push the Wall, Then Check",
    subtitle: "Learn what early anger feels like",
    minutes: 1,
    tags: ["anger"],
    why: "Anger shows up in your body before it comes out of your mouth. This teaches you what it feels like.",
    closing: "Most people notice anger when it's already a 7. Learning the body signs lets you catch it at a 3.",
    tagline: "Catch it in the body before it hits the mouth.",
    purpose: "Anger shows up in your body before it comes out of your mouth. This teaches you what it feels like.",
    steps: [
      ["Stand facing a wall with both palms flat on it. Or press your palms together.", 8],
      ["Push hard for 10 seconds. Tighten your jaw and fists too.", 12],
      ["Let go.", 4],
      ["Now notice your jaw, fists, chest and face. What do they feel like?", 15],
      ["That tension is what early anger feels like.", 10],
      ["Next time you notice it, that's your signal to slow down.", 10],
      ["Say: \"Catch it in the body before it hits the mouth.\"", 8],
    ],
    adel: {
      skill: "noticing early body signs of anger by feeling contrast",
      needs: ["I don't notice I'm angry until I'm already yelling", "My anger comes out of nowhere", "I want to catch it earlier", "I don't know my own warning signs", "I'm already at a 9 before I notice"],
      states: ["frustrated", "tense", "on edge", "angry"],
      when: "Offer when a member wants to learn their own early anger cues, not just calm down after the fact.",
    },
  }),

  // 3. explode (Managing Big Emotions)

  // 4. pause (Managing Big Emotions)

  // 5. managing-conflict (Managing Big Emotions)

  // 6. communicating-upset (Managing Big Emotions)

  // 7. repair (Managing Big Emotions)

  // 8. emotional-strength (Managing Big Emotions)

  // Legacy response-sequence exercise, retained for saved exercise links.
  g({
    id: "beat-your-own-time",
    title: "Beat Your Own Time",
    subtitle: "Turn your whole system into a timed challenge",
    minutes: 1,
    tags: ["anger", "cbt"],
    purpose: "Running your full notice-pause-respond sequence as a timed challenge builds the reps that make it automatic.",
    steps: [
      ["Say your sequence out loud, fast, start to finish: notice, pause, breathe, ask, respond.", 15],
      ["Now do it again, slower this time, like you're really living each step.", 15],
      ["Try it a third time, and see if you can say it smoother than the first try.", 15],
      ["Picture a moment today where you'll actually need this sequence.", 12],
      ["Run through it once more, picturing that exact moment.", 12],
      ["Say: \"Every rep counts, even the messy ones.\"", 8],
    ],
    closing: "You just ran your sequence three times, like reps in training. That's what makes it automatic later.",
    adel: {
      skill: "drilling the full response sequence as timed reps",
      needs: ["I want this to feel automatic, not a struggle every time", "I still have to think hard to pause", "I forget parts of my plan when I'm heated", "I've made progress but it's not consistent", "I want to practice my whole system"],
      states: ["motivated", "frustrated", "determined", "stuck"],
      when: "Offer when a member already knows their response steps and wants to practice making them stick.",
    },
  }),

  // 10. count-on (Building My Support Team)

  // 11. positive-connections (Building My Support Team)

  // 12. housing (Getting Back on My Feet)

  // 13. work (Getting Back on My Feet)
  g({
    id: "practice-the-line-eyes-up",
    title: "Talking About My Past",
    subtitle: "Own it, say what changed, say what you bring",
    minutes: 1,
    tags: ["communication"],
    purpose: "Your past will come up: with employers, landlords, family and new people. A short, honest answer you've practiced keeps it from taking over. In California, most employers can't ask until after they offer you the job, and then you get a chance to respond.",
    why: "Your past will come up: with employers, landlords, family and new people. A short, honest answer you've practiced keeps it from taking over. In California, most employers can't ask until after they offer you the job, and then you get a chance to respond.",
    scene: "You got a job offer. A few days later, HR calls: \"Your background check came back. Is there anything you'd like us to know before we decide?\"",
    steps: [
      ["Don't panic. In California, they have to give you a chance to respond, usually at least five business days.", 12],
      ["Own it, briefly: \"Yes, I have a conviction from 2019. I served my time.\"", 12],
      ["What's changed: \"Since then, I've finished a program and stayed on track.\"", 12],
      ["What I bring: \"I'm reliable, I work hard, and I'm ready to prove it here.\"", 12],
      ["Offer proof: \"I can send a letter from my case manager and my program certificate.\"", 12],
      ["Say it once more in your own words, steady and short.", 15],
    ],
    closing: "Use the same three parts with a landlord, a new friend or family. Keep it short. If a job offer gets pulled because of your record, ask your case manager or legal aid about your rights.",
    tagline: "Own it, what changed, what I bring.",
    adel: {
      skill: "talking about your past honestly and briefly",
      needs: ["My background check came back", "How do I explain my conviction?", "A landlord asked about my record", "I never know what to say when my past comes up"],
      states: ["anxious", "ashamed", "hopeful"],
      when: "Offer when a member is job or housing hunting, or dreading a conversation about their past; for legal questions, point them to legal aid.",
    },
  }),

  // 14. money-basics (Getting Back on My Feet)

  // 15. food-resources (Getting Back on My Feet)

  // 16. healthcare-support (Getting Back on My Feet)
  g({
    id: "shake-off-the-nerves",
    title: "Shake Off the Waiting Room Nerves",
    subtitle: "A body reset before you walk in",
    minutes: 1,
    tags: ["anxiety"],
    purpose: "A quick physical shake-out settles the body before a medical visit you've been putting off, so nerves don't decide whether you go.",
    steps: [
      ["Stand and shake out both hands for five seconds.", 8],
      ["Roll your shoulders back slowly, three times.", 10],
      ["Take one breath in, and let it out slower than it came in.", 10],
      ["Plant your feet and press them into the floor for a few seconds.", 10],
      ["Say out loud the one thing you want to ask about at the visit.", 12],
      ["Say: \"One door opens the rest. I just have to walk in.\"", 10],
    ],
    closing: "You just settled your body before you even picked up the phone. That's often the hardest part.",
    adel: {
      skill: "settling nerves in the body before a medical appointment or call",
      needs: ["I've put off medical care for a long time", "I don't know where to start", "I'm nervous about walking into a clinic", "I have something health-related I've been ignoring", "I don't know the difference between urgent and emergency care"],
      states: ["nervous", "anxious", "avoidant", "hesitant"],
      when: "Offer right before a member is about to call or walk into a healthcare appointment they've been avoiding.",
    },
  }),

  // 17. my-benefits (Getting Back on My Feet)
  g({
    id: "see-it-from-the-workers-side",
    title: "See It From the Worker's Side",
    subtitle: "Make it easy for them to say yes",
    minutes: 1,
    tags: ["goal-setting"],
    purpose: "Benefits workers have huge caseloads. A complete, on-time application gets approved faster.",
    why: "Benefits workers have huge caseloads. A complete, on-time application gets approved faster.",
    steps: [
      ["Picture your benefits worker. They have about 100 cases on their desk.", 10],
      ["What slows them down? Missing forms, missing copies, late answers.", 12],
      ["What makes it easy? Every form filled out, copies attached, turned in on time.", 12],
      ["Think of one benefit you're working on. What's missing?", 12],
      ["Pick one thing to get ready this week.", 10],
      ["Say: \"Make it easy to say yes.\"", 6],
    ],
    closing: "You can't control the system. You can make your file the easy one.",
    tagline: "Make it easy to say yes.",
    adel: {
      skill: "reframing a benefits denial by seeing it from the worker's perspective",
      needs: ["I don't know what benefits I qualify for", "I have paperwork I haven't finished", "I've been denied something and don't know if I can appeal", "I don't have a system for keeping my documents", "I feel confused every time I try to figure this out"],
      states: ["discouraged", "confused", "frustrated", "overwhelmed"],
      when: "Offer when a member is discouraged by a denial or stuck paperwork and feels like giving up.",
    },
  }),

  // 18. transportation (Getting Back on My Feet)
  g({
    id: "plan-b-rehearsed",
    title: "Plan B, Rehearsed",
    subtitle: "Always have a backup ride",
    minutes: 1,
    tags: ["goal-setting"],
    purpose: "Rides fall through. A backup you've planned keeps one late bus from becoming a missed appointment.",
    why: "Rides fall through. A backup you've planned keeps one late bus from becoming a missed appointment.",
    scene: "The bus doesn't come, and your appointment is in 30 minutes.",
    steps: [
      ["Don't panic. Go to Plan B.", 6],
      ["Who do you call? A friend, family, a ride-share, your case manager.", 12],
      ["Medi-Cal appointment? Medi-Cal rides need to be booked ahead, so next time, book early.", 12],
      ["Call the clinic: \"I'm running late. Can you still see me, or should I reschedule?\"", 12],
      ["Picture getting there, or getting a new time, instead of just not showing.", 10],
      ["Say: \"Always have a Plan B ride.\"", 6],
    ],
    closing: "Missing an appointment because of a ride is common. Calling ahead and having Plan B keeps it from counting against you.",
    tagline: "Always have a Plan B ride.",
    adel: {
      skill: "mentally rehearsing a transportation backup plan before it's needed",
      needs: ["I've missed appointments because of a ride", "I only have one way to get places", "I get anxious the night before an appointment about how I'll get there", "I don't have a backup plan if my ride falls through", "I avoid making plans because getting there feels too hard"],
      states: ["anxious", "stressed", "worried", "stuck"],
      when: "Offer the night before or morning of an appointment when transportation is uncertain.",
    },
  }),

  // 19. community-connections (Getting Back on My Feet)

  // 20. legal-responsibilities (Getting Back on My Feet)
  g({
    id: "call-ahead-out-loud",
    title: "Call Ahead, Out Loud",
    subtitle: "Reschedule before, not after",
    minutes: 1,
    tags: ["communication"],
    purpose: "Calling before you miss a court date, PO meeting or class is very different from not showing up.",
    why: "Calling before you miss a court date, PO meeting or class is very different from not showing up.",
    steps: [
      ["Picture an appointment you can't make: PO, court, a class or a drug test.", 10],
      ["Call before it starts. Say: \"This is ___.\"", 10],
      ["\"My appointment is ___ at ___.\"", 10],
      ["\"I can't make it because ___.\"", 10],
      ["\"Can we reschedule?\" Then write down the new date and who you talked to.", 12],
      ["Say: \"Call before, not after.\"", 6],
    ],
    closing: "Always call ahead, and get the name of who you talked to. For court dates, ask your lawyer or legal aid before you miss one.",
    tagline: "Call before, not after.",
    adel: {
      skill: "rehearsing a reschedule call for a legal or program deadline",
      needs: ["I've missed or almost missed a legal date", "I avoid calling when I know I can't make something", "I feel anxious about my legal responsibilities", "I don't always know who to call when something comes up", "I don't know if my fines can go on a payment plan"],
      states: ["anxious", "avoidant", "worried", "stressed"],
      when: "Offer when a member knows they'll miss a legal or program date and is avoiding the call.",
    },
  }),

  // 21. resource-plan (Getting Back on My Feet)
  g({
    id: "write-it-for-future-you",
    title: "Write It for Future You",
    subtitle: "Put what you need on paper before a crisis",
    minutes: 1,
    tags: ["goal-setting"],
    purpose: "In a crisis, your phone might be dead and your mind might go blank. Paper still works.",
    why: "In a crisis, your phone might be dead and your mind might go blank. Paper still works.",
    steps: [
      ["Picture yourself in a hard moment. Your phone is dead.", 10],
      ["What number would you need? Who would you call?", 12],
      ["Where would you go for food, a bed or help?", 12],
      ["What appointment can't you miss?", 10],
      ["All of that goes on one page. That's what you're building next.", 10],
      ["Say: \"Write it down before you need it.\"", 6],
    ],
    closing: "Keep a printed copy in your wallet or bag. Future you will be glad you did.",
    tagline: "Write it down before you need it.",
    adel: {
      skill: "motivating a resource page by picturing your future self using it",
      needs: ["My important information is scattered everywhere", "I don't have a single place to find what I need in an emergency", "I've forgotten a number or address I needed", "I feel unprepared for a hard week", "I've never written down my resources in one place"],
      states: ["overwhelmed", "unprepared", "scattered", "motivated"],
      when: "Offer when a member agrees a resource page would help but hasn't started writing one yet.",
    },
  }),
];
