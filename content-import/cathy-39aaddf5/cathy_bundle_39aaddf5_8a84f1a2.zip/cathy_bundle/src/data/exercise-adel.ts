// Adel ↔ Part A exercise mapping.
// Every Build My Skills Part A exercise is indexed here with its module,
// submodule, skill, and the everyday things a member might say when it could
// help. Adel's server uses findExerciseCandidates() to offer (never force) the
// matching exercise, which opens in the existing /exercise/$exerciseId player.

import { LIBRARY } from "./library";
import { RECOVERY_MODULES } from "./recovery";
import { LIBRARY_TOPICS, RECOVERY_TOPICS } from "./topic-content";
import { getExercise, type ExerciseAdelMeta } from "./exercises";
import { KEPT_ADEL_META } from "./exercise-adel-meta";
import { NEED_ENTRIES } from "./needs-map";

/** Fallback for exercises without metadata: the lesson's need tags from needs-map. */
export function fallbackAdelMeta(lessonId: string, area: PartAEntry["area"], purpose: string): ExerciseAdelMeta | undefined {
  const entry = NEED_ENTRIES.find((e) => e.lessonId === lessonId && e.area === (area === "SUD Recovery Journey" ? "Recovery Journey" : "Self Help Library"))
    ?? NEED_ENTRIES.find((e) => e.lessonId === lessonId);
  if (!entry?.needTags.length) return undefined;
  return { skill: purpose, needs: entry.soundsLike.slice(0, 6), states: entry.needTags.map((t) => t.replace(/-/g, " ")), when: entry.problem };
}

export type PartAEntry = {
  exerciseId: string;
  title: string;
  purpose: string;
  partA: true;
  area: "Self Help Library" | "SUD Recovery Journey";
  module: string;
  submodule: string;
  submoduleId: string;
  meta: ExerciseAdelMeta | undefined;
  /** Guided exercises: the "Take it with you" line, used when Adel offers it. */
  tagline?: string;
};

function build(): PartAEntry[] {
  const out: PartAEntry[] = [];
  const push = (area: PartAEntry["area"], module: string, submodule: string, submoduleId: string, exId?: string) => {
    const ex = exId ? getExercise(exId) : undefined;
    if (!ex) return;
    out.push({
      exerciseId: ex.id, title: ex.title, purpose: ex.purpose, partA: true,
      area, module, submodule, submoduleId, meta: ex.adel ?? KEPT_ADEL_META[ex.id] ?? fallbackAdelMeta(submoduleId, area, ex.purpose),
      ...(ex.content.kind === "guided" && ex.content.tagline ? { tagline: ex.content.tagline } : {}),
    });
  };
  for (const c of LIBRARY) for (const i of c.items) push("Self Help Library", c.name, i.title, i.id, LIBRARY_TOPICS[i.id]?.exerciseId);
  for (const m of RECOVERY_MODULES) {
    const name = (m as { title?: string; name?: string }).title ?? (m as { name?: string }).name ?? m.id;
    for (const l of m.lessons) push("SUD Recovery Journey", name, l.title, l.id, RECOVERY_TOPICS[l.id]?.exerciseId);
  }
  return out;
}

export const PART_A_INDEX: PartAEntry[] = build();

const STOP = new Set("i me my the a an and or to of in on is it im i'm just so but for with that this be am do dont don't can cant can't have get got at really about what when like feel feeling you your".split(" "));
// Light synonym folding so recognition works on the underlying need, not exact words.
const FOLD: [RegExp, string][] = [
  [/\b(crav\w*|urges?|want(ing)? to use|wanna use|want to drink|using again|get high|relapse\w*)\b/g, " craving "],
  [/\b(worr\w*|what if|nervous|anxious|anxiety|scared|afraid|panic\w*)\b/g, " worry "],
  [/\b(overwhelm\w*|too much|drowning|so much to do)\b/g, " overwhelmed "],
  [/\b(angry|anger|mad|pissed|furious|rage|snap\w*|explod\w*|blow up)\b/g, " angry "],
  [/\b(sleep\w*|insomnia|awake|tired|can't rest)\b/g, " sleep "],
  [/\b(motivat\w*|lazy|no energy|can't start|don't care)\b/g, " motivation "],
  [/\b(trigger\w*|set me off|reminded me)\b/g, " trigger "],
  [/\b(lonely|alone|isolat\w*|no one|nobody)\b/g, " alone "],
  [/\b(ashamed|shame|guilt\w*|embarrass\w*)\b/g, " shame "],
  [/\b(slip\w*|used again|messed up|drank)\b/g, " slip "],
  [/\b(calm down|chill|relax\w*)\b/g, " calm "],
];

function tokens(text: string): string[] {
  let t = ` ${text.toLowerCase()} `;
  for (const [re, rep] of FOLD) t = t.replace(re, rep);
  return t.replace(/[^a-z\s]/g, " ").split(/\s+/).filter((w) => w.length > 2 && !STOP.has(w));
}

const DOCS = PART_A_INDEX.map((e) => {
  const m = e.meta;
  const strong = new Set(tokens([m?.skill, ...(m?.needs ?? []), ...(m?.states ?? [])].join(" ")));
  const weak = new Set(tokens([e.submodule, e.title, m?.when].join(" ")));
  return { e, strong, weak };
});

/** Top Part A exercises that fit what the member has said. Empty when nothing fits. */
export function findExerciseCandidates(text: string, limit = 4): PartAEntry[] {
  const q = new Set(tokens(text));
  if (!q.size) return [];
  return DOCS.map(({ e, strong, weak }) => {
    let s = 0;
    for (const w of q) { if (strong.has(w)) s += 2; else if (weak.has(w)) s += 1; }
    return { e, s };
  })
    .filter((x) => x.s >= 2)
    .sort((a, b) => b.s - a.s)
    .slice(0, limit)
    .map((x) => x.e);
}
