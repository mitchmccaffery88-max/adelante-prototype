// Adel-facing metadata for kept Part A exercises. Plain language, never diagnostic.
import type { ExerciseAdelMeta } from "./exercises";

export const KEPT_ADEL_META: Record<string, ExerciseAdelMeta> = {
  "what-holds-me": {
    "skill": "Finding what's steady when everything feels new",
    "needs": [
      "everything feels new and shaky",
      "I don't know where to start",
      "I feel unsteady",
      "I just got here and I'm nervous",
      "I need to feel grounded"
    ],
    "states": [
      "shaky",
      "new",
      "nervous",
      "unsteady"
    ],
    "when": "Offer this early on, when a member feels overwhelmed by how new and unfamiliar everything feels."
  },
  "box-breathing": {
    "skill": "Slowing your body down with steady breathing",
    "needs": [
      "I can't calm down",
      "my mind is racing",
      "I'm really anxious right now",
      "I feel like I'm spinning out",
      "I need to relax fast",
      "I'm getting really angry"
    ],
    "states": [
      "anxious",
      "panicked",
      "wound up",
      "angry"
    ],
    "when": "Offer this when a member is worked up right now and needs a quick way to slow their body down."
  },
  "one-step-shrink": {
    "skill": "Shrinking a big pile of tasks down to one",
    "needs": [
      "I have too much to do",
      "I'm overwhelmed",
      "I don't know where to start",
      "everything is piling up",
      "I feel frozen by how much there is to handle"
    ],
    "states": [
      "overwhelmed",
      "frozen",
      "stuck"
    ],
    "when": "Offer this when a member feels buried under too many tasks at once."
  },
  "worry-shelf": {
    "skill": "Testing a worry, then setting it aside for later",
    "needs": [
      "I can't stop worrying",
      "my mind keeps going to the worst case",
      "I can't stop thinking about it",
      "this worry won't leave me alone",
      "I need to get this worry out of my head"
    ],
    "states": [
      "worried",
      "anxious",
      "stuck in thought"
    ],
    "when": "Offer this when a member is stuck circling the same worry and needs a way to set it down."
  },
  "senses-5-4-3-2-1": {
    "skill": "Using your five senses to come back to the present",
    "needs": [
      "I feel on edge",
      "I'm spiraling",
      "something triggered me",
      "I don't feel like myself right now",
      "I feel really wound up"
    ],
    "states": [
      "on edge",
      "triggered",
      "panicked",
      "disconnected"
    ],
    "when": "Offer this when a member seems highly activated or disconnected and needs to come back to the present moment fast."
  },
  "safe-place": {
    "skill": "Building a calm place in your mind",
    "needs": [
      "I don't feel safe",
      "I need somewhere calm to go in my head",
      "I'm really anxious",
      "I can't relax anywhere",
      "I need to feel calm right now"
    ],
    "states": [
      "anxious",
      "unsafe",
      "tense"
    ],
    "when": "Offer this when a member needs a portable way to feel calmer, especially when their surroundings feel unsafe or stressful."
  },
  "heavy-body-release": {
    "skill": "Releasing tension from your body before sleep",
    "needs": [
      "I can't sleep",
      "my body feels tense",
      "I can't wind down at night",
      "I'm too wired to fall asleep",
      "I lie awake for hours"
    ],
    "states": [
      "tense",
      "restless",
      "wired"
    ],
    "when": "Offer this at night or when a member says their body won't relax enough to sleep."
  },
  "trigger-replay": {
    "skill": "Spotting what set off a craving",
    "needs": [
      "I had a craving and don't know why",
      "something triggered me",
      "I want to use",
      "I almost used and I don't know what started it",
      "I keep getting caught off guard by cravings"
    ],
    "states": [
      "shaken",
      "confused",
      "craving"
    ],
    "when": "Offer this after a craving has passed, when a member wants to understand what set it off."
  },
  "urge-surfing-timer": {
    "skill": "Riding out a craving without acting on it",
    "needs": [
      "I want to use",
      "I have a really strong urge right now",
      "I'm craving something",
      "I don't think I can hold out",
      "the craving feels too strong"
    ],
    "states": [
      "craving",
      "urgent",
      "shaky"
    ],
    "when": "Offer this the moment a member reports an active craving and needs to get through it right now."
  },
  "anger-thermometer": {
    "skill": "Knowing your anger number and your next move",
    "needs": [
      "I'm getting really angry",
      "I feel like I'm about to explode",
      "I can't control my temper",
      "someone made me furious",
      "I don't want to say something I'll regret"
    ],
    "states": [
      "angry",
      "heated",
      "on edge"
    ],
    "when": "Offer this when a member's anger is rising and they need a plan for what to do next before it boils over."
  },
  "picture-the-call": {
    "skill": "Rehearsing your first call on a bad night",
    "needs": [
      "I don't know who I'd call if things got bad",
      "I want a plan for a hard night",
      "I'm scared I won't reach out when I need to",
      "I need to know what I'd say if I called for help",
      "I want to be ready before a crisis hits"
    ],
    "states": [
      "anxious",
      "preparing",
      "uncertain"
    ],
    "when": "Offer this when a member is building a support plan and needs to rehearse actually making the call."
  },
  "long-exhale": {
    "skill": "Breathing out longer than you breathe in to calm your body",
    "needs": [
      "I need to calm down fast",
      "my heart is racing",
      "I feel panicky",
      "I need to relax right now",
      "I'm too keyed up to think straight"
    ],
    "states": [
      "panicked",
      "anxious",
      "keyed up"
    ],
    "when": "Offer this when a member needs a very quick, simple way to physically calm down in the moment."
  },
  "walk-into-the-room": {
    "skill": "Rehearsing walking into your first meeting",
    "needs": [
      "I'm scared to go to my first meeting",
      "I don't know what to expect at a meeting",
      "the idea of walking in there terrifies me",
      "I keep avoiding going to a meeting",
      "I need to picture doing this before I actually do it"
    ],
    "states": [
      "scared",
      "anxious",
      "avoidant"
    ],
    "when": "Offer this when a member is nervous about attending a first meeting and hasn't gone yet."
  },
  "helper-scan": {
    "skill": "Spotting the people who are already helping you",
    "needs": [
      "I feel like I have no one",
      "I feel completely alone",
      "I forget that people are actually there for me",
      "I need to remember who's on my side",
      "nobody has my back"
    ],
    "states": [
      "lonely",
      "hopeless",
      "isolated"
    ],
    "when": "Offer this when a member feels alone and needs a quick reminder of the people who've already shown up for them."
  },
  "comeback-rehearsal": {
    "skill": "Rehearsing stop, get safe, tell someone after a slip",
    "needs": [
      "I already used",
      "I used last night",
      "I slipped",
      "I messed up and don't know what to do next",
      "I feel like giving up after using again",
      "I need to know what to do right now after a slip"
    ],
    "states": [
      "ashamed",
      "panicked",
      "discouraged"
    ],
    "when": "Offer this immediately when a member discloses a recent slip and needs the next right move, not judgment."
  },
  "unfreeze-90": {
    "skill": "Getting your body moving when you feel frozen",
    "needs": [
      "I can't move, I feel stuck",
      "I'm frozen and can't do anything",
      "I feel paralyzed right now",
      "I can't get myself to do anything",
      "my body won't cooperate with me"
    ],
    "states": [
      "frozen",
      "stuck",
      "numb"
    ],
    "when": "Offer this when a member describes feeling physically or mentally frozen and unable to act."
  },
  "sample-three-rooms": {
    "skill": "Picturing trying a few different kinds of meetings",
    "needs": [
      "I don't know which meeting to try",
      "I'm not sure what kind of meeting is right for me",
      "meetings feel intimidating and I don't know where to start",
      "I want to find a meeting that fits me",
      "I've never been to a meeting before"
    ],
    "states": [
      "uncertain",
      "overwhelmed",
      "curious"
    ],
    "when": "Offer this when a member is deciding what kind of recovery meeting to try and feels unsure where to start."
  },
  "sunday-review": {
    "skill": "Looking back at the week before planning the next one",
    "needs": [
      "I want to plan my week better",
      "I never look back at how last week went",
      "I want to build a weekly routine",
      "I keep starting the week without a plan",
      "I need a weekly check-in habit"
    ],
    "states": [
      "reflective",
      "organizing",
      "motivated"
    ],
    "when": "Offer this at the start of a week when a member is building a weekly recovery routine."
  },
  "halt-check": {
    "skill": "Checking if you're hungry, angry, lonely, or tired",
    "needs": [
      "I have a craving and don't know why",
      "I feel off but can't tell what's wrong",
      "something's bothering me and I can't name it",
      "I want to use but I'm not sure what's driving it",
      "I feel bad and don't know the cause"
    ],
    "states": [
      "craving",
      "unsettled",
      "tired"
    ],
    "when": "Offer this when a member reports a craving or bad mood without a clear cause, to check basic unmet needs."
  },
  "wind-down-rehearsal": {
    "skill": "Practicing the hour before bed",
    "needs": [
      "I can't sleep",
      "I don't have a bedtime routine",
      "my nights feel chaotic",
      "I need to wind down better before bed",
      "I lie awake because my mind won't slow down"
    ],
    "states": [
      "restless",
      "tired",
      "wired"
    ],
    "when": "Offer this when a member struggles to fall asleep and needs a consistent wind-down routine."
  },
  "move-for-two-minutes": {
    "skill": "Changing your mood by moving your body for two minutes",
    "needs": [
      "I feel stuck in a bad mood",
      "I need to shift my energy",
      "I feel sluggish and low",
      "I want to feel different fast",
      "I've been sitting with this feeling too long"
    ],
    "states": [
      "low energy",
      "stuck",
      "restless"
    ],
    "when": "Offer this when a member is in a low or stuck mood and could benefit from quick movement."
  },
  "warning-signs": {
    "skill": "Checking for the early signs that show up before relapse",
    "needs": [
      "I'm worried I might relapse",
      "I don't know if I'm slipping",
      "I feel like something is off with my recovery",
      "I want to check in on my warning signs",
      "I feel like I'm sliding backward"
    ],
    "states": [
      "worried",
      "uneasy",
      "self-aware"
    ],
    "when": "Offer this when a member expresses concern they might be slipping and wants an honest check-in."
  },
  "spot-the-chain-link": {
    "skill": "Finding where you usually get stuck in the chain to relapse",
    "needs": [
      "I keep ending up in the same bad spot",
      "I want to understand my usual pattern before relapse",
      "I keep getting surprised by how I end up close to using",
      "I need to find where I can interrupt this earlier",
      "relapse feels like it sneaks up on me"
    ],
    "states": [
      "reflective",
      "worried",
      "determined"
    ],
    "when": "Offer this when a member wants to understand their personal relapse pattern to catch it earlier."
  },
  "play-the-tape-forward": {
    "skill": "Playing the whole story forward, not just the good first minute",
    "needs": [
      "I keep thinking about how good using would feel",
      "a using thought only shows me the good part",
      "I need to remember what happens after",
      "I'm romanticizing using right now",
      "I want to think this through all the way"
    ],
    "states": [
      "craving",
      "tempted",
      "reflective"
    ],
    "when": "Offer this when a member is fixating on the appealing first moment of using and needs the fuller picture."
  },
  "plan-my-exit": {
    "skill": "Rehearsing your way out before you walk into a risky place",
    "needs": [
      "I have to go somewhere risky",
      "I'm nervous about being around triggers",
      "I want an exit plan before I go",
      "I need to know how I'll leave if things get bad",
      "I'm heading into a situation that could be risky"
    ],
    "states": [
      "anxious",
      "preparing",
      "at risk"
    ],
    "when": "Offer this before a member enters a high-risk situation, so they have an exit rehearsed."
  },
  "return-to-basics": {
    "skill": "Rehearsing the basic things that always help after a hard stretch",
    "needs": [
      "I've had a really hard stretch",
      "I don't know how to get back on track",
      "things have fallen apart a bit",
      "I need to get back to what works",
      "I feel like I've lost my footing"
    ],
    "states": [
      "discouraged",
      "overwhelmed",
      "hopeful"
    ],
    "when": "Offer this when a member has had a rough patch and needs a simple way back to their basics."
  },
  "three-good-things": {
    "skill": "Replaying three good things from the day on purpose",
    "needs": [
      "today felt like a bad day",
      "I only remember the hard parts of today",
      "I need to end the day on something positive",
      "I want to notice the good moments too",
      "today was rough but I know it wasn't all bad"
    ],
    "states": [
      "discouraged",
      "tired",
      "reflective"
    ],
    "when": "Offer this at the end of the day when a member is fixated on what went wrong."
  },
  "look-how-far": {
    "skill": "Picturing where you started, then where you are now",
    "needs": [
      "I don't feel like I've made any progress",
      "I forget how far I've come",
      "I need to see my growth clearly",
      "today feels hard and I've lost sight of my progress",
      "I want to compare day one to today"
    ],
    "states": [
      "discouraged",
      "doubtful",
      "reflective"
    ],
    "when": "Offer this when a member feels stuck or discouraged and has lost sight of how far they've actually come."
  }
};
