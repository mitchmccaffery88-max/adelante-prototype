// Plug-and-play guided exercises for the "When Recovery Gets Hard" mission
// and related Building My Support Team library topics.
// Tap Start, follow timed steps, nothing to type.
import type { Exercise } from "./exercises";

type G = Omit<Exercise, "type" | "content"> & {
  steps: [string, number][];
  closing: string;
  why?: string;
  scene?: string;
  tagline?: string;
};

const g = ({ steps, closing, why, scene, tagline, ...rest }: G): Exercise => ({
  ...rest,
  type: "guided",
  content: { kind: "guided", why, scene, tagline, steps: steps.map(([say, secs]) => ({ say, secs })), closing },
});

export const GUIDED_WHEN_HARD: Exercise[] = [
  g({
    id: "picture-the-call",
    title: "Picture the Call",
    subtitle: "Rehearse reaching out before you need to",
    minutes: 1, tags: ["support"],
    purpose: "A call you've practiced is easier to make when things get loud.",
    why: "A call you've practiced is easier to make when things get loud.",
    steps: [
      ["Open your phone. Find your first person.", 10],
      ["Picture pressing call.", 8],
      ["Say your first line: \"Hey, it's me. I'm having a rough time. Can you talk?\"", 12],
      ["No answer? Picture going to the next person on your list.", 10],
      ["Still no answer? Picture texting your peer specialist, or calling 988.", 12],
      ["Say: \"Call before it gets loud.\"", 8],
    ],
    closing: "Practice the call now so it's automatic later. Call before the craving or the feeling gets loud.",
    tagline: "Call before it gets loud.",
  }),
  {"id": "spot-the-chain-link", "title": "Spot the Chain Link", "subtitle": "Catch a relapse on the first rung", "minutes": 1, "tags": ["relapse-prevention"], "purpose": "Relapse usually starts in your emotions, then your thinking, long before you use. Catching it early is easier.", "type": "guided", "content": {"kind": "guided", "why": "Relapse usually starts in your emotions, then your thinking, long before you use. Catching it early is easier.", "tagline": "Catch it on the first rung.", "closing": "Most relapses start weeks before using. Watch the first rung.", "steps": [{"say": "Take a slow breath. You can skip any step.", "secs": 8}, {"say": "Rung one, emotional: you're bottling things up, isolating, skipping self-care. You're not thinking about using yet.", "secs": 15}, {"say": "Rung two, mental: part of you wants to use. You think about old times, or plan a \"safe\" way.", "secs": 15}, {"say": "Rung three, physical: you go get it.", "secs": 8}, {"say": "Where would you most likely catch it? The earlier the rung, the easier the catch.", "secs": 12}, {"say": "One more slow breath. Say: \"Catch it on the first rung.\"", "secs": 8}]}},
  {"id": "play-the-tape-forward", "title": "Play the Tape Forward", "subtitle": "See past the fantasy", "minutes": 1, "tags": ["craving", "relapse-prevention"], "purpose": "Cravings show you the first five minutes. Playing the tape forward shows you the rest.", "type": "guided", "content": {"kind": "guided", "why": "Cravings show you the first five minutes. Playing the tape forward shows you the rest.", "tagline": "Play the tape to the end.", "closing": "The craving only shows you the start. You know how the story ends.", "steps": [{"say": "Notice the fantasy: the first hit, the first drink, the relief.", "secs": 10}, {"say": "Now keep the tape rolling. One hour later. Where are you? How do you feel?", "secs": 15}, {"say": "The next morning. Who are you texting? What are you hiding?", "secs": 15}, {"say": "A month later. Your job, your family, your PO, your kids.", "secs": 15}, {"say": "Now picture the other tape: you didn't use. Where are you a month from now?", "secs": 12}, {"say": "Say: \"Play the tape to the end.\"", "secs": 6}]}},
  {"id": "plan-my-exit", "title": "Plan My Exit", "subtitle": "Know your exit before you enter", "minutes": 1, "tags": ["relapse-prevention"], "purpose": "High-risk events are easier when your way out is planned before you arrive.", "type": "guided", "content": {"kind": "guided", "why": "High-risk events are easier when your way out is planned before you arrive.", "scene": "Your family is having a cookout. There will be drinking.", "tagline": "Know your exit before you enter.", "closing": "You can go to hard events. Just know how you're leaving before you walk in.", "steps": [{"say": "Before you go: how will you get home? Your own ride, not someone else's.", "secs": 12}, {"say": "Your leave line: \"I've got an early morning. I'm heading out.\"", "secs": 10}, {"say": "Your sober buddy: someone to text, or bring with you.", "secs": 10}, {"say": "At the event: hold your own drink, a soda or water, all night.", "secs": 10}, {"say": "The moment it feels risky, use your line and go. No goodbye tour.", "secs": 12}, {"say": "Say: \"Know your exit before you enter.\"", "secs": 6}]}},
  {"id": "return-to-basics", "title": "Return to Basics", "subtitle": "Restart today", "minutes": 1, "tags": ["relapse-prevention"], "purpose": "After a slip, you don't need a big plan. You need the basics, today.", "type": "guided", "content": {"kind": "guided", "why": "After a slip, you don't need a big plan. You need the basics, today.", "tagline": "Back to basics, today.", "closing": "Day one isn't a punishment. It's a decision you make again, today.", "steps": [{"say": "Drink a glass of water.", "secs": 10}, {"say": "Eat a real meal today.", "secs": 8}, {"say": "Find one meeting you can get to today, in person or online.", "secs": 12}, {"say": "Make one call: your sponsor, Devon or your counselor.", "secs": 10}, {"say": "Sleep tonight at a normal time.", "secs": 8}, {"say": "Say: \"Back to basics, today.\"", "secs": 6}]}},
];
