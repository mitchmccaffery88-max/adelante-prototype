// Fallback "My If–Then Plan" content for Library lessons.
// PLACEHOLDER COPY — lesson content in if-then-content.ts (IF_THEN_CONTENT) now overrides these;
// these defaults only apply to a lesson with no entry there and no topic-level `ifThen`.
import type { IfThenConfig, ToolFlowStep } from "./module-schema";
import { IF_THEN_CONTENT, BACKUP_ACTIONS } from "./if-then-content";
import { RECOVERY_IF_THEN_CONTENT } from "./recovery-if-then-content";
export { RECOVERY_IF_THEN_CONTENT } from "./recovery-if-then-content";

/** Shown on every backup line for high-risk lessons. Opens the existing Get Help screen. */
export const CRISIS_BACKUP = "Get crisis support now";

export const DEFAULT_BACKUPS = [BACKUP_ACTIONS.smaller, BACKUP_ACTIONS.people, BACKUP_ACTIONS.peer];

const GENERIC: IfThenConfig = {
  risk: "standard",
  cues: ["I start to feel stressed", "I feel stuck or behind", "I'm alone with nothing to do"],
  moves: ["Take 3 slow breaths", "Write down one next step", "Reach out to one person"],
  smallMoves: ["Take one slow breath"],
};

export const IF_THEN_DEFAULTS: Record<string, IfThenConfig> = {
  "starting-strong": { ...GENERIC, cues: ["I feel overwhelmed by everything I have to do", "I feel behind other people", "My day has no plan"], moves: ["Pick one task and do only that", "Look at my plan for today", "Call someone I trust"] },
  understanding: { ...GENERIC, cues: ["My symptoms start to get worse", "I feel like something is wrong with me", "I'm unsure about my diagnosis"], moves: ["Write down what I notice", "Ask my provider at my next visit", "Talk with someone I trust"] },
  treatment: { ...GENERIC, cues: ["I want to skip an appointment", "I forget my medication", "I feel like treatment isn't working"], moves: ["Call to reschedule instead of skipping", "Set a phone reminder", "Tell my provider how I feel"] },
  "train-mind": { ...GENERIC, cues: ["A harsh thought about myself shows up", "My mind starts racing", "I expect the worst"], moves: ["Name the thought out loud", "Ask: is this a fact or a feeling?", "Do 5-4-3-2-1 grounding"] },
  "strengthen-recovery": { ...GENERIC, risk: "high", cues: ["A craving starts", "I'm around people who use", "I feel bored or lonely"], moves: ["Leave where I am", "Set a 20-minute timer and wait it out", "Text or call my support person"], smallMoves: ["Drink a glass of water", "Step outside for 2 minutes"] },
  "big-emotions": { ...GENERIC, risk: "high", cues: ["I feel anger rising", "I feel a wave of sadness", "I feel panic in my chest"], moves: ["Step away for a minute", "Take 3 slow breaths before I answer", "Name the feeling to myself"] },
  "support-team": { ...GENERIC, cues: ["I feel like I'm on my own", "I don't want to bother anyone", "I need help but don't ask"], moves: ["Send one short text", "Go to a meeting or group", "Message my peer specialist"] },
  "back-on-feet": { ...GENERIC, cues: ["A bill or form stresses me out", "I run out of food or money", "I miss a deadline"], moves: ["Make a list of what's due", "Call the office and ask", "Ask my case manager for help"] },
  "success-plan": { ...GENERIC, cues: ["I lose track of my goal", "Something gets in the way of my plan", "I feel like giving up"], moves: ["Read my goal again", "Pick one small step for today", "Talk it through with someone"] },
};

const sud = (cues: string[], moves: string[], smallMoves: string[], backups: string[]): IfThenConfig => ({ risk: "high", cues, moves, smallMoves, backups });

/** SUD Recovery Journey defaults, keyed by recovery module id. Never mixed with Library category defaults. */
export const RECOVERY_IF_THEN_DEFAULTS: Record<string, IfThenConfig> = {
  "first-days": sud(["A craving hits out of nowhere", "My body feels on edge", "I freeze and don't know what to do next"], ["Leave where I am and text my peer specialist", "Breathe out slower than I breathe in, 10 times", "Do one 10-minute task"], ["Drink a glass of water", "Put my feet flat on the floor"], [BACKUP_ACTIONS.craving, BACKUP_ACTIONS.people, BACKUP_ACTIONS.peer, BACKUP_ACTIONS.neverUseAlone]),
  "my-people": sud(["I feel alone", "I want to skip my meeting", "I need help but don't want to ask"], ["Text one person on my support list", "Go to a meeting, even if I'm late", "Message my peer specialist"], ["Send a one-line text", "Read my support list"], [BACKUP_ACTIONS.meeting, BACKUP_ACTIONS.people, BACKUP_ACTIONS.peer]),
  understanding: sud(["A using thought shows up", "I'm hungry, angry, lonely, or tired", "I end up near one of my triggers"], ["Say \"that's a using thought\" and wait 20 minutes", "Take care of the basic need first", "Leave the trigger behind"], ["Take 3 slow breaths", "Name the feeling to myself"], [BACKUP_ACTIONS.craving, BACKUP_ACTIONS.basics, BACKUP_ACTIONS.sponsor, BACKUP_ACTIONS.naloxone]),
  "everyday-life": sud(["My routine falls apart", "I'm bored with nothing to do", "I skip a meal or don't sleep"], ["Do the 10-minute version of my routine", "Do one thing from my Instead-Of list", "Eat something and drink water"], ["Stand up and stretch", "Put on music"], [BACKUP_ACTIONS.smaller, BACKUP_ACTIONS.basics, BACKUP_ACTIONS.peer]),
  relationships: sud(["Someone pushes my buttons", "Someone from the old life reaches out", "Guilt about the past hits me"], ["Pause before I answer", "Say no and leave", "Talk it through with my sponsor or peer"], ["Take one slow breath", "Step away for a minute"], [BACKUP_ACTIONS.stepAway, BACKUP_ACTIONS.sleepOnIt, BACKUP_ACTIONS.sponsor]),
  "life-that-works": sud(["A bill or form stresses me out", "I have cash and nothing to do", "I miss a ride or an appointment"], ["Make one call and ask for help", "Put money where it's hard to reach", "Call to reschedule right away"], ["Write down what's due", "Step outside for 2 minutes"], [BACKUP_ACTIONS.callTomorrow, BACKUP_ACTIONS.resources211, BACKUP_ACTIONS.caseManager]),
  "when-hard": sud(["I notice my warning signs", "I start missing the old days of using", "I slip"], ["Tell one safe person today", "Play the tape all the way forward", "Get safe first, then call my sponsor or peer"], ["Open my relapse prevention plan", "Step outside for 2 minutes"], [BACKUP_ACTIONS.readPlan, BACKUP_ACTIONS.people, BACKUP_ACTIONS.sponsor, BACKUP_ACTIONS.neverUseAlone]),
  "someone-new": sud(["I feel like the old me", "I doubt I can change", "I feel empty"], ["Ask what my future self would do", "Write down one piece of proof", "Do one thing that matters to me"], ["Read my vision card", "Name one strength"], [BACKUP_ACTIONS.writeDown, BACKUP_ACTIONS.smaller, BACKUP_ACTIONS.peer]),
  "living-recovery": sud(["I start skipping the basics", "Life gets hard again", "I think I don't need meetings anymore"], ["Go back to my basics today", "Call my people", "Go to a meeting this week"], ["Check my three anchors", "Text my sponsor"], [BACKUP_ACTIONS.meeting, BACKUP_ACTIONS.readPlan, BACKUP_ACTIONS.sponsor]),
};

/** Prefix that marks a SUD Recovery Journey module id passed as `categoryId`. */
export const RECOVERY_PREFIX = "recovery:";

/**
 * Plan content for a lesson. Library: IF_THEN_CONTENT[lessonId] → topic `ifThen` → category default.
 * SUD ("recovery:<moduleId>"): RECOVERY_IF_THEN_CONTENT[lessonId] → RECOVERY_IF_THEN_DEFAULTS[moduleId]; never Library defaults.
 */
export function resolveIfThen(categoryId: string, lessonId?: string, own?: IfThenConfig): Required<Pick<IfThenConfig, "backups">> & IfThenConfig {
  const base = categoryId.startsWith(RECOVERY_PREFIX)
    ? (lessonId ? RECOVERY_IF_THEN_CONTENT[lessonId] : undefined) ?? RECOVERY_IF_THEN_DEFAULTS[categoryId.slice(RECOVERY_PREFIX.length)] ?? RECOVERY_IF_THEN_DEFAULTS["first-days"]!
    : (lessonId ? IF_THEN_CONTENT[lessonId] : undefined) ?? own ?? IF_THEN_DEFAULTS[categoryId] ?? GENERIC;
  return { ...base, backups: base.backups?.length ? base.backups : DEFAULT_BACKUPS };
}

export const IF_THEN_IDS = { cue: "ifthen-cue", move: "ifthen-move", backup: "ifthen-backup" } as const;

/** Pseudo tool steps so Adel's existing SUGGEST lines can draft an IF cue and THEN move. */
export function ifThenSuggestionSteps(c: IfThenConfig): ToolFlowStep[] {
  return [
    { id: IF_THEN_IDS.cue, title: "My If–Then Plan — IF (the moment)", instruction: "Pick one.", maxPicks: 1, options: c.cues },
    { id: IF_THEN_IDS.move, title: "My If–Then Plan — THEN I WILL (my move)", instruction: "Pick one.", maxPicks: 1,
      options: [...new Set([...c.moves, ...(c.cantLeave ?? []), ...(c.smallMoves ?? [])])] },
  ];
}
