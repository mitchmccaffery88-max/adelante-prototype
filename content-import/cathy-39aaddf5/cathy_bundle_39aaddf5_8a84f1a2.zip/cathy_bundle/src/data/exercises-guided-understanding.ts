// Plug-and-play guided exercises written for the "Understanding My Addiction"
// Recovery Journey mission. Tap Start, follow timed steps, nothing to type.
import type { Exercise } from "./exercises";

type G = Omit<Exercise, "type" | "content"> & {
  steps: [string, number][];
  closing: string;
};

const g = ({ steps, closing, ...rest }: G): Exercise => ({
  ...rest,
  type: "guided",
  content: { kind: "guided", steps: steps.map(([say, secs]) => ({ say, secs })), closing },
});

export const GUIDED_UNDERSTANDING: Exercise[] = [
  g({
    id: "spot-the-setup",
    title: "Spot the Setup",
    subtitle: "See a trigger coming before it lands",
    minutes: 2, tags: ["triggers", "craving"],
    purpose: "Triggers feel like ambushes, but most have a pattern. Rehearse spotting one before it catches you off guard.",
    steps: [
      ["Picture a place, person, or moment that usually sets you off. Just picture it, don't relive it.", 15],
      ["Notice the first small sign your body gives you — tight chest, racing mind, wanting to leave.", 15],
      ["Say out loud: \"There it is. I see the setup.\"", 10],
      ["Picture yourself taking one step back, physically or in your mind.", 12],
      ["Picture yourself doing your next right move instead — walking away, calling someone, or just breathing.", 15],
      ["Say: \"Seeing it coming is half of handling it.\"", 10],
    ],
    closing: "You just rehearsed catching a trigger early. That's the skill that makes the next one smaller.",
  }),
  {"id": "halt-check", "title": "HALT Check", "subtitle": "Hungry, angry, lonely, tired?", "minutes": 1, "tags": ["craving"], "type": "guided", "adel": {"skill": "checking basic needs that fuel cravings", "needs": ["I'm craving and don't know why", "I'm cranky and want to use", "I feel off"], "states": ["craving", "irritable", "drained"], "when": "Offer when a member reports a craving or bad mood without a clear trigger."}, "purpose": "From 12-Step recovery. Cravings hit harder when a basic need isn't met.", "content": {"kind": "guided", "steps": [{"say": "Quick check. Four letters.", "secs": 4}, {"say": "H: Hungry? When did you last eat?", "secs": 10}, {"say": "A: Angry? Is something bugging you?", "secs": 10}, {"say": "L: Lonely? When did you last talk to someone?", "secs": 10}, {"say": "T: Tired? How did you sleep?", "secs": 10}, {"say": "Which one is highest right now?", "secs": 8}, {"say": "Fix that one first: eat, cool off, call someone or rest.", "secs": 12}, {"say": "Say: \"Hungry, angry, lonely, tired?\"", "secs": 6}], "why": "From 12-Step recovery. Cravings hit harder when a basic need isn't met.", "closing": "When a craving hits, run HALT first. The fix might be a sandwich or a nap.", "tagline": "Hungry, angry, lonely, tired?"}},
];
