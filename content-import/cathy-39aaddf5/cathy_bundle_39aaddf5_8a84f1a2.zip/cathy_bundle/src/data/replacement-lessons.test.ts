import test from "node:test";
import assert from "node:assert/strict";
import { LIBRARY } from "./library";
import { findRecoveryLesson } from "./recovery";
import { getRecoverySixStepModule } from "./recovery-module-schema";
import { getSelfHelpModule } from "./module-schema";
import { getExercise } from "./exercises";
import { PART_A_INDEX } from "./exercise-adel";
import { NEED_ENTRIES } from "./needs-map";
import { resolveIfThen, CRISIS_BACKUP } from "./if-then-defaults";
import { BACKUP_ACTIONS, IF_THEN_CONTENT } from "./if-then-content";
import { SUPERVISION_SLIP } from "./care-notes";
import { findNeedMatches } from "@/lib/needs-match";

const lessons = [
  { category: "understanding", id: "understanding-3", exercise: "call-give-stay", maxPicks: [2, 2, 1, 1, 1], seconds: [10, 10, 12, 12, 15, 10, 6], tags: ["meds", "craving", "safety"], backups: [BACKUP_ACTIONS.neverUseAlone, BACKUP_ACTIONS.naloxone, BACKUP_ACTIONS.peer] },
  { category: "big-emotions", id: "grief-loss", exercise: "a-place-for-the-loss", maxPicks: [3, 3, 2, 2, 1], seconds: [6, 15, 10, 20, 12, 10, 8], tags: ["low-mood", "family", "craving"], backups: [BACKUP_ACTIONS.writeDown, BACKUP_ACTIONS.safetyPlan, BACKUP_ACTIONS.peer, BACKUP_ACTIONS.therapy] },
  { category: "when-hard", id: "when-hard-9", exercise: "steady-before-the-call", maxPicks: [1, 1, 2, 2, 2], seconds: [6, 15, 10, 12, 10, 6], exerciseMinutes: 1, tags: ["slip", "shame", "safety"], backups: [BACKUP_ACTIONS.people, BACKUP_ACTIONS.peer, BACKUP_ACTIONS.legalAid, BACKUP_ACTIONS.neverUseAlone] },
];

for (const rule of lessons) {
  const library = rule.id === "grief-loss";
  test(`${rule.id} lasts 8 minutes with four steps and the supplied pick limits`, () => {
    const mod = library ? getSelfHelpModule(rule.category, rule.id) : getRecoverySixStepModule(rule.category, rule.id);
    assert.ok(mod);
    assert.equal(mod.minutes, 8);
    assert.deepEqual(mod.skill.steps.map(step => step.maxPicks), rule.maxPicks);
    assert.equal(mod.exerciseId, rule.exercise);
    if (!library) assert.equal(findRecoveryLesson(rule.category, rule.id)?.lesson.minutes, 8);
  });
  test(`${rule.id} launches a two-minute guided exercise with the supplied timings`, () => {
    const exercise = getExercise(rule.exercise);
    assert.ok(exercise);
    assert.equal(exercise.minutes, (rule as { exerciseMinutes?: number }).exerciseMinutes ?? 2);
    assert.equal(exercise.type, "guided");
    assert.equal(exercise.content.kind, "guided");
    if (exercise.content.kind !== "guided") return;
    assert.deepEqual(exercise.content.steps.map(step => step.secs), rule.seconds);
    assert.equal(PART_A_INDEX.find(entry => entry.submoduleId === rule.id)?.exerciseId, rule.exercise);
  });
  test(`${rule.id} has a high-risk plan with ordered backups and no stored crisis chip`, () => {
    const plan = resolveIfThen(library ? rule.category : `recovery:${rule.category}`, rule.id);
    assert.equal(plan.risk, "high");
    assert.equal(plan.backups.includes(CRISIS_BACKUP), false);
    assert.deepEqual(plan.backups, rule.backups);
    assert.equal(plan.cues.length, 5);
    assert.equal(plan.moves.length, 5);
    assert.equal(plan.smallMoves?.length, 2);
  });
  test(`${rule.id} uses the supplied need tags`, () => {
    assert.deepEqual(NEED_ENTRIES.find(entry => entry.lessonId === rule.id)?.needTags, rule.tags);
  });
}

test("grief-loss is last in Managing Big Emotions and old completion IDs do not hide it", () => {
  const items = LIBRARY.find(category => category.id === "big-emotions")?.items;
  assert.equal(items?.at(-1)?.id, "grief-loss");
  assert.equal(items?.some(item => item.id === "respond-not-react"), false);
  assert.equal(IF_THEN_CONTENT["respond-not-react"], undefined);
  assert.equal(getSelfHelpModule("big-emotions", "respond-not-react"), null);
  assert.ok(findNeedMatches("grief loss sadness", { completedLessonIds: ["respond-not-react"] }).some(entry => entry.lessonId === "grief-loss"));
});

test("when-hard-9 carries the shared supervision slip note", () => {
  assert.deepEqual(getRecoverySixStepModule("when-hard", "when-hard-9")?.careNote, SUPERVISION_SLIP);
});

test("the requested dirty-test phrase recommends when-hard-9", () => {
  assert.equal(findNeedMatches("my test is going to be dirty")[0]?.lessonId, "when-hard-9");
});