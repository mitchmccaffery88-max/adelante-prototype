export type CareNote = { title: string; body: string; links?: { label: string; action: string }[] };
export type LessonCareNotes = CareNote | CareNote[];

export const COURT_ORDER: CareNote = {
  title: "Before you reach out",
  body: "If a court order, a restraining order, or a condition of your probation or parole limits contact with someone, reaching out can be a violation, even to apologize. Check with your officer or attorney first. Some amends are made by how you live now, not by contacting the person.",
  links: [{ label: "Legal help", action: "resource:Legal Services" }],
};
export const ASSOCIATION: CareNote = {
  title: "Check your terms",
  body: "Some probation and parole terms limit who you can be around or where you can go. If you're not sure what yours say, ask your officer or case manager before you spend time with someone from the past.",
};
export const DV: CareNote = {
  title: "If someone is hurting or controlling you",
  body: "If someone hits you, threatens you, or controls where you go, your money, or who you talk to, that isn't a conflict to fix with better words. It's abuse, and it isn't your fault. You can get confidential help any time.",
  links: [{ label: "Call the National DV Hotline", action: "tel:18007997233" }, { label: "Safe shelter nearby", action: "resource:Emergency Shelter" }],
};
export const CWS: CareNote = {
  title: "If there's a case or court order about your kids",
  body: "If you have an open child welfare (CWS) case, or a custody or visitation order, follow its rules for calls and visits. Your CWS worker or attorney can tell you what's allowed. Showing up for every required step counts as rebuilding trust too.",
  links: [{ label: "Family & Reunification help", action: "resource:Family & Reunification" }],
};
export const SUPERVISION_SLIP: CareNote = {
  title: "If you're on probation or parole",
  body: "A slip can show up on a test. Talk with your counselor, peer specialist, or attorney about how to handle it with your officer. Getting back to treatment fast shows you're taking it seriously.",
  links: [{ label: "Message Devon", action: "screen:peer" }, { label: "Book a therapy visit", action: "screen:therapy" }],
};

export const STOPPING_SAFELY: CareNote = {
  title: "Stopping safely",
  body: "If you drink heavily every day or take pills like Xanax or Klonopin, stopping suddenly can cause seizures. Talk to a doctor or call the Tulare County SUD Access Line before you stop.",
  links: [{ label: "Call 1-866-732-4114", action: "tel:18667324114" }],
};

export const ANY_TIME_HELP: CareNote = {
  title: "Any time, day or night",
  body: "If you have thoughts of hurting yourself, call or text 988, or tap Crisis support. You don't have to wait for anything else.",
  links: [{ label: "Call or text 988", action: "tel:988" }, { label: "Crisis support", action: "screen:crisis" }],
};
export const MEDICINE_CONTINUITY: CareNote = {
  title: "Were you on medicine for addiction inside?",
  body: "If you got buprenorphine, methadone, or naltrexone inside, keep it going. Missing doses raises your overdose risk fast. Want to start? Medi-Cal covers it. Call the SUD Access Line or ask your clinic.",
  links: [{ label: "Call 1-866-732-4114", action: "tel:18667324114" }, { label: "Learn more", action: "lesson:Medicine, Tolerance, and Staying Alive" }],
};

export const LIBRARY_CARE_NOTES: Record<string, LessonCareNotes> = {
  repair: COURT_ORDER, "rebuild-trust": [COURT_ORDER, CWS], "difficult-relationships": [COURT_ORDER, DV],
  "positive-connections": ASSOCIATION, "recovery-choices": ASSOCIATION,
  boundaries: DV, "managing-conflict": DV, "one-bad-day": [SUPERVISION_SLIP, STOPPING_SAFELY], sud: STOPPING_SAFELY,
};
export const RECOVERY_CARE_NOTES: Record<string, LessonCareNotes> = {
  "relationships-1": COURT_ORDER, "relationships-4": COURT_ORDER, "relationships-8": COURT_ORDER, "relationships-10": COURT_ORDER,
  "relationships-6": ASSOCIATION, "relationships-7": ASSOCIATION, "living-recovery-6": ASSOCIATION,
  "relationships-2": DV, "relationships-3": DV, "relationships-5": CWS,
  "first-days-1": MEDICINE_CONTINUITY, "first-days-8": ANY_TIME_HELP,
  "first-days-5": [SUPERVISION_SLIP, STOPPING_SAFELY, MEDICINE_CONTINUITY], "when-hard-5": SUPERVISION_SLIP, "when-hard-6": [SUPERVISION_SLIP, STOPPING_SAFELY],
};