import { type LibraryCategory } from "./library-types";
import { LIBRARY_PART_A } from "./library-part-a";
import { LIBRARY_PART_B } from "./library-part-b";
import { LIBRARY_PART_C } from "./library-part-c";

export * from "./library-types";

export const LIBRARY: LibraryCategory[] = [...LIBRARY_PART_A, ...LIBRARY_PART_B, ...LIBRARY_PART_C];
