// Shared types for the Self-Help Learning Library.
// Every module follows the same 9-step evidence-based framework:
// Problem → Check-In → Learn → Interactive Experience → Adel → Insight →
// Today's Action → Measure Again → Save to Toolkit.

export type ActivityKind =
  | "card-sort"      // sort items into 2 buckets (e.g. Fact vs Story)
  | "decision-path"  // choose one option, see how it plays out
  | "sliders"        // adjust 2-3 sliders to reflect an inner state
  | "reflection"     // tap cards that resonate
  | "scenario"       // read a moment, pick a response
  | "timeline"       // arrange steps in order
  | "breathing"      // guided paced breathing
  | "grounding";     // 5-4-3-2-1 senses

export type Activity = {
  kind: ActivityKind;
  title: string;
  instruction: string;
  items?: string[];
  buckets?: [string, string];
  choices?: { label: string; feedback: string; good?: boolean }[];
  sliders?: { id: string; label: string; leftLabel: string; rightLabel: string }[];
  cards?: string[];
  steps?: string[];
};

export type LibraryItem = {
  id: string;
  title: string;
  minutes: number;
  problem: string;
  checkInCraving?: boolean;
  learnTitle: string;
  learnBody: string;
  activity: Activity;
  adelReflection: string;
  adelQuestion: string;
  insight: string;
  action: string;
  toolkitLabel: string;
};

export type LibraryCategory = {
  id: string;
  name: string;
  desc: string;
  icon: string;
  clinicalTarget: string;
  items: LibraryItem[];
};

// Legacy alias so existing imports don't break
export type LibraryItemType = ActivityKind;

export const sortBuckets = (a: string, b: string): [string, string] => [a, b];
