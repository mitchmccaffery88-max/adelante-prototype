// Plug-and-play guided exercises: tap Start, follow timed steps, nothing to type.
// New exercises supporting the "Healing My Relationships" recovery mission.
import type { Exercise } from "./exercises";

type G = Omit<Exercise, "type" | "content"> & {
  steps: [string, number][];
  closing: string;
};

const g = ({ steps, closing, ...rest }: G): Exercise => ({
  ...rest,
  type: "guided",
  content: { kind: "guided", steps: steps.map(([say, secs]) => ({ say, secs })), closing },
});

export const GUIDED_RELATIONSHIPS: Exercise[] = [
  g({
    id: "keep-one-promise",
    title: "Keep One Promise",
    subtitle: "Pick a small, doable promise to keep today",
    minutes: 1, tags: ["support", "communication"],
    purpose: "Trust rebuilds through small kept promises, not big words. Choose one thing you can actually follow through on today.",
    steps: [
      ["Think of one person whose trust you're rebuilding. Picture their face.", 12],
      ["Say out loud one small thing you could promise them today — a call, a text, showing up on time.", 15],
      ["Ask yourself: can I really do this one, no matter what? If not, pick a smaller one.", 15],
      ["Picture yourself doing it later today, exactly as planned.", 15],
      ["Say: \"Small and kept beats big and broken.\"", 10],
    ],
    closing: "You picked one promise you can actually keep. That's how trust comes back — one at a time.",
  }),
  g({
    id: "practice-the-no",
    title: "Practice the No",
    subtitle: "Say a boundary line without a long explanation",
    minutes: 1, tags: ["communication", "support"],
    purpose: "A short, kind no protects a relationship instead of hurting it. Practicing the line makes it easier to say when you're put on the spot.",
    steps: [
      ["Think of something you've had a hard time saying no to.", 10],
      ["Say out loud: \"I can't do that.\"", 10],
      ["Now add one kind line after it: \"But I care about you.\" or \"Let's find another way.\"", 15],
      ["Say the whole line again, calm and steady.", 12],
      ["Notice: you didn't need a long reason. Short was enough.", 12],
    ],
    closing: "That's your boundary line. Short, kind, and ready when you need it.",
  }),
];
