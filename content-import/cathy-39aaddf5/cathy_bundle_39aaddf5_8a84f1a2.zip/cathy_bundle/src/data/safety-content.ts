/**
 * Overdose-prevention safety content.
 *
 * CONTENT INTEGRITY: this is medical safety information. Nothing here is
 * AI-generated or freely written — every step and phone number below is
 * transcribed from a named clinical/public-health source (SAMHSA, CDC,
 * California DHCS Naloxone Distribution Project, Never Use Alone).
 *
 * Like the resource library, every item ships `verified: false` and is
 * flagged for clinical review before release.
 */

export type SourcedItem = {
  /** Named clinical source this text was taken from. */
  source: string;
  sourceUrl: string;
  /** Always false in prototype — pending clinical review sign-off. */
  verified: false;
};

export const NALOXONE_REVIEW_FLAG = {
  status: "pending-clinical-review" as const,
  note:
    "Overdose-prevention content is transcribed from SAMHSA, CDC and California DHCS materials. It must be reviewed and signed off by a licensed clinician, and every Tulare County location re-confirmed by phone, before release.",
};

/** Free / low-cost naloxone access points relevant to Tulare County, CA. */
export const NALOXONE_ACCESS: (SourcedItem & {
  id: string;
  name: string;
  what: string;
  city: string;
  phone: string;
  website: string;
  level: "county" | "state" | "national" | "pharmacy";
})[] = [
  {
    id: "nlx-tchhsa",
    name: "Tulare County Health & Human Services Agency",
    what: "County public health division — ask for the naloxone (Narcan) distribution program and overdose-prevention supplies.",
    city: "Visalia, CA",
    phone: "(559) 624-8000",
    website: "https://tchhsa.org",
    level: "county",
    source: "Tulare County HHSA public health program listing",
    sourceUrl: "https://tchhsa.org",
    verified: false,
  },
  {
    id: "nlx-fhcn",
    name: "Family HealthCare Network",
    what: "Community health centers across Visalia, Tulare, Porterville and Dinuba. Ask a clinic staff member about naloxone — no appointment needed to ask.",
    city: "Tulare County (multiple sites)",
    phone: "(877) 960-3426",
    website: "https://www.fhcn.org",
    level: "county",
    source: "Family HealthCare Network site directory",
    sourceUrl: "https://www.fhcn.org",
    verified: false,
  },
  {
    id: "nlx-ndp",
    name: "California Naloxone Distribution Project (DHCS)",
    what: "State program that supplies free naloxone to eligible organizations, including reentry, county and community programs. Your case manager or peer specialist can request it through this program.",
    city: "Statewide (California)",
    phone: "",
    website: "https://www.dhcs.ca.gov/individuals/Pages/Naloxone_Distribution_Project.aspx",
    level: "state",
    source: "California Department of Health Care Services (DHCS)",
    sourceUrl: "https://www.dhcs.ca.gov/individuals/Pages/Naloxone_Distribution_Project.aspx",
    verified: false,
  },
  {
    id: "nlx-pharmacy",
    name: "Any California pharmacy — no prescription needed",
    what: "California pharmacists can furnish naloxone without a prescription. Over-the-counter nasal naloxone is also sold directly off the shelf. Ask at the counter: \"Do you have naloxone?\"",
    city: "Anywhere in California",
    phone: "",
    website: "https://www.cdc.gov/overdose-prevention/reversing-overdose/index.html",
    level: "pharmacy",
    source: "CDC — Reversing an Overdose / California statewide standing order",
    sourceUrl: "https://www.cdc.gov/overdose-prevention/reversing-overdose/index.html",
    verified: false,
  },
  {
    id: "nlx-nextdistro",
    name: "NEXT Distro — naloxone by mail",
    what: "Mails free naloxone to people who can't get to a distribution site. Delivered in plain packaging.",
    city: "Nationwide (mail order)",
    phone: "",
    website: "https://nextdistro.org",
    level: "national",
    source: "NEXT Distro national mail-based naloxone program",
    sourceUrl: "https://nextdistro.org",
    verified: false,
  },
];

/** Plain-language administration steps, transcribed from SAMHSA/CDC guidance. */
export const NALOXONE_STEPS: { n: number; title: string; body: string }[] = [
  {
    n: 1,
    title: "Check if they respond",
    body:
      "Shout their name. Rub your knuckles hard on the center of their chest. If they don't wake up, treat it as an overdose. Signs: they won't wake up, breathing is slow or stopped, lips or fingertips look blue or gray, they're making a snoring or gurgling sound.",
  },
  {
    n: 2,
    title: "Call 911",
    body:
      "Say \"someone is not breathing.\" You do not have to say anything about drugs. California's 911 Good Samaritan law protects people who call for help at an overdose from being charged for simple possession. It may not protect you from a parole or probation violation. Call anyway. A life is worth it, and your attorney or peer specialist can help with what comes after.",
  },
  {
    n: 3,
    title: "Give naloxone",
    body:
      "Nasal spray: tilt their head back, put the nozzle all the way into one nostril, press the plunger firmly. That's the whole dose — one device, one spray.",
  },
  {
    n: 4,
    title: "Help them breathe",
    body:
      "If they aren't breathing, give rescue breaths — head tilted back, chin lifted, one breath every 5 seconds — or chest compressions if that's what you know how to do.",
  },
  {
    n: 5,
    title: "Give a second dose if nothing changes",
    body:
      "If they haven't woken up or started breathing after 2 to 3 minutes, give another dose in the other nostril. Keep going every 2 to 3 minutes until they respond or help arrives.",
  },
  {
    n: 6,
    title: "Stay with them",
    body:
      "Naloxone wears off in 30 to 90 minutes and the overdose can come back. Roll them onto their side so they don't choke. Don't leave them alone until paramedics get there.",
  },
];

export const NALOXONE_STEPS_SOURCE: SourcedItem = {
  source: "SAMHSA Opioid Overdose Prevention Toolkit; CDC — Reversing an Overdose",
  sourceUrl: "https://www.samhsa.gov/substance-use/treatment/overdose-prevention",
  verified: false,
};

/** Never-use-alone: a line you can actually call before you use. */
export const NEVER_USE_ALONE = {
  name: "Never Use Alone",
  phone: "1-800-484-3731",
  what:
    "A free, confidential national line. You call before you use, tell them where you are, and stay on the line. If you stop responding, they send emergency medical help to your address. Local dispatch decides who comes.",
  hours: "24 hours a day, every day",
  website: "https://neverusealone.com",
  source: "Never Use Alone Inc. — national overdose prevention lifeline",
  sourceUrl: "https://neverusealone.com",
  verified: false as const,
  /**
   * No Tulare County-specific never-use-alone line has been confirmed. Until
   * one is verified, this national line is what we surface.
   */
  localLineConfirmed: false,
};

export const TOLERANCE_WARNING =
  "If you've been locked up, in treatment, or off for even a few days, your tolerance has dropped. The amount that used to be normal for you can stop your breathing now. The first two weeks after release are the highest-risk stretch there is. If you're going to use, use less than you think you need, don't mix with alcohol or pills, and don't use alone.";

export const FENTANYL_WARNING = {
  title: "Fentanyl isn't only in heroin",
  body: "Fentanyl can be in meth, cocaine, and pills that look real. Carry naloxone even if you don't use opioids. Fentanyl test strips can check drugs before use; ask your clinic or a harm reduction program for them.",
  source: "CDC fentanyl facts",
  sourceUrl: "https://www.cdc.gov/overdose-prevention/about/fentanyl.html",
  verified: false,
} satisfies SourcedItem & { title: string; body: string };
