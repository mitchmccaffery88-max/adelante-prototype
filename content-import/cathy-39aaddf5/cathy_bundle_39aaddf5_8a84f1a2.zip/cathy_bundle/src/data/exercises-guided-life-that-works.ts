// Guided exercises for the "Building a Life That Works" recovery mission.
import type { Exercise } from "./exercises";

type G = Omit<Exercise, "type" | "content"> & {
  steps: [string, number][];
  closing: string;
};

const g = ({ steps, closing, ...rest }: G): Exercise => ({
  ...rest,
  type: "guided",
  content: { kind: "guided", steps: steps.map(([say, secs]) => ({ say, secs })), closing },
});

export const GUIDED_LIFE_THAT_WORKS: Exercise[] = [
  g({
    id: "waiting-room-breath",
    title: "Waiting Room Breathing",
    subtitle: "Settle your body before the appointment",
    minutes: 2, tags: ["anxiety"],
    purpose: "Health appointments can bring up nerves, especially if you've avoided them before. Slow breathing helps your body settle while you wait.",
    steps: [
      ["Sit with your feet flat on the floor.", 8],
      ["Breathe in for four counts.", 8],
      ["Breathe out for six counts.", 8],
      ["Do that four more times, slower each time.", 30],
      ["Say to yourself: \"Taking care of my body is part of my recovery.\"", 10],
    ],
    closing: "Your body is a little steadier now. You can carry that into the appointment.",
  }),
  g({
    id: "one-call-warmup",
    title: "Warm Up the Call",
    subtitle: "Say your opening line first",
    minutes: 1, tags: ["support", "communication"],
    purpose: "The hardest part of calling a resource is the first sentence. Practicing it once out loud makes the real call easier.",
    steps: [
      ["Think of the resource or agency you need to call.", 10],
      ["Say out loud: \"Hi, my name is ___, and I'm looking for help with ___.\"", 15],
      ["Picture them asking a question. Practice answering calmly.", 15],
      ["Say: \"Can you tell me what I need to bring?\"", 12],
      ["Picture yourself hanging up, having gotten one piece of information.", 10],
    ],
    closing: "You already said the hardest sentence once. The real call is just saying it again.",
  }),
  g({
    id: "tuesday-one-year",
    title: "My Tuesday, One Year From Now",
    subtitle: "Picture an ordinary good day",
    minutes: 2, tags: ["goal-setting"],
    purpose: "A big future can feel foggy. Picturing one normal, ordinary day makes it feel real and worth working toward.",
    steps: [
      ["Picture waking up on an ordinary Tuesday, one year from now.", 12],
      ["Where are you? What does the room look like?", 12],
      ["What do you do first? Notice the small details.", 12],
      ["Who do you see or talk to that day?", 12],
      ["What do you do for work or purpose that day?", 12],
      ["Say out loud one detail you want to be true.", 12],
    ],
    closing: "That Tuesday is built one step at a time, starting with today.",
  }),
];
