import test from "node:test";
import assert from "node:assert/strict";
import { getExercise } from "./exercises";
import { LIBRARY_TOPICS } from "./topic-content";
import { IF_THEN_CONTENT } from "./if-then-content";
import { namedLessonTarget } from "@/lib/lesson-tools";

const lessons: { id: string; exerciseId: string; toolName: string; partB: string | null; limits: number[] }[] = [{"id": "thoughts-wont-stop", "exerciseId": "solving-or-spinning", "toolName": "Loop Breaker", "partB": null, "limits": [3, 2, 3, 1]}, {"id": "fact-story", "exerciseId": "camera-test", "toolName": "Fact Check", "partB": null, "limits": [1, 1, 2, 2, 1]}, {"id": "thinking-traps", "exerciseId": "name-that-trap", "toolName": "Trap Spotter", "partB": null, "limits": [3, 3, 2, 2]}, {"id": "inner-voice", "exerciseId": "best-friend-test", "toolName": "Coach's Corner", "partB": null, "limits": [3, 1, 3, 1, 2]}, {"id": "worry-cycle", "exerciseId": "worst-best-likely", "toolName": "Odds Check", "partB": null, "limits": [1, 1, 1, 3, 1]}, {"id": "bigger-picture", "exerciseId": "three-other-reasons", "toolName": "Wide Angle", "partB": null, "limits": [1, 1, 3, 3, 1]}, {"id": "confidence-decisions", "exerciseId": "ten-ten-ten", "toolName": "Decision Playbook", "partB": null, "limits": [1, 3, 3, 1, 1]}, {"id": "letting-go-shame", "exerciseId": "did-not-am", "toolName": "Shame to Repair", "partB": null, "limits": [2, 1, 1, 2, 2]}, {"id": "solving-problems", "exerciseId": "say-it-list-three-take-one", "toolName": "Problem Breaker", "partB": null, "limits": [1, 3, 1, 1, 1]}, {"id": "resilient-mindset", "exerciseId": "comeback-story", "toolName": "Comeback Kit", "partB": null, "limits": [3, 1, 3, 2, 1]}, {"id": "want-to-use", "exerciseId": "count-by-sevens", "toolName": "Urge Profile", "partB": null, "limits": [3, 3, 2, 1, 3]}, {"id": "recovery-choices", "exerciseId": "spot-the-small-choice", "toolName": "Chain Breaker", "partB": null, "limits": [1, 4, 1, 2]}, {"id": "stress-without-using", "exerciseId": "tipp", "toolName": "Relief Menu", "partB": null, "limits": [3, 3, 2, 2, 1]}, {"id": "one-bad-day", "exerciseId": "comeback-rehearsal", "toolName": "Setback Debrief", "partB": null, "limits": [1, 4, 2, 2, 2]}, {"id": "recovery-toolbox", "exerciseId": "run-the-toolbox", "toolName": "3-2-1 Toolbox", "partB": null, "limits": [3, 2, 1, 1]}, {"id": "recovery-support-system", "exerciseId": "reverse-the-roles", "toolName": "Support Lineup", "partB": null, "limits": [1, 1, 1, 1, 1]}, {"id": "who-i-want", "exerciseId": "toward-or-away", "toolName": "True North", "partB": null, "limits": [3, 3, 3, 1, 3]}, {"id": "understanding-emotions", "exerciseId": "check-the-facts", "toolName": "Feelings Decoder", "partB": null, "limits": [2, 2, 2, 1, 2]}, {"id": "anger-signs", "exerciseId": "push-the-wall-check", "toolName": "Anger Thermometer", "partB": "anger-thermometer", "limits": []}, {"id": "choose-response", "exerciseId": "two-timelines", "toolName": "React or Respond", "partB": null, "limits": [3, 2, 3, 2]}, {"id": "managing-conflict", "exerciseId": "reflect-first", "toolName": "Fair Fight Rules", "partB": null, "limits": [4, 1, 3, 2]}, {"id": "communicating-upset", "exerciseId": "fact-feeling-ask", "toolName": "Say-It Script", "partB": null, "limits": [1, 1, 1, 1, 1]}, {"id": "emotional-strength", "exerciseId": "please-check", "toolName": "Fuel Gauge", "partB": null, "limits": [1, 1, 1, 2, 1]}, {"id": "grief-loss", "exerciseId": "a-place-for-the-loss", "toolName": "Carrying the Loss", "partB": null, "limits": [3, 3, 2, 2, 1]}, {"id": "triggers", "exerciseId": "turn-walk-call", "toolName": "Trigger Clean Sweep", "partB": null, "limits": [3, 3, 3, 2, 6]}, {"id": "surfing", "exerciseId": "urge-surfing", "toolName": "Surf Log", "partB": null, "limits": [1, 1, 1, 3, 1]}, {"id": "motivation", "exerciseId": "readiness-ruler", "toolName": "Reasons Why", "partB": null, "limits": [5, 3, 1, 1]}, {"id": "explode", "exerciseId": "hand-brake", "toolName": "Reaction Replay", "partB": null, "limits": [1, 1, 3, 1, 2]}, {"id": "pause", "exerciseId": "time-out-done-right", "toolName": "Pause Button", "partB": null, "limits": [1, 2, 3, 1, 1]}, {"id": "repair", "exerciseId": "three-part-repair", "toolName": "Repair Kit", "partB": null, "limits": [1, 1, 2, 1, 1]}];

for (const expected of lessons) {
  test(`${expected.id}: Part A and Part B content`, () => {
    const topic = LIBRARY_TOPICS[expected.id];
    assert.ok(topic);
    assert.equal(topic.exerciseId, expected.exerciseId);
    const exercise = getExercise(expected.exerciseId);
    assert.ok(exercise && exercise.content.kind === "guided");
    if (exercise.content.kind !== "guided") return;
    assert.ok(exercise.content.tagline);
    assert.ok(exercise.content.steps.reduce((t, s) => t + s.secs, 0) <= 120);
    assert.equal(topic.toolName, expected.toolName);
    assert.ok(topic.toolIntro);
    if (expected.partB) {
      assert.equal(topic.partBExerciseId, "anger-thermometer");
      assert.ok(getExercise("anger-thermometer"));
      return;
    }
    const steps = topic.skillSteps!;
    assert.ok(steps.length >= 3 && steps.length <= 5);
    assert.deepEqual(steps.map((s) => s.maxPicks), expected.limits);
    for (const step of steps) {
      if (step.optionsFrom) assert.deepEqual(step.options, steps.find((s) => s.id === step.optionsFrom)?.options);
      else assert.ok(step.options.length >= 3, `${expected.id}/${step.id}`);
    }
  });
  test(`${expected.id}: first move opens its Part A exercise`, () => {
    const topic = LIBRARY_TOPICS[expected.id]!;
    const plan = IF_THEN_CONTENT[expected.id];
    assert.equal(plan?.moves.length, 5);
    const target = namedLessonTarget(plan!.moves[0]!, { ...topic, lessonId: expected.id });
    assert.equal(target?.kind, "exercise");
    if (target?.kind === "exercise") assert.equal(target.exercise.id, expected.exerciseId);
  });
}

test("named matches from the batch", () => {
  const at = (id: string, move: string) => namedLessonTarget(move, { ...LIBRARY_TOPICS[id]!, lessonId: id });
  assert.equal(at("confidence-decisions", "Run 10-10-10")?.kind, "exercise");
  assert.equal(at("who-i-want", "Ask: Toward or Away?")?.kind, "exercise");
  assert.equal(at("explode", "Use the Hand Brake: press and breathe out for six")?.kind, "exercise");
  assert.equal(at("anger-signs", "Check my Anger Thermometer for my move")?.kind, "tool");
  assert.equal(namedLessonTarget("Do my 10-Second Check-In", { exerciseId: "ten-second-check-in" })?.kind, "exercise");
});

