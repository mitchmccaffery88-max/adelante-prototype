// New Part A exercises for Group D slots.
// Palette: memory/association, if-then rehearsal, sorting-in-your-head,
// behavioral micro-practice, craving-specific skills (not urge surfing).
import type { Exercise } from "./exercises";

type G = Omit<Exercise, "type" | "content"> & {
  steps: [string, number][];
  closing: string;
};

const g = ({ steps, closing, ...rest }: G): Exercise => ({
  ...rest,
  type: "guided",
  content: { kind: "guided", steps: steps.map(([say, secs]) => ({ say, secs })), closing },
});

export const PARTA_D: Exercise[] = [
  // first-days-2 — "What Should I Do If I Want to Use?"
  {"id": "name-the-craving-voice", "title": "Name the Craving Voice", "subtitle": "Give the using voice a name", "minutes": 1, "tags": ["craving"], "type": "guided", "purpose": "From SMART Recovery. Naming the using voice helps you see it as separate from you.", "content": {"kind": "guided", "steps": [{"say": "Notice the thought. That's the using voice.", "secs": 8}, {"say": "Give it a name, like \"the salesman\" or \"the old me.\"", "secs": 10}, {"say": "Say: \"That's ___ talking.\"", "secs": 8}, {"say": "It always leaves something out. What? Tomorrow, the shame, what you'd lose.", "secs": 15}, {"say": "Answer it: \"I hear you. I'm not doing what you say.\"", "secs": 10}, {"say": "Say: \"That's the addiction talking.\"", "secs": 6}], "why": "From SMART Recovery. Naming the using voice helps you see it as separate from you.", "scene": "You're watching TV, and a thought slides in: \"One wouldn't hurt. You've been good.\"", "closing": "The voice will keep talking. You don't have to do what it says.", "tagline": "That's the addiction talking."}, "adel": {"skill": "Talking back to a craving instead of obeying it", "needs": ["I want to use right now", "This craving feels like it's in charge", "I don't know what to do when the urge hits", "It feels like this feeling won't stop", "I keep arguing with myself about using"], "states": ["craving", "urgent", "shaky", "torn"], "when": "Offer when a member describes an active urge to use and needs a fast, in-the-moment move rather than a plan for later."}},

  // first-days-7 — "Why Is Asking for Help So Hard?"
  g({
    id: "stand-tall-before-asking",
    title: "Stand Tall Before You Ask",
    subtitle: "A body practice, not a script",
    minutes: 1,
    tags: ["support", "communication"],
    purpose: "Your body can feel small before you ask for help, even before your mouth says anything. This practice changes your body first — nothing gets sent.",
    adel: {
      skill: "Using your body to feel steadier before asking for help",
      needs: [
        "Asking for help makes me feel weak",
        "I freeze up before I ask anyone for anything",
        "I feel small when I have to ask",
        "My chest gets tight thinking about asking",
        "I talk myself out of asking every time",
      ],
      states: ["nervous", "small", "hesitant", "tense"],
      when: "Offer when a member is dreading an upcoming ask and needs a body-based warm-up, separate from wording the request.",
    },
    steps: [
      ["Stand up, if you can. Feet flat on the floor, a little apart.", 10],
      ["Roll your shoulders back and let them drop.", 10],
      ["Lift your chin just slightly — not proud, just level.", 10],
      ["Put one hand flat on your chest and take one slow breath.", 12],
      ["Say out loud, plain and steady: \"I'm allowed to need something.\"", 12],
      ["Notice how your body feels now compared to when you sat down.", 12],
    ],
    closing: "You didn't ask anyone anything yet. You just practiced standing like someone who's allowed to ask.",
  }),

  // first-days-8 — "Why Do I Feel Like This?"
  {"id": "sort-body-or-story", "title": "Body or Story?", "subtitle": "Make sense of early-recovery feelings", "minutes": 1, "tags": ["cbt"], "type": "guided", "purpose": "Early recovery brings feelings from your body healing and from stories your head tells. Each needs something different.", "content": {"kind": "guided", "steps": [{"say": "Notice the feeling. Don't fix it yet.", "secs": 8}, {"say": "Ask: is this my body healing? Tired, irritable, foggy, achy?", "secs": 12}, {"say": "Or is it a story my head is telling? \"I'll never make it.\" \"Nobody cares.\"", "secs": 12}, {"say": "If it's body: eat, drink water, rest, move.", "secs": 10}, {"say": "If it's a story: notice it's a thought, not a fact.", "secs": 10}, {"say": "Early recovery brings a lot of both. It gets better as your body heals.", "secs": 10}, {"say": "Say: \"Some days it's just the healing.\"", "secs": 6}], "why": "Early recovery brings feelings from your body healing and from stories your head tells. Each needs something different.", "closing": "Ask \"body or story?\" whenever a mood hits out of nowhere.", "tagline": "Some days it's just the healing."}, "adel": {"skill": "Mentally sorting a feeling into body cause or story cause", "needs": ["My mood swings for no reason", "I don't know why I suddenly feel like this", "I went from fine to upset really fast", "I can't tell if I'm actually okay or not", "I get irritated over nothing"], "states": ["moody", "confused", "irritable", "unsettled"], "when": "Offer when a member notices a sudden mood shift in early recovery and wants a quick way to make sense of it, not a full check-in."}},

  // first-days-9 — "How Can I End Today Strong?"

  // first-days-10 — "I Made It Through My First Week."
  {"id": "find-the-proof", "title": "Find the Proof", "subtitle": "See what you got through this week", "minutes": 1, "tags": ["goal-setting"], "type": "guided", "purpose": "A week is easy to blur past. Finding real moments you got through makes the win count.", "content": {"kind": "guided", "steps": [{"say": "Let this week play back in your head.", "secs": 12}, {"say": "Stop on one hard moment you got through.", "secs": 12}, {"say": "What did you do to get through it?", "secs": 15}, {"say": "Find one more.", "secs": 12}, {"say": "That's proof. Not a hope. Something that really happened.", "secs": 10}, {"say": "Say: \"I got through a week. That's proof.\"", "secs": 6}], "why": "A week is easy to blur past. Finding real moments you got through makes the win count.", "closing": "Every week you get through adds to the proof. Keep counting.", "tagline": "I got through a week. That's proof."}, "adel": {"skill": "Recalling one specific proof moment from a recent stretch of recovery", "needs": ["I made it a week but it doesn't feel like a big deal", "I don't feel like I've actually done anything", "I can't point to anything that shows I'm changing", "This week feels like a blur", "I want proof I'm actually doing this"], "states": ["numb", "proud", "unsure", "tired"], "when": "Offer when a member hits a short-term milestone but downplays it or can't name evidence of their own effort."}},

  // my-people-1 — "Why Can't I Do This Alone?"
  {"id": "remember-who-showed-up", "title": "Remember Who Showed Up", "subtitle": "See connection as part of recovery", "minutes": 1, "tags": ["support"], "type": "guided", "purpose": "Isolation says nobody's there. A real memory of someone showing up says otherwise.", "content": {"kind": "guided", "steps": [{"say": "Think back to a time things were bad.", "secs": 10}, {"say": "Who showed up for you? Just one person.", "secs": 12}, {"say": "What did they do? A ride, a call, sitting with you?", "secs": 15}, {"say": "What did it change for you?", "secs": 12}, {"say": "Someone did that once. Someone can again.", "secs": 10}, {"say": "Say: \"We do together what I can't do alone.\"", "secs": 8}], "why": "Isolation says nobody's there. A real memory of someone showing up says otherwise.", "closing": "Recovery isn't a solo job. Find your people.", "tagline": "We do together what I can't do alone."}, "adel": {"skill": "Recalling a specific memory of someone showing up for you", "needs": ["I feel like I have to do this alone", "Nobody's really in my corner", "I don't think anyone would actually show up for me", "I've been pulling away from people", "I feel like a burden if I reach out"], "states": ["isolated", "doubtful", "lonely", "guarded"], "when": "Offer when a member is convinced they have no real support and needs a memory-based counter, not a new plan to build connections."}},

  // my-people-3 — "What Really Happens at a Meeting?"
  {"id": "sort-my-meeting-thoughts", "title": "Worry or Fact?", "subtitle": "What really happens at a meeting", "minutes": 1, "tags": ["support", "anxiety"], "type": "guided", "purpose": "Most first-meeting worries are bigger than what really happens.", "content": {"kind": "guided", "steps": [{"say": "Worry: \"I'll have to talk.\" Fact: you can pass. Just say, \"I'll pass.\"", "secs": 12}, {"say": "Worry: \"They'll judge me.\" Fact: everyone in that room was new once.", "secs": 12}, {"say": "Worry: \"I won't know what to do.\" Fact: just sit, listen and follow along.", "secs": 12}, {"say": "Worry: \"Someone will recognize me.\" Fact: most meetings ask that who you see there stays there.", "secs": 12}, {"say": "Worry: \"It's not for people like me.\" Fact: there are meetings for every kind of person.", "secs": 12}, {"say": "Say: \"You can always pass.\"", "secs": 6}], "why": "Most first-meeting worries are bigger than what really happens.", "closing": "You don't have to say a word. Go, sit and listen.", "tagline": "You can always pass."}, "adel": {"skill": "Mentally sorting worries about a meeting into fact vs. worry", "needs": ["I'm nervous about walking into a meeting", "I don't know what actually happens there", "I think they'll make me talk", "I'm scared someone will judge me", "My head is full of worries about going"], "states": ["nervous", "unsure", "anxious", "avoidant"], "when": "Offer when a member is avoiding their first meeting because of stacked-up worries rather than lack of information."}},

  // my-people-5 — "What Does a Peer Recovery Specialist Do?"

  // my-people-7 — "How Do I Learn to Trust Again?"
  g({
    id: "remember-a-kept-promise",
    title: "Remember a Kept Promise",
    subtitle: "Pull up one time trust actually held",
    minutes: 1,
    tags: ["support", "relapse-prevention"],
    purpose: "Trust feels impossible in the abstract. Remembering one specific time someone — including you — kept a promise makes it feel possible again.",
    adel: {
      skill: "Recalling a specific memory of a promise being kept",
      needs: [
        "I struggle to trust people, even ones trying to help",
        "I've been let down before and can't forget it",
        "I don't trust myself to keep promises",
        "I hold back from getting close to anyone new",
        "I want to learn how to trust again",
      ],
      states: ["guarded", "hurt", "doubtful", "hopeful"],
      when: "Offer when a member is stuck on general distrust and needs a specific counter-memory rather than a new promise to make.",
    },
    steps: [
      ["Think back over your life — not everyone, just one moment.", 10],
      ["Find one specific time someone kept a small promise to you, or you kept one to yourself.", 15],
      ["Picture exactly what happened, in detail.", 15],
      ["Notice what it felt like when it actually held.", 12],
      ["Say out loud: \"Trust held once, right there.\"", 10],
      ["Say: \"It can hold again, one small promise at a time.\"", 10],
    ],
    closing: "You just found one real memory where trust worked. That's your evidence that it's not impossible.",
  }),

  // my-people-8 — "How Do I Ask for Help?"
  {"id": "if-they-say-no-rehearsal", "title": "If They Say No", "subtitle": "Ask, and handle a no", "minutes": 1, "tags": ["support", "communication"], "type": "guided", "purpose": "Fear of a no stops a lot of asks. Rehearsing the no takes the sting out of it.", "content": {"kind": "guided", "steps": [{"say": "Think of something you need to ask someone for.", "secs": 10}, {"say": "Rehearse the ask, small and clear: \"Can you help me with ___ on ___?\"", "secs": 12}, {"say": "Picture them saying yes. Good.", "secs": 8}, {"say": "Now picture them saying no.", "secs": 8}, {"say": "Practice your answer: \"Okay, thanks anyway.\" No arguing, no hard feelings.", "secs": 12}, {"say": "Then picture going to the next person on your list.", "secs": 10}, {"say": "Say: \"A no is just a next.\"", "secs": 6}], "why": "Fear of a no stops a lot of asks. Rehearsing the no takes the sting out of it.", "closing": "A no isn't a no forever, or from everyone. Ask the next person.", "tagline": "A no is just a next."}, "adel": {"skill": "Mentally rehearsing an if-then for both a yes and a no", "needs": ["I'm afraid people will say no", "I keep talking myself out of asking", "I don't know what I'd do if they refused", "I only picture the worst outcome", "Asking feels too risky to try"], "states": ["anxious", "hesitant", "avoidant"], "when": "Offer when a member is stalled before an ask specifically because they're stuck imagining rejection."}},

  // my-people-9 — "What Does Recovery Look Like This Week?"
  {"id": "sort-my-week-in-my-head", "title": "Sort My Week", "subtitle": "Build recovery into the week", "minutes": 1, "tags": ["goal-setting", "support"], "type": "guided", "purpose": "A week with recovery built in holds up better than one you figure out day by day.", "content": {"kind": "guided", "steps": [{"say": "Picture the seven days ahead.", "secs": 10}, {"say": "Place two meetings. Which days?", "secs": 12}, {"say": "Place one check-in with a person: Devon, your sponsor or a friend.", "secs": 12}, {"say": "Place one healthy thing just for you: a walk, a game, time with family.", "secs": 12}, {"say": "Picture the week with all four in it.", "secs": 10}, {"say": "Say: \"Two meetings, one check-in, one good thing.\"", "secs": 6}], "why": "A week with recovery built in holds up better than one you figure out day by day.", "closing": "Put them in your phone now, before the week fills up.", "tagline": "Two meetings, one check-in, one good thing."}, "adel": {"skill": "Mentally sorting a week into meeting, check-in, and healthy-activity slots", "needs": ["I don't know what my week is supposed to look like", "I mean to plan my week but never do", "My week doesn't have set recovery time in it", "I forget to include people in my plans", "I want my week to actually include recovery"], "states": ["overwhelmed", "unsure", "scattered"], "when": "Offer before a member sits down to plan their week, as a quick mental first pass before any writing."}},

  // understanding-2 — "Why Are My Cravings So Strong?"

  // understanding-3 — "What Keeps Triggering Me?"
  g({
    id: "sort-the-setup",
    title: "Sort the Setup",
    subtitle: "Sort your last few cravings into buckets",
    minutes: 1,
    tags: ["triggers", "craving"],
    purpose: "Triggers hide in patterns. Sorting your last few cravings into person, place, feeling, or time buckets shows the pattern fast.",
    adel: {
      skill: "Mentally sorting recent cravings into trigger categories to spot a pattern",
      needs: [
        "Cravings seem to hit without warning",
        "I haven't figured out what actually sets me off",
        "It feels random every time",
        "I want to know my real triggers",
        "I keep getting caught off guard",
      ],
      states: ["confused", "frustrated", "on edge"],
      when: "Offer when a member feels ambushed by cravings and hasn't yet connected them to a pattern.",
    },
    steps: [
      ["Think of the last three times a craving hit, one at a time.", 15],
      ["For the first one, sort it in your head: was it a person, a place, a feeling, or a time of day?", 12],
      ["Do the same for the second one.", 12],
      ["Do the same for the third one.", 12],
      ["Notice if two or more landed in the same bucket.", 12],
      ["Say out loud: \"That bucket is my real setup. Now I can watch for it.\"", 10],
    ],
    closing: "You just sorted your own pattern in your head. That bucket is where your plan should point first.",
  }),

  // understanding-5 — "Why Does Stress Make Me Want to Use?"
  {"id": "three-reasons-tap", "title": "Three Reasons Tap", "subtitle": "Three fingers, three reasons", "minutes": 1, "tags": ["craving", "anxiety"], "type": "guided", "purpose": "When stress pushes you toward using, your reasons can go blank. Tapping them out brings them back.", "content": {"kind": "guided", "steps": [{"say": "Notice the stress, and the pull to use riding along with it.", "secs": 10}, {"say": "Hold up one hand. Tap your thumb to your first finger. Say one reason you're staying sober.", "secs": 15}, {"say": "Second finger. A second reason.", "secs": 12}, {"say": "Third finger. A third reason.", "secs": 12}, {"say": "Look at your hand. Three reasons, right there.", "secs": 8}, {"say": "Say: \"Three fingers, three reasons.\"", "secs": 6}], "why": "When stress pushes you toward using, your reasons can go blank. Tapping them out brings them back.", "closing": "Your reasons don't disappear when stress shows up. They're at your fingertips.", "tagline": "Three fingers, three reasons."}, "adel": {"skill": "Physically tapping out three personal reasons not to use during a stress-driven craving", "needs": ["Stress makes me want to use more than anything", "I can't think of why I'm doing this when I'm stressed", "My reasons disappear the moment stress hits", "I need something quick when stress turns into a craving", "My mind goes blank under pressure"], "states": ["stressed", "tense", "urgent"], "when": "Offer right after a member names a stressful trigger and a craving following close behind it."}},
];
