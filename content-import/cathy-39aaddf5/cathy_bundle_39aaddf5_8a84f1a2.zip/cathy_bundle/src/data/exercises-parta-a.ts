// Plug-and-play Part A guided exercises for Group A slots.
// Techniques favor body/movement, posture & voice practice,
// object/sensory focus, and counting/sorting in your head.
import type { Exercise, ExerciseAdelMeta } from "./exercises";

type G = Omit<Exercise, "type" | "content"> & {
  steps: [string, number][];
  closing: string;
  why?: string;
  scene?: string;
  tagline?: string;
  adel?: ExerciseAdelMeta;
};

const g = ({ steps, closing, why, scene, tagline, ...rest }: G): Exercise => ({
  ...rest,
  type: "guided",
  content: { kind: "guided", why, scene, tagline, steps: steps.map(([say, secs]) => ({ say, secs })), closing },
});

export const PARTA_A: Exercise[] = [
  // sud — Understanding Substance Use Disorder
  g({
    id: "count-by-sevens",
    title: "Count By Sevens",
    subtitle: "Give the craving part of your brain a math job",
    minutes: 1,
    tags: ["craving"],
    why: "Cravings get louder when your mind has nothing else to do. Counting backward gives it a job.",
    scene: "A craving hits while you're standing in line at the store.",
    closing: "Nobody can tell you're counting. Use it in line, on the bus or anywhere a craving hits.",
    tagline: "Count it down, ride it out.",
    purpose: "Cravings get louder when your mind has nothing else to do. Counting backward gives it a job.",
    steps: [
      ["Start at 100. In your head, subtract 7. Say the new number.", 10],
      ["Keep going: subtract 7 again.", 12],
      ["Again. As fast as you can.", 15],
      ["Lost count? No problem. Start over at 100.", 10],
      ["Keep going until you get below 50.", 20],
      ["Notice the craving. It's still there, but quieter.", 10],
    ],
    adel: {
      skill: "using mental counting to ride out a craving",
      needs: ["I can't stop thinking about using", "This craving feels too loud to ignore", "I need something to do with my hands or my head right now", "I don't want to just wait this out doing nothing"],
      states: ["craving", "restless", "wired", "distracted"],
      when: "Offer when a member describes a craving happening right now and needs a quick mental task to break its pull.",
    },
  }),

  // depression — Understanding Depression

  // anxiety — Understanding Anxiety

  // bipolar — Understanding Bipolar Disorder

  // ptsd — Understanding PTSD & Trauma

  // psychosis — Understanding Schizophrenia & Psychosis

  // my-triggers-2 — Understanding My Triggers

  // my-strengths — Understanding My Strengths

  // treatment-team — Understanding My Treatment Team

  // recovery-journey-2 — Understanding My Recovery Journey
  g({
    id: "walk-the-stages",
    title: "Walk the Stages",
    subtitle: "A step back isn't the start",
    minutes: 1,
    tags: ["goal-setting"],
    steps: [["Stand up if you can, or stay seated and use one foot.", 8], ["Step forward: getting stable.", 6], ["Step forward: building strength.", 6], ["Step forward: reconnecting.", 6], ["Step forward: growing.", 6], ["Now take one step back, on purpose. You're still on the same path, past where you started.", 15], ["Step forward again.", 6], ["Say: \"A step back isn't the start.\"", 8]],
    why: "Recovery moves in stages. A setback is a step back on the same path, not a return to the start.",
    closing: "When a setback makes it feel like you've lost everything, remember the step back. You're still on the path.",
    tagline: "A step back isn't the start.",
    purpose: "Recovery moves in stages. A setback is a step back on the same path, not a return to the start.",
    adel: {
      skill: "using physical steps to feel recovery as a nonlinear direction",
      needs: ["I feel like a setback erased all my progress", "I don't know what stage of recovery I'm in", "I thought recovery was supposed to be a straight line", "I want to see how far I've actually come"],
      states: ["discouraged", "confused", "reflective", "uncertain"],
      when: "Offer when a member feels like a setback undid their progress or is unsure where they stand in their recovery.",
    },
  }),

  // why-meds — Why My Medication Matters
  g({
    id: "hold-whats-working",
    title: "Hold What's Working",
    subtitle: "Let an object stand in for quiet progress",
    minutes: 1, tags: ["cbt"],
    purpose: "Medication working quietly is easy to dismiss. Holding something steady while you say what's better keeps that quiet progress from getting lost.",
    steps: [
      ["Hold something steady in your hand — your phone, a cup, anything nearby.", 8],
      ["Feel how solid and unchanging it is while you hold it.", 10],
      ["Say out loud one thing that's been a little steadier since you started treatment.", 15],
      ["Hold the object a bit tighter and say: \"Quiet progress is still progress.\"", 12],
      ["Set the object down gently, like setting down doubt for a moment.", 10],
      ["Say: \"I don't need fireworks to know something is working.\"", 10],
    ],
    closing: "You just named quiet progress and gave it something solid to hold onto. That counts.",
    adel: {
      skill: "using a held object to notice quiet, hard-to-feel progress",
      needs: ["I don't feel like my medication is doing anything", "I expected to feel better faster", "I've thought about stopping because nothing feels different", "I don't know if it's actually working"],
      states: ["doubtful", "discouraged", "impatient", "uncertain"],
      when: "Offer when a member is doubting whether their medication is working and needs a way to notice small, real changes.",
    },
  }),

  // med-routine — Building My Medication Routine

  // tracking-feelings — Tracking How I'm Feeling

  // side-effects — Managing Side Effects

  // talking-provider — Talking With My Provider

  // missed-dose — What If I Miss a Dose?

  // habits-treatment — Building Healthy Habits Around Treatment

  // treatment-goals — Understanding My Treatment Goals

  // prep-appointments — Preparing for Appointments

  // ownership — Taking Ownership of My Recovery
];
