import { test } from "node:test";
import assert from "node:assert/strict";
import { allChecked, planExpired, checkDayPlan, nextDayActions, buildPlanActions, NEEDS, safetyLines, type DayPlan } from "./reentry";

const plan = (): DayPlan => ({ savedAt: "2026-10-21T12:00:00Z", actions: buildPlanActions({ needs: [NEEDS.shelter, NEEDS.food], answers: {} }), person: { name: "Sam", phone: "5595550123" }, checks: {} });

test("day plan expires exactly after 24 hours", () => {
  const p = plan();
  assert.equal(planExpired(p, Date.parse(p.savedAt) + 24 * 3600e3 - 1), false);
  assert.equal(planExpired(p, Date.parse(p.savedAt) + 24 * 3600e3), true);
});
test("check-offs and failed actions survive a saved-plan round trip", () => {
  const p = checkDayPlan(checkDayPlan(plan(), "devon", "done"), "shelter", "failed");
  const restored: DayPlan = JSON.parse(JSON.stringify(p));
  assert.equal(restored.checks.devon, "done");
  assert.equal(restored.checks.shelter, "failed");
  assert.equal(checkDayPlan(restored, "devon", null).checks.devon, undefined);
});
test("next day carries unfinished actions and re-adds both standing actions", () => {
  let p = plan();
  for (const id of ["devon", "meeting", "food"]) p = checkDayPlan(p, id, "done");
  p = checkDayPlan(p, "shelter", "failed");
  assert.deepEqual(nextDayActions(p).map((a) => a.id), ["devon", "meeting", "shelter"]);
});
test("Home hides the plan only once every action is done", () => {
  let p = plan();
  assert.equal(allChecked(p), false);
  for (const a of p.actions) p = checkDayPlan(p, a.id, "done");
  assert.equal(allChecked(p), true);
});
test("saved support name and phone stay separate and the safety line uses the name", () => {
  const p: DayPlan = JSON.parse(JSON.stringify(plan()));
  assert.deepEqual(p.person, { name: "Sam", phone: "5595550123" });
  assert.equal(safetyLines(p.person.name).urge, "If an urge hits: Craving right now · Sam · 988");
});