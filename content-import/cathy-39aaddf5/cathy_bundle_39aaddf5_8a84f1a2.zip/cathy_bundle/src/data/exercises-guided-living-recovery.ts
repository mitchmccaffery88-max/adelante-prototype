// Plug-and-play guided exercises for the Living Recovery mission.
import type { Exercise } from "./exercises";

type G = Omit<Exercise, "type" | "content"> & {
  steps: [string, number][];
  closing: string;
};

const g = ({ steps, closing, ...rest }: G): Exercise => ({
  ...rest,
  type: "guided",
  content: { kind: "guided", steps: steps.map(([say, secs]) => ({ say, secs })), closing },
});

export const GUIDED_LIVING_RECOVERY: Exercise[] = [
  g({
    id: "picture-your-seat-at-a-meeting",
    title: "Picture Your Seat at a Meeting",
    subtitle: "See yourself still showing up",
    minutes: 1, tags: ["support", "relapse-prevention"],
    purpose: "Picturing yourself in the room makes it easier to actually go when the week gets busy.",
    steps: [
      ["Picture a meeting you go to or could go to. See the room.", 12],
      ["Picture your usual seat, or one you'd pick.", 10],
      ["Notice one face you'd expect to see there.", 10],
      ["Say out loud: \"Showing up is still part of my recovery.\"", 10],
      ["Say which day this week you'll go.", 10],
    ],
    closing: "You just pictured yourself still showing up. That's what keeps the habit alive.",
  }),
  g({
    id: "name-your-hard-times-basics",
    title: "Name Your Hard-Times Basics",
    subtitle: "The moves that already worked once",
    minutes: 1, tags: ["relapse-prevention"],
    purpose: "Naming the basics that already worked once means you don't have to reinvent a plan mid-crisis.",
    steps: [
      ["Think back to a hard stretch you already got through.", 10],
      ["Say out loud one basic thing that helped you then.", 12],
      ["Say a second thing that helped.", 10],
      ["Say: \"These still work. I don't need something new.\"", 12],
      ["Say who you'd call early next time, before it gets bad.", 12],
    ],
    closing: "You just pulled out a plan that's already proven. That's ready whenever you need it.",
  }),
  g({
    id: "read-your-plan-out-loud",
    title: "Read Your Plan Out Loud",
    subtitle: "People, routine, warning signs, purpose",
    minutes: 2, tags: ["goal-setting", "support"],
    purpose: "Reading your whole plan out loud, start to finish, makes it feel like one real thing you can trust.",
    steps: [
      ["Say who is on your recovery team, out loud.", 12],
      ["Say your basic weekly routine.", 12],
      ["Say one early warning sign you watch for.", 12],
      ["Say one reason your recovery matters to you.", 12],
      ["Say all four together, start to finish, like reading a page.", 15],
    ],
    closing: "That's your plan in one breath. Simple enough to repeat on any day, good or hard.",
  }),
];
