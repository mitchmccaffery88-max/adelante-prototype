// Plug-and-play guided exercises: tap Start, follow timed steps, nothing to type.
// Part of the one shared Exercise Library (merged into EXERCISES).
import type { Exercise } from "./exercises";

type G = Omit<Exercise, "type" | "content"> & {
  steps: [string, number][];
  closing: string;
  why?: string;
  scene?: string;
  tagline?: string;
};

const g = ({ steps, closing, why, scene, tagline, ...rest }: G): Exercise => ({
  ...rest,
  type: "guided",
  content: { kind: "guided", why, scene, tagline, steps: steps.map(([say, secs]) => ({ say, secs })), closing },
});

export const GUIDED_EXERCISES: Exercise[] = [
  g({
    id: "what-holds-me",
    title: "What's Holding Me Up",
    subtitle: "Feel what's already steady",
    minutes: 1, tags: ["anxiety", "goal-setting"],
    purpose: "When everything is new, find the few things that aren't moving. You'll use your body and your voice — no writing.",
    steps: [
      ["Press your feet flat into the floor. Feel the ground push back.", 10],
      ["Put a hand on the chair, wall, or bed under you. It's holding your weight right now.", 10],
      ["Out loud, name one thing you have today that you didn't have a week ago.", 15],
      ["Now name one person who knows you're out.", 15],
      ["Name one thing you'll do today no matter what — eat, shower, a walk.", 15],
      ["Those three things are your footing. Say: \"I'm not starting from nothing.\"", 10],
    ],
    closing: "You just found three footholds. That's enough ground to take one step.",
  }),
  g({
    id: "one-step-shrink",
    title: "Shrink the Pile",
    subtitle: "From everything to one thing",
    minutes: 2, tags: ["anxiety", "goal-setting"],
    purpose: "Overwhelm is your brain holding every task at once. This practice sets them down, one by one, until only one is left in your hands.",
    steps: [
      ["Hold your arms out like you're carrying a big stack of boxes. That's everything on your mind.", 12],
      ["Feel how heavy it is. Your shoulders know this feeling.", 10],
      ["Now bend down and set the whole stack on the floor. Arms down.", 10],
      ["Pick back up just one box — the one that's due soonest. Hold it in front of you.", 15],
      ["Look at it. What's the very first 5-minute piece of it? Say it out loud.", 20],
      ["Everything else is still on the floor. It'll wait. You only carry this one.", 10],
    ],
    closing: "One box. One piece. That's the whole job for the next hour.",
  }),
  g({
    id: "worry-shelf",
    title: "The Worry Shelf",
    subtitle: "Park it until later",
    minutes: 2, tags: ["cbt", "anxiety"],
    purpose: "Worry wants your attention right now. This practice gives each worry one quick test, then puts it on a shelf so it stops following you around.",
    steps: [
      ["Picture a high shelf in front of you. It's strong. It can hold a lot.", 10],
      ["Bring up the worry that's loudest. Just the headline — no details.", 12],
      ["Ask it out loud: \"Can I do anything about you today?\"", 12],
      ["If yes — name the one thing, and you'll do it after this. If no — keep going.", 15],
      ["Picture putting it in a box, closing the lid, and setting it on the shelf.", 12],
      ["Say: \"I'll look at you at 6 o'clock. Not before.\"", 10],
      ["Do the same with one more worry if there is one. Box, lid, shelf.", 15],
    ],
    closing: "The worries didn't vanish — they're parked. You get to choose when you look at them.",
  }),
  g({"id": "senses-5-4-3-2-1", "title": "5-4-3-2-1 Grounding", "subtitle": "Use your senses to come back to now", "minutes": 1, "tags": ["anxiety"], "steps": [["Look around. Name 5 things you can see.", 15], ["Listen. Name 4 things you can hear.", 15], ["Touch. Name 3 things you can feel: your feet, your clothes, the chair.", 12], ["Breathe. Take 2 slow breaths, out longer than in.", 12], ["Notice 1 thing that tells you you're okay right now.", 10]], "why": "Your senses pull you back to right here, right now, faster than thinking can.", "closing": "Use it anywhere: a crowded store, the bus, a waiting room. Your senses are always with you.", "tagline": "Look. Listen. Breathe. Notice.", "adel": {"skill": "grounding through the senses when the body is on high alert", "needs": ["My heart is pounding for no reason", "I feel jumpy and on edge", "I feel far away"], "states": ["on edge", "panicky", "numb"], "when": "Offer when a member's body is on high alert or they feel disconnected."}, "purpose": "Your senses pull you back to right here, right now, faster than thinking can."}),
  g({
    id: "safe-place",
    title: "My Safe Place",
    subtitle: "Build a place your body can go",
    minutes: 2, tags: ["anxiety", "support"],
    purpose: "You can't always change where you are. You can build a place in your mind that your body learns to relax into.",
    steps: [
      ["Think of a place — real or made up — where you felt, or could feel, okay. Pick the first one that comes.", 15],
      ["What do you see there? Colors, light, what's around you.", 15],
      ["What do you hear? Maybe quiet, water, wind, a voice you trust.", 15],
      ["What does the air feel like on your skin? Warm, cool, still?", 12],
      ["Notice your shoulders. Let them drop the way they would there.", 12],
      ["Give this place a one-word name. You can come back here any time by saying it.", 12],
    ],
    closing: "That place is yours now. The more you visit, the faster your body goes there.",
  }),
  {"id": "heavy-body-release", "title": "Heavy Body Release", "subtitle": "Let your body go heavy for sleep", "minutes": 2, "tags": ["anxiety"], "purpose": "Progressive muscle relaxation. Tightening and releasing each part tells your body it's safe to rest.", "type": "guided", "content": {"why": "Progressive muscle relaxation. Tightening and releasing each part tells your body it's safe to rest.", "closing": "Use it in bed with the lights off. If you're still awake after 20 minutes, get up for a bit and try again.", "tagline": "Heavy, warm, done.", "kind": "guided", "steps": [{"say": "Lie down or sit back. Let your eyes close if that's okay.", "secs": 8}, {"say": "Squeeze your feet and toes tight for five seconds. Let go. Feel them go heavy.", "secs": 12}, {"say": "Tighten your legs. Hold. Let go. Heavy and warm.", "secs": 12}, {"say": "Tighten your stomach and back. Hold. Let go.", "secs": 12}, {"say": "Make fists and tighten your arms. Hold. Let go.", "secs": 12}, {"say": "Lift your shoulders to your ears. Hold. Drop them.", "secs": 12}, {"say": "Scrunch your face. Hold. Let it go soft.", "secs": 12}, {"say": "Your whole body is heavy. Stay here and breathe.", "secs": 20}]}},
  {"id": "walk-into-the-room", "title": "Walk Into the Room", "subtitle": "Get in the door of your first meeting", "minutes": 1, "tags": ["support"], "type": "guided", "purpose": "The hardest part of a first meeting is the door. Once you're in, you can just listen.", "content": {"kind": "guided", "steps": [{"say": "Notice your heart going. That's normal. Everyone's first time feels like this.", "secs": 10}, {"say": "Take one slow breath.", "secs": 6}, {"say": "Open the door. You don't have to talk to anyone yet.", "secs": 10}, {"say": "Find a seat near the back, or by the door if that helps.", "secs": 10}, {"say": "If someone asks, say: \"I'm new. I'll just listen.\"", "secs": 10}, {"say": "That's it. You're in.", "secs": 6}, {"say": "Say: \"Just get in the door.\"", "secs": 6}], "why": "The hardest part of a first meeting is the door. Once you're in, you can just listen.", "scene": "You're standing outside your first meeting. You can hear people talking inside.", "closing": "Nobody expects you to talk at your first meeting. Getting in the door is the win.", "tagline": "Just get in the door."}},
  {"id": "helper-scan", "title": "Spot My Helpers", "subtitle": "Find one helper today", "minutes": 1, "tags": ["support"], "type": "guided", "purpose": "You likely have more help around you than you can see right now.", "content": {"kind": "guided", "steps": [{"say": "Think back over the last few days.", "secs": 8}, {"say": "Who's been safe to be around? Someone who didn't push you or judge you.", "secs": 15}, {"say": "Think of Devon, a case manager, a family member or someone from a meeting.", "secs": 15}, {"say": "Pick one.", "secs": 8}, {"say": "What's one small thing you could ask them for today?", "secs": 12}, {"say": "Say: \"Find one helper today.\"", "secs": 6}], "why": "You likely have more help around you than you can see right now.", "closing": "One helper is enough to start. Reach out to them today.", "tagline": "Find one helper today."}},
  g({
    id: "comeback-rehearsal",
    title: "Stop, Safe, Tell",
    subtitle: "The first hour after a slip",
    minutes: 1,
    tags: ["relapse-prevention"],
    why: "What you do right after a slip matters more than the slip itself.",
    scene: "You used last night. You wake up feeling sick and ashamed.",
    closing: "A slip is information, not the end. Stop, get safe and tell someone today.",
    tagline: "Stop. Safe. Tell.",
    purpose: "What you do right after a slip matters more than the slip itself.",
    steps: [
      ["Stop. No more today. One slip doesn't have to become a run.", 10],
      ["Safe. If you might use again, don't use alone, and keep naloxone (Narcan) close. Your tolerance may be lower than you think.", 15],
      ["Safe also means the basics: water, food and rest.", 8],
      ["Tell. Pick one person you'll tell today: sponsor, peer specialist, counselor.", 12],
      ["Picture sending the text: \"I slipped last night. Can we talk today?\"", 12],
      ["Say: \"Stop. Safe. Tell.\"", 8],
    ],
  }),
  {"id": "unfreeze-90", "title": "Unfreeze in 90 Seconds", "subtitle": "Move first, think second", "minutes": 2, "tags": ["goal-setting"], "type": "guided", "purpose": "When you're frozen, thinking keeps you stuck. Moving gets you going.", "content": {"kind": "guided", "steps": [{"say": "Stuck? Don't think yet. Move first.", "secs": 6}, {"say": "Stand up.", "secs": 6}, {"say": "Get a glass of water and drink it.", "secs": 15}, {"say": "Look around. Pick one thing to fix: make the bed, wash a dish, put on your shoes.", "secs": 12}, {"say": "Do it now.", "secs": 30}, {"say": "Notice you're moving. Now pick the next thing.", "secs": 10}, {"say": "Say: \"Move first, think second.\"", "secs": 6}], "why": "When you're frozen, thinking keeps you stuck. Moving gets you going.", "closing": "When you don't know what to do, do something small. The next step gets clearer once you're moving.", "tagline": "Move first, think second."}},
  g({
    id: "three-good-things",
    title: "Three Good Things",
    subtitle: "End the day on what went right",
    minutes: 1, tags: ["goal-setting"],
    purpose: "Your brain replays the bad parts of a day on its own. This takes one minute to replay the good ones on purpose.",
    steps: [
      ["Get comfortable. Think back over today, from morning to now.", 10],
      ["Say out loud one thing that went okay — even something small, like a good meal.", 15],
      ["Say a second one. Maybe something you handled, or someone who was kind.", 15],
      ["Say a third. Something you did for your recovery counts.", 15],
      ["Say: \"Today had good in it. I'm closing it here.\"", 8],
    ],
    closing: "Three good things. That's what you take to bed tonight.",
  }),
  {"id": "look-how-far", "title": "Look How Far", "subtitle": "Look back on purpose", "minutes": 1, "tags": ["goal-setting"], "purpose": "Progress is hard to see day to day. Looking back on purpose shows how far you've come.", "type": "guided", "content": {"kind": "guided", "why": "Progress is hard to see day to day. Looking back on purpose shows how far you've come.", "tagline": "Look back on purpose.", "closing": "When it feels like nothing's changed, look back on purpose.", "steps": [{"say": "Picture day one. Where were you? How did you feel?", "secs": 15}, {"say": "Now picture today. Where are you?", "secs": 12}, {"say": "What's different about your housing? Your health? Your people?", "secs": 15}, {"say": "What's different about you?", "secs": 12}, {"say": "Say: \"Look back on purpose.\"", "secs": 6}]}},
  {
    id: "long-exhale",
    title: "Four In, Six Out",
    subtitle: "Longer out-breaths calm your body",
    minutes: 2,
    type: "breathing",
    tags: ["anxiety", "craving"],
    purpose: "When you breathe out longer than you breathe in, your heart rate slows. Ten rounds is enough to feel it.",
    content: { kind: "breathing", inhale: 4, hold: 0, exhale: 6, holdOut: 0, instruction: "Breathe in through your nose for 4. Out slowly through your mouth for 6." },
  },
  {"id": "trigger-replay", "title": "Trigger Replay", "subtitle": "Find the cue, routine and reward", "minutes": 1, "tags": ["triggers", "craving"], "type": "guided", "purpose": "Habits run on a loop. Seeing the loop shows you where to change it.", "content": {"kind": "guided", "steps": [{"say": "Take a slow breath first. You can skip any step.", "secs": 8}, {"say": "Think of one pattern that keeps repeating. Replay it slowly, like a video.", "secs": 15}, {"say": "Find the cue: what happened right before?", "secs": 12}, {"say": "Find the routine: what did you do?", "secs": 10}, {"say": "Find the reward: what did it give you? Relief, escape, energy, company?", "secs": 12}, {"say": "Picture a new routine that gives you something similar.", "secs": 12}, {"say": "One more slow breath. Say: \"Same cue, new routine.\"", "secs": 8}], "why": "Habits run on a loop. Seeing the loop shows you where to change it.", "closing": "You can't always avoid the cue. You can change the routine.", "tagline": "Same cue, new routine."}},
];
