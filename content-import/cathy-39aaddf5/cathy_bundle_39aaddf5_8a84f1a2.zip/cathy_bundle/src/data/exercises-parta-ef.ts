// Plug-and-play guided exercises replacing duplicate Part A exercises
// across the "Changing My Everyday Life," "Healing My Relationships,"
// "Building a Life That Works," "When Recovery Gets Hard," "Becoming
// Someone New," and "Living Recovery" topics (Groups E and F).
// Tap Start, follow timed steps, nothing to type.
import type { Exercise } from "./exercises";

type G = Omit<Exercise, "type" | "content"> & {
  steps: [string, number][];
  closing: string;
};

const g = ({ steps, closing, ...rest }: G): Exercise => ({
  ...rest,
  type: "guided",
  content: { kind: "guided", steps: steps.map(([say, secs]) => ({ say, secs })), closing },
});

export const PARTA_EF: Exercise[] = [
  // ---- Group E ----
  g({
    id: "the-one-finger-promise",
    title: "The One-Finger Promise",
    subtitle: "A small gesture for a promise you'll keep",
    minutes: 1,
    tags: ["support", "communication"],
    purpose: "Trust rebuilds through small proof, not big words. Tie one promise to a small gesture so your body remembers it too.",
    adel: {
      skill: "committing to a small kept promise",
      needs: [
        "I've apologized but trust hasn't come back",
        "I want people to just believe me already",
        "I've broken promises before",
        "I don't always follow through on small things",
        "I want to know how to actually rebuild trust",
      ],
      states: ["impatient", "guilty", "hopeful", "unsure"],
      when: "Offer when a member is working on rebuilding trust with someone and needs a small, concrete promise to anchor to, not just words.",
    },
    steps: [
      ["Think of one person whose trust you're rebuilding.", 10],
      ["Think of one small, doable thing you could promise them this week.", 15],
      ["Hold up one finger. Say: \"One promise.\" Say what it is, out loud.", 15],
      ["Press that finger to your palm, like sealing it. Say: \"Small and kept.\"", 12],
      ["Picture doing it, on the day you said, this coming week.", 15],
      ["Say: \"Every time I look at my hand, I'll remember I said this.\"", 12],
    ],
    closing: "One finger, one promise. Small and kept beats big and broken, every time.",
  }),

  // ---- Group F ----
  g({
    id: "the-silent-thank-you",
    title: "The Silent Thank-You",
    subtitle: "Notice a win by thanking someone in your head",
    minutes: 1,
    tags: ["support"],
    purpose: "Small wins are easier to notice when they're tied to a person, not just a fact. Say a quiet thank-you in your head.",
    adel: {
      skill: "noticing a small win through directed silent gratitude",
      needs: [
        "I let small wins pass without noticing them",
        "I only notice the hard days, not the good ones",
        "I feel silly celebrating something small",
        "I don't tell anyone when something goes well",
        "I downplay my own progress",
      ],
      states: ["dismissive", "flat", "unseen", "tired"],
      when: "Offer when a member had a small win but tends to brush past it instead of letting it register.",
    },
    steps: [
      ["Think of one small win from today or this week, even a tiny one.", 12],
      ["Think of one person connected to that win — who helped, or who'd be glad.", 12],
      ["In your head, say to them: \"Thank you for ___.\" Fill in why.", 15],
      ["Notice how the win feels different once someone else is part of it.", 12],
      ["Say out loud: \"That counts. Small wins are still wins.\"", 12],
      ["Pick one way you'll let yourself notice the next one.", 10],
    ],
    closing: "A silent thank-you made that win stick a little longer. It's easier to notice the next one now.",
  }),
  {"id": "the-daily-touchstone", "title": "The Daily Touchstone", "subtitle": "Touch base every day", "minutes": 1, "tags": ["relapse-prevention"], "purpose": "Long-term recovery holds up on three anchors: people, routine and purpose.", "adel": {"skill": "using a physical touchstone gesture as a daily recovery check-in", "needs": ["I think I should be past needing this by now", "I've let a routine slide because things felt fine", "I go long stretches without checking in with anyone", "I forget what actually keeps me steady", "I feel embarrassed still needing a plan"], "states": ["complacent", "drifting", "embarrassed", "steady"], "when": "Offer when a member's recovery system has been working and risks fading from neglect during a stable stretch."}, "type": "guided", "content": {"kind": "guided", "why": "Long-term recovery holds up on three anchors: people, routine and purpose.", "tagline": "Touch base every day.", "closing": "A one-minute check each day keeps small slips from growing.", "steps": [{"say": "People: did you connect with someone in recovery today?", "secs": 12}, {"say": "Routine: did you keep your basics? Sleep, meals, meds, a meeting?", "secs": 12}, {"say": "Purpose: did you do one thing that mattered to you?", "secs": 12}, {"say": "If one is missing, that's the one to add today.", "secs": 10}, {"say": "Say: \"Touch base every day.\"", "secs": 6}]}},
  {"id": "count-what-youve-survived", "title": "Count What You've Survived", "subtitle": "I've gotten through worse", "minutes": 1, "tags": ["relapse-prevention"], "purpose": "When a crisis hits, it can feel like everything's gone. Counting what you've survived proves it isn't.", "adel": {"skill": "counting past hardships survived to build confidence for a current hard season", "needs": ["I worry a big enough crisis could take me back to zero", "I don't have a plan for really hard times, only easy ones", "I've gotten through something hard before and forgot how", "I tend to isolate when things get bad", "I wait too long to ask for help in a crisis"], "states": ["scared", "overwhelmed", "doubtful", "isolated"], "when": "Offer when a member is facing a hard season and fears it could undo their recovery, and needs evidence they've made it through hard things before."}, "type": "guided", "content": {"kind": "guided", "why": "When a crisis hits, it can feel like everything's gone. Counting what you've survived proves it isn't.", "tagline": "I've gotten through worse.", "closing": "This crisis is real. So is everything you've already survived.", "steps": [{"say": "Think of one hard thing you've gotten through sober.", "secs": 12}, {"say": "Another one.", "secs": 10}, {"say": "Another one.", "secs": 10}, {"say": "Keep counting. Small ones count.", "secs": 12}, {"say": "Look at the number. That's your proof.", "secs": 8}, {"say": "Say: \"I've gotten through worse.\"", "secs": 6}]}},
];
