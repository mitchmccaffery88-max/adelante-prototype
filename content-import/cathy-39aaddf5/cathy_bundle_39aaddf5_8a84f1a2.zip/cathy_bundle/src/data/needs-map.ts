// Needs map — one entry for every Self-Help Library lesson, every Recovery
// Journey lesson, and the key support screens. Built from the SAME content the
// lesson talks already send to Adel, so the main chat can teach from real app
// content instead of giving generic tips. needTags are plain data, seeded by
// hand below, so they can be reviewed and edited without touching code logic.

import { LIBRARY } from "./library";
import { RECOVERY_MODULES } from "./recovery";
import { buildSelfHelpModule } from "./module-schema";
import { getRecoverySixStepModule } from "./recovery-module-schema";
import { getExercise } from "./exercises";

export const NEED_TAGS = [
  "low-mood", "anxiety", "anger", "craving", "slip", "sleep", "alone", "shame",
  "family", "trauma", "meds", "basics", "work", "motivation", "thoughts",
  "overwhelm", "safety",
] as const;
export type NeedTag = (typeof NEED_TAGS)[number];

export const PRIMARY_LESSONS: Partial<Record<NeedTag, string[]>> = {
  anxiety: ["anxiety", "managing-worry", "worry-cycle", "grounding"],
  thoughts: ["mind-wont-slow", "thoughts-wont-stop", "fact-story"],
  overwhelm: ["overwhelmed", "finding-footing", "solving-problems"],
  anger: ["anger-signs", "pause", "choose-response"],
  sleep: ["healthy-sleep", "everyday-life-2"],
};

export type NeedEntry = {
  area: "Self Help Library" | "Recovery Journey" | "Screen";
  moduleName: string;
  lessonId: string;
  title: string;
  minutes: number;
  /** Ready-made ACTION tag: module:<title> for Self-Help, lesson:<title> for Recovery Journey, screen:<id> for screens. */
  actionTag: string;
  problem: string;
  /** Welcome "Have you ever…" lines + checklist statements. */
  soundsLike: string[];
  /** Key teaching points. */
  teach: string[];
  action: string;
  exerciseId?: string;
  exerciseTitle?: string;
  needTags: NeedTag[];
};

// ------------------------------------------------------------ tag seeds
// Hand-seeded from each lesson's title and problem. Plain data — edit freely.

const LIBRARY_TAGS: Record<string, NeedTag[]> = {
  // Starting Strong
  "finding-footing": ["overwhelm", "motivation"],
  "daily-rhythm": ["motivation", "sleep"],
  "mind-wont-slow": ["anxiety", "thoughts"],
  overwhelmed: ["overwhelm"],
  "managing-worry": ["anxiety", "thoughts"],
  grounding: ["anxiety", "overwhelm"],
  "big-feelings": ["overwhelm", "anger"],
  "safe-now": ["safety", "trauma"],
  "healthy-sleep": ["sleep"],
  "stability-plan": ["basics", "overwhelm"],
  // Understanding My Diagnosis
  sud: ["craving"],
  depression: ["low-mood"],
  anxiety: ["anxiety"],
  bipolar: ["low-mood", "thoughts"],
  ptsd: ["trauma", "safety"],
  psychosis: ["thoughts", "meds"],
  "my-triggers-2": ["craving", "thoughts"],
  "my-strengths": ["motivation", "shame"],
  "treatment-team": ["meds", "alone"],
  "recovery-journey-2": ["motivation", "craving"],
  // Taking Care of My Treatment
  "why-meds": ["meds"],
  "med-routine": ["meds"],
  "tracking-feelings": ["low-mood", "sleep"],
  "side-effects": ["meds"],
  "talking-provider": ["meds", "alone"],
  "missed-dose": ["meds"],
  "habits-treatment": ["meds", "motivation"],
  "treatment-goals": ["meds", "motivation"],
  "prep-appointments": ["meds", "basics"],
  ownership: ["motivation", "shame"],
  // Train My Mind
  "thoughts-wont-stop": ["thoughts", "anxiety"],
  "fact-story": ["thoughts"],
  "thinking-traps": ["thoughts"],
  "inner-voice": ["thoughts", "shame", "low-mood"],
  "worry-cycle": ["anxiety", "thoughts"],
  "bigger-picture": ["thoughts", "low-mood"],
  "confidence-decisions": ["motivation", "overwhelm"],
  "letting-go-shame": ["shame", "low-mood"],
  "solving-problems": ["overwhelm", "motivation"],
  "resilient-mindset": ["motivation", "low-mood"],
  // Strengthen My Recovery
  "want-to-use": ["craving"],
  triggers: ["craving"],
  surfing: ["craving"],
  "recovery-choices": ["craving", "motivation"],
  "stress-without-using": ["overwhelm", "craving"],
  "one-bad-day": ["slip", "shame"],
  "recovery-toolbox": ["craving", "motivation"],
  motivation: ["motivation"],
  "recovery-support-system": ["alone", "craving"],
  "who-i-want": ["motivation", "shame"],
  // Managing Big Emotions
  "understanding-emotions": ["overwhelm"],
  "anger-signs": ["anger"],
  explode: ["anger"],
  pause: ["anger", "overwhelm"],
  "choose-response": ["anger"],
  "managing-conflict": ["anger", "family"],
  "communicating-upset": ["anger", "family"],
  repair: ["anger", "family", "shame"],
  "emotional-strength": ["overwhelm", "motivation"],
  "grief-loss": ["low-mood", "family", "craving"],
  // Building My Support Team
  "count-on": ["alone"],
  "ask-help": ["alone", "shame"],
  "rebuild-trust": ["family", "alone"],
  boundaries: ["family", "anger"],
  "communicating-needs": ["family", "alone"],
  "difficult-relationships": ["family", "anger"],
  "positive-connections": ["alone"],
  "my-community": ["alone"],
  "give-receive": ["alone", "family"],
  "support-plan": ["alone"],
  // Getting Back on My Feet
  housing: ["basics"],
  work: ["work"],
  "money-basics": ["basics", "work"],
  "food-resources": ["basics"],
  "healthcare-support": ["basics", "meds"],
  "my-benefits": ["basics"],
  transportation: ["basics"],
  "community-connections": ["alone", "basics"],
  "legal-responsibilities": ["basics", "overwhelm"],
  "resource-plan": ["basics"],
  // My Success Plan
  "my-vision": ["motivation"],
  "goals-that-matter": ["motivation"],
  "breaking-goals": ["motivation", "overwhelm"],
  "action-plan": ["motivation"],
  "habits-goals": ["motivation"],
  "staying-motivated": ["motivation", "low-mood"],
  setbacks: ["slip", "motivation"],
  "success-system": ["motivation", "basics"],
  "celebrating-progress": ["motivation", "low-mood"],
  "future-roadmap": ["motivation"],
};

const RECOVERY_TAGS: Record<string, NeedTag[]> = {
  // My First Days Out
  "first-days-1": ["overwhelm", "anxiety"],
  "first-days-2": ["craving"],
  "first-days-3": ["alone", "craving"],
  "first-days-4": ["alone", "basics"],
  "first-days-5": ["slip", "shame"],
  "first-days-6": ["overwhelm", "motivation"],
  "first-days-7": ["alone", "shame"],
  "first-days-8": ["low-mood", "thoughts"],
  "first-days-9": ["sleep", "low-mood"],
  "first-days-10": ["motivation"],
  // Finding My People
  "my-people-1": ["alone"],
  "my-people-2": ["alone"],
  "my-people-3": ["alone", "anxiety"],
  "my-people-4": ["alone"],
  "my-people-5": ["alone"],
  "my-people-6": ["alone"],
  "my-people-7": ["alone", "family"],
  "my-people-8": ["alone", "shame"],
  "my-people-9": ["motivation"],
  "my-people-10": ["motivation", "alone"],
  // Understanding My Addiction
  "understanding-1": ["craving", "thoughts"],
  "understanding-2": ["craving"],
  "understanding-3": ["meds", "craving", "safety"],
  "understanding-4": ["craving", "sleep", "anger", "alone"],
  "understanding-5": ["overwhelm", "craving"],
  "understanding-6": ["low-mood", "anxiety", "meds"],
  "understanding-7": ["thoughts", "slip"],
  "understanding-8": ["sleep", "low-mood"],
  "understanding-9": ["trauma", "shame"],
  "understanding-10": ["shame", "motivation"],
  // Changing My Everyday Life
  "everyday-life-1": ["motivation", "overwhelm"],
  "everyday-life-2": ["sleep"],
  "everyday-life-3": ["basics", "craving"],
  "everyday-life-4": ["low-mood", "motivation"],
  "everyday-life-5": ["craving", "motivation"],
  "everyday-life-6": ["overwhelm", "anger"],
  "everyday-life-7": ["motivation", "thoughts"],
  "everyday-life-8": ["meds"],
  "everyday-life-9": ["low-mood", "motivation"],
  "everyday-life-10": ["motivation"],
  // Healing My Relationships
  "relationships-1": ["family", "shame"],
  "relationships-2": ["family", "anger"],
  "relationships-3": ["family", "anger"],
  "relationships-4": ["family"],
  "relationships-5": ["family"],
  "relationships-6": ["alone", "family"],
  "relationships-7": ["family", "safety"],
  "relationships-8": ["family", "shame"],
  "relationships-9": ["shame", "low-mood"],
  "relationships-10": ["family"],
  // Building a Life That Works
  "life-that-works-1": ["basics"],
  "life-that-works-2": ["work"],
  "life-that-works-3": ["basics", "work"],
  "life-that-works-4": ["work", "motivation"],
  "life-that-works-5": ["basics"],
  "life-that-works-6": ["basics", "meds"],
  "life-that-works-7": ["basics"],
  "life-that-works-8": ["motivation", "craving"],
  "life-that-works-9": ["motivation"],
  "life-that-works-10": ["basics", "overwhelm"],
  // When Recovery Gets Hard
  "when-hard-1": ["slip", "craving"],
  "when-hard-2": ["slip", "craving"],
  "when-hard-3": ["craving", "thoughts"],
  "when-hard-4": ["craving", "safety"],
  "when-hard-5": ["slip", "shame"],
  "when-hard-6": ["slip", "motivation"],
  "when-hard-7": ["alone", "slip"],
  "when-hard-8": ["craving", "motivation"],
  "when-hard-9": ["slip", "shame", "safety"],
  "when-hard-10": ["slip", "craving"],
  // Becoming Someone New
  "someone-new-1": ["motivation", "shame"],
  "someone-new-2": ["motivation", "shame"],
  "someone-new-3": ["motivation", "low-mood"],
  "someone-new-4": ["motivation"],
  "someone-new-5": ["low-mood", "motivation"],
  "someone-new-6": ["anxiety", "low-mood"],
  "someone-new-7": ["motivation", "alone"],
  "someone-new-8": ["alone", "motivation"],
  "someone-new-9": ["motivation"],
  "someone-new-10": ["motivation"],
  // Living Recovery
  "living-recovery-1": ["motivation", "craving"],
  "living-recovery-2": ["alone", "motivation"],
  "living-recovery-3": ["alone"],
  "living-recovery-4": ["alone", "motivation"],
  "living-recovery-5": ["alone", "motivation"],
  "living-recovery-6": ["motivation", "safety"],
  "living-recovery-7": ["overwhelm", "safety"],
  "living-recovery-8": ["motivation", "low-mood"],
  "living-recovery-9": ["motivation", "low-mood"],
  "living-recovery-10": ["motivation", "slip"],
};

// ------------------------------------------------------------ screens

const SCREEN_ENTRIES: NeedEntry[] = [
  { area: "Screen", moduleName: "Community Resources", lessonId: "resource:employment", title: "Find fair-chance jobs", minutes: 2, actionTag: "resource:Employment",
    problem: "Some local employers and programs hire people with a record.", soundsLike: ["I need a job", "nobody will hire me", "my record", "job search", "who hires people with a record"], teach: ["Some local employers and programs hire people with a record."], action: "See Employment resources.", needTags: ["work"] },
  { area: "Screen", moduleName: "Community Resources", lessonId: "resource:housing", title: "Find housing help", minutes: 2, actionTag: "resource:Housing",
    problem: "Local housing programs can help you find a place.", soundsLike: ["I need a place to live", "I need housing", "help with rent", "sober living"], teach: ["Local housing programs can help you find a place."], action: "See Housing resources.", needTags: ["basics"] },
  { area: "Screen", moduleName: "Community Resources", lessonId: "resource:legal-services", title: "Find legal help", minutes: 2, actionTag: "resource:Legal Services",
    problem: "Free legal help can clear old fines or help with your record.", soundsLike: ["I need a lawyer", "help with my record", "clean up my record", "I need my ID", "legal help"], teach: ["Free legal help can clear old fines or help with your record."], action: "See Legal Services resources.", needTags: ["basics"] },
  { area: "Screen", moduleName: "Community Resources", lessonId: "resource:food-assistance", title: "Find food near me", minutes: 2, actionTag: "resource:Food Assistance",
    problem: "Food banks and free meals are nearby.", soundsLike: ["I need food", "where can I eat", "food bank", "I'm hungry"], teach: ["Food banks and free meals are nearby."], action: "See Food Assistance resources.", needTags: ["basics"] },
  { area: "Screen", moduleName: "Community Resources", lessonId: "resource:transportation", title: "Find a ride", minutes: 2, actionTag: "resource:Transportation",
    problem: "Bus passes and ride programs can get you to appointments.", soundsLike: ["I need a ride", "I don't have a car", "how do I get there", "bus pass"], teach: ["Bus passes and ride programs can get you to appointments."], action: "See Transportation resources.", needTags: ["basics"] },
  { area: "Screen", moduleName: "Community Resources", lessonId: "resource:healthcare", title: "Find a clinic", minutes: 2, actionTag: "resource:Healthcare",
    problem: "Local clinics see people with or without insurance.", soundsLike: ["I need a doctor", "I'm sick", "I need a clinic", "health care"], teach: ["Local clinics see people with or without insurance."], action: "See Healthcare resources.", needTags: ["basics", "meds"] },
  { area: "Screen", moduleName: "Community Resources", lessonId: "resource:recovery-meetings", title: "Find recovery meetings", minutes: 2, actionTag: "resource:Recovery Meetings",
    problem: "Meetings are free and you don't have to talk.", soundsLike: ["I need a meeting", "AA or NA near me", "recovery group"], teach: ["Meetings are free and you don't have to talk."], action: "See Recovery Meetings resources.", needTags: ["craving", "alone"] },
  { area: "Screen", moduleName: "Community Resources", lessonId: "resource:education", title: "Find school or training", minutes: 2, actionTag: "resource:Education",
    problem: "GED, college and trade programs are open to people with a record.", soundsLike: ["I want my GED", "go back to school", "job training", "learn a trade"], teach: ["GED, college and trade programs are open to people with a record."], action: "See Education resources.", needTags: ["work"] },
  { area: "Screen", moduleName: "My support", lessonId: "screen:peer", title: "Talk to Devon, your peer specialist", minutes: 1, actionTag: "screen:peer",
    problem: "Need a real person who's been through this.", soundsLike: ["I want to talk to a real person", "I need someone who gets it", "I want to talk to Devon"],
    teach: ["Devon is a peer specialist — someone who has been through this and is trained to help."], action: "Message Devon.", needTags: ["alone"] },
  { area: "Screen", moduleName: "My support", lessonId: "screen:therapy", title: "Book a video therapy session", minutes: 2, actionTag: "screen:therapy",
    problem: "Wanting to talk with a licensed therapist.", soundsLike: ["I want to talk to a therapist", "I need counseling", "I want professional help"],
    teach: ["A licensed therapist can meet by video through the app."], action: "Book a video session.", needTags: ["low-mood", "anxiety", "trauma"] },
  { area: "Screen", moduleName: "Today", lessonId: "screen:craving", title: "Get through this craving", minutes: 2, actionTag: "screen:craving",
    problem: "A craving is happening right now.", soundsLike: ["I'm craving right now", "I want to use right now", "the urge is hitting me"],
    teach: ["A craving peaks and passes — ride it out one minute at a time."], action: "Open the craving screen.", exerciseId: "urge-surfing-timer", exerciseTitle: "Urge Surfing Timer", needTags: ["craving"] },
  { area: "Screen", moduleName: "Today", lessonId: "screen:safety-plan", title: "Open my safety plan", minutes: 2, actionTag: "screen:safety-plan",
    problem: "Feeling unsafe or close to the edge.", soundsLike: ["I don't feel safe", "I'm scared of what I might do", "I need my safety plan"],
    teach: ["Your safety plan has your own words and people for the hardest moments."], action: "Open the safety plan.", needTags: ["safety"] },
  { area: "Screen", moduleName: "My support", lessonId: "screen:meetings", title: "Find a recovery meeting", minutes: 2, actionTag: "screen:meetings",
    problem: "Wanting to find a meeting nearby.", soundsLike: ["I want to go to a meeting", "where are meetings near me", "I need a group"],
    teach: ["Meetings are free, nearby, and you don't have to talk."], action: "Find a meeting.", needTags: ["alone", "craving"] },
  { area: "Screen", moduleName: "Today", lessonId: "screen:day-plan", title: "Open my 24-hour plan", minutes: 1, actionTag: "screen:day-plan",
    problem: "The next 24 hours need a plan.", soundsLike: ["what should I do today", "my plan for today", "I need a plan for tonight"],
    teach: ["Your 24-hour plan has the next small steps you already chose."], action: "Open the 24-hour plan.", needTags: ["basics", "overwhelm"] },
  { area: "Screen", moduleName: "Public Assistance", lessonId: "screen:pa-phone", title: "Get a free phone (LifeLine)", minutes: 3, actionTag: "resource:Public Assistance – Phone",
    problem: "No phone or no phone service.", soundsLike: ["I need a phone", "my phone got cut off", "I can't afford a phone"],
    teach: ["LifeLine gives a free phone and service if you qualify."], action: "See the phone section.", needTags: ["basics"] },
  { area: "Screen", moduleName: "Public Assistance", lessonId: "screen:pa-food", title: "Find food help", minutes: 3, actionTag: "resource:Public Assistance – Food",
    problem: "Hungry or out of food money.", soundsLike: ["I'm hungry", "I need food", "food stamps", "CalFresh"],
    teach: ["CalFresh and local food banks can help this week."], action: "See the food section.", needTags: ["basics"] },
  { area: "Screen", moduleName: "Public Assistance", lessonId: "screen:pa-shelter", title: "Find shelter & housing help", minutes: 3, actionTag: "resource:Public Assistance – Shelter",
    problem: "Nowhere to sleep tonight.", soundsLike: ["I need a place to sleep", "I'm homeless", "I need shelter tonight"],
    teach: ["Call 2-1-1 and the Coordinated Entry access points first for a bed tonight."], action: "See the shelter section.", needTags: ["basics", "safety"] },
  { area: "Screen", moduleName: "Public Assistance", lessonId: "screen:pa-cash", title: "Cash aid & health coverage", minutes: 3, actionTag: "resource:Public Assistance – Cash",
    problem: "No money or no health coverage.", soundsLike: ["I'm broke", "I need cash aid", "I need Medi-Cal", "I can't pay my bills"],
    teach: ["CalWORKs, General Assistance, Medi-Cal and SSI may apply to you."], action: "See the cash aid section.", needTags: ["basics", "meds"] },
];

// ------------------------------------------------------------ build

function lessonEntry(
  area: NeedEntry["area"], moduleName: string, lessonId: string, title: string, minutes: number,
  mod: ReturnType<typeof buildSelfHelpModule>, problem: string, action: string, tags: NeedTag[],
): NeedEntry {
  const teach = [
    ...mod.understanding.essentials.map((e) => `${e.heading}: ${e.body}`),
    ...(mod.insight ? [mod.insight] : []),
  ].filter(Boolean).slice(0, 4);
  const ex = mod.exerciseId ? getExercise(mod.exerciseId) : undefined;
  return {
    area, moduleName, lessonId, title, minutes,
    actionTag: `${area === "Self Help Library" ? "module" : "lesson"}:${title}`,
    problem,
    soundsLike: [
      ...[...mod.understanding.welcome, ...mod.understanding.checklist].slice(0, 8),
      ...(lessonId === "when-hard-9" ? ["my test is going to be dirty", "my test came back dirty", "should I skip my test"] : []),
    ],
    teach,
    action,
    ...(ex ? { exerciseId: ex.id, exerciseTitle: ex.title } : {}),
    needTags: tags,
  };
}

function buildEntries(): NeedEntry[] {
  const out: NeedEntry[] = [];
  for (const cat of LIBRARY) {
    for (const item of cat.items) {
      const mod = buildSelfHelpModule(cat, item);
      out.push(lessonEntry("Self Help Library", cat.name, item.id, item.title, item.minutes, mod, item.problem, item.action, LIBRARY_TAGS[item.id] ?? []));
    }
  }
  for (const mod of RECOVERY_MODULES) {
    for (const lesson of mod.lessons) {
      const six = getRecoverySixStepModule(mod.id, lesson.id);
      if (!six) continue;
      out.push(lessonEntry("Recovery Journey", mod.name, lesson.id, lesson.title, lesson.minutes, six, lesson.focus, lesson.action, RECOVERY_TAGS[lesson.id] ?? []));
    }
  }
  return [...out, ...SCREEN_ENTRIES];
}

export const NEED_ENTRIES: NeedEntry[] = buildEntries();

/** For each tag, the lessons that cover it, in module order (to be replaced by a reviewed list). */
export const NEED_PATHS: Record<NeedTag, string[]> = Object.fromEntries(
  NEED_TAGS.map((tag) => [tag, NEED_ENTRIES.filter((e) => e.area !== "Screen" && e.needTags.includes(tag)).map((e) => e.lessonId)]),
) as Record<NeedTag, string[]>;
