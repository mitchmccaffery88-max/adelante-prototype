// Adelante Recovery Journey — standardized SUD submodule content architecture.
// Every recovery lesson is expanded into this 10-section shape so the whole
// journey shares one reusable template (see components/recovery-submodule-template).

import { RECOVERY_MODULES, type RecoveryLesson, type RecoveryModule } from "./recovery";

export type CheckInScale = {
  question: string;
  left: string;
  right: string;
  /** At or above this value we surface extra support options. */
  supportAt: number;
  /** true = higher is harder (craving), false = higher is better (hope, connection) */
  higherIsHarder: boolean;
};

export type SkillStep = { label: string; placeholder: string; chips: string[] };

export type RecoverySubmodule = {
  id: string;
  moduleId: string;
  moduleName: string;
  mission: string;
  title: string;
  minutes: number;
  clinicalGoal: string;
  approaches: string[];
  /** 1 — Understand My Challenge */
  challenge: {
    welcome: string;
    understanding: string[];
    relate: string[];
    validation: string;
  };
  /** 2 — Check In With Myself */
  checkIn: { primary: CheckInScale; secondary: CheckInScale; wordPrompt: string };
  /** 3 — Learn What's Happening */
  learn: {
    whyHard: string;
    brain: string;
    perspective: string;
    concepts: { heading: string; body: string }[];
    didYouKnow: string;
    takeaway: string;
  };
  /** 4 — Build My Skills */
  skill: { label: string; purpose: string; steps: SkillStep[] };
  /** 5 — Practice in Real Life */
  practice: {
    scenario: string;
    choices: { label: string; feedback: string }[];
    ifPrompt: string;
    thenPlaceholder: string;
  };
  /** 6 — Talk It Through With Adel */
  adel: { intro: string; prompts: string[] };
  /** 7 — My Insight */
  insight: { statement: string; prompts: string[] };
  /** 8 — My Next Step Today */
  actions: string[];
  /** Peer recovery story shown inside section 3. */
  story: { name: string; text: string };
  /** 10 — Save to My Toolkit */
  toolName: string;
};

const BASE_APPROACHES = ["Motivational Interviewing", "Trauma-Informed Care", "Recovery-Oriented Care"];

const MODULE_APPROACHES: Record<string, string[]> = {
  welcome: [...BASE_APPROACHES, "Recovery Capital Model", "Positive Psychology"],
  "first-days": [...BASE_APPROACHES, "Relapse Prevention Therapy", "DBT distress tolerance"],
  "my-people": [...BASE_APPROACHES, "Peer Support Model", "12-Step Recovery Principles"],
  understanding: [...BASE_APPROACHES, "CBT", "Relapse Prevention Therapy"],
  "everyday-life": [...BASE_APPROACHES, "CBT behavioral activation", "SMART Recovery"],
  "living-recovery": [...BASE_APPROACHES, "ACT values work", "12-Step Recovery Principles"],
};

const GENERIC_RELATE = [
  "I feel overwhelmed",
  "I don't know what to do next",
  "I feel alone",
  "I want support but don't know where to find it",
  "I want to make different choices",
];

const DEFAULT_ACTIONS = [
  "Attend a meeting",
  "Call someone who supports me",
  "Practice my recovery skill",
  "Complete one important task",
  "Ask for help",
  "Take care of my health",
];

/** Hand-written richer content for exemplar lessons, merged over the derived defaults. */
const OVERRIDES: Record<string, Partial<RecoverySubmodule>> = {
  "first-days-2": {
    clinicalGoal: "Build a usable craving plan the member can run in under 60 seconds.",
    challenge: {
      welcome: "Have you ever had the thought to use hit so fast it felt like it wasn't even a choice?",
      understanding: [
        "You're out, and everything is loud — money, family, paperwork, people who still use.",
        "A craving can show up in the middle of a normal day and take over your whole body.",
        "Most people don't have a plan for that moment. They just try to hold on.",
      ],
      relate: [
        "I get cravings out of nowhere",
        "I don't know what to do when one hits",
        "I've used to make a feeling stop",
        "I'm around people who still use",
        "I want a plan I can actually follow",
      ],
      validation: "If you checked some of these, you are not alone. Cravings are one of the most common experiences in early recovery — and they are survivable.",
    },
    checkIn: {
      primary: { question: "How strong is your urge to use right now?", left: "No urge", right: "Very strong", supportAt: 7, higherIsHarder: true },
      secondary: { question: "How ready do you feel to ride it out?", left: "Not ready", right: "Very ready", supportAt: 0, higherIsHarder: false },
      wordPrompt: "Describe how you're feeling in one word.",
    },
    learn: {
      whyHard: "A craving isn't weakness. Your brain built a shortcut: substance = fast relief. That shortcut fires before you get a vote.",
      brain: "Your brain is trying to protect you. It remembers what stopped the pain quickest and offers it again — especially when you're tired, hungry, angry, or alone.",
      perspective: "Every craving you ride out without using makes the shortcut a little weaker. That's not willpower, it's rewiring.",
      concepts: [
        { heading: "Cravings are a wave", body: "They rise, peak, and fall. Most peak in about 20 minutes, even when it feels endless." },
        { heading: "Change place, people, or position", body: "Moving your body changes the signal. Stand up, step outside, go where people are." },
        { heading: "Reach out before you decide", body: "One text buys you time. Time is the whole game." },
      ],
      didYouKnow: "Studies of urge surfing show cravings typically peak and drop within 20–30 minutes when you don't act on them.",
      takeaway: "I don't have to make the craving go away. I only have to outlast it.",
    },
  },
  "my-people-1": {
    clinicalGoal: "Increase recovery capital by naming three reachable supports.",
    checkIn: {
      primary: { question: "How connected do you feel to people who support your recovery?", left: "Not connected", right: "Very connected", supportAt: 0, higherIsHarder: false },
      secondary: { question: "How comfortable are you reaching out today?", left: "Not at all", right: "Very", supportAt: 0, higherIsHarder: false },
      wordPrompt: "Describe how you're feeling in one word.",
    },
  },
  "welcome-1": {
    checkIn: {
      primary: { question: "How hopeful do you feel about your recovery today?", left: "Not hopeful", right: "Very hopeful", supportAt: 0, higherIsHarder: false },
      secondary: { question: "How much is today feeling like a struggle?", left: "Not much", right: "A lot", supportAt: 7, higherIsHarder: true },
      wordPrompt: "Describe how you're feeling in one word.",
    },
  },
};

function derive(mod: RecoveryModule, lesson: RecoveryLesson): RecoverySubmodule {
  const [a, b, c] = lesson.learn;
  return {
    id: lesson.id,
    moduleId: mod.id,
    moduleName: mod.name,
    mission: mod.mission,
    title: lesson.title,
    minutes: lesson.minutes,
    clinicalGoal: `Help the member answer "${lesson.focus}" and leave with one usable tool: ${lesson.tool}.`,
    approaches: MODULE_APPROACHES[mod.id] ?? BASE_APPROACHES,
    challenge: {
      welcome: `Have you ever asked yourself, "${lesson.focus}" — and not known where to start?`,
      understanding: [
        `This comes up a lot in recovery, especially early on: ${lesson.focus.toLowerCase()}`,
        "Coming home means handling a lot at once — housing, money, family, cravings, appointments.",
        "You don't have to solve all of it. This lesson takes one piece of it.",
      ],
      relate: GENERIC_RELATE,
      validation: "If you checked some of these, you are not alone. Many people in recovery feel exactly this way.",
    },
    checkIn: {
      primary: { question: `Right now, how much is "${lesson.focus.replace(/\?$/, "")}" a struggle for you?`, left: "Not much", right: "A lot", supportAt: 7, higherIsHarder: true },
      secondary: { question: "How confident do you feel handling it today?", left: "Not at all", right: "Very", supportAt: 0, higherIsHarder: false },
      wordPrompt: "Describe how you're feeling in one word.",
    },
    learn: {
      whyHard: a ?? "This is hard because it asks something of you at a time when a lot is already being asked.",
      brain: "Your brain is trying to protect you. What feels like a bad habit is usually an old survival move that used to work.",
      perspective: c ?? "Recovery changes this pattern slowly, through small repeated choices — not one perfect day.",
      concepts: lesson.learn.map((l, i) => ({ heading: ["What's really going on", "What helps", "What to remember", "One more thing"][i] ?? "Also true", body: l })),
      didYouKnow: "People who build even one recovery tool they wrote themselves are more likely to use it under stress than one handed to them.",
      takeaway: b ?? "I do not have to change everything today. I only need to take the next healthy step.",
    },
    skill: {
      label: lesson.tool,
      purpose: `${lesson.build.prompt} This becomes your "${lesson.tool}" — saved to your Recovery Toolkit at the end.`,
      steps: [
        { label: "My part of this", placeholder: lesson.build.placeholder, chips: lesson.build.chips },
        { label: "My warning signs", placeholder: "What tells me this is starting…", chips: ["Restless", "Angry", "Isolating", "Skipping meals", "Not sleeping", "Avoiding calls"] },
        { label: "My support people", placeholder: "Name and how to reach them…", chips: ["Sponsor", "Peer specialist", "Community health worker", "Therapist", "Family"] },
      ],
    },
    practice: {
      scenario: lesson.practice.scenario,
      choices: lesson.practice.choices.map((label) => ({
        label,
        feedback: `That's a real option. "${label}" buys you time and keeps you connected — that's what matters more than doing it perfectly.`,
      })),
      ifPrompt: "IF this happens…",
      thenPlaceholder: lesson.practice.thenPlaceholder,
    },
    adel: {
      intro: `Adel can help you go deeper on "${lesson.title}" — or just listen. Nothing you say here gets you in trouble.`,
      prompts: [
        "What part of this feels hardest for you?",
        "What has helped you get through difficult moments before?",
        "Who could support you with this?",
        "What is one thing you learned about yourself today?",
      ],
    },
    insight: {
      statement: "Recovery is built through small choices, not one perfect moment.",
      prompts: ["I learned…", "I noticed…", "I want to remember…"],
    },
    actions: [lesson.action, ...DEFAULT_ACTIONS],
    story: lesson.story,
    toolName: lesson.tool,
  };
}

export function getRecoverySubmodule(moduleId: string, lessonId: string): RecoverySubmodule | null {
  const mod = RECOVERY_MODULES.find((m) => m.id === moduleId);
  const lesson = mod?.lessons.find((l) => l.id === lessonId);
  if (!mod || !lesson) return null;
  const base = derive(mod, lesson);
  const o = OVERRIDES[lesson.id];
  return o ? { ...base, ...o } : base;
}
