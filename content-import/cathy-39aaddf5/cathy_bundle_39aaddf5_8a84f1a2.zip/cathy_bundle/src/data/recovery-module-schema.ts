// Recovery Journey source content is first expressed in the canonical schema,
// then adapted to its six-step lesson model without rewriting lesson content.

import { RECOVERY_MODULES, type RecoveryLesson, type RecoveryModule } from "./recovery";
import { getRecoverySubmodule } from "./recovery-submodule";
import { RECOVERY_TOPICS, applyTopic } from "./topic-content";
import { toSelfHelpModule, type CanonicalModule, type SelfHelpModule, type ToolFlowStep } from "./module-schema";

const RELATE_FALLBACK = [
  "I get thrown off by this more than I let on.",
  "I don't know what to do when it happens.",
  "I've used to make a feeling stop.",
  "I'm around people or places that make it harder.",
  "I want a plan I can actually follow.",
  "I want to handle this without using.",
];

const WARNING_SIGNS = [
  "Restless", "Angry", "Isolating", "Skipping meals", "Not sleeping",
  "Avoiding calls", "Skipping meetings", "Keeping secrets",
];

const SUPPORT_OPTIONS = [
  "Sponsor", "Peer recovery specialist", "Community health worker",
  "Therapist", "Family member", "Friend from a meeting", "Case manager",
];

const RECOVERY_IF = [
  "A craving hits out of nowhere.",
  "I'm alone and my head gets loud.",
  "Someone from the old life reaches out.",
  "I have money in my pocket and nothing to do.",
  "I'm hungry, angry, lonely, or tired.",
];

const RECOVERY_THEN = [
  "Use the tool I just built.",
  "Text one person on my support list.",
  "Change my place, people, or position.",
  "Get to a meeting today.",
  "Ride it out for 20 minutes before I decide anything.",
];

const RECOVERY_NEXT = [
  "Go to one meeting.",
  "Call or text someone who supports my recovery.",
  "Practice the skill I built today.",
  "Take care of one basic need — food, sleep, water.",
  "Ask for help before I think I need it.",
];

function buildFromLesson(mod: RecoveryModule, lesson: RecoveryLesson): CanonicalModule {
  const sub = getRecoverySubmodule(mod.id, lesson.id)!;
  const [l1, l2, l3] = lesson.learn;

  const skillSteps: ToolFlowStep[] = [
    {
      id: "mine",
      title: "Step 1 — What's true for me here",
      instruction: lesson.build.prompt,
      options: lesson.build.chips,
      maxPicks: 3,
    },
    {
      id: "signs",
      title: "Step 2 — My warning signs",
      instruction: "Pick what shows up first when this starts.",
      options: WARNING_SIGNS,
      maxPicks: 3,
    },
    {
      id: "people",
      title: "Step 3 — Who I reach out to",
      instruction: "Choose who you'd actually contact.",
      options: SUPPORT_OPTIONS,
      maxPicks: 3,
    },
    {
      id: "next",
      title: "Step 4 — My move today",
      instruction: "Choose one action you can do today.",
      options: [lesson.action, ...RECOVERY_NEXT].slice(0, 5),
      maxPicks: 1,
    },
  ];

  return {
    id: lesson.id,
    categoryId: mod.id,
    categoryName: mod.name,
    title: lesson.title,
    subtitle: `Mission: ${mod.mission}`,
    minutes: lesson.minutes,
    challenge: {
      welcome: [
        sub.challenge.welcome,
        ...sub.challenge.understanding,
      ],
      checklistTitle: "Which of these sound like you?",
      checklist: RELATE_FALLBACK,
      normalizing: sub.challenge.validation,
    },
    checkIn: {
      intro: "Rate where you are right now. This is just for you — nothing here gets you in trouble.",
      dimensions: [
        {
          id: "struggle",
          label: sub.checkIn.primary.question,
          left: sub.checkIn.primary.left,
          right: sub.checkIn.primary.right,
          higherIsHarder: sub.checkIn.primary.higherIsHarder,
        },
        {
          id: "confidence",
          label: sub.checkIn.secondary.question,
          left: sub.checkIn.secondary.left,
          right: sub.checkIn.secondary.right,
          higherIsHarder: sub.checkIn.secondary.higherIsHarder,
        },
        {
          id: "support",
          label: "How supported do you feel in your recovery today?",
          left: "On my own",
          right: "Well supported",
          higherIsHarder: false,
        },
      ],
      reflectionPrompt: sub.checkIn.wordPrompt,
    },
    learn: {
      whyHappening: { heading: "What's really going on", body: sub.learn.whyHard },
      whyHard: {
        heading: "Why this is hard in recovery",
        body: sub.learn.brain,
        bullets: [l1, l2, l3].filter(Boolean) as string[],
      },
      stages: {
        heading: `A peer's story — ${sub.story.name}`,
        stages: [
          { name: "Where they started", quote: lesson.focus, body: sub.story.text },
          { name: "What changed", quote: l2 ?? "Small steps, repeated.", body: sub.learn.perspective },
          { name: "Where it led", quote: lesson.tool, body: `They kept one thing they could use again: "${lesson.tool}". That's what you're building in the next step.` },
        ],
      },
      reframe: {
        heading: "A smaller question",
        body: `Instead of "How do I fix all of this?", try "${lesson.focus}" — just for today. ${sub.learn.perspective}`,
      },
      didYouKnow: sub.learn.didYouKnow,
      keyTakeaway: sub.learn.takeaway,
    },
    skill: {
      toolName: lesson.tool,
      purpose: sub.skill.purpose,
      steps: skillSteps,
      saveLabel: lesson.tool,
      reminder: sub.insight.statement,
    },
    practice: {
      scenarioTitle: "A real moment",
      scenario: lesson.practice.scenario,
      prompt: "What's your first move?",
      choices: sub.practice.choices,
      closing: "There's no perfect answer. What matters is having a move ready before the moment shows up.",
      ifOptions: RECOVERY_IF,
      thenOptions: [...lesson.practice.choices, ...RECOVERY_THEN].slice(0, 6),
      confidencePrompt: "How confident do you feel using this plan if this happens today?",
    },
    adel: {
      intro: "Adel is a recovery coach, not a therapist. Nothing you say here gets you in trouble.",
      questions: [
        `What part of "${lesson.title.replace(/[.?]$/, "")}" feels hardest for you right now?`,
        "What has already helped you get through a hard moment in your recovery?",
        "Who could you tell about what you built today?",
      ],
      recommends: [{ label: `More in ${mod.name}`, action: `ACTION:recovery:${mod.id}` }],
    },
    insight: sub.insight.statement,
    nextSteps: [lesson.action, ...RECOVERY_NEXT].slice(0, 5),
    progressNote: "Adel looks at the change between your first and second ratings — showing up counts more than the number.",
    toolkitKey: `recovery:${lesson.id}`,
  };
}

export function getRecoveryCanonicalModule(moduleId: string, lessonId: string): CanonicalModule | null {
  const mod = RECOVERY_MODULES.find((m) => m.id === moduleId);
  const lesson = mod?.lessons.find((l) => l.id === lessonId);
  if (!mod || !lesson) return null;
  return applyTopic(buildFromLesson(mod, lesson), RECOVERY_TOPICS[lesson.id], false);
}

/** Recovery Journey's six-step lesson shape, preserving the existing lesson content. */
export function getRecoverySixStepModule(moduleId: string, lessonId: string): SelfHelpModule | null {
  const canonical = getRecoveryCanonicalModule(moduleId, lessonId);
  if (!canonical) return null;
  const lesson = RECOVERY_MODULES.find((m) => m.id === moduleId)?.lessons.find((l) => l.id === lessonId);
  const sixStep = toSelfHelpModule(canonical);
  // The peer story is its own card in Build My Skill, not a lesson idea; drop generated stages.
  return {
    ...sixStep,
    understanding: { ...sixStep.understanding, stages: undefined },
    peerStory: RECOVERY_TOPICS[lessonId]?.story ?? lesson?.story,
  };
}
