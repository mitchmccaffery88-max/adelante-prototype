import test from "node:test";
import assert from "node:assert/strict";
import { LIBRARY_TOPICS, RECOVERY_TOPICS } from "./topic-content";
import { getSelfHelpModule } from "./module-schema";
import { getRecoverySixStepModule } from "./recovery-module-schema";
import { resolveRelatedLesson, resolveRelatedLessons } from "./related-lessons";

const pairs = [
  ["daily-rhythm", "everyday-life-1"], ["grounding", "first-days-1"],
  ["big-feelings", "everyday-life-6"], ["one-bad-day", "first-days-5"],
  ["first-days-5", "when-hard-5"], ["housing", "life-that-works-1"],
  ["work", "life-that-works-2"], ["money-basics", "life-that-works-3"],
  ["transportation", "life-that-works-5"], ["healthcare-support", "life-that-works-6"],
  ["letting-go-shame", "relationships-9"], ["boundaries", "relationships-3"],
  ["rebuild-trust", "relationships-1"], ["my-strengths", "someone-new-1"],
  ["my-vision", "someone-new-9"], ["managing-worry", "worry-cycle"],
] as const;

function moduleFor(id: string) {
  const lesson = resolveRelatedLesson(id);
  if (!lesson) return null;
  return lesson.kind === "library" ? getSelfHelpModule(lesson.category, id) : getRecoverySixStepModule(lesson.moduleId, id);
}

for (const [a, b] of pairs) {
  test(`${a} and ${b} link both ways through topic data and the lesson schema`, () => {
    for (const [source, target] of [[a, b], [b, a]]) {
      const topic = LIBRARY_TOPICS[source] ?? RECOVERY_TOPICS[source];
      assert.ok(topic?.related?.includes(target));
      const mod = moduleFor(source);
      assert.ok(mod?.related?.includes(target));
      const resolved = resolveRelatedLessons(mod?.related);
      assert.ok(resolved.some((lesson) => lesson.id === target));
      assert.ok(resolved.every((lesson) => lesson.id !== source));
    }
  });
}

test("the three slip lessons have adjacent reciprocal links, not an extra pair", () => {
  assert.deepEqual(moduleFor("one-bad-day")?.related, ["first-days-5"]);
  assert.deepEqual(moduleFor("first-days-5")?.related, ["one-bad-day", "when-hard-5"]);
  assert.deepEqual(moduleFor("when-hard-5")?.related, ["first-days-5"]);
});

test("unknown saved related ids are ignored and repeated ids produce one destination", () => {
  assert.equal(resolveRelatedLesson("retired-or-unknown"), undefined);
  assert.deepEqual(resolveRelatedLessons(["retired-or-unknown"]), []);
  assert.equal(resolveRelatedLessons(["work", "work"]).length, 1);
});

test("Work's recovery destination uses Life That Works 2 and a Recovery action", () => {
  const lesson = resolveRelatedLesson("life-that-works-2");
  assert.equal(lesson?.kind, "recovery");
  if (lesson?.kind !== "recovery") return;
  assert.equal(lesson.moduleId, "life-that-works");
  assert.ok(lesson.action.startsWith("lesson:"));
  assert.ok(resolveRelatedLesson("work")?.action.startsWith("module:"));
});

for (const [category, id, limits, exercise] of [
  ["everyday-life", "everyday-life-1", [3, 2, 2, 2, 3], "picture-tomorrow-morning"],
  ["starting-strong", "mind-wont-slow", [3, 2, 3, 2, 1], "snow-globe"],
  ["starting-strong", "overwhelmed", [8, 2, 2, 2, 1], "stop-skill"],
] as const) {
  test(`${id} uses its assigned exercise and supplied pick limits`, () => {
    const mod = id === "everyday-life-1" ? getRecoverySixStepModule(category, id) : getSelfHelpModule(category, id);
    assert.ok(mod);
    assert.equal(mod.exerciseId, exercise);
    assert.deepEqual(mod.skill.steps.map((step) => step.maxPicks), limits);
  });
}