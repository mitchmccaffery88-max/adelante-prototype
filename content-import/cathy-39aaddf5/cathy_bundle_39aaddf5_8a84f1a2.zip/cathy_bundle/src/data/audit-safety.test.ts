import test from "node:test";
import assert from "node:assert/strict";
import { RESOURCES, MEDS, OBLIGATIONS } from "./mock";
import { LIBRARY_TOPICS, RECOVERY_TOPICS } from "./topic-content";
import { IF_THEN_CONTENT, BACKUP_ACTIONS } from "./if-then-content";
import { RECOVERY_IF_THEN_CONTENT } from "./recovery-if-then-content";
import { ANY_TIME_HELP, MEDICINE_CONTINUITY, SUPERVISION_SLIP, STOPPING_SAFELY } from "./care-notes";
import { LINES } from "./contact-numbers";
import { FENTANYL_WARNING } from "./safety-content";
import { backupAction } from "@/lib/plans";
import { resolveResource, normalizeSavedResourceIds, correctPrototypeMeds, correctPrototypeObligations, RESOURCE_ID_ALIASES } from "@/lib/resource-aliases";
import { getRecoverySixStepModule } from "./recovery-module-schema";

test("first-days-8 keeps fixed anytime support destinations outside mood choices", () => {
  assert.equal(RECOVERY_TOPICS["first-days-8"]?.skillSteps?.flatMap((step) => step.options).some((option) => /hurt myself|want to die/i.test(option)), false);
  assert.equal(getRecoverySixStepModule("first-days", "first-days-8")?.careNote, ANY_TIME_HELP);
  assert.deepEqual(ANY_TIME_HELP.links?.map((link) => link.action), ["tel:988", "screen:crisis"]);
});
test("medicine continuity is stacked after all existing first-days-5 notes", () => {
  assert.equal(getRecoverySixStepModule("first-days", "first-days-1")?.careNote, MEDICINE_CONTINUITY);
  assert.deepEqual(getRecoverySixStepModule("first-days", "first-days-5")?.careNote, [SUPERVISION_SLIP, STOPPING_SAFELY, MEDICINE_CONTINUITY]);
  assert.deepEqual(MEDICINE_CONTINUITY.links?.map((link) => link.action), ["tel:18667324114", "lesson:Medicine, Tolerance, and Staying Alive"]);
});
test("all emergency lesson backups have 988 immediately before 911", () => {
  let emergencyLists = 0;
  const configs = [...Object.values(IF_THEN_CONTENT), ...Object.values(RECOVERY_IF_THEN_CONTENT), ...Object.values(LIBRARY_TOPICS).flatMap((topic) => topic.ifThen ? [topic.ifThen] : []), ...Object.values(RECOVERY_TOPICS).flatMap((topic) => topic.ifThen ? [topic.ifThen] : [])];
  for (const config of configs) {
    const index = config.backups?.indexOf(BACKUP_ACTIONS.emergency) ?? -1;
    if (index < 0) continue;
    emergencyLists++;
    assert.equal(config.backups?.[index - 1], BACKUP_ACTIONS.crisisLine);
  }
  assert.equal(emergencyLists, 6);
  assert.deepEqual(backupAction(BACKUP_ACTIONS.crisisLine), { kind: "tel", phone: "988", label: BACKUP_ACTIONS.crisisLine });
});
test("county crisis contact and fentanyl source remain pending verification", () => {
  assert.equal(LINES.tulareCrisis.tel, "18003201616");
  assert.equal(LINES.tulareCrisis.verified, false);
  assert.equal(FENTANYL_WARNING.sourceUrl, "https://www.cdc.gov/overdose-prevention/about/fentanyl.html");
  assert.equal(FENTANYL_WARNING.verified, false);
});
test("retired AA, NAMI and every duplicate 211 resolve to one retained entry", () => {
  for (const [old, kept] of Object.entries(RESOURCE_ID_ALIASES)) {
    assert.equal(RESOURCES.some((resource) => resource.id === old), false);
    assert.equal(resolveResource(old)?.id, kept);
  }
  assert.equal(RESOURCES.filter((resource) => resource.phone === "211").length, 1);
  assert.equal(resolveResource("211-housing")?.category, "assistance");
  assert.deepEqual(normalizeSavedResourceIds(["aa-central-valley", "add-aa-tulare-county", "211-housing", "pa-211-shelter"]), ["add-aa-tulare-county", "pa-211-food"]);
});
test("SUD treatment stays reachable in Healthcare and probation uses county contact", () => {
  assert.equal(resolveResource("kings-view-sud")?.category, "healthcare");
  const probation = resolveResource("tulare-probation-adult");
  assert.equal(probation?.address, "221 S. Mooney Blvd, Room 206");
  assert.equal(probation?.city, "Visalia, CA 93291");
  assert.equal(probation?.phone, "(559) 713-2750");
  assert.equal(probation?.website, "https://tularecounty.ca.gov/probation/contact-us");
  assert.equal(probation?.verified, false);
  assert.equal(OBLIGATIONS[0]?.phone, "(559) 713-2750");
});
test("demo sertraline has one 50 mg morning dose and removes only the old demo evening duplicate", () => {
  const sertraline = MEDS.filter((med) => med.med === "Sertraline");
  assert.equal(sertraline.length, 1);
  assert.equal(sertraline[0]?.time, "8:00 AM");
  assert.equal(sertraline[0]?.dose, "50 mg · 1 tablet");
  const morning = sertraline[0];
  assert.ok(morning);
  const custom = { ...morning, id: "custom-med", time: "8:00 PM" };
  assert.deepEqual(correctPrototypeMeds([morning, { ...morning, id: "med-pm", time: "8:00 PM" }, custom]), [morning, custom]);
});
test("old demo obligation location is corrected without changing completion or personal edits", () => {
  const obligation = OBLIGATIONS[0];
  assert.ok(obligation);
  const legacy = { ...obligation, location: "Tulare County Probation, 1424 Forum Dr, Visalia", completed: true };
  const own = { ...obligation, location: "My confirmed office" };
  assert.equal(correctPrototypeObligations([legacy])[0]?.completed, true);
  assert.equal(correctPrototypeObligations([legacy])[0]?.location, obligation.location);
  assert.deepEqual(correctPrototypeObligations([own]), [own]);
});