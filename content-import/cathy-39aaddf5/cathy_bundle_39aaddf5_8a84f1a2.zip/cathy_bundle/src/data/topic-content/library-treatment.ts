import type { TopicContent } from "./types";

// Taking Care of My Treatment — topic-specific content (batch 2).
export const TREATMENT: Record<string, TopicContent> = {
  "why-meds": {
    exerciseId: "two-sides",
    toolName: "The Weigh-In",
    toolIntro: "Weigh what your medication gives you and what it costs, so you can talk it through.",
    welcome: [
      "Have you ever taken medication for weeks and wondered if it's doing anything at all?",
      "No fireworks, no instant fix, just the same days — so it's easy to think it isn't working.",
      "Medication often works quietly, by lowering the volume, not by flipping a switch.",
    ],
    checklist: [
      "I've thought about stopping because I don't feel a difference.",
      "I wonder if the medication is even doing anything.",
      "I expected to feel better faster.",
      "Nobody explained what the medication is actually supposed to do.",
      "I feel weak for needing it.",
      "I compare my progress to people who don't take medication.",
    ],
    normalizing: "If this sounds like you, that's a very common place to be. Slow, quiet change is easy to miss. Medicine for opioid or alcohol use is real treatment too, not swapping one drug for another. The next steps help you notice what's already shifting.",
    whyHard: {
      heading: "Why 'nothing's happening' is misleading",
      body: "Medication usually works by lowering the intensity of bad days, not by creating instant good ones. That kind of change is hard to feel day to day, but it's real, and it's what makes the rest of your recovery possible.",
      bullets: ["Expecting a fast, obvious change", "Comparing yourself to people without a diagnosis", "Feeling like needing help means weakness", "Not knowing what the medication is supposed to do", "Judging it too soon"],
    },
    reframe: {
      heading: "Fewer bad days, not instant good ones",
      body: "Instead of asking \"Do I feel amazing?\", ask \"Are my worst days a little less bad than they used to be?\" That's the real measure, and it usually shows up before you notice it.",
    },
    checkIn: [
      { id: "struggle", label: "How much doubt do you have about your medication right now?", left: "None", right: "A lot", higherIsHarder: true },
      { id: "confidence", label: "How well can you explain what your medication is supposed to do?", left: "Not well", right: "Very well", higherIsHarder: false },
      { id: "support", label: "How comfortable are you asking your provider questions?", left: "Not comfortable", right: "Very comfortable", higherIsHarder: false },
    ],
    adelQuestions: [
      "What made you start wondering if the medication is working?",
      "Has anything, even something small, felt a little steadier lately?",
    ],
    skillSteps: [{"id": "meds", "title": "Step 1 — My medications", "maxPicks": 4, "instruction": "Pick what each one is for, and type its name in the box.", "options": ["For mood", "For anxiety", "For sleep", "For voices or thoughts", "For cravings", "For focus", "For my physical health", "Not sure what it's for"], "shared": "medications"}, {"id": "helps", "title": "Step 2 — What it helps me do in real life", "maxPicks": 3, "instruction": "Choose up to 3.", "options": ["Sleep through the night", "Keep my temper", "Stay out of the hospital", "Think clearly", "Feel less anxious", "Get out of bed", "Stay away from using", "Get along with people"]}, {"id": "bothers", "title": "Step 3 — What bothers me about it", "maxPicks": 3, "instruction": "Choose up to 3.", "options": ["Side effects", "Remembering to take it", "Cost or refills", "How it makes me feel about myself", "What people say", "Feeling flat", "Weight change", "Nothing much"]}, {"id": "unsure", "title": "Step 4 — What I'm unsure about", "maxPicks": 2, "instruction": "Choose up to 2.", "options": ["How long I'll need it", "If it's the right dose", "If it's working", "Mixing it with other things", "Long-term side effects", "What happens if I stop", "If there's another option", "Nothing right now"]}, {"id": "question", "title": "Step 5 — My question for my prescriber", "maxPicks": 1, "instruction": "Pick one.", "options": ["Is this the right dose for me?", "How long will I need this?", "What can I do about the side effects?", "Is there another option?", "What happens if I miss a dose?", "Could I come off it someday, and how?"]}],
  },

  "med-routine": {
    exerciseId: "stack-spot-signal",
    toolName: "Lock-In Routine",
    toolIntro: "Set up your meds so you don't have to remember.",
    welcome: [
      "Have you ever meant to take your medication and realized hours later that you forgot?",
      "It's not that you don't care. Memory alone is a shaky system for something that needs to happen every day.",
      "An anchor, something you already do without thinking, can carry the reminder for you.",
    ],
    checklist: [
      "I forget doses sometimes.",
      "My timing shifts around depending on the day.",
      "I don't have a set spot where I keep my medication.",
      "I tell myself I'll remember later and then don't.",
      "My routine changes too much to build a habit.",
      "I feel bad about myself when I miss a dose.",
    ],
    normalizing: "Forgetting doses is common, especially when your days don't look the same twice. The fix isn't more willpower. It's picking one anchor your body already relies on.",
    whyHard: {
      heading: "Why remembering isn't enough",
      body: "Your brain is built to notice new and urgent things, not quiet daily tasks. A pill bottle sitting on a shelf doesn't compete with a ringing phone or a hungry stomach. Attaching the dose to something that already happens gives your brain a trigger it won't miss.",
      bullets: ["Relying on memory alone", "A routine that changes daily", "Medication stored somewhere out of sight", "No cue that reminds you", "Beating yourself up instead of building a system"],
    },
    reframe: {
      heading: "Anchor it, don't remember it",
      body: "Pick one thing you already do at roughly the same time every day, coffee, brushing your teeth, plugging in your phone, and put your medication right next to it. The anchor does the remembering for you.",
    },
    checkIn: [
      { id: "struggle", label: "How often do you forget or delay a dose?", left: "Rarely", right: "Often", higherIsHarder: true },
      { id: "confidence", label: "How confident are you that you could build one solid anchor?", left: "Not confident", right: "Very confident", higherIsHarder: false },
      { id: "support", label: "How much does your daily routine stay the same?", left: "Changes a lot", right: "Pretty steady", higherIsHarder: false },
    ],
    adelQuestions: [
      "What time of day do you usually forget or almost forget?",
      "What's one thing you do every single day, no matter what?",
    ],
    skillSteps: [{"id": "anchor", "title": "Step 1 — My anchor habit", "maxPicks": 1, "instruction": "Pick one.", "options": ["Morning coffee", "Brushing my teeth", "Breakfast", "Getting dressed", "Dinner", "Getting into bed", "My morning prayer", "Feeding my pet"]}, {"id": "spot", "title": "Step 2 — Where my meds live", "maxPicks": 1, "instruction": "Pick one.", "options": ["Next to the coffee maker", "By my toothbrush", "On my nightstand", "Kitchen counter", "With my keys", "In a pillbox by the sink", "In my bag"]}, {"id": "signal", "title": "Step 3 — My backup signal", "maxPicks": 2, "instruction": "Choose up to 2.", "options": ["Phone alarm", "Pillbox", "Someone who checks on me", "Note on the mirror", "Pharmacy text reminders", "Check it off on a calendar", "Adel reminder"], "feeds": "move"}, {"id": "pharmacy", "title": "Step 4 — My pharmacy", "maxPicks": 1, "instruction": "Pick one.", "options": ["CVS", "Walgreens", "Rite Aid", "Walmart", "My clinic's pharmacy", "Mail order"], "shared": "pharmacy"}, {"id": "refill", "title": "Step 5 — Refills and days away", "maxPicks": 3, "instruction": "Choose up to 3.", "options": ["Auto-refill", "Call when I have 7 days left", "Ask for a 90-day supply", "Ask about delivery", "Pillbox in my bag for days away", "Phone alarm goes with me", "Pack meds before overnights", "Ask my pharmacist about doses at work"]}],
  },

  "tracking-feelings": {
    exerciseId: "ten-second-check-in",
    toolName: "Signal Tracker",
    toolIntro: "Track what matters most for you, and know when to tell someone.",
    welcome: [
      "Have you ever sat in an appointment and gone blank when someone asked how you've been?",
      "You know it's been a mix of days, but the details slip away by the time you're in the room.",
      "A tiny daily habit can hand your provider the real picture instead of just your worst memory.",
    ],
    checklist: [
      "I can't remember how the week actually went.",
      "I only remember my worst day when asked.",
      "I've never tracked my mood or sleep.",
      "I don't know what my provider actually wants to hear.",
      "I feel put on the spot at appointments.",
      "I want to give better information but don't know how.",
    ],
    normalizing: "This happens to almost everyone. Your brain holds onto the hardest moment, not the average week. A quick daily number fixes that without much effort at all.",
    whyHard: {
      heading: "Why memory alone falls short",
      body: "When you're asked to summarize a whole week, your brain grabs the loudest memory, usually the worst one, and treats it like the whole story. A short daily rating captures the real pattern instead of one moment.",
      bullets: ["Remembering only the hardest day", "No record to look back on", "Feeling unprepared in appointments", "Not knowing what details matter", "Guessing instead of showing real data"],
    },
    reframe: {
      heading: "Ten seconds beats a guess",
      body: "You don't need a journal or a long form. Three numbers a day, mood, sleep, side effects, give your provider more useful information than an hour of trying to remember.",
    },
    checkIn: [
      { id: "struggle", label: "How hard is it to describe your week when asked?", left: "Easy", right: "Very hard", higherIsHarder: true },
      { id: "confidence", label: "How confident are you that you could track three numbers a day?", left: "Not confident", right: "Very confident", higherIsHarder: false },
      { id: "support", label: "How useful would this feel at your next appointment?", left: "Not useful", right: "Very useful", higherIsHarder: false },
    ],
    adelQuestions: [
      "What do you usually say when someone asks how you've been?",
      "What time of day would be easiest for you to log a quick number?",
    ],
    skillSteps: [{"id": "track", "title": "Step 1 — What I'll track", "maxPicks": 3, "instruction": "Choose up to 3.", "options": ["Mood", "Sleep", "Anxiety", "Cravings", "Voices or unusual thoughts", "Energy", "Anger", "Pain"]}, {"id": "when", "title": "Step 2 — When I'll check in", "maxPicks": 1, "instruction": "Pick one.", "options": ["When I wake up", "With my morning meds", "At lunch", "After dinner", "Before bed", "With my evening meds"]}, {"id": "number", "title": "Step 3 — When it's time to tell someone", "maxPicks": 2, "instruction": "Choose up to 2.", "options": ["My mood is 3 or lower two days in a row", "I sleep under 5 hours two nights in a row", "My anxiety hits 8 or higher", "My cravings hit 8 or higher", "A number changes a lot from my normal", "Any number scares me"], "feeds": "cue"}, {"id": "who", "title": "Step 4 — Who I tell", "maxPicks": 2, "instruction": "Choose up to 2.", "options": ["Prescriber", "Counselor", "Case manager", "Peer specialist", "Sponsor", "A family member", "A friend I trust"], "shared": "supportPeople"}],
  },

  "side-effects": {
    exerciseId: "know-your-red-flags",
    toolName: "Side Effect Log",
    toolIntro: "Use it each time something feels off. Never stop a medicine on your own; bring this to your prescriber.",
    welcome: [
      "Have you ever felt off since starting a medication but talked yourself out of mentioning it?",
      "Maybe you're tired all the time, or things feel flat, and you're not sure if it's the medication or just life.",
      "Your body is sending real information, and it's worth listening to.",
    ],
    checklist: [
      "Something feels different since I started this medication.",
      "I haven't told anyone about it.",
      "I've thought about just stopping instead of speaking up.",
      "I don't know if what I'm feeling counts as a side effect.",
      "I'm worried they'll take me off something that's helping.",
      "I feel embarrassed bringing up side effects.",
    ],
    normalizing: "Noticing something feels off is normal, and so is not knowing whether it's worth mentioning. It almost always is. Side effects that get reported can usually be fixed.",
    whyHard: {
      heading: "Why side effects go unreported",
      body: "It's easy to assume a side effect is just part of the deal, or to worry that speaking up means losing a medication that's helping in other ways. Most side effects can be adjusted through timing, dose, or a change, but only if your provider knows about them.",
      bullets: ["Assuming nothing can be done", "Fear of losing a helpful medication", "Not being sure it's worth mentioning", "Feeling embarrassed", "Staying quiet and then quitting instead"],
    },
    reframe: {
      heading: "Reported beats silent",
      body: "A side effect nobody knows about can't be fixed. Stopping on your own is the riskiest option. Reporting it, even something small, is the fastest way back to feeling better.",
    },
    checkIn: [
      { id: "struggle", label: "How much is a side effect bothering you right now?", left: "Not at all", right: "A lot", higherIsHarder: true },
      { id: "confidence", label: "How clear are you on what you're noticing in your body?", left: "Not clear", right: "Very clear", higherIsHarder: false },
      { id: "support", label: "How comfortable are you reporting it to your provider?", left: "Not comfortable", right: "Very comfortable", higherIsHarder: false },
    ],
    adelQuestions: [
      "What have you noticed in your body since starting this medication?",
      "What's stopped you from mentioning it so far?",
    ],
    skillSteps: [{"id": "med", "title": "Step 1 — Which medication", "maxPicks": 2, "instruction": "Choose up to 2.", "options": ["For mood", "For anxiety", "For sleep", "For voices or thoughts", "For cravings", "For focus", "For my physical health"], "shared": "medications"}, {"id": "noticed", "title": "Step 2 — What I noticed", "maxPicks": 3, "instruction": "Choose up to 3.", "options": ["Tired all day", "Upset stomach", "Trouble sleeping", "Shaky or restless", "Dizzy", "Dry mouth", "Weight change", "Feeling flat or numb", "Sexual side effects", "Headache"], "feeds": "cue"}, {"id": "bother", "title": "Step 3 — How much it bothers me", "maxPicks": 1, "instruction": "Pick one.", "options": ["1–2: Barely", "3–4: A little", "5–6: It gets in the way", "7–8: A lot", "9–10: I can't keep going like this"]}, {"id": "timing", "title": "Step 4 — When it shows up", "maxPicks": 1, "instruction": "Pick one.", "options": ["Right after my dose", "A few hours after", "At night", "In the morning", "All day", "Only some days", "Since my dose changed"]}, {"id": "tried", "title": "Step 5 — What I tried", "maxPicks": 2, "instruction": "Choose up to 2.", "options": ["Taking it with food", "Taking it at a different time (after asking)", "Drinking more water", "Resting", "Called my pharmacist", "Told my prescriber", "Nothing yet"]}],
  },

  "talking-provider": {
    exerciseId: "dont-say-fine",
    toolName: "Speak-Up Script",
    toolIntro: "Lines ready for the parts of a visit that are hardest to say. Adel can help with the words.",
    welcome: [
      "Have you ever left an appointment and realized you never said the thing you came to say?",
      "The visit moves fast, questions come at you, and your own list gets lost.",
      "A short appointment can still cover what matters, if you go in with it ready.",
    ],
    checklist: [
      "My appointments feel rushed.",
      "I leave without saying what I meant to.",
      "I forget my questions once I'm in the room.",
      "I let the provider lead the whole visit.",
      "I say I'm fine even when I'm not.",
      "I wish I said more at my last appointment.",
    ],
    normalizing: "Short appointments catch almost everyone off guard. The people who get the most out of them come in with a short list, ready to go. That's a skill, not luck.",
    whyHard: {
      heading: "Why short visits are hard to use well",
      body: "Providers work in tight windows and often lead with their own checklist. If you're not ready with your own priorities, the visit gets shaped entirely by their questions instead of your life.",
      bullets: ["Appointments that move fast", "Losing your train of thought under pressure", "Letting the provider set the whole agenda", "Saying \"I'm fine\" out of habit", "Forgetting by the time you're in the room"],
    },
    reframe: {
      heading: "Three things, said first",
      body: "Bring what's better, what's worse, and one question, written down, in your pocket. Say them in the first two minutes so they actually get addressed.",
    },
    checkIn: [
      { id: "struggle", label: "How rushed do your appointments usually feel?", left: "Not rushed", right: "Very rushed", higherIsHarder: true },
      { id: "confidence", label: "How confident are you that you could say your three things out loud?", left: "Not confident", right: "Very confident", higherIsHarder: false },
      { id: "support", label: "How supported do you feel bringing things up with your provider?", left: "Not supported", right: "Very supported", higherIsHarder: false },
    ],
    adelQuestions: [
      "What's the one thing you've been meaning to say and haven't?",
      "What usually gets in the way of saying it during the visit?",
    ],
    skillSteps: [{"id": "afraid", "title": "Step 1 — What I've been afraid to bring up", "maxPicks": 2, "instruction": "Choose up to 2.", "options": ["Side effects", "I stopped a medication", "I've been using", "Voices or strange thoughts", "Money or insurance", "Feeling worse", "Sexual side effects", "I'm not taking it the way I should"]}, {"id": "say", "title": "Step 2 — How I'll start", "maxPicks": 1, "instruction": "Pick one.", "options": ["\"There's something I've been nervous to tell you.\"", "\"I want to be honest about something.\"", "\"This is hard to say, but it's important.\"", "\"I need help with something I haven't mentioned.\"", "\"Can we talk about how the medicine is really going?\""]}, {"id": "rushed", "title": "Step 3 — My line if I feel rushed", "maxPicks": 1, "instruction": "Pick one.", "options": ["\"Can I have one more minute on this?\"", "\"Before you go, I have one more thing.\"", "\"This is important to me.\"", "\"Can someone call me about this?\""]}, {"id": "confused", "title": "Step 4 — My line if I don't understand", "maxPicks": 1, "instruction": "Pick one.", "options": ["\"Can you explain it another way?\"", "\"What does that mean for me?\"", "\"Can you write that down?\"", "\"Let me say it back to make sure I got it.\""]}, {"id": "disagree", "title": "Step 5 — My line if I don't agree", "maxPicks": 1, "instruction": "Pick one.", "options": ["\"I'd like to talk about other options.\"", "\"That doesn't feel right for me. Can we talk about why?\"", "\"What happens if I don't do that?\"", "\"Can I think about it and get back to you?\""]}],
  },

  "missed-dose": {
    exerciseId: "pause-check-call",
    toolName: "Missed-Dose Card",
    toolIntro: "Your missed-dose rules in one place.",
    welcome: [
      "Have you ever missed a dose and then spiraled into feeling like you ruined everything?",
      "Maybe you skipped the next one too, telling yourself you already messed up.",
      "One missed dose is common and usually fixable. What matters is what you do next.",
    ],
    checklist: [
      "I've missed a dose and panicked about what to do.",
      "I've doubled up without checking if that's safe.",
      "I've given up on the day after one miss.",
      "I feel ashamed when I forget.",
      "I don't know my medication's actual missed-dose rule.",
      "One miss has turned into several before.",
    ],
    normalizing: "Missing a dose happens to almost everyone at some point. It's not a restart button. Knowing who to call ahead of time keeps one miss from turning into a pattern.",
    whyHard: {
      heading: "Why one miss can spiral",
      body: "Shame shows up fast after a mistake, and it tells you the day, or the week, is already ruined. That thinking is what actually causes multiple misses, not the first one. A clear plan short-circuits the shame spiral.",
      bullets: ["Panicking instead of checking the rule", "Doubling up without asking", "Giving up on the whole day", "Feeling shame instead of getting information", "Letting one miss become several"],
    },
    reframe: {
      heading: "A pattern, not a perfect record",
      body: "Check the label or call your pharmacist. They know what's safe for your medicine. Don't double up unless they say it's okay. Some medicines, like shots that last for weeks, have their own rules, so call your clinic. Two misses in a row is worth a call, not a spiral.",
    },
    checkIn: [
      { id: "struggle", label: "How much shame comes up when you miss a dose?", left: "None", right: "A lot", higherIsHarder: true },
      { id: "confidence", label: "How sure are you what to do after a missed dose?", left: "Not sure", right: "Very sure", higherIsHarder: false },
      { id: "support", label: "How easy would it be to call your pharmacy with a question?", left: "Very hard", right: "Easy", higherIsHarder: false },
    ],
    adelQuestions: [
      "What usually causes a dose to slip for you?",
      "What does the voice in your head say right after you realize you missed one?",
    ],
    skillSteps: [{"id": "rule", "title": "Step 1 — What my label says to do", "maxPicks": 2, "instruction": "Check your label or ask your pharmacist.", "options": ["Take it when I remember, unless it's almost time for the next one", "Skip it and take the next one on time", "Call my pharmacist to ask", "Call my clinic (shots and some medicines)", "I took a photo of the label", "I need to find out"]}, {"id": "pharmacy", "title": "Step 2 — My pharmacy", "maxPicks": 1, "instruction": "Pick one.", "options": ["CVS", "Walgreens", "Rite Aid", "Walmart", "My clinic's pharmacy", "Mail order"], "shared": "pharmacy"}, {"id": "clinic", "title": "Step 3 — When I call my clinic", "maxPicks": 3, "instruction": "Choose up to 3.", "options": ["I miss a shot", "I miss two doses in a row", "I feel sick after missing", "I'm out of medicine", "I'm not sure what to do", "I miss a medicine for cravings"]}, {"id": "change", "title": "Step 4 — What I'll change", "maxPicks": 2, "instruction": "Choose up to 2.", "options": ["Set a phone alarm", "Use a pillbox", "Move my bottle to my anchor spot", "Carry a dose with me", "Set up auto-refill", "Ask someone to check on me", "Use Stack It, Spot It, Signal It"], "feeds": "move"}],
  },

  "habits-treatment": {
    exerciseId: "cue-routine-reward",
    toolName: "Treatment Teammates",
    toolIntro: "One small habit that helps your treatment work, tracked for a week.",
    welcome: [
      "Have you ever taken your medication perfectly but still felt like it wasn't fully working?",
      "Late nights, skipped meals, or no movement all day can quietly work against it.",
      "You don't need to fix everything at once. One steady helper habit makes a real difference.",
    ],
    checklist: [
      "I sometimes skip meals for long stretches.",
      "My sleep is inconsistent.",
      "I drink alcohol on top of my medication.",
      "I don't move my body much most days.",
      "I drink a lot of caffeine throughout the day.",
      "I feel like I'm doing everything I can and it's still not enough.",
    ],
    normalizing: "You don't need to overhaul your whole life. Sleep, food, water, and movement all support how well medication works, and picking just one is enough to notice a difference.",
    whyHard: {
      heading: "Why the rest of the day matters too",
      body: "Medication doesn't work in isolation. Poor sleep, skipped meals, or heavy alcohol use can all blunt how well it does its job. This isn't extra credit, it's part of the treatment, but it doesn't mean doing everything perfectly. Alcohol on top of some medicines, like buprenorphine, methadone, opioids, benzos, or sleep pills, can slow or stop your breathing. Ask your prescriber or pharmacist what's safe with yours.",
      bullets: ["Believing the medication has to do all the work alone", "Skipping meals without noticing the effect", "Inconsistent sleep", "Alcohol interfering with treatment", "Trying to fix everything at once instead of one thing"],
    },
    reframe: {
      heading: "One helper, not five",
      body: "You don't need to sleep perfectly, eat perfectly, and exercise daily all at once. Pick the one helper habit that's most realistic for you right now and let that be enough for this week.",
    },
    checkIn: [
      { id: "struggle", label: "How much do daily habits seem to work against your treatment right now?", left: "Not much", right: "A lot", higherIsHarder: true },
      { id: "confidence", label: "How confident are you that you could add one helper habit this week?", left: "Not confident", right: "Very confident", higherIsHarder: false },
      { id: "support", label: "How much energy do you have to work on this right now?", left: "None", right: "Plenty", higherIsHarder: false },
    ],
    adelQuestions: [
      "Which of these habits feels the most out of balance right now?",
      "What's one small version of a helper habit you could actually keep up?",
    ],
    skillSteps: [{"id": "habit", "title": "Step 1 — The habit that helps my treatment", "maxPicks": 1, "instruction": "Pick one.", "options": ["Same bedtime", "Regular meals", "Walking", "Drinking water", "Cutting back on alcohol", "Less caffeine", "Getting outside", "Cutting back on smoking"], "shared": "dailyHabits"}, {"id": "cue", "title": "Step 2 — Its cue", "maxPicks": 1, "instruction": "Pick one.", "options": ["After I wake up", "After my meds", "After lunch", "When I get home", "After dinner", "Before bed"]}, {"id": "small", "title": "Step 3 — The smallest version", "maxPicks": 1, "instruction": "Pick one.", "options": ["A 5-minute walk", "One glass of water", "In bed on time 3 nights a week", "Eat breakfast", "One less drink", "Sit outside for 5 minutes"], "feeds": "move"}, {"id": "reward", "title": "Step 4 — My reward", "maxPicks": 1, "instruction": "Pick one.", "options": ["Music", "Coffee or tea", "Checking it off", "A show", "Telling someone", "Time on my phone"]}, {"id": "track", "title": "Step 5 — How I'll track 7 days", "maxPicks": 1, "instruction": "Pick one.", "options": ["Check it off in my toolkit", "Calendar on the wall", "Phone notes", "Tell Adel each day", "Tell my peer specialist"]}],
  },

  "treatment-goals": {
    exerciseId: "miracle-question",
    toolName: "Progress Markers",
    toolIntro: "What better looks like for you, and how you'll know you're getting there.",
    welcome: [
      "Have you ever been in treatment for a while without anyone asking what 'better' actually means to you?",
      "Clinical goals like fewer symptoms are real, but they might not match what you're actually working toward.",
      "When your own goals are part of the plan, the plan starts to make sense.",
    ],
    checklist: [
      "Nobody has asked me what I actually want out of treatment.",
      "My goals feel like they belong to my provider, not me.",
      "I've never said my real goal out loud.",
      "I'm not sure what 'better' would look like for me.",
      "I go along with the plan without much say in it.",
      "I want the plan to be about my actual life, not just symptoms.",
    ],
    normalizing: "It's common for treatment to focus on symptoms without ever naming what you actually want your life to look like. Naming your own goal is what makes the plan feel like yours.",
    whyHard: {
      heading: "Why clinical goals can feel disconnected",
      body: "\"Fewer symptoms\" is useful information for a provider, but it's not something you can picture yourself living. \"Being steady enough to see my kids\" is something you can picture, work toward, and know when you've reached.",
      bullets: ["Goals that sound clinical instead of personal", "Never being asked what you actually want", "Not knowing what 'better' would look like", "Following a plan without a say in it", "Losing motivation because the goal doesn't feel like yours"],
    },
    reframe: {
      heading: "Your goal, written in",
      body: "Think about what you want your life to look like, not just what symptoms you want gone. When that goal is written into your plan, the rest of the plan starts making sense around it.",
    },
    checkIn: [
      { id: "struggle", label: "How disconnected does your treatment plan feel from your real goals?", left: "Very connected", right: "Very disconnected", higherIsHarder: true },
      { id: "confidence", label: "How clear are you on what 'better' means for your life?", left: "Not clear", right: "Very clear", higherIsHarder: false },
      { id: "support", label: "How comfortable are you sharing your goal with your provider?", left: "Not comfortable", right: "Very comfortable", higherIsHarder: false },
    ],
    adelQuestions: [
      "What would 'better' actually look like in your everyday life?",
      "What's stopped you from saying that goal out loud before?",
    ],
    skillSteps: [{"id": "better", "title": "Step 1 — What better looks like in my life", "maxPicks": 3, "instruction": "Choose up to 3.", "options": ["Working", "Sleeping well", "Getting along with family", "Staying sober", "My own place", "Feeling calm", "Being there for my kids", "Getting out more"], "shared": "values"}, {"id": "signs", "title": "Step 2 — Three signs I'm getting better", "maxPicks": 3, "instruction": "Choose up to 3.", "options": ["Sleeping through the night", "Fewer bad days", "Keeping appointments", "Fewer cravings", "Laughing more", "Less anger", "Enjoying things again", "Getting out of the house"]}, {"id": "now", "title": "Step 3 — Where I am now", "maxPicks": 1, "instruction": "Pick one.", "options": ["1–2", "3–4", "5–6", "7–8", "9–10"]}, {"id": "next", "title": "Step 4 — The next small sign I'm working toward", "maxPicks": 1, "instruction": "Pick one.", "options": ["Sleeping through the night", "Fewer bad days", "Keeping appointments", "Fewer cravings", "Laughing more", "Less anger", "Enjoying things again", "Getting out of the house"], "optionsFrom": "signs"}, {"id": "share", "title": "Step 5 — Share with my provider?", "maxPicks": 1, "instruction": "Pick one.", "options": ["Yes, at my next visit", "Yes, send it now", "Not yet", "I'll talk to my case manager first"]}],
  },

  "prep-appointments": {
    exerciseId: "five-ts",
    toolName: "Game-Day Prep",
    toolIntro: "Everything for your next visit in one place. Type the date and time in the box.",
    welcome: [
      "Have you ever shown up to an appointment without your notes, or missed it altogether?",
      "It's rarely about not caring. It's usually about the ride, the timing, or just forgetting.",
      "A short prep list the night before can catch all three.",
    ],
    checklist: [
      "I've missed an appointment I meant to go to.",
      "I show up without knowing exactly what to say.",
      "I forget my medication list.",
      "Getting a ride is often the hard part.",
      "I don't have a set way of getting ready ahead of time.",
      "I feel unprepared even when I do make it there.",
    ],
    normalizing: "Missed or unprepared appointments usually come down to logistics, not motivation. A short checklist the night before handles most of it.",
    whyHard: {
      heading: "Why appointments slip through the cracks",
      body: "Transportation, timing, and forgetting are the three biggest reasons people miss or arrive unprepared for appointments, far more often than not caring. Handling those three things the night before changes the outcome.",
      bullets: ["No ride lined up", "Forgetting the date or time", "Notes or questions not written down", "No medication list on hand", "Rushing out the door instead of planning ahead"],
    },
    reframe: {
      heading: "The appointment starts the night before",
      body: "Confirm the time, plan the ride, and put your notes and med list somewhere you'll grab them. That's the whole difference between showing up ready and showing up scrambled, or not at all.",
    },
    checkIn: [
      { id: "struggle", label: "How often do appointments feel like a scramble?", left: "Rarely", right: "Every time", higherIsHarder: true },
      { id: "confidence", label: "How confident are you that you could prep the night before?", left: "Not confident", right: "Very confident", higherIsHarder: false },
      { id: "support", label: "How easy is it for you to line up a ride?", left: "Very hard", right: "Easy", higherIsHarder: false },
    ],
    adelQuestions: [
      "Which part usually breaks down for you: the ride, the timing, or remembering?",
      "What would make your next appointment feel less stressful to get to?",
    ],
    skillSteps: [{"id": "visit", "title": "Step 1 — The visit", "maxPicks": 1, "instruction": "Pick one.", "options": ["Prescriber", "Counselor", "Primary care", "Case manager", "PO or court", "Benefits office", "Lab work", "Dentist"]}, {"id": "ride", "title": "Step 2 — My ride and backup", "maxPicks": 2, "instruction": "Choose up to 2.", "options": ["Bus", "A friend or family member", "Medi-Cal ride (call ahead)", "Walk or bike", "Ride-share", "My case manager", "Drive myself", "Video visit, no ride needed"]}, {"id": "bring", "title": "Step 3 — What to bring", "maxPicks": 5, "instruction": "Choose up to 5.", "options": ["ID", "Insurance card", "Medication list or bottles", "My Signal Tracker numbers", "My Side Effect Log", "Questions on my phone", "Paperwork they asked for", "Phone charger"]}, {"id": "talk", "title": "Step 4 — My top three talking points", "maxPicks": 3, "instruction": "Choose up to 3.", "options": ["What's better", "What's harder", "A side effect", "My mood or sleep numbers", "A question about my medicine", "Something I've been afraid to bring up", "A refill", "Paperwork I need"]}],
  },

  ownership: {
    exerciseId: "bran",
    toolName: "Treatment Playbook",
    toolIntro: "Your treatment on one page, built from the tools in this module.",
    welcome: [
      "Have you ever felt like treatment was just something being done to you, instead of something you're part of?",
      "Saying yes and figuring it out later can feel easier in the moment.",
      "But asking a few questions turns you from a passenger into a partner in your own care.",
    ],
    checklist: [
      "I go along with suggestions without asking questions.",
      "I don't fully understand parts of my own plan.",
      "I've said yes to something I wasn't sure about.",
      "I'm not sure I could explain my treatment plan to someone else.",
      "I feel like decisions happen without me.",
      "I want more say in what happens to me.",
    ],
    normalizing: "Feeling like treatment is happening to you, rather than with you, is common, especially early on. Ownership doesn't mean doing it alone. It means having a real say.",
    whyHard: {
      heading: "Why staying quiet feels easier",
      body: "Saying yes and moving on avoids an awkward moment, but it's also how people quietly stop taking something that isn't working, or agree to something they don't understand. Providers give options; you're the one who has to live with the choice.",
      bullets: ["Agreeing without understanding", "Not asking follow-up questions", "Feeling like a passenger, not a partner", "Not knowing your own plan well enough to explain it", "Silently stopping something instead of asking about it"],
    },
    reframe: {
      heading: "Three questions make you a partner",
      body: "You don't have to overhaul how you talk to your provider. Asking what something is for, what to expect, and when to check back turns any decision into one you're actually part of.",
    },
    checkIn: [
      { id: "struggle", label: "How much does treatment feel like something happening to you?", left: "Not at all", right: "A lot", higherIsHarder: true },
      { id: "confidence", label: "How well could you explain your own plan to someone else?", left: "Not well", right: "Very well", higherIsHarder: false },
      { id: "support", label: "How comfortable are you asking your provider questions?", left: "Not comfortable", right: "Very comfortable", higherIsHarder: false },
    ],
    adelQuestions: [
      "What's one part of your plan you'd want to understand better?",
      "What usually stops you from asking a question in the moment?",
    ],
    skillSteps: [{"id": "treated", "title": "Step 1 — What I'm being treated for, in my words", "maxPicks": 3, "instruction": "Choose up to 3.", "options": ["Depression", "Anxiety", "Bipolar disorder", "PTSD or trauma", "Psychosis", "Substance use", "Sleep problems", "Still figuring it out"]}, {"id": "meds", "title": "Step 2 — My medications", "maxPicks": 4, "instruction": "Choose up to 4.", "options": ["For mood", "For anxiety", "For sleep", "For voices or thoughts", "For cravings", "For focus", "For my physical health"], "shared": "medications"}, {"id": "routine", "title": "Step 3 — My routine and missed-dose plan", "maxPicks": 3, "instruction": "Choose up to 3.", "options": ["Take it with my anchor habit", "Pillbox", "Phone alarm", "Auto-refill", "Check the label if I miss", "Call my pharmacist if I'm unsure", "Never double up without asking"]}, {"id": "tracking", "title": "Step 4 — What I'm tracking", "maxPicks": 3, "instruction": "Choose up to 3.", "options": ["Mood", "Sleep", "Anxiety", "Cravings", "Side effects", "Energy", "Voices", "My progress markers"]}, {"id": "team", "title": "Step 5 — What I want my team to know", "maxPicks": 2, "instruction": "Choose up to 2.", "options": ["What better means to me", "A side effect I'm dealing with", "I want to talk about options", "I'm doing well", "I've been struggling", "Something I've been afraid to say", "When I want to review this plan"]}],
  },
};
