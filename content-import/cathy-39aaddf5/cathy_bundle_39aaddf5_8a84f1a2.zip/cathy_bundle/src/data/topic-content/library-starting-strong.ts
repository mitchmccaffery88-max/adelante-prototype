import type { TopicContent } from "./types";
import { ANY_TIME_HELP } from "../care-notes";

// Starting Strong — topic-specific content (audit batch 1).
export const STARTING_STRONG: Record<string, TopicContent> = {
  // Hand-authored reference module: only Part A was a keyword guess.
  "finding-footing": {
    exerciseId: "feet",
    toolName: "Reentry Compass",
    toolIntro: "Get your bearings: what's steady, what's changed, what matters and your next step.",
    skillSteps: [{"id": "steady", "title": "Step 1 — What's steady right now", "maxPicks": 3, "instruction": "Choose up to 3.", "options": ["A place to sleep", "My ID or papers", "A phone", "Someone who checks on me", "My meds", "Regular meals", "A program or meeting", "My faith"]}, {"id": "changed", "title": "Step 2 — What's changed or still uncertain", "maxPicks": 3, "instruction": "Choose up to 3.", "options": ["Phones and technology", "Prices", "My family", "My neighborhood", "Friends who moved on", "Rules I have to follow", "Housing", "Work or money"]}, {"id": "values", "title": "Step 3 — My top three values", "maxPicks": 3, "instruction": "Choose up to 3.", "options": ["Family", "Freedom", "Honesty", "Faith", "Health", "Respect", "Being reliable", "Peace"], "shared": "values"}, {"id": "next", "title": "Step 4 — My next right step", "maxPicks": 1, "instruction": "Pick one.", "options": ["Get my ID", "Get a phone", "Check in with my case manager", "Go to a meeting", "Call family", "Find my next meal and bed", "Make one appointment", "Rest today"], "feeds": "move"}, {"id": "people", "title": "Step 5 — My support people", "maxPicks": 3, "instruction": "Choose up to 3.", "options": ["Case manager", "Peer specialist", "Sponsor", "A family member", "A friend in recovery", "Counselor", "Someone from church", "My PO"], "shared": "supportPeople"}],
  },

  "daily-rhythm": {
    exerciseId: "five-minute-reset",
    toolName: "Daily Rhythm Builder",
    toolIntro: "Give your day a shape with a few anchors and a way to wind down.",
    welcome: [
      "Have you ever looked up and realized the whole day slipped by without you deciding anything?",
      "Maybe you slept late, skipped a meal, and the evening felt long and empty.",
      "For a long time, someone else may have set your schedule. Now every hour is yours to fill.",
    ],
    checklist: [
      "I wake up at a different time every day.",
      "I forget to eat until I'm starving.",
      "Afternoons feel long and empty.",
      "I stay up late because nothing tells me to stop.",
      "My days blur together.",
      "Cravings or bad moods hit hardest when I have nothing planned.",
    ],
    normalizing: "If some of these fit, it makes sense. Going from a set schedule to no schedule is a big jump. A few steady anchors can give your day its shape back.",
    whyHard: {
      heading: "Why an empty day is harder than a busy one",
      body: "When nothing is planned, your brain has to make hundreds of small choices, and it gets tired fast. Tired brains grab whatever is easiest, and that is often old habits. Anchors take those choices off the table.",
      bullets: ["Sleeping at odd hours", "Skipping meals", "Long stretches of boredom", "Late nights on the phone", "Feeling like the day \"got away\""],
    },
    reframe: {
      heading: "Anchors, not a schedule",
      body: "You don't need a minute-by-minute plan. Start with three things that happen at about the same time every day: when you wake up, one meal, and when you go to bed. Everything else can hang off those.",
    },
    checkIn: [
      { id: "overwhelm", label: "How shapeless have your days felt lately?", left: "They have a shape", right: "Totally shapeless", higherIsHarder: true },
      { id: "confidence", label: "How sure are you that you could keep one daily anchor this week?", left: "Not sure", right: "Very sure", higherIsHarder: false },
      { id: "hope", label: "How rested and steady does your body feel?", left: "Worn out", right: "Steady", higherIsHarder: false },
    ],
    adelQuestions: [
      "What time of day is hardest for you right now?",
      "Was there ever a routine, inside or out, that actually felt good to you?",
    ],
    skillSteps: [{"id": "wake", "title": "Step 1 — My wake-up time", "maxPicks": 1, "instruction": "Pick one.", "options": ["6:00 a.m.", "6:30 a.m.", "7:00 a.m.", "7:30 a.m.", "8:00 a.m.", "8:30 a.m.", "9:00 a.m."]}, {"id": "anchors", "title": "Step 2 — My three daily anchors", "maxPicks": 3, "instruction": "Choose up to 3.", "options": ["Wake up at the same time", "Eat breakfast", "Take my meds", "A walk outside", "Lunch at the same time", "A meeting or group", "Check in with my support person", "Dinner at the same time", "Bed at the same time"], "shared": "dailyHabits"}, {"id": "stack", "title": "Step 3 — My anchor habit", "maxPicks": 1, "instruction": "Pick one.", "options": ["After coffee, I take my meds", "After I wake up, I make my bed", "After lunch, I take a walk", "After dinner, I plan tomorrow", "After I brush my teeth, I put my phone away", "After my meeting, I call someone"], "feeds": "move"}, {"id": "evening", "title": "Step 4 — My evening reset", "maxPicks": 3, "instruction": "Choose up to 3.", "options": ["Phone on the charger an hour before bed", "Shower", "Lay out clothes for tomorrow", "Prayer or quiet time", "Light snack and water", "Dim the lights", "Write tomorrow's first task", "Music or a podcast"]}, {"id": "bed", "title": "Step 5 — My bedtime", "maxPicks": 1, "instruction": "Pick one.", "options": ["9:30 p.m.", "10:00 p.m.", "10:30 p.m.", "11:00 p.m.", "11:30 p.m.", "Midnight"]}],
  },

  "mind-wont-slow": {
    exerciseId: "snow-globe",
    toolName: "Calm Mind Card",
    toolIntro: "A pocket card for when your thoughts won't slow down.",
    welcome: [
      "Have you ever laid down to rest and your thoughts started going a hundred miles an hour?",
      "One worry leads to another, then another, and you can't find the off switch.",
      "Trying to think your way out of it only seems to make it louder.",
    ],
    checklist: [
      "My thoughts race when I try to rest.",
      "I replay conversations over and over.",
      "I jump from one worry to the next.",
      "It's hard to focus on one thing.",
      "My body feels wired even when I'm tired.",
      "I use my phone or TV to drown my thoughts out.",
    ],
    normalizing: "If this sounds like you, your mind isn't broken. It's been on watch for a long time. The next steps show you how to use your body to help it slow down.",
    whyBullets: ["Thoughts looping", "Tight chest or jaw", "Trouble falling asleep", "Jumping between worries", "Feeling wired and tired at once"],
    checkIn: [
      { id: "overwhelm", label: "How fast are your thoughts going right now?", left: "Slow and calm", right: "Racing", higherIsHarder: true },
      { id: "confidence", label: "How much control do you feel over where your mind goes?", left: "None", right: "A lot", higherIsHarder: false },
      { id: "hope", label: "How settled does your body feel?", left: "Wired", right: "Settled", higherIsHarder: false },
    ],
    adelQuestions: [
      "When does your mind race the most: at night, when you're alone, or somewhere else?",
      "What's one thing that has slowed your mind down before, even a little?",
    ],
    whyHard: { heading: "Why your mind won't slow down", body: "After a long time on watch, your brain keeps scanning even when you're safe. Lying still gives it room to race. Thinking harder doesn't switch it off. Your body is the faster way in.", bullets: ["Thoughts looping", "Tight chest or jaw", "Trouble falling asleep", "Jumping between worries", "Feeling wired and tired at once"] },
    reframe: { heading: "Slow the body, the mind follows", body: "Breathe out longer than you breathe in, put your thoughts on paper, or do something with your hands for a few minutes. When your body slows down, your thoughts usually follow." },
    skillSteps: [{"id": "mind", "title": "Step 1 — What's running through my mind", "maxPicks": 3, "instruction": "Choose up to 3.", "options": ["Money", "Housing", "Family", "Court or probation", "My recovery", "Work", "My health", "Things from the past"]}, {"id": "control", "title": "Step 2 — The part I can control", "maxPicks": 2, "instruction": "Choose up to 2.", "options": ["Making one call", "Showing up", "Asking for help", "How I talk to myself", "Taking care of my body", "Writing it down for tomorrow", "Nothing today, and that's okay"]}, {"id": "signs", "title": "Step 3 — My warning signs", "maxPicks": 3, "instruction": "Choose up to 3.", "options": ["Thoughts racing at night", "Tight chest or jaw", "Can't sit still", "Replaying conversations", "Can't focus", "Snapping at people", "Not sleeping", "Scrolling to drown it out"], "shared": "warningSigns", "feeds": "cue"}, {"id": "tool", "title": "Step 4 — My calming tools", "maxPicks": 2, "instruction": "Choose up to 2.", "options": ["Snow Globe Reset", "Slow breathing", "Write the thoughts down", "Do something with my hands", "Take a short walk", "Music", "Prayer", "Talk to someone"], "shared": "copingTools", "feeds": "move"}, {"id": "reminder", "title": "Step 5 — My reminder line", "maxPicks": 1, "instruction": "Pick one.", "options": ["\"Let it settle.\"", "\"Thoughts aren't orders.\"", "\"I can pick this up tomorrow.\"", "\"Slow body, slow mind.\"", "\"One thing at a time.\"", "\"I've gotten through nights like this before.\""]}],
  },

  overwhelmed: {
    exerciseId: "stop-skill",
    toolName: "Overwhelm Reset",
    toolIntro: "Get the pile out of your head and pick one first step.",
    welcome: [
      "Have you ever looked at your to-do list and felt like you couldn't even pick it up?",
      "The ID, the phone, the appointment, the bill, the family call. It all feels due today.",
      "So you freeze, or you bounce between everything and finish nothing.",
    ],
    checklist: [
      "I have too many things due at once.",
      "I freeze and do nothing.",
      "I start five things and finish none.",
      "Small tasks feel huge.",
      "I snap at people when I'm overloaded.",
      "I avoid my phone because of what's waiting on it.",
    ],
    normalizing: "If you checked a few, that's what overload feels like, not laziness. The skill here is making the pile smaller, not working harder.",
    whyBullets: ["Freezing up", "Bouncing between tasks", "Short temper", "Avoiding calls and mail", "Feeling behind all the time"],
    checkIn: [
      { id: "overwhelm", label: "How heavy does your to-do pile feel right now?", left: "Light", right: "Crushing", higherIsHarder: true },
      { id: "confidence", label: "How clear are you on what to do first?", left: "No idea", right: "Very clear", higherIsHarder: false },
      { id: "hope", label: "How doable does today feel?", left: "Not doable", right: "Doable", higherIsHarder: false },
    ],
    adelQuestions: [
      "What's the one thing on your list that's been sitting there the longest?",
      "Who could take one small piece of this off your plate?",
    ],
    whyHard: { heading: "Why everything feels due at once", body: "When you come home, the ID, phone, benefits, appointments, and family all land in the same few weeks. Your brain can't hold that many open loops, so it freezes or jumps around. That's overload, not laziness.", bullets: ["Freezing up", "Bouncing between tasks", "Short temper", "Avoiding calls and mail", "Feeling behind all the time"] },
    reframe: { heading: "Make the pile smaller", body: "Write everything down so it's out of your head. Circle the one thing that's due soonest or unlocks the rest, like an ID or a phone. Do only that for now, and ask someone to take one piece." },
    skillSteps: [{"id": "pile", "title": "Step 1 — Everything on my plate", "maxPicks": 8, "instruction": "Choose up to 8.", "options": ["ID or documents", "Phone", "Benefits paperwork", "Appointments", "Housing", "Work or job search", "Family", "Court or probation", "Money and bills", "My health"]}, {"id": "today", "title": "Step 2 — Do today", "maxPicks": 2, "instruction": "Pick what's due soonest or unlocks the rest.", "options": ["ID or documents", "Phone", "Benefits paperwork", "Appointments", "Housing", "Work or job search", "Family", "Court or probation", "Money and bills", "My health"], "optionsFrom": "pile"}, {"id": "help", "title": "Step 3 — Ask for help with", "maxPicks": 2, "instruction": "Choose up to 2.", "options": ["ID or documents", "Phone", "Benefits paperwork", "Appointments", "Housing", "Work or job search", "Family", "Court or probation", "Money and bills", "My health"], "optionsFrom": "pile"}, {"id": "who", "title": "Step 4 — Who can help", "maxPicks": 2, "instruction": "Choose up to 2.", "options": ["Case manager", "Peer specialist", "A family member", "211", "Sponsor", "Counselor", "A friend", "Legal aid"], "shared": "supportPeople"}, {"id": "first", "title": "Step 5 — My smallest first step", "maxPicks": 1, "instruction": "Pick one.", "options": ["Write the whole list down", "Make one call", "Find one document", "Fill out one form", "Send one text asking for help", "Set a 10-minute timer and start"], "feeds": "move"}],
  },

  "managing-worry": {
    exerciseId: "leaves-on-a-stream",
    toolName: "Worry Workbench",
    toolIntro: "Sort your worries so they stop running all day.",
    welcome: [
      "Have you ever spent a whole afternoon worrying about something that hadn't happened yet?",
      "What if the job says no? What if my family doesn't come around? What if I mess up?",
      "Worry can feel like you're preparing, but it usually just wears you out.",
    ],
    checklist: [
      "I worry about things I can't control.",
      "I picture the worst-case version.",
      "Worry keeps me up at night.",
      "I ask \"what if\" a lot.",
      "Worrying feels like it keeps me safe.",
      "I feel tired from thinking so much.",
    ],
    normalizing: "Lots of people coming home worry all day. There's real uncertainty. The goal isn't to stop caring. It's to worry on purpose, for a short time, instead of all day long.",
    whyHard: {
      heading: "Why worry feels useful",
      body: "Worry tricks your brain into thinking it's solving a problem. But most worries are about things you can't act on today. The worry keeps running because it never gets an answer.",
      bullets: ["Lots of \"what if\" thoughts", "Picturing the worst", "Trouble sleeping", "Checking and re-checking", "Feeling tense in your stomach or shoulders"],
    },
    reframe: {
      heading: "Can I do something about it today?",
      body: "Ask every worry one question: \"Can I do something about this today?\" If yes, do the smallest piece. If no, park it until a set worry time, like 15 minutes at 6 p.m.",
    },
    checkIn: [
      { id: "overwhelm", label: "How much is worry taking up your day?", left: "Barely", right: "All day", higherIsHarder: true },
      { id: "confidence", label: "How well can you tell what you can control and what you can't?", left: "Not well", right: "Very well", higherIsHarder: false },
      { id: "hope", label: "How able do you feel to put a worry down for a while?", left: "Not able", right: "Very able", higherIsHarder: false },
    ],
    adelQuestions: [
      "What's the worry that comes back the most?",
      "If a friend had that same worry, what would you tell them?",
    ],
    skillSteps: [{"id": "worries", "title": "Step 1 — Empty my mind", "maxPicks": 5, "instruction": "Choose up to 5.", "options": ["Money", "Housing", "Family", "My recovery", "Court or probation", "Work", "My health", "What people think of me"]}, {"id": "work", "title": "Step 2 — One I can work on today", "maxPicks": 1, "instruction": "Pick one.", "options": ["Money", "Housing", "Family", "My recovery", "Court or probation", "Work", "My health", "What people think of me"], "optionsFrom": "worries"}, {"id": "window", "title": "Step 3 — My Worry Window", "maxPicks": 1, "instruction": "Pick 15 minutes a day to worry on purpose.", "options": ["After breakfast", "Lunchtime", "5:00 p.m.", "6:00 p.m.", "7:00 p.m.", "On my evening walk"]}, {"id": "now", "title": "Step 4 — Right here, right now", "maxPicks": 1, "instruction": "Pick one.", "options": ["Take a walk", "Do one chore", "Call someone", "Eat something", "Do Leaves on a Stream", "Write the worry down and close the page", "Pray or sit quietly", "Work with my hands"], "feeds": "move"}],
  },

  grounding: {
    exerciseId: "senses-5-4-3-2-1",
    toolName: "Ground Control",
    toolIntro: "Your 3-minute routine for when your body goes on high alert.",
    welcome: [
      "Have you ever had your heart pound out of nowhere, like your body was ready to fight or run?",
      "Maybe a loud noise, a crowded store, or someone standing too close set it off.",
      "Your mind knows you're okay, but your body hasn't gotten the message yet.",
    ],
    checklist: [
      "My heart races when nothing is wrong.",
      "I jump at loud sounds.",
      "I sit with my back to the wall.",
      "Crowds make my body tense up.",
      "I can't sit still.",
      "I feel far away or numb sometimes.",
    ],
    normalizing: "These are common after time in places where you had to stay on guard. Your body learned to protect you. Grounding teaches it that right here, right now, is okay.",
    whyHard: {
      heading: "Why you can't just \"calm down\"",
      body: "High alert starts in the part of your brain that works faster than words. Telling yourself to relax doesn't reach it. Your senses do: what you see, touch, and hear right now.",
      bullets: ["Pounding heart", "Tight muscles", "Scanning the room", "Feeling jumpy", "Feeling spaced out"],
    },
    reframe: {
      heading: "Talk to your body in its own language",
      body: "Instead of arguing with the alarm, give your body proof: cold water, feet on the floor, naming five things you can see. Each one tells it you're here and safe.",
    },
    checkIn: [
      { id: "overwhelm", label: "How on-edge does your body feel right now?", left: "Calm", right: "Very on edge", higherIsHarder: true },
      { id: "confidence", label: "How well can you bring yourself back when you feel jumpy?", left: "Not well", right: "Very well", higherIsHarder: false },
      { id: "hope", label: "How present do you feel in this room?", left: "Far away", right: "Right here", higherIsHarder: false },
    ],
    adelQuestions: [
      "Where are you when your body goes on high alert the most?",
      "What helps your body feel even a little bit safer?",
    ],
    skillSteps: [{"id": "body", "title": "Step 1 — Where stress shows in my body", "maxPicks": 3, "instruction": "Choose up to 3.", "options": ["Chest", "Stomach", "Jaw", "Shoulders and neck", "Hands", "Head", "Legs", "My breathing"]}, {"id": "signals", "title": "Step 2 — My stress signals", "maxPicks": 3, "instruction": "Choose up to 3.", "options": ["Heart pounding", "Fast breathing", "Scanning the room", "Feeling jumpy", "Can't sit still", "Feeling numb or far away", "Sweating", "Clenched fists"], "shared": "warningSigns", "feeds": "cue"}, {"id": "breathe", "title": "Step 3 — My breathe-and-move", "maxPicks": 2, "instruction": "Choose up to 2.", "options": ["Breathe in 4, out 6", "Box breathing", "Three long exhales", "Stretch my arms and shoulders", "Walk for two minutes", "Shake out my hands", "Squeeze and release my fists", "Roll my shoulders"], "shared": "copingTools", "feeds": "move"}, {"id": "ground", "title": "Step 4 — My ground-and-encourage", "maxPicks": 2, "instruction": "Choose up to 2.", "options": ["5-4-3-2-1", "Press my feet into the floor", "Cold water on my hands", "Hold something textured", "Say the date and where I am", "\"I'm here. I'm safe right now.\"", "\"This is an old alarm.\"", "\"Feet down. Look around.\""]}, {"id": "where", "title": "Step 5 — Where I'll use it", "maxPicks": 3, "instruction": "Choose up to 3.", "options": ["Stores and lines", "The bus", "Appointments", "At home at night", "Around family", "At work", "Crowds", "Waiting rooms"]}],
  },

  "big-feelings": {
    exerciseId: "rain",
    toolName: "Emotion Navigator",
    toolIntro: "Steer through a big feeling instead of letting it run you.",
    welcome: [
      "Have you ever had a feeling hit so hard it took over your whole day?",
      "Anger from a phone call, or sadness out of nowhere, and suddenly nothing else matters.",
      "Maybe inside, showing feelings wasn't safe, so they come out all at once now.",
    ],
    checklist: [
      "Small things set off big reactions.",
      "I go from 0 to 10 fast.",
      "I push feelings down until they explode.",
      "One bad moment ruins my whole day.",
      "I don't always know what I'm feeling.",
      "I've used to make a feeling stop.",
    ],
    normalizing: "Big feelings aren't a flaw. Many people learned to lock feelings away to survive. Now they're coming back, and you can learn to ride them instead of being run by them.",
    whyHard: {
      heading: "Why feelings stretch out",
      body: "Many feelings rise and fall within minutes if you don't feed them. Fighting it, hiding it, or acting on it right away keeps it going longer.",
      bullets: ["Going from calm to furious fast", "Crying out of nowhere", "Shutting down", "Saying things you regret", "Wanting it to stop right now"],
    },
    reframe: {
      heading: "Ride the wave, don't fight it",
      body: "You don't have to like the feeling or fix it. Name it, give it a number, and wait a few minutes before you act. Most feelings drop on their own.",
    },
    checkIn: [
      { id: "overwhelm", label: "How strong are your feelings today?", left: "Mild", right: "Taking over", higherIsHarder: true },
      { id: "confidence", label: "How able are you to name what you're feeling?", left: "Not able", right: "Very able", higherIsHarder: false },
      { id: "hope", label: "How sure are you a big feeling will pass if you wait?", left: "Not sure", right: "Very sure", higherIsHarder: false },
    ],
    adelQuestions: [
      "What usually happens right before a feeling takes over?",
      "When a feeling has passed before without you acting on it, what helped?",
    ],
    skillSteps: [{"id": "name", "title": "Step 1 — Name it", "maxPicks": 2, "instruction": "Choose up to 2.", "options": ["Anger", "Sadness", "Shame", "Fear", "Loneliness", "Jealousy", "Numbness", "Hurt"]}, {"id": "body", "title": "Step 2 — Where I feel it", "maxPicks": 2, "instruction": "Choose up to 2.", "options": ["Hot face", "Tight chest", "Knot in my stomach", "Clenched jaw", "Tears", "Shaky hands", "Heavy body", "Racing heart"]}, {"id": "message", "title": "Step 3 — What it's telling me", "maxPicks": 2, "instruction": "Choose up to 2.", "options": ["Something feels unfair", "I miss someone", "I'm scared of losing something", "I need rest", "I need help", "I feel disrespected", "I made a mistake", "I'm not sure yet"]}, {"id": "response", "title": "Step 4 — My healthy response", "maxPicks": 2, "instruction": "Choose up to 2.", "options": ["Use RAIN", "Walk for 10 minutes", "Wait 20 minutes before I respond", "Text someone", "Cold water", "Write it down", "Listen to one song", "Pray or sit quietly"], "shared": "copingTools", "feeds": "move"}],
  },

  "safe-now": {
    exerciseId: "wise-mind",
    toolName: "Safety Net",
    toolIntro: "Your plan for when things start to feel unsafe.",
    careNote: ANY_TIME_HELP,
    welcome: [
      "Have you ever been somewhere that should feel fine, but your body just won't relax?",
      "Maybe it's certain people, a street, or being out after dark.",
      "Being out doesn't automatically make you feel safe, especially after years of watching your back.",
    ],
    checklist: [
      "Some places still don't feel safe.",
      "Certain people make me tense.",
      "I don't have a spot that's just mine.",
      "I sleep lightly or wake up on guard.",
      "I avoid going out alone.",
      "I don't know who I can trust yet.",
    ],
    normalizing: "Feeling unsafe after coming home is common and makes sense. Safety is something you can build on purpose, around you and inside you.",
    whyHard: {
      heading: "Why safe doesn't feel safe yet",
      body: "Your body learned what danger looks like, and it still checks for it everywhere. It takes repeated safe moments, in the same places with the same people, for your body to believe it.",
      bullets: ["Trouble relaxing at home", "Watching doors", "Avoiding certain streets", "Staying up late", "Not trusting new people"],
    },
    reframe: {
      heading: "Build safety on two sides",
      body: "Outside: choose where you go, who you're with, and what time you're out. Inside: build a calm place in your mind your body can return to. Both get stronger with practice.",
    },
    checkIn: [
      { id: "overwhelm", label: "How unsafe do you feel in your day-to-day life?", left: "Safe", right: "Very unsafe", higherIsHarder: true },
      { id: "confidence", label: "How much can you choose safer people and places?", left: "Not at all", right: "A lot", higherIsHarder: false },
      { id: "hope", label: "How easy is it for your body to relax somewhere?", left: "Very hard", right: "Easy", higherIsHarder: false },
    ],
    adelQuestions: [
      "Where do you feel most at ease these days, even a little?",
      "Who is one person that makes a place feel safer when they're there?",
    ],
    skillSteps: [{"id": "signs", "title": "Step 1 — Signs things are getting unsafe", "maxPicks": 3, "instruction": "Choose up to 3.", "options": ["Old friends coming around", "Being out late", "Feeling on high alert", "Someone pressuring me", "Not sleeping", "Fighting at home", "Wanting to use"], "shared": "warningSigns", "feeds": "cue"}, {"id": "calm", "title": "Step 2 — My calm-down list", "maxPicks": 3, "instruction": "Choose up to 3.", "options": ["Wise Mind", "5-4-3-2-1", "Slow breathing", "Take a walk", "Cold water", "Pray or sit quietly", "Call someone", "Go to a meeting"], "shared": "copingTools", "feeds": "move"}, {"id": "people", "title": "Step 3 — My support options", "maxPicks": 3, "instruction": "Choose up to 3.", "options": ["Case manager", "Peer specialist", "Sponsor", "A family member", "A friend in recovery", "Counselor", "Someone from church", "My PO"], "shared": "supportPeople"}, {"id": "places", "title": "Step 4 — My safe places", "maxPicks": 3, "instruction": "Choose up to 3.", "options": ["My room", "A library", "A meeting hall", "A park in daylight", "A family member's home", "A church or community center", "My peer specialist's office", "A 24-hour diner"], "shared": "safePlaces"}, {"id": "emergency", "title": "Step 5 — If I'm in danger", "maxPicks": 1, "instruction": "Pick one.", "options": ["Call or text 988", "Call 911", "Go to the nearest emergency room", "Open my safety plan", "Call my counselor's after-hours line", "Go to someone I trust right now"], "crisisLink": true}],
  },

  "healthy-sleep": {
    exerciseId: "cognitive-shuffle",
    toolName: "Lights-Out Plan",
    toolIntro: "Set up your nights so sleep comes easier.",
    welcome: [
      "Have you ever laid in bed for hours, tired but wide awake?",
      "Or you finally fall asleep, then wake up at 3 a.m. with your mind already running.",
      "Years of lights, noise, and head counts can change how your body sleeps.",
    ],
    checklist: [
      "It takes me a long time to fall asleep.",
      "I wake up a lot during the night.",
      "I sleep during the day and can't sleep at night.",
      "I'm on my phone in bed.",
      "Quiet feels too quiet.",
      "I feel tired all day.",
    ],
    normalizing: "Sleep problems are really common in early reentry and early recovery. Your body is still adjusting. Sleep can get better with a few steady habits and a way to help your body let go.",
    whyHard: {
      heading: "Why your body won't switch off",
      body: "Sleep needs your body to feel safe and loose. If you've been on alert for years, or your body is healing from substances, your muscles may stay braced even in bed. Screens and naps make it harder.",
      bullets: ["Lying awake", "Waking at night", "Racing thoughts in bed", "Napping late", "Feeling foggy in the morning"],
    },
    reframe: {
      heading: "Set up sleep, don't force it",
      body: "You can't make yourself sleep. You can make it easier: same wake time, no screens in the last hour, and a way to let your body go heavy. Sleep follows.",
    },
    checkIn: [
      { id: "overwhelm", label: "How rough has your sleep been this week?", left: "Good", right: "Very rough", higherIsHarder: true },
      { id: "confidence", label: "How able are you to relax your body at bedtime?", left: "Not able", right: "Very able", higherIsHarder: false },
      { id: "hope", label: "How rested do you feel when you wake up?", left: "Exhausted", right: "Rested", higherIsHarder: false },
    ],
    adelQuestions: [
      "What usually keeps you up: your thoughts, your body, noise, or something else?",
      "What's one thing about your nights you'd want to change first?",
    ],
    skillSteps: [{"id": "harder", "title": "Step 1 — What makes sleep harder", "maxPicks": 3, "instruction": "Choose up to 3.", "options": ["Phone in bed", "Late naps", "Caffeine after lunch", "Racing thoughts", "Noise", "A room that's too quiet", "Bad dreams", "Sharing a room"], "feeds": "cue"}, {"id": "wind", "title": "Step 2 — My wind-down routine", "maxPicks": 3, "instruction": "Choose up to 3.", "options": ["Phone across the room", "Warm shower", "Dim the lights", "Cognitive Shuffle", "Prayer or quiet time", "A fan or white noise", "Light stretching", "Write tomorrow's list"], "shared": "dailyHabits", "feeds": "move"}, {"id": "space", "title": "Step 3 — My sleep-space fixes", "maxPicks": 3, "instruction": "Choose up to 3.", "options": ["Darker room", "Cooler room", "Earplugs", "Fan or white noise", "Clean sheets", "Clock turned away", "Phone charging across the room", "Bed is only for sleep"]}, {"id": "promise", "title": "Step 4 — My sleep promise", "maxPicks": 1, "instruction": "Pick one.", "options": ["Up by 6:30 a.m.", "Up by 7:00 a.m.", "Up by 7:30 a.m.", "Up by 8:00 a.m.", "Same wake time on weekends too", "No naps after 3 p.m.", "Out of bed if I'm awake 20 minutes"]}],
  },

  "stability-plan": {
    exerciseId: "stable",
    toolName: "Stability Plan",
    toolIntro: "Your plan for staying steady, built from the tools you made in this module.",
    welcome: [
      "Have you ever had a really good day and then couldn't figure out how to get another one?",
      "Some days you feel solid. Other days everything slides, and you're not sure why.",
      "Good days aren't random. They have ingredients you can learn to repeat.",
    ],
    checklist: [
      "My good days feel like luck.",
      "One bad day turns into a bad week.",
      "I don't know what makes a day go well.",
      "I start strong, then fall off.",
      "I only think about my plan when things go wrong.",
      "I want something steady to come back to.",
    ],
    normalizing: "Most people don't know what makes their good days work until they look. That's what this module does: turn your good days into a plan you can use on hard ones.",
    whyHard: {
      heading: "Why good days don't repeat on their own",
      body: "When a day goes well, we move on without noticing why. When it goes badly, we remember every detail. A stability plan writes down what works, so it's there when your head is cloudy.",
      bullets: ["Up-and-down weeks", "Dropping routines when life gets busy", "Forgetting what helped", "Starting over again and again", "Only reaching out in a crisis"],
    },
    reframe: {
      heading: "Copy what already works",
      body: "Instead of inventing a whole new life, look at your best recent day. What did you eat, who did you talk to, where did you go? Repeat two or three of those on purpose.",
    },
    checkIn: [
      { id: "overwhelm", label: "How up-and-down have your days been lately?", left: "Steady", right: "All over the place", higherIsHarder: true },
      { id: "confidence", label: "How well do you know what makes a good day for you?", left: "No idea", right: "I know", higherIsHarder: false },
      { id: "hope", label: "How ready are you to repeat what works?", left: "Not ready", right: "Very ready", higherIsHarder: false },
    ],
    adelQuestions: [
      "Tell me about one recent day that went okay. What was in it?",
      "What's usually the first thing to slip when a day starts going wrong?",
    ],
    skillSteps: [{"id": "habits", "title": "Step 1 — My daily habits", "maxPicks": 4, "instruction": "Choose up to 4.", "options": ["Wake up at the same time", "Eat breakfast", "Take my meds", "A walk outside", "A meeting or group", "Check in with my support person", "Wind down at night", "Bed at the same time"], "shared": "dailyHabits"}, {"id": "signs", "title": "Step 2 — My warning signs", "maxPicks": 4, "instruction": "Choose up to 4.", "options": ["Skipping meals", "Staying in bed", "Ignoring my phone", "Feeling irritable", "Not sleeping", "Around old people or places", "Thoughts racing", "Dropping my routine"], "shared": "warningSigns", "feeds": "cue"}, {"id": "tools", "title": "Step 3 — My coping tools", "maxPicks": 4, "instruction": "Choose up to 4.", "options": ["FEET", "STOP", "5-4-3-2-1", "RAIN", "Snow Globe Reset", "Wise Mind", "Slow breathing", "Take a walk"], "shared": "copingTools"}, {"id": "people", "title": "Step 4 — My support team", "maxPicks": 4, "instruction": "Choose up to 4.", "options": ["Case manager", "Peer specialist", "Sponsor", "A family member", "A friend in recovery", "Counselor", "Someone from church", "My PO"], "shared": "supportPeople"}, {"id": "next", "title": "Step 5 — The next helpful thing", "maxPicks": 1, "instruction": "Pick one.", "options": ["Eat something", "Take a walk", "Text my support person", "Go to a meeting", "Do one small task", "Go to bed early", "Read this plan", "Run the 5-Minute Reset"], "feeds": "move"}],
  },
};
