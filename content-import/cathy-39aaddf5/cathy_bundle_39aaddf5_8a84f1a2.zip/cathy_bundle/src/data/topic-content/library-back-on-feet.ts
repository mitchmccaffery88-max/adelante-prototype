import type { TopicContent } from "./types";

// Getting Back on My Feet — topic-specific content (batch 2).
export const BACK_ON_FEET: Record<string, TopicContent> = {
  housing: {
    exerciseId: "openings-requirements-next",
    toolName: "Home Base Tracker",
    toolIntro: "Keep your housing search in one place.",
    welcome: [
      "Have you ever gotten a move-out notice and felt your stomach drop?",
      "Thirty days can look like nothing and forever at the same time.",
      "The paperwork, the calls, the waiting lists — it can feel like too much to even start.",
      "But housing is a series of steps, not one giant leap.",
    ],
    checklist: [
      "I don't know where I'll be living in a month.",
      "I keep putting off the housing calls.",
      "I don't have my documents together.",
      "I feel like my record will close every door.",
      "I don't know who's supposed to help me with this.",
      "I freeze when I think about starting over somewhere new.",
    ],
    normalizing: "If this sounds like you, that's a normal response to a housing scramble, not a sign you're failing at it. The people who land somewhere start early and keep their papers in one place. You can build that habit starting today.",
    whyHard: {
      heading: "Why housing feels like a maze",
      body: "Housing runs on paperwork, timing, and screening rules that change from place to place. When you don't know the rules, every step feels risky, so it's tempting to freeze or wait. But the clock on a notice keeps moving whether you act or not.",
      bullets: ["Not knowing which documents you need", "Records showing up on background checks", "Waitlists with no clear timeline", "Fear of another rejection", "Not knowing who can actually help"],
    },
    reframe: {
      heading: "One call, two options",
      body: "You don't need the whole plan today. You need one call to your case manager or housing navigator asking for the two best options right now. That turns an overwhelming problem into two real choices.",
    },
    checkIn: [
      { id: "struggle", label: "How shaky does your housing situation feel right now?", left: "Stable", right: "Very shaky", higherIsHarder: true },
      { id: "confidence", label: "How confident do you feel that you can find your next step?", left: "Not confident", right: "Very confident", higherIsHarder: false },
      { id: "support", label: "How much support do you have lined up for housing?", left: "None", right: "A lot", higherIsHarder: false },
    ],
    adelQuestions: [
      "What documents do you already have, and what's still missing?",
      "Who is one person who could help you make a housing call today?",
    ],
    skillSteps: [
      { id: "docs", title: "Step 1 — Documents I have", instruction: "Choose up to 5.", maxPicks: 5, options: ["ID", "Social Security card", "Birth certificate", "Proof of income", "References", "Release papers", "Benefits letter", "Rental history"] },
      { id: "need", title: "Step 2 — Documents I still need", instruction: "Choose up to 3.", maxPicks: 3, options: ["ID", "Social Security card", "Birth certificate", "Proof of income", "References", "Release papers", "Benefits letter"] },
      { id: "applied", title: "Step 3 — Places I've applied or called", instruction: "Choose up to 3.", maxPicks: 3, options: ["Sober living", "Transitional housing", "A shelter", "Section 8 or a housing list", "A room for rent", "Staying with family", "A program bed"] },
      { id: "follow", title: "Step 4 — My next follow-up", instruction: "Pick one.", maxPicks: 1, feeds: "move", options: ["Call back this week", "Turn in a document", "Check my place on a waitlist", "Ask my case manager for options", "Visit in person", "Call 211"] },
    ],
  },

  work: {
    exerciseId: "practice-the-line-eyes-up",
    toolName: "Second-Chance Pitch",
    toolIntro: "How you'll talk about your past, your skills and where to apply.",
    welcome: [
      "Have you ever skipped applying for a job because you figured your record would end it?",
      "That worry makes sense. A record makes the search harder.",
      "But in California, most employers can't ask about your record until after they offer you the job.",
      "Knowing your rights, and where to look, changes the odds.",
    ],
    checklist: [
      "I've avoided applying because of my record.",
      "I don't know when an employer is allowed to ask about it.",
      "I don't know which places hire people with a record.",
      "I'm nervous about what to say if it comes up.",
      "I don't have a resume or a way to explain the gap.",
      "I've been turned down and wanted to give up.",
    ],
    normalizing: "If this sounds like you, you're not alone. A record is a real barrier, and feeling discouraged makes sense. You also have more rights and more options than most people are told.",
    whyHard: {
      heading: "Why the job search feels stacked against you",
      body: "Some employers still screen people out, and waiting to hear back wears you down. But California's Fair Chance Act says most employers with five or more workers can't ask about convictions until after a job offer. Even then, they have to look at your situation and give you a chance to respond before they take the offer back.",
      bullets: ["Not knowing your rights", "Not knowing who hires people with a record", "Dreading the record question", "No resume or recent work to show", "Getting turned down and losing hope"],
    },
    reframe: {
      heading: "Rights first, then your story",
      body: "Start where people with records get hired: fair-chance employers, staffing agencies, and the job center. You don't have to bring up your record before an offer. Some jobs, like working with kids or in health care, can check earlier. After an offer, use a short, honest answer about what you've done since. If an offer gets pulled, ask your case manager or legal aid for help.",
    },
    checkIn: [
      { id: "struggle", label: "How discouraging does the job search feel right now?", left: "Not discouraging", right: "Very discouraging", higherIsHarder: true },
      { id: "confidence", label: "How well do you know your rights about your record?", left: "Not well", right: "Very well", higherIsHarder: false },
      { id: "support", label: "How much help do you have with your job search?", left: "None", right: "A lot", higherIsHarder: false },
    ],
    adelQuestions: [
      "What kind of work are you looking for right now?",
      "What has your record gotten in the way of so far?",
    ],
    skillSteps: [
      { id: "answer", title: "Step 1 — How I'll talk about my past", instruction: "You can edit it in the box.", maxPicks: 1, options: ["\"I made a mistake, I served my time, and I'm ready to work.\"", "\"I have a record. Since then I've completed a program and stayed on track.\"", "\"I'm not proud of my past. I'm proud of what I've done since.\""] },
      { id: "skills", title: "Step 2 — My top skills", instruction: "Choose up to 3.", maxPicks: 3, options: ["Hard-working", "Reliable", "Good with my hands", "Learn fast", "Good with people", "Cooking", "Construction", "Driving", "Warehouse", "Cleaning"] },
      { id: "proof", title: "Step 3 — Proof I can send", instruction: "Choose up to 3.", maxPicks: 3, options: ["Program certificate", "Letter from my case manager", "Letter from my counselor or PO", "Classes I've finished", "GED or diploma", "Work or volunteer references", "Proof I'm in treatment"] },
      { id: "refs", title: "Step 4 — My references", instruction: "Choose up to 2.", maxPicks: 2, options: ["Case manager", "Program staff", "A past employer", "Peer specialist", "A pastor", "A volunteer coordinator", "A teacher"] },
      { id: "where", title: "Step 5 — Fair-chance places to try", instruction: "Choose up to 2.", maxPicks: 2, feeds: "move", options: ["Honest Jobs", "America's Job Center", "Workforce programs", "Temp agencies", "Second-chance employers my case manager knows", "Trade apprenticeships"] },
    ],
  },

  "money-basics": {
    exerciseId: "payday-order",
    toolName: "Budget Basics Calculator",
    toolIntro: "What's coming in, what's going out, and what's left.",
    partBExerciseId: "budget-basics",
    welcome: [
      "Have you ever gotten paid and watched the money disappear before the important stuff got covered?",
      "Maybe it went to something small and urgent, and then rent felt impossible again.",
      "Money stress can feel like it's always chasing you.",
      "An order of operations can take a lot of that panic away.",
    ],
    checklist: [
      "My money is gone before I pay what matters most.",
      "I don't have a system for spending.",
      "I feel anxious every payday.",
      "I don't know where my money actually goes.",
      "Small purchases add up without me noticing.",
      "I avoid thinking about money until it's a crisis.",
    ],
    normalizing: "If this sounds familiar, you're not bad with money — you likely never had a simple order to follow. Most budgets fail because they're too detailed. A short list of what comes first works better.",
    whyHard: {
      heading: "Why detailed budgets don't stick",
      body: "Tracking every dollar takes time and energy most people don't have to spare. What actually works is deciding, ahead of time, what gets paid first the moment money lands, so you're not making decisions when you're tired or tempted.",
      bullets: ["Too many categories to track", "Spending before thinking", "No cash-only limit for extras", "Bills competing with daily needs", "Feeling shame instead of making a plan"],
    },
    reframe: {
      heading: "Order beats budgeting",
      body: "Housing first, then transportation, then food, then everything else. Handle the first two or three the same day money lands, before anything else touches it.",
    },
    checkIn: [
      { id: "struggle", label: "How much stress is money causing you right now?", left: "None", right: "A lot", higherIsHarder: true },
      { id: "confidence", label: "How confident do you feel following a spending order?", left: "Not confident", right: "Very confident", higherIsHarder: false },
      { id: "support", label: "How much help do you have with money questions?", left: "None", right: "A lot", higherIsHarder: false },
    ],
    adelQuestions: [
      "Where does your money usually leak first?",
      "What are the top two things that need to get paid the day money lands?",
    ],
    skillSteps: [
      { id: "order", title: "Step 1 — My payday order", instruction: "Put your top priorities first.", maxPicks: 3, options: ["Rent or housing", "Transportation", "Food", "Phone", "Debts or fines"] },
      { id: "leak", title: "Step 2 — Where my money leaks", instruction: "Choose up to two.", maxPicks: 2, options: ["Eating out", "Impulse buys", "Lending it out", "No cash limit", "Late fees"] },
      { id: "fix", title: "Step 3 — What I'll try", instruction: "Choose up to two.", maxPicks: 2, options: ["Pay top two the same day", "Cash-only for extras", "Set a weekly limit", "Ask for help with a plan"] },
      { id: "check", title: "Step 4 — When I'll check in on it", instruction: "Pick one.", maxPicks: 1, options: ["Every payday", "Once a week", "Once a month"] },
    ],
  },

  "food-resources": {
    exerciseId: "pantry-call",
    toolName: "Pantry Finder",
    toolIntro: "Know where food is before you run out.",
    welcome: [
      "Have you ever opened the cupboard a few days before payday and found it empty?",
      "Food can run short fast, especially when money is tight.",
      "Asking for food help can feel uncomfortable, even though it's exactly what these programs are for.",
      "There's usually more available than it feels like.",
    ],
    checklist: [
      "My food runs out before money comes back.",
      "I don't know what food help I qualify for.",
      "I feel embarrassed to ask for food help.",
      "I haven't applied for CalFresh or similar programs.",
      "I don't know where the food banks near me are.",
      "I wait until the cupboard is empty to look for help.",
    ],
    normalizing: "Running short on food is common in early reentry, and reaching for these resources isn't a failure. CalFresh, food banks, and community meals exist because this happens to a lot of people. They're built to be used.",
    whyHard: {
      heading: "Why food help feels hard to ask for",
      body: "Applying takes documents and time, and asking for help with something as basic as food can feel shameful even when it shouldn't. That shame keeps people waiting until things are worse than they need to be.",
      bullets: ["Not knowing the application process", "Feeling embarrassed to ask", "Not knowing your local options", "Waiting until you're already out of food", "Thinking one program is all there is"],
    },
    reframe: {
      heading: "Stack a few sources",
      body: "You don't need one perfect solution. Stack two or three: CalFresh, a food bank, and a community meal. Together they stop food from being a monthly emergency.",
    },
    checkIn: [
      { id: "struggle", label: "How often does your food run short?", left: "Rarely", right: "Very often", higherIsHarder: true },
      { id: "confidence", label: "How confident do you feel finding food help?", left: "Not confident", right: "Very confident", higherIsHarder: false },
      { id: "support", label: "How much food support do you have set up right now?", left: "None", right: "A lot", higherIsHarder: false },
    ],
    adelQuestions: [
      "Which food resource near you haven't you used yet?",
      "What's stopped you from applying for CalFresh or a food program so far?",
    ],
    skillSteps: [
      { id: "calfresh", title: "Step 1 — My CalFresh status", instruction: "Pick one.", maxPicks: 1, options: ["I have it", "I applied", "I need to apply", "I was denied", "I don't know if I qualify"] },
      { id: "pantries", title: "Step 2 — Places I can get food", instruction: "Choose up to 3.", maxPicks: 3, options: ["A food bank", "A church pantry", "Free community meals", "My program's meals", "A shelter kitchen", "WIC", "Senior or family programs", "211 can help me find one"] },
      { id: "reload", title: "Step 3 — When my benefits reload", instruction: "Pick one.", maxPicks: 1, options: ["Early in the month", "Mid-month", "Late in the month", "I don't know yet"] },
      { id: "plan", title: "Step 4 — My plan for the last week of the month", instruction: "Choose up to 2.", maxPicks: 2, feeds: "move", options: ["Go to a food bank", "Go to a free meal", "Save a little each week", "Ask family", "Call 211", "Ask my case manager"] },
    ],
  },

  "healthcare-support": {
    exerciseId: "three-question-pocket-card",
    toolName: "Health Home Base",
    toolIntro: "Where you go for what, all in one place.",
    welcome: [
      "Have you ever put off a doctor's visit for so long that it felt easier to keep ignoring it?",
      "Years can pass without a checkup, and starting again can feel intimidating.",
      "The system has a lot of doors, and it's hard to know which one to knock on.",
      "One appointment can open the rest for you.",
    ],
    checklist: [
      "I've put off medical care for a long time.",
      "I don't know where to start.",
      "I don't have insurance or know if I qualify for Medi-Cal.",
      "I'm nervous about walking into a clinic.",
      "I have something health-related I've been ignoring.",
      "I don't know the difference between urgent and emergency care.",
    ],
    normalizing: "It's common to put off healthcare for years while dealing with everything else. That doesn't mean you're behind for good. Community clinics see this all the time, and one visit usually connects you to whatever else you need.",
    whyHard: {
      heading: "Why healthcare feels like it has too many doors",
      body: "Medical, dental, mental health, and prescriptions can all feel like separate systems with separate rules. Not knowing where something fits makes it easy to avoid the whole thing.",
      bullets: ["Not knowing if something is urgent or routine", "No insurance card in hand", "Fear of cost", "Not knowing which clinic to call", "Feeling judged for waiting so long"],
    },
    reframe: {
      heading: "One door opens the rest",
      body: "You don't have to solve your whole health history at once. Community health centers handle primary care, behavioral health, and prescriptions on a sliding scale, often in the same building. One new-patient appointment gets the ball rolling.",
    },
    checkIn: [
      { id: "struggle", label: "How overwhelming does dealing with healthcare feel?", left: "Not overwhelming", right: "Very overwhelming", higherIsHarder: true },
      { id: "confidence", label: "How confident do you feel finding the right care?", left: "Not confident", right: "Very confident", higherIsHarder: false },
      { id: "support", label: "How much help do you have navigating healthcare?", left: "None", right: "A lot", higherIsHarder: false },
    ],
    adelQuestions: [
      "What health thing have you been putting off the longest?",
      "What's stopping you from calling a clinic this week?",
    ],
    skillSteps: [
      { id: "coverage", title: "Step 1 — My Medi-Cal status", instruction: "Pick one.", maxPicks: 1, options: ["I have it", "I applied", "I need to apply", "It lapsed", "I don't know"] },
      { id: "doctor", title: "Step 2 — My doctor and clinic", instruction: "Choose up to 2.", maxPicks: 2, shared: "careTeam", options: ["Primary care doctor", "Community health clinic", "Prescriber", "Dentist", "Eye doctor", "Not yet"] },
      { id: "where", title: "Step 3 — Where I go for what", instruction: "Choose up to 3.", maxPicks: 3, options: ["911 for emergencies", "Urgent care for same-day problems", "My clinic for check-ups", "Pharmacy for medicine questions", "Dentist for teeth", "Telehealth after hours"] },
      { id: "next", title: "Step 4 — My next appointment", instruction: "Pick one.", maxPicks: 1, feeds: "move", options: ["Make a check-up appointment", "Find a dentist", "Get my eyes checked", "Refill my medicine", "Follow up on a referral", "Ask my case manager to help me start"] },
    ],
  },

  "my-benefits": {
    exerciseId: "see-it-from-the-workers-side",
    toolName: "Paperwork Tracker",
    toolIntro: "Every benefit, its status and its deadlines.",
    welcome: [
      "Have you ever heard about a benefit you might qualify for, but the paperwork stopped you before you even started?",
      "Medi-Cal, CalFresh, General Assistance — the names alone can feel like a wall.",
      "A lot of denials aren't about whether you qualify. They're about a missing form.",
      "A little organization goes a long way here.",
    ],
    checklist: [
      "I don't know what benefits I qualify for.",
      "I have paperwork I haven't finished.",
      "I've been denied something and don't know if I can appeal.",
      "I don't have a system for keeping my documents.",
      "I've missed an appointment tied to a benefit before.",
      "I feel confused every time I try to figure this out.",
    ],
    normalizing: "If benefits paperwork feels confusing, that's the system, not you. Many denials come from a missing document or a missed appointment, not because someone didn't qualify. That's fixable.",
    whyHard: {
      heading: "Why benefits paperwork piles up",
      body: "Each program has its own forms, deadlines, and renewal dates. Juggling several at once, especially while handling everything else in early reentry, makes it easy for one piece to slip through the cracks.",
      bullets: ["Different forms for every program", "Deadlines that sneak up", "Documents scattered in different places", "Not knowing you can appeal a denial", "Feeling defeated after one rejection"],
    },
    reframe: {
      heading: "Paperwork can be fixed",
      body: "A denial usually means something is missing, not that you don't qualify. Keep every document in one folder, and if you're denied, ask what's missing and appeal. Someone's job is to help you finish it.",
    },
    checkIn: [
      { id: "struggle", label: "How confusing does the benefits process feel right now?", left: "Not confusing", right: "Very confusing", higherIsHarder: true },
      { id: "confidence", label: "How confident do you feel getting your paperwork in order?", left: "Not confident", right: "Very confident", higherIsHarder: false },
      { id: "support", label: "How much help do you have with benefits paperwork?", left: "None", right: "A lot", higherIsHarder: false },
    ],
    adelQuestions: [
      "Which benefit is closest to being finished?",
      "Is there a denial or missing document you've been putting off dealing with?",
    ],
    skillSteps: [
      { id: "program", title: "Step 1 — My programs", instruction: "Choose up to 4.", maxPicks: 4, options: ["CalFresh", "Medi-Cal", "General Assistance", "SSI or SSDI", "CalWORKs", "Housing help", "Unemployment", "Phone program"] },
      { id: "status", title: "Step 2 — Status", instruction: "Pick one.", maxPicks: 1, options: ["Approved", "Applied, waiting", "Need to apply", "Denied, thinking about appealing", "Up for renewal"] },
      { id: "docs", title: "Step 3 — Documents they need", instruction: "Choose up to 3.", maxPicks: 3, options: ["ID", "Social Security card", "Proof of income", "Proof of address", "Release papers", "Bank statements", "Medical records"] },
      { id: "deadline", title: "Step 4 — My next deadline", instruction: "Pick one.", maxPicks: 1, feeds: "move", options: ["Turn in a document", "Renewal form", "Interview", "Appeal deadline", "Call my worker back", "Report a change"] },
      { id: "worker", title: "Step 5 — Who helps me with this", instruction: "Pick one.", maxPicks: 1, shared: "careTeam", options: ["Case manager", "My benefits worker", "Peer specialist", "Legal aid", "211"] },
    ],
  },

  transportation: {
    exerciseId: "plan-b-rehearsed",
    toolName: "Plan B Ride Card",
    toolIntro: "A Plan A, B and C for every regular appointment.",
    welcome: [
      "Have you ever missed something important simply because you couldn't get there?",
      "Maybe the bus ran late, or the ride you counted on fell through.",
      "Transportation problems can look like motivation problems from the outside, but they're not.",
      "A backup plan can save the whole day.",
    ],
    checklist: [
      "I've missed appointments because of a ride.",
      "I only have one way to get places.",
      "I don't know all the transportation options near me.",
      "I get anxious the night before an appointment about how I'll get there.",
      "I don't have a backup plan if my ride falls through.",
      "I avoid making plans because getting there feels too hard.",
    ],
    normalizing: "Missed appointments are often a transportation problem wearing a different name. That's not a character flaw — it's a logistics gap, and logistics gaps can be closed with a backup plan.",
    whyHard: {
      heading: "Why rides break more plans than motivation does",
      body: "One ride falling through can knock out an entire day of plans if there's no second option. Without a backup, a small transportation hiccup turns into a missed appointment, and missed appointments can carry real consequences.",
      bullets: ["Relying on just one way to get around", "Not knowing bus routes near you", "No backup for last-minute changes", "Appointments spread across separate trips", "Feeling stuck when a ride cancels"],
    },
    reframe: {
      heading: "Two options beat one",
      body: "You don't need a perfect system. You need one backup for your main way of getting around. Two options is usually the difference between making it and not.",
    },
    checkIn: [
      { id: "struggle", label: "How much does transportation get in your way?", left: "Not much", right: "A lot", higherIsHarder: true },
      { id: "confidence", label: "How confident do you feel getting where you need to go?", left: "Not confident", right: "Very confident", higherIsHarder: false },
      { id: "support", label: "How many transportation options do you have lined up?", left: "None", right: "Several", higherIsHarder: false },
    ],
    adelQuestions: [
      "What's your backup if your usual ride falls through?",
      "Which appointment coming up worries you most for getting there?",
    ],
    skillSteps: [
      { id: "appts", title: "Step 1 — My regular appointments", instruction: "Choose up to 3.", maxPicks: 3, options: ["PO", "Court", "Counseling", "Prescriber", "Meetings", "Work", "Drug testing", "Classes"] },
      { id: "a", title: "Step 2 — My Plan A ride", instruction: "Pick one.", maxPicks: 1, options: ["Bus", "Drive myself", "A family member", "A friend", "Bike or walk", "Program van"] },
      { id: "b", title: "Step 3 — My Plan B ride", instruction: "Pick one.", maxPicks: 1, options: ["Bus", "A friend", "A family member", "Ride-share", "My case manager", "Walk or bike"] },
      { id: "c", title: "Step 4 — My Plan C", instruction: "Pick one.", maxPicks: 1, options: ["Medi-Cal ride (book ahead)", "Program van", "Reschedule", "Video visit instead", "211 for ride help"] },
      { id: "late", title: "Step 5 — Who I call if I'll be late", instruction: "Choose up to 2.", maxPicks: 2, options: ["The office I'm going to", "My PO", "My case manager", "My counselor", "My boss"] },
    ],
  },

  "legal-responsibilities": {
    exerciseId: "call-ahead-out-loud",
    toolName: "Court & PO Calendar",
    toolIntro: "Every date, condition and contact in one place.",
    welcome: [
      "Have you ever felt your stomach sink because you realized you were going to miss a check-in?",
      "Court dates, fines, probation requirements — it's a lot to keep straight at once.",
      "The instinct might be to avoid it and explain later.",
      "But calling ahead changes everything about how a missed date is treated.",
    ],
    checklist: [
      "I've missed or almost missed a legal date.",
      "I don't have my dates written down anywhere reliable.",
      "I avoid calling when I know I can't make something.",
      "I feel anxious about my legal responsibilities.",
      "I don't know if my fines can go on a payment plan.",
      "I don't always know who to call when something comes up.",
    ],
    normalizing: "Feeling overwhelmed by legal requirements is common, especially when there's a lot to track. The good news is that calling ahead of a problem is treated very differently than dealing with it after. That single habit can protect a lot.",
    whyHard: {
      heading: "Why a missed date costs more than it seems",
      body: "A no-show can be read as avoidance, even when life just got in the way. Fines and requirements can often be negotiated, but only if you reach out before the deadline, not after it's already passed.",
      bullets: ["Juggling multiple dates at once", "Fear of getting in trouble for asking", "Not knowing fines can be adjusted", "Avoiding the phone call", "Forgetting a date without a reminder system"],
    },
    reframe: {
      heading: "Call before, not after",
      body: "Ahead of time, a scheduling conflict is just a scheduling conflict. After the fact, it can look like avoidance. One short phone call, made early, is the single highest-value habit here.",
    },
    checkIn: [
      { id: "struggle", label: "How much stress are your legal responsibilities causing you?", left: "None", right: "A lot", higherIsHarder: true },
      { id: "confidence", label: "How confident do you feel keeping track of your dates?", left: "Not confident", right: "Very confident", higherIsHarder: false },
      { id: "support", label: "How comfortable are you calling ahead when there's a conflict?", left: "Not comfortable", right: "Very comfortable", higherIsHarder: false },
    ],
    adelQuestions: [
      "What's your next legal date, and is it written down somewhere you'll see it?",
      "What would you say if you had to call and ask to reschedule?",
    ],
    skillSteps: [
      { id: "dates", title: "Step 1 — What I need to keep track of", instruction: "Choose up to 4.", maxPicks: 4, options: ["Court dates", "PO check-ins", "Drug testing", "Required classes", "Community service", "Fines or fees", "Treatment requirements", "Curfew"] },
      { id: "contacts", title: "Step 2 — My contacts", instruction: "Choose up to 2.", maxPicks: 2, shared: "careTeam", options: ["PO", "Lawyer or public defender", "Legal aid", "Case manager", "Court clerk", "Program staff"] },
      { id: "conditions", title: "Step 3 — Conditions I need to remember", instruction: "Choose up to 3.", maxPicks: 3, options: ["No contact with certain people", "Stay in the county", "Curfew", "Testing", "Treatment", "Work or school", "Fees or restitution", "Report changes in address or job"] },
      { id: "fines", title: "Step 4 — Fines and payments", instruction: "Pick one.", maxPicks: 1, options: ["No fines", "Payment plan set up", "Need to ask for a payment plan", "Behind on payments", "Not sure what I owe"] },
      { id: "remind", title: "Step 5 — Reminders", instruction: "Pick one.", maxPicks: 1, options: ["Phone reminder two days before", "Phone reminder the day before", "Calendar on the wall", "Adel reminder", "My case manager reminds me"] },
    ],
  },

  "community-connections": {
    exerciseId: "know-three-names",
    toolName: "Local Lowdown",
    toolIntro: "The places near you that help, in one place.",
    welcome: [
      "Have you ever moved through your day not knowing what resources were even nearby?",
      "It's hard to use help you don't know exists.",
      "Every county has a network of meetings, centers, and services, but nobody hands you the map.",
      "Knowing just a few by name can make hard weeks a lot shorter.",
    ],
    checklist: [
      "I don't know what's available in my area.",
      "I don't know where the nearest recovery meeting is.",
      "I've never used the library, workforce center, or 211.",
      "I feel disconnected from my community.",
      "I don't know where to print documents or get an ID.",
      "I rely on guessing instead of knowing.",
    ],
    normalizing: "Not knowing your local resources isn't a personal failing — nobody hands you that list when you get out. Learning your county's network is a skill you can build, one call at a time.",
    whyHard: {
      heading: "Why the local map feels invisible",
      body: "Resources exist, but they're scattered across different buildings, phone numbers, and websites. Without someone pointing you to them, they stay invisible even when they're close by.",
      bullets: ["No single list of local resources", "Not knowing 211 can route you almost anywhere", "Feeling too busy to look things up", "Not knowing who else uses these services", "Assuming you have to figure it out alone"],
    },
    reframe: {
      heading: "You only need three to start",
      body: "You don't need to memorize every resource in Tulare County. Knowing three by name — a meeting, a place to print documents, and 211 — makes most hard weeks a lot shorter.",
    },
    checkIn: [
      { id: "struggle", label: "How disconnected from local resources do you feel?", left: "Well connected", right: "Very disconnected", higherIsHarder: true },
      { id: "confidence", label: "How confident do you feel finding what you need locally?", left: "Not confident", right: "Very confident", higherIsHarder: false },
      { id: "support", label: "How many local resources do you already know by name?", left: "None", right: "Several", higherIsHarder: false },
    ],
    adelQuestions: [
      "Which local resource would help you most this month?",
      "Who could you ask if you don't know where to find something?",
    ],
    skillSteps: [
      { id: "meeting", title: "Step 1 — My nearest meeting", instruction: "Pick one.", maxPicks: 1, options: ["AA", "NA", "SMART Recovery", "Celebrate Recovery", "A peer support group", "Still looking"] },
      { id: "internet", title: "Step 2 — Free internet and printing", instruction: "Choose up to 2.", maxPicks: 2, options: ["Public library", "Job center", "Community center", "My program office", "A church"] },
      { id: "work", title: "Step 3 — Job help", instruction: "Pick one.", maxPicks: 1, options: ["America's Job Center", "A workforce program", "My case manager", "A temp agency", "Still looking"] },
      { id: "id", title: "Step 4 — ID and documents", instruction: "Choose up to 2.", maxPicks: 2, options: ["DMV", "Social Security office", "County records office", "My case manager can help", "Still looking"] },
      { id: "numbers", title: "Step 5 — My go-to numbers", instruction: "Choose up to 3.", maxPicks: 3, options: ["211", "988", "My case manager", "My peer specialist", "My clinic", "Legal aid"] },
    ],
  },

  "resource-plan": {
    exerciseId: "write-it-for-future-you",
    toolName: "One-Page Lifeline",
    toolIntro: "Your most important contacts and places on one printable page, built from this module.",
    welcome: [
      "Have you ever needed one important number or address and had to dig through ten different places to find it?",
      "You may have pieces of a plan scattered across your phone, your memory, and scraps of paper.",
      "On a hard day, digging for information takes energy you don't have.",
      "One page with everything on it changes that.",
    ],
    checklist: [
      "My important information is scattered everywhere.",
      "I don't have a single place to find what I need in an emergency.",
      "I've forgotten a number or address I needed.",
      "My phone is my only backup for this information.",
      "I feel unprepared for a hard week.",
      "I've never written down my resources in one place.",
    ],
    normalizing: "Having your resources scattered is common when you're juggling a lot at once. Putting them on one page isn't extra work — it's work you do once so you don't have to search for it later.",
    whyHard: {
      heading: "Why scattered information costs you on hard days",
      body: "When you're stressed, searching for information takes more energy than it should. If everything you need is in one place, a hard day becomes something you can read your way through instead of something you have to research.",
      bullets: ["Information spread across apps and paper", "Phones dying at the worst times", "Forgetting who to call for what", "No backup if your phone is lost", "Starting from scratch every time something comes up"],
    },
    reframe: {
      heading: "One page, everything",
      body: "You don't need ten browser tabs. You need one page with the six things you rely on most. When a hard week hits, you read instead of research.",
    },
    checkIn: [
      { id: "struggle", label: "How scattered do your resources feel right now?", left: "Organized", right: "Very scattered", higherIsHarder: true },
      { id: "confidence", label: "How confident do you feel you could find what you need in an emergency?", left: "Not confident", right: "Very confident", higherIsHarder: false },
      { id: "support", label: "How prepared do you feel for a hard week?", left: "Not prepared", right: "Very prepared", higherIsHarder: false },
    ],
    adelQuestions: [
      "What's the one line on your resource page you'd need first in an emergency?",
      "Who could help you put this page together if it feels like a lot?",
    ],
    skillSteps: [
      { id: "housing", title: "Step 1 — Housing and food", instruction: "Choose up to 2.", maxPicks: 2, options: ["My housing contact", "Sober living manager", "Food bank", "Free meals", "211"] },
      { id: "health", title: "Step 2 — Health", instruction: "Choose up to 2.", maxPicks: 2, shared: "careTeam", options: ["Primary care", "Clinic", "Prescriber", "Pharmacy", "Counselor", "Dentist"] },
      { id: "benefits", title: "Step 3 — Benefits and legal", instruction: "Choose up to 2.", maxPicks: 2, options: ["Benefits worker", "Case manager", "PO", "Lawyer or public defender", "Legal aid", "Court clerk"] },
      { id: "rides", title: "Step 4 — Rides", instruction: "Choose up to 2.", maxPicks: 2, options: ["Bus line", "Backup ride", "Medi-Cal ride line", "Program van"] },
      { id: "crisis", title: "Step 5 — Crisis", instruction: "Choose up to 2.", maxPicks: 2, crisisLink: true, options: ["988", "911", "My safety plan", "My 2 a.m. person", "My clinic's after-hours line"] },
    ],
  },
};
