import type { TopicContent } from "./types";

// Building My Support Team — topic-specific content (batch 2).
export const SUPPORT_TEAM: Record<string, TopicContent> = {
  "count-on": {
    exerciseId: "show-up-test",
    toolName: "Support Circle Mapper",
    toolIntro: "Put the people in your corner in the right ring.",
    partBExerciseId: "support-circle",
    welcome: [
      "Have you ever needed to call someone and realized you weren't sure who to pick?",
      "Maybe your phone has forty numbers in it, but only a few feel safe to actually use.",
      "Support isn't one big pile of people. It comes in layers, and it helps to know which layer each person is in.",
    ],
    checklist: [
      "I don't know who to call first when things get hard.",
      "I mix up people who are steady with people who aren't.",
      "I have a lot of contacts but few I'd actually call.",
      "I forget the people who are paid to help me.",
      "I second-guess who's really in my corner.",
      "I want a clearer picture of who I can count on.",
    ],
    normalizing: "If this sounds like you, that's common after time away from your usual people. Sorting your circle isn't cold — it's how you stop guessing on a hard night.",
    whyHard: {
      heading: "Why it's hard to know who's steady",
      body: "People's roles in your life can shift a lot during a big change like this. Someone who was steady before might not be right now, and someone new might turn out to be reliable. Your circle needs a fresh look, not an old list.",
      bullets: ["Calling the wrong person out of habit", "Feeling unsure who'd actually pick up", "Mixing up favors with real support", "Forgetting professionals who are paid to help", "Feeling alone even with contacts saved", "Knowing which people have to report what you tell them"],
    },
    reframe: {
      heading: "Layers, not one big circle",
      body: "You don't need a crowd. You need to know who's in your inner circle for anytime, who's steady but not urgent, and who's a professional you can lean on. Two clear layers beat twenty maybes. Your officer can help with requirements and referrals, but has to report some things, like a positive test. For cravings and hard feelings, your peer specialist, counselor, or sponsor are safer first calls.",
    },
    checkIn: [
      { id: "struggle", label: "How unsure do you feel about who's actually in your corner?", left: "Very sure", right: "Very unsure", higherIsHarder: true },
      { id: "confidence", label: "How confident are you that you could name your first call right now?", left: "Not confident", right: "Very confident", higherIsHarder: false },
      { id: "support", label: "How many people do you feel truly steady with today?", left: "None", right: "A few", higherIsHarder: false },
    ],
    adelQuestions: [
      "Who has shown up for you more than once since you've been out?",
      "Is there someone paid to help you, like a case manager or peer specialist, that you haven't leaned on yet?",
    ],
    skillSteps: [
      { id: "inner", title: "Step 1 — My inner circle", instruction: "Choose up to two people you'd call anytime.", maxPicks: 2, options: ["Sponsor", "Mom or dad", "Sibling", "Best friend", "Peer specialist", "Partner"] },
      { id: "steady", title: "Step 2 — Steady, not urgent", instruction: "Choose up to three.", maxPicks: 3, options: ["Case manager", "Coworker", "Friend from a meeting", "Extended family", "Neighbor", "Faith leader"] },
      { id: "pro", title: "Step 3 — Professionals I can use", instruction: "Choose up to two.", maxPicks: 2, options: ["Counselor", "Doctor", "Probation or parole officer (for requirements and referrals)", "Housing navigator", "Peer specialist"] },
      { id: "first", title: "Step 4 — My first call", instruction: "Pick the one person you'll save at the top of your favorites.", maxPicks: 1, options: ["Sponsor", "Peer specialist", "A family member", "A friend in recovery", "Case manager"] },
    ],
  },

  "ask-help": {
    exerciseId: "small-specific-soon",
    toolName: "Ask List",
    toolIntro: "What you need, who could help, and your first ask.",
    welcome: [
      "Have you ever needed something small but stayed quiet instead of asking?",
      "Maybe somewhere along the way, asking for help got you used, judged, or hurt.",
      "Out here, that same old rule can leave you stuck on things a quick ask could solve.",
    ],
    checklist: [
      "I'd rather struggle alone than ask.",
      "I wait until I'm desperate to ask for anything.",
      "I feel weak or like a burden when I ask.",
      "I ask in a vague way instead of saying exactly what I need.",
      "I've been let down before when I asked.",
      "I want to get better at asking clearly.",
    ],
    normalizing: "Plenty of people come home with this same rule running in the background. It made sense once. It doesn't have to run your life now — asking clearly is a skill you can build.",
    whyHard: {
      heading: "Why asking feels risky",
      body: "In a lot of environments, asking for help was a real risk. Your brain learned to protect you by staying quiet. That protection doesn't know the difference between then and now, so it still fires even when the person in front of you would say yes.",
      bullets: ["Waiting until things are urgent", "Feeling like a burden", "Asking in a roundabout way", "Assuming the answer is no before you try", "Feeling shame after asking"],
    },
    reframe: {
      heading: "Small and specific gets a yes",
      body: "A vague ask like \"I never have help\" is hard for anyone to act on. A specific ask like \"Can you drive me Thursday at 9?\" is easy to picture and easy to say yes to. Try one small, specific ask this week.",
    },
    checkIn: [
      { id: "struggle", label: "How hard is it for you to ask for help right now?", left: "Easy", right: "Very hard", higherIsHarder: true },
      { id: "confidence", label: "How confident do you feel making one specific ask?", left: "Not confident", right: "Very confident", higherIsHarder: false },
      { id: "support", label: "How likely is it someone would say yes if you asked?", left: "Not likely", right: "Very likely", higherIsHarder: false },
    ],
    adelQuestions: [
      "What's one thing you need this week that you haven't asked for yet?",
      "What usually stops you right before you ask?",
    ],
    skillSteps: [
      { id: "need", title: "Step 1 — What I need help with", instruction: "Choose up to 3.", maxPicks: 3, options: ["Rides", "Food", "A phone", "Paperwork", "Childcare", "Someone to talk to", "A place to stay", "Money for something specific"] },
      { id: "who", title: "Step 2 — Who could help", instruction: "Choose up to 3.", maxPicks: 3, shared: "supportPeople", options: ["Case manager", "Peer specialist", "Sponsor", "A family member", "A friend", "Someone from church", "211"] },
      { id: "stops", title: "Step 3 — What stops me from asking", instruction: "Choose up to 2.", maxPicks: 2, options: ["I don't want to be a burden", "They might say no", "I don't want to owe anyone", "It feels weak", "I don't know how to ask", "I've been let down before"] },
      { id: "first", title: "Step 4 — My first ask", instruction: "Pick one.", maxPicks: 1, feeds: "move", options: ["Ask for a ride", "Ask for help with a form", "Ask someone to just listen", "Ask for a meal", "Ask my case manager for a referral", "Ask someone to come with me to an appointment"] },
    ],
  },

  "rebuild-trust": {
    exerciseId: "their-side-of-the-table",
    toolName: "Trust Deposits",
    toolIntro: "Small promises, kept, add up.",
    welcome: [
      "Have you ever apologized and meant it, but still watched someone stay guarded around you?",
      "Words can only do so much. Trust usually comes back slower than we want it to.",
      "The good news is you already know how it gets rebuilt: one kept promise at a time.",
    ],
    checklist: [
      "I want people to trust me faster than they do.",
      "I feel frustrated when apologies don't change things right away.",
      "I've made promises before that I didn't keep.",
      "I don't always follow through on small things.",
      "I want a way to show change instead of just saying it.",
      "I get discouraged and want to stop trying.",
    ],
    normalizing: "Wanting trust to come back quickly makes sense — waiting is uncomfortable. But trust rebuilding at its own pace isn't a sign you're failing. It's just how trust works for everyone.",
    whyHard: {
      heading: "Why trust takes so long to rebuild",
      body: "Trust isn't restored by explaining or promising. It's restored by a pattern of small kept commitments over time. Every kept promise is a deposit. Every explanation without action is a withdrawal, even when the explanation is true.",
      bullets: ["Wanting credit before it's earned", "Feeling like nothing you do is enough", "Getting impatient with slow progress", "Old broken promises still being remembered", "Wanting to give up on rebuilding"],
    },
    reframe: {
      heading: "Deposits, not speeches",
      body: "You don't need a big gesture. You need to say what you're going to do, then do exactly that, without asking for credit. Do it again next week. Let time do the rest.",
    },
    checkIn: [
      { id: "struggle", label: "How impatient do you feel about earning trust back?", left: "Patient", right: "Very impatient", higherIsHarder: true },
      { id: "confidence", label: "How confident are you that you can keep a small promise this week?", left: "Not confident", right: "Very confident", higherIsHarder: false },
      { id: "support", label: "How willing is at least one person to give you a chance right now?", left: "Not willing", right: "Very willing", higherIsHarder: false },
    ],
    adelQuestions: [
      "Who are you most hoping will trust you again?",
      "What's one small promise you could make and keep this week?",
    ],
    skillSteps: [
      { id: "person", title: "Step 1 — The person", instruction: "Pick one.", maxPicks: 1, options: ["Mom", "Dad", "Partner", "My kids", "Brother or sister", "A friend", "My sponsor", "An employer"] },
      { id: "promises", title: "Step 2 — Small promises I can keep", instruction: "Choose up to 3.", maxPicks: 3, feeds: "move", options: ["Call when I say I will", "Show up on time", "Text back the same day", "Pay back a small amount", "Keep my appointments", "Tell the truth about where I am", "Follow through on one plan", "Do what I said I'd do around the house"] },
      { id: "track", title: "Step 3 — How I'll track kept promises", instruction: "Pick one.", maxPicks: 1, options: ["Check them off in my toolkit", "A note on my phone", "A calendar", "Tell my sponsor each week", "Tell Adel"] },
      { id: "check", title: "Step 4 — When I'll check in on it", instruction: "Pick one.", maxPicks: 1, options: ["In one week", "In two weeks", "In a month", "At my next counseling visit"] },
    ],
  },

  boundaries: {
    exerciseId: "broken-record",
    toolName: "Line in the Sand",
    toolIntro: "One boundary, the words to say it and what you'll do if it's crossed.",
    welcome: [
      "Have you ever let someone walk all over you, then cut them off completely once it got to be too much?",
      "It can feel like there are only two settings: let everything in, or shut everyone out.",
      "A boundary is a middle path — one that's about what you'll do, not about controlling them.",
    ],
    checklist: [
      "I let people push past my limits.",
      "I cut people off completely instead of setting a limit.",
      "I feel guilty for saying no.",
      "I explain and argue instead of just holding my line.",
      "I don't know the difference between a boundary and a wall.",
      "I want relationships that are possible, not gone or overwhelming.",
    ],
    normalizing: "Swinging between no limits and no relationship is common, especially if boundaries weren't modeled for you before. Boundaries are a skill, and like any skill, they get easier with practice.",
    whyHard: {
      heading: "Why boundaries feel confusing",
      body: "A wall keeps everyone out and ends the relationship. A boundary says what you will do and keeps the relationship possible. Without a clear model for this, it's easy to swing between the two extremes.",
      bullets: ["Feeling guilty for having limits", "Over-explaining instead of just holding the line", "Cutting people off entirely", "Letting the same thing happen again and again", "Confusing distance with punishment"],
    },
    reframe: {
      heading: "State what you'll do",
      body: "You don't need permission or an argument to have a boundary. \"If the yelling starts, I'm leaving for an hour\" is about you, not them. Say it once, calmly, then follow through.",
    },
    checkIn: [
      { id: "struggle", label: "How often do people push past your limits right now?", left: "Rarely", right: "Often", higherIsHarder: true },
      { id: "confidence", label: "How confident do you feel saying a boundary out loud?", left: "Not confident", right: "Very confident", higherIsHarder: false },
      { id: "support", label: "How much do you believe you can hold a boundary without losing the relationship?", left: "Not much", right: "A lot", higherIsHarder: false },
    ],
    adelQuestions: [
      "Where do you most need a boundary right now?",
      "What's the difference between a boundary and a wall, in your own words?",
    ],
    skillSteps: [
      { id: "who", title: "Step 1 — The person or situation", instruction: "Pick one.", maxPicks: 1, options: ["A family member", "An old friend", "My partner", "A roommate", "Someone who uses", "Someone asking for money", "Coworkers", "My ex"] },
      { id: "boundary", title: "Step 2 — My boundary", instruction: "Pick one.", maxPicks: 1, options: ["\"I won't lend money.\"", "\"I won't give rides to old spots.\"", "\"I won't stay if there's using.\"", "\"I won't talk about my case.\"", "\"I'll leave if there's yelling.\"", "\"I won't answer calls after 10 p.m.\""] },
      { id: "say", title: "Step 3 — What I'll say", instruction: "Pick one.", maxPicks: 1, options: ["\"I'm not able to do that.\"", "\"That doesn't work for me.\"", "\"No, but thanks for asking.\"", "\"I need to go now.\"", "\"I can't tonight, but I can Saturday.\""] },
      { id: "crossed", title: "Step 4 — If it's crossed, I'll", instruction: "Choose up to 2.", maxPicks: 2, feeds: "move", options: ["Leave", "Say it again, once", "Hang up", "Take a break from them", "Tell my support person", "Go to a meeting"] },
      { id: "backup", title: "Step 5 — Who backs me up", instruction: "Choose up to 2.", maxPicks: 2, shared: "supportPeople", crisisLink: true, options: ["Sponsor", "Peer specialist", "Counselor", "A family member", "A friend in recovery", "Case manager"] },
    ],
  },

  "communicating-needs": {
    exerciseId: "need-statement",
    toolName: "Need It, Say It",
    toolIntro: "Name your needs and get the top one said.",
    welcome: [
      "Have you ever been upset with someone for not doing something you never actually asked them to do?",
      "It's easy to expect people to just know, especially when saying it out loud feels risky.",
      "Nobody can read your mind, but they might be glad to help once you tell them.",
    ],
    checklist: [
      "I expect people to know what I need without me saying it.",
      "I get resentful when needs go unmet.",
      "I hint instead of asking directly.",
      "I feel exposed when I say what I actually need.",
      "I stay quiet and then explode later.",
      "I want to get better at naming a need plainly.",
    ],
    normalizing: "Expecting people to guess is a really common pattern, and it usually comes from needs not being safe to say out loud before. Naming a need plainly is a skill you can build one sentence at a time.",
    whyHard: {
      heading: "Why unspoken needs turn into resentment",
      body: "A need that stays in your head can't be met by anyone else. It quietly builds into frustration, then resentment, even though the other person never had the chance to respond. Saying it out loud is the only way it can actually get met.",
      bullets: ["Hoping someone will just notice", "Feeling hurt when they don't", "Hinting instead of asking directly", "Building resentment in silence", "Feeling exposed when naming a need"],
    },
    reframe: {
      heading: "One need, one request",
      body: "Keep it simple: \"I need ___. Can you ___?\" One clear need, one clear ask, no long build-up. It feels risky at first, and it gets easier every time you say it.",
    },
    checkIn: [
      { id: "struggle", label: "How often do you expect people to just know what you need?", left: "Rarely", right: "Often", higherIsHarder: true },
      { id: "confidence", label: "How confident do you feel saying a need out loud?", left: "Not confident", right: "Very confident", higherIsHarder: false },
      { id: "support", label: "How safe does it feel to say a need to someone in your life?", left: "Not safe", right: "Safe", higherIsHarder: false },
    ],
    adelQuestions: [
      "Which need would you feel most awkward saying out loud?",
      "Who's one person you could practice naming a need with?",
    ],
    skillSteps: [
      { id: "needs", title: "Step 1 — My needs", instruction: "Choose up to 3.", maxPicks: 3, options: ["Rest", "Respect", "Space", "Help with something", "Time with my kids", "Support at meetings", "Someone to listen", "Honesty"] },
      { id: "who", title: "Step 2 — Who could meet them", instruction: "Choose up to 2.", maxPicks: 2, shared: "supportPeople", options: ["Partner", "A family member", "Case manager", "Sponsor", "Peer specialist", "A friend", "Counselor"] },
      { id: "top", title: "Step 3 — My need statement for the top one", instruction: "Fill in the blanks in the box if you want.", maxPicks: 1, options: ["\"I need ___. It would help me ___. Can you ___?\"", "\"I need some space tonight. It helps me calm down. Can we talk tomorrow?\"", "\"I need help with my paperwork. It would help me meet the deadline. Can you go over it with me?\"", "\"I need you to listen. It helps me feel less alone. Can you just hear me out?\""] },
      { id: "when", title: "Step 4 — When I'll say it", instruction: "Pick one.", maxPicks: 1, options: ["Today", "Tomorrow", "At my next appointment", "This weekend", "When we're both calm", "In a text first"] },
    ],
  },

  "difficult-relationships": {
    exerciseId: "serenity-sort",
    toolName: "Distance Dial",
    toolIntro: "Set how close you'll be, and how you'll get out.",
    welcome: [
      "Have you ever wished you could just delete someone from your life, but you can't because of family or kids?",
      "Some relationships aren't good for your recovery, but a clean break isn't possible or even something you want.",
      "You have more control here than it might feel like, just not over the person themselves.",
    ],
    checklist: [
      "Someone in my life isn't good for my recovery.",
      "I feel stuck because I can't cut them off completely.",
      "I keep hoping they'll change.",
      "I don't know what I can actually control in the relationship.",
      "I feel guilty for wanting distance.",
      "I want a plan for managing contact instead of avoiding the whole thing.",
    ],
    normalizing: "Feeling stuck between needing distance and not being able to fully leave is common, especially with family or co-parents. There's more room to work with than it feels like right now.",
    whyHard: {
      heading: "Why it's rarely all-or-nothing",
      body: "You can't control whether someone changes, but you can control how often you see them, where, how long, and what you talk about. That's especially true with family and co-parents, who often need managed contact rather than a clean break.",
      bullets: ["Hoping they'll change instead of changing the terms", "Feeling guilty for wanting less contact", "Not noticing what's actually in your control", "Repeating the same hard visit over and over", "Feeling stuck between too close and gone"],
    },
    reframe: {
      heading: "Change the terms, not the person",
      body: "You can change how often you see them, where you meet, how long you stay, and whether you lend money. You can't change their opinion of you or whether they grow. Focus your energy on the levers that are actually yours.",
    },
    checkIn: [
      { id: "struggle", label: "How much is this relationship weighing on your recovery right now?", left: "Not much", right: "A lot", higherIsHarder: true },
      { id: "confidence", label: "How confident do you feel changing one term of contact?", left: "Not confident", right: "Very confident", higherIsHarder: false },
      { id: "support", label: "How much support do you have for setting this distance?", left: "None", right: "A lot", higherIsHarder: false },
    ],
    adelQuestions: [
      "Which lever could you pull this week: how often, where, or how long?",
      "What's made it hardest to change the terms with this person so far?",
    ],
    skillSteps: [
      { id: "person", title: "Step 1 — The person", instruction: "Pick one.", maxPicks: 1, options: ["A parent", "A sibling", "My ex", "My kids' other parent", "An old friend", "A relative who uses", "A coworker", "My roommate"] },
      { id: "close", title: "Step 2 — How close I want to be right now", instruction: "Pick one.", maxPicks: 1, options: ["Close", "Some contact", "A little contact", "Only when I have to", "Not right now"] },
      { id: "how", title: "Step 3 — How often, where and how long", instruction: "Choose up to 3.", maxPicks: 3, options: ["Once a week", "Once a month", "Only on holidays", "In public places only", "Phone or text only", "One hour max", "With someone else there", "During the day only"] },
      { id: "off", title: "Step 4 — Off-limits for now", instruction: "Choose up to 3.", maxPicks: 3, options: ["Money", "Rides", "My case", "The past", "Using", "Staying overnight", "Politics or religion", "Other family drama"] },
      { id: "exit", title: "Step 5 — My exit line", instruction: "Pick one.", maxPicks: 1, feeds: "move", options: ["\"I've got to head out.\"", "\"I have an appointment.\"", "\"Let's pick this up another time.\"", "\"I'm going to go now.\"", "\"I need to get some air.\""] },
    ],
  },

  "positive-connections": {
    exerciseId: "give-it-three-visits",
    toolName: "New Rooms",
    toolIntro: "New places to try, and notes from your first three visits.",
    welcome: [
      "Have you ever realized that almost everyone in your phone is tied to the life you're trying to leave behind?",
      "It can feel like there's nowhere new to meet people who are good for where you're headed.",
      "New connections usually come from new rooms, not from waiting for the right conversation to happen.",
    ],
    checklist: [
      "Most people I know are from my old life.",
      "I don't know where to meet new people.",
      "I've gone to a new place once and not gone back.",
      "I feel like an outsider walking into a new room.",
      "I want people around me who support where I'm headed.",
      "I keep waiting instead of showing up somewhere new.",
    ],
    normalizing: "Feeling short on positive connections after a big life change is common. New people come from repeated exposure in new rooms, not from one good conversation, and that's something you can practice.",
    whyHard: {
      heading: "Why new connections take repetition",
      body: "You can't meet different people in the same old places. Meetings, classes, work, volunteering, gyms, and churches are where new connection grows, but usually not from the first visit. Showing up to the same room three times is often what it takes.",
      bullets: ["Feeling like a stranger the first time", "Giving up after one visit", "Comparing a new room to old, easy connections", "Waiting for people to approach you first", "Underestimating how long it takes"],
    },
    reframe: {
      heading: "Same room, three times",
      body: "Pick one room, and go three times before you judge whether it's for you. Connection usually starts to happen on its own once people see your face more than once.",
    },
    checkIn: [
      { id: "struggle", label: "How disconnected from positive people do you feel right now?", left: "Connected", right: "Very disconnected", higherIsHarder: true },
      { id: "confidence", label: "How confident are you that you could show up somewhere new three times?", left: "Not confident", right: "Very confident", higherIsHarder: false },
      { id: "support", label: "How open do you feel to trying a new room this month?", left: "Not open", right: "Very open", higherIsHarder: false },
    ],
    adelQuestions: [
      "Which room feels most doable for you this month?",
      "What's stopped you from going back to a new place before?",
    ],
    skillSteps: [
      { id: "rooms", title: "Step 1 — Rooms to try", instruction: "Choose up to 3.", maxPicks: 3, options: ["A recovery meeting", "A class", "A gym", "A faith group", "Volunteering", "A sports league", "A library program", "A community garden"] },
      { id: "when", title: "Step 2 — Day and time", instruction: "Pick one.", maxPicks: 1, options: ["Monday evening", "Tuesday evening", "Wednesday evening", "Thursday evening", "Saturday morning", "Sunday"] },
      { id: "who", title: "Step 3 — Who could come with me", instruction: "Pick one.", maxPicks: 1, shared: "supportPeople", options: ["Sponsor", "Peer specialist", "A friend", "A family member", "No one, I'll go solo"] },
      { id: "notes", title: "Step 4 — How it's going", instruction: "Choose up to 2.", maxPicks: 2, options: ["Visit one: awkward but I went", "Visit two: someone said hi", "Visit three: someone knew my name", "I want to keep going", "I'll try a different room"] },
    ],
  },

  "my-community": {
    exerciseId: "early-and-useful",
    toolName: "Belonging Blueprint",
    toolIntro: "Go from showing up to belonging.",
    welcome: [
      "Have you ever gone to the same place several times and still felt like a stranger there?",
      "Attending isn't the same as belonging, and it's easy to feel like an outsider even when you show up.",
      "Belonging usually comes from contributing something small, not from waiting to be noticed.",
    ],
    checklist: [
      "I've been to the same place several times and still feel like an outsider.",
      "I sit in the back and don't interact.",
      "I don't know how to contribute without being asked.",
      "I feel like I don't belong anywhere yet.",
      "I want to be known somewhere, not just present.",
      "I hold back because I'm not sure I'll stick around.",
    ],
    normalizing: "Feeling like attendance alone hasn't built belonging is really common. Belonging usually comes from small, repeated contribution, and that's a skill you can start using right away.",
    whyHard: {
      heading: "Why showing up isn't the same as belonging",
      body: "A community is a place where you're expected and where you contribute, not just a place you attend. Setting up chairs, giving someone a ride, or checking in on someone newer turns attendance into belonging. Contribution is what people remember.",
      bullets: ["Sitting in the back without interacting", "Waiting to be invited to help", "Feeling unseen despite showing up", "Comparing yourself to people who seem to already belong", "Underestimating how small a contribution can be"],
    },
    reframe: {
      heading: "Contribute, don't just attend",
      body: "You don't have to talk much or be the center of attention. Arriving early and helping with something small is often what turns a room of strangers into people who know your name.",
    },
    checkIn: [
      { id: "struggle", label: "How much like an outsider do you feel in your groups right now?", left: "Like I belong", right: "Like an outsider", higherIsHarder: true },
      { id: "confidence", label: "How confident do you feel offering to help with something small?", left: "Not confident", right: "Very confident", higherIsHarder: false },
      { id: "support", label: "How welcoming has this group felt so far?", left: "Not welcoming", right: "Welcoming", higherIsHarder: false },
    ],
    adelQuestions: [
      "Where could you contribute something small this week?",
      "What's stopped you from offering to help before now?",
    ],
    skillSteps: [
      { id: "where", title: "Step 1 — Where I want to belong", instruction: "Choose up to 2.", maxPicks: 2, options: ["My meeting", "A church", "A gym", "A volunteer group", "My job", "My neighborhood", "A sports team", "A class"] },
      { id: "give", title: "Step 2 — What I can contribute", instruction: "Choose up to 2.", maxPicks: 2, options: ["Making coffee", "Setting up chairs", "Giving rides", "Listening to newer people", "Sharing my story", "Cooking", "Fixing things", "Showing up on time"] },
      { id: "met", title: "Step 3 — People I've met", instruction: "Choose up to 3.", maxPicks: 3, options: ["Someone from my meeting", "A neighbor", "A coworker", "Someone from church", "Someone at the gym", "A volunteer", "No one yet"] },
      { id: "week", title: "Step 4 — One way to show up this week", instruction: "Pick one.", maxPicks: 1, feeds: "move", options: ["Get there 10 minutes early", "Offer to help set up", "Learn one name", "Check in on someone newer", "Stay after to clean up", "Take a service job"] },
    ],
  },

  "give-receive": {
    exerciseId: "just-say-thanks",
    toolName: "Give and Get",
    toolIntro: "Keep support flowing both ways.",
    welcome: [
      "Have you ever felt more comfortable giving everything away than letting someone give something to you?",
      "Or maybe it's the other way around, and taking help feels like racking up a debt you can never pay off.",
      "Support is supposed to move in both directions, and finding your balance is something you can practice.",
    ],
    checklist: [
      "I give a lot but rarely let people help me.",
      "I feel guilty when someone does something for me.",
      "I take help but feel like I owe them right away.",
      "I burn out from always being the one giving.",
      "I don't let people really know me because I'm always the helper.",
      "I want to feel okay on both sides of support.",
    ],
    normalizing: "Being lopsided toward giving or receiving is common, especially if being needed felt safer than being vulnerable. Finding balance is something you can build gradually, on purpose.",
    whyHard: {
      heading: "Why balance is hard to find",
      body: "Only giving keeps you needed but exhausted, and it can keep people from really knowing you. Only taking can feel like it builds a debt you have to pay off. Balanced support means being able to say \"I need help\" and \"let me help you\" in the same week.",
      bullets: ["Feeling safer giving than receiving", "Feeling indebted after receiving help", "Burning out from constant giving", "Avoiding vulnerability by staying the helper", "Not knowing which side is harder for you"],
    },
    reframe: {
      heading: "Both directions, same week",
      body: "You don't have to fix your balance overnight. Try accepting one offer of help without immediately paying it back, and offering one small thing to someone else. Both are part of real connection.",
    },
    checkIn: [
      { id: "struggle", label: "How lopsided does your giving and receiving feel right now?", left: "Balanced", right: "Very lopsided", higherIsHarder: true },
      { id: "confidence", label: "How confident do you feel accepting help without paying it back right away?", left: "Not confident", right: "Very confident", higherIsHarder: false },
      { id: "support", label: "How okay do you feel letting someone see you need something?", left: "Not okay", right: "Okay", higherIsHarder: false },
    ],
    adelQuestions: [
      "Which side is harder for you: giving or receiving?",
      "When's the last time you let someone help you without paying it back right away?",
    ],
    skillSteps: [
      { id: "give", title: "Step 1 — Ways I give", instruction: "Choose up to 3.", maxPicks: 3, options: ["Listening", "Giving rides", "Cooking", "Helping with chores", "Sharing at meetings", "Watching kids", "Fixing things", "Checking in on people"] },
      { id: "get", title: "Step 2 — Ways I let people help", instruction: "Choose up to 2.", maxPicks: 2, options: ["Taking a ride", "Accepting food", "Letting someone listen", "Asking for advice", "Taking help with paperwork", "Letting someone check on me", "I don't, yet"] },
      { id: "lopsided", title: "Step 3 — Where it's lopsided", instruction: "Pick one.", maxPicks: 1, options: ["I give more than I get", "I take more than I give", "It's pretty even", "I don't do much of either right now"] },
      { id: "week", title: "Step 4 — One give and one get this week", instruction: "Choose up to 2.", maxPicks: 2, feeds: "move", options: ["Say yes to one offer", "Ask for something small", "Do something for someone", "Say thank you and nothing else", "Check in on someone", "Let someone check on me"] },
    ],
  },

  "support-plan": {
    exerciseId: "picture-the-call",
    toolName: "The 2 A.M. Plan",
    toolIntro: "Exactly who to call, what to say and what to do while you wait.",
    welcome: [
      "Have you ever had a bad night and realized you didn't actually know who to call first?",
      "In the moment, it's hard to think clearly, which is exactly why a plan written ahead of time matters.",
      "A support plan is something you build now, calm, so it works later, when you're not.",
    ],
    checklist: [
      "I don't have a clear call order for a hard night.",
      "I freeze when I'm supposed to reach out.",
      "I don't know what to do if my first call doesn't answer.",
      "I've never written my support plan down.",
      "I forget who's actually available at 2 a.m.",
      "I want something simple I can grab in a bad moment.",
    ],
    normalizing: "Not having a clear plan yet is common, especially if you've never needed to write one down before. A short written plan is one of the simplest tools you can build, and it works exactly when you need it to.",
    whyHard: {
      heading: "Why the moment is the wrong time to plan",
      body: "On a hard night, your brain is not at its clearest. That's the worst possible time to figure out who to call and what to say. A plan written ahead of time, while you're calm, does the thinking for you in advance.",
      bullets: ["Freezing when it's time to reach out", "Not knowing who's actually free to answer", "Giving up after one unanswered call", "Not knowing what to do while waiting", "Never having written it down before"],
    },
    reframe: {
      heading: "Write it before you need it",
      body: "A support plan is just a short list: who to call first, who's next if they don't answer, and what you'll do while you wait. Written calm, it works even on the nights you're not.",
    },
    checkIn: [
      { id: "struggle", label: "How unclear does your plan for a hard night feel right now?", left: "Very clear", right: "Very unclear", higherIsHarder: true },
      { id: "confidence", label: "How confident are you that you'd use your plan if a hard night came?", left: "Not confident", right: "Very confident", higherIsHarder: false },
      { id: "support", label: "How many people are actually reachable for you on a hard night?", left: "None", right: "A few", higherIsHarder: false },
    ],
    adelQuestions: [
      "Who is your first call, and who is your backup?",
      "What will you do while you wait for someone to call you back?",
    ],
    skillSteps: [
      { id: "order", title: "Step 1 — My call order", instruction: "Pick in the order you'd call them.", maxPicks: 3, shared: "supportPeople", options: ["Sponsor", "Peer specialist", "A family member", "A friend in recovery", "Counselor", "Case manager", "Someone from my meeting"] },
      { id: "say", title: "Step 2 — What I'll say", instruction: "Pick one.", maxPicks: 1, options: ["\"I'm having a rough time. Can you talk?\"", "\"I'm struggling. Can you stay on the phone with me?\"", "\"I need help right now.\"", "\"Can you come get me?\"", "\"I don't want to be alone right now.\""] },
      { id: "wait", title: "Step 3 — What I do while I wait", instruction: "Choose up to 3.", maxPicks: 3, shared: "copingTools", feeds: "move", options: ["Go somewhere with people", "Slow breathing", "5-4-3-2-1", "Drink water", "Walk", "Pray", "Text the next person", "Leave where I am"] },
      { id: "crisis", title: "Step 4 — If no one answers and it's an emergency", instruction: "Pick one.", maxPicks: 1, crisisLink: true, options: ["Call or text 988", "Call 911", "Go to the nearest ER", "Open my safety plan", "Call my clinic's after-hours line"] },
      { id: "save", title: "Step 5 — Where I'll keep it", instruction: "Pick one.", maxPicks: 1, options: ["My lock screen", "A card in my wallet", "Taped by my bed", "My toolkit here", "Phone favorites"] },
    ],
  },
};
