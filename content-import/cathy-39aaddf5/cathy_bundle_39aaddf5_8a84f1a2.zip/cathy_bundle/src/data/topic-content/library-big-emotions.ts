import type { TopicContent } from "./types";

// Managing Big Emotions — topic-specific content (batch 2).
export const BIG_EMOTIONS: Record<string, TopicContent> = {
  "understanding-emotions": {
    exerciseId: "check-the-facts",
    toolName: "Feelings Decoder",
    toolIntro: "Figure out what a feeling is telling you.",
    welcome: [
      "Have you ever felt something strong in your chest but couldn't find the word for it?",
      "Maybe it comes out as \"I'm just mad\" when underneath it's actually hurt, or scared, or ashamed.",
      "When you can't name a feeling, it tends to run the show instead of you.",
    ],
    checklist: [
      "I feel something strong but can't say what it is.",
      "I say \"I'm fine\" when I'm not.",
      "One feeling word covers a lot of different things for me.",
      "I notice my body before I notice the feeling.",
      "I judge myself for feeling a certain way.",
      "I don't know what most of my feelings are pointing at.",
    ],
    normalizing: "If naming feelings is hard, that's common, especially if showing emotion wasn't safe before. Naming a feeling is a skill, and it gets easier with practice.",
    whyHard: {
      heading: "Why naming a feeling is harder than it sounds",
      body: "Emotions start in a fast part of the brain, before words show up. If you never had a safe place to practice naming feelings, that connection between feeling and word stays weak. It's not that you don't have feelings. It's that the label hasn't caught up yet.",
      bullets: ["Feeling something without a name for it", "Calling everything \"mad\" or \"fine\"", "Feeling it in your body before your head knows why", "Feeling flooded all at once", "Not trusting what you feel"],
    },
    reframe: {
      heading: "Every feeling is pointing at something",
      body: "Anger usually points at a line that got crossed. Fear points at a threat. Sadness points at a loss. Guilt points at a value you care about. You don't have to obey the feeling — just ask what it's flagging.",
    },
    checkIn: [
      { id: "struggle", label: "How hard is it to name what you're feeling right now?", left: "Easy", right: "Very hard", higherIsHarder: true },
      { id: "confidence", label: "How confident do you feel figuring out what a feeling is about?", left: "Not confident", right: "Very confident", higherIsHarder: false },
      { id: "support", label: "How much hope do you have that this gets easier with practice?", left: "Not much", right: "A lot", higherIsHarder: false },
    ],
    adelQuestions: [
      "What feeling shows up the most for you, and what might it be pointing at?",
      "Is there a feeling you were never allowed to show growing up?",
    ],
    skillSteps: [
      {"id": "feeling", "title": "Step 1 — The feeling", "instruction": "Choose up to 2.", "maxPicks": 2, "options": ["Angry", "Sad", "Scared", "Ashamed", "Lonely", "Jealous", "Guilty", "Numb", "Hurt", "Anxious"]},
      {"id": "body", "title": "Step 2 — Where I feel it", "instruction": "Choose up to 2.", "maxPicks": 2, "options": ["Chest", "Stomach", "Face", "Jaw", "Hands", "Throat", "Shoulders", "All over"]},
      {"id": "set", "title": "Step 3 — What set it off", "instruction": "Choose up to 2.", "maxPicks": 2, "options": ["A call or text", "Something someone said", "A memory", "Being ignored", "A mistake I made", "Bad news", "Being tired or hungry", "Not sure"], "feeds": "cue"},
      {"id": "fits", "title": "Step 4 — Does it fit the facts?", "instruction": "Pick one.", "maxPicks": 1, "options": ["Yes, it fits", "Partly", "No, I added a story", "Not sure yet"]},
      {"id": "need", "title": "Step 5 — What I need", "instruction": "Choose up to 2.", "maxPicks": 2, "options": ["Talk to someone", "Rest", "Eat", "Some space", "Fix a problem", "Let it pass", "Say how I feel", "A walk"], "feeds": "move"},
    ],
  },

  "anger-signs": {
    exerciseId: "push-the-wall-check",
    toolName: "Anger Thermometer",
    toolIntro: "Know your number, know your move.",
    partBExerciseId: "anger-thermometer",
    welcome: [
      "Have you ever noticed you were already yelling before you realized you were even angry?",
      "The signs were probably there earlier: a tight jaw, a hot face, hands curling into fists.",
      "Your body usually knows before your mind catches up.",
    ],
    checklist: [
      "I don't notice I'm angry until I'm already loud.",
      "My jaw or hands tighten without me noticing.",
      "My face gets hot before I say anything.",
      "I go quiet and cold instead of showing it.",
      "By the time I notice, I only have damage control left.",
      "I want to catch it earlier.",
    ],
    normalizing: "Most people never learned to check in with their body early. The good news is those early signs are already there, waiting for you to notice them.",
    whyHard: {
      heading: "Why anger sneaks up on you",
      body: "Anger doesn't come from nowhere. It builds in your body first, minutes before it shows on your face. If you're used to pushing feelings down, you may skip right past the early signs and land at a 9 or 10 without noticing the runway.",
      bullets: ["Jaw or hands tightening", "Face or neck getting hot", "Breathing getting faster", "Pacing or restlessness", "Tunnel vision"],
    },
    reframe: {
      heading: "Catch it at a 3, not a 9",
      body: "At a 3 you still have choices. At a 9 you're mostly doing damage control. Learning your own early signs, the ones nobody else sees, gives you back that window.",
    },
    checkIn: [
      { id: "struggle", label: "How often do you notice anger only after it's already big?", left: "Rarely", right: "Almost always", higherIsHarder: true },
      { id: "confidence", label: "How well do you know your own early warning signs?", left: "Not well", right: "Very well", higherIsHarder: false },
      { id: "support", label: "How hopeful are you that you can catch it earlier?", left: "Not hopeful", right: "Very hopeful", higherIsHarder: false },
    ],
    adelQuestions: [
      "What's the very first sign your body gives you, before all the others?",
      "When was the last time you caught it early? What helped?",
    ],
    skillSteps: [
      { id: "signs", title: "Step 1 — My early body signs", instruction: "Choose up to three.", maxPicks: 3, options: ["Jaw tightens", "Hands clench", "Face gets hot", "Chest tight", "Voice gets louder", "Pacing", "Tunnel vision", "Going quiet and cold"] },
      { id: "first", title: "Step 2 — The very first one", instruction: "Which one shows up before the rest?", maxPicks: 1, options: ["Jaw tightens", "Hands clench", "Face gets hot", "Chest tight", "Going quiet and cold"] },
      { id: "where", title: "Step 3 — Where this hits me most", instruction: "Choose up to two.", maxPicks: 2, options: ["At home", "At work", "With family", "In traffic", "On the phone", "In line or crowds"] },
      { id: "move", title: "Step 4 — What I'll do at a 3", instruction: "Choose one.", maxPicks: 1, options: ["Check my jaw and shoulders", "Take one slow breath", "Say \"give me a second\"", "Step away for a minute"] },
    ],
  },

  explode: {
    exerciseId: "hand-brake",
    toolName: "Reaction Replay",
    toolIntro: "Replay one blow-up so next time goes differently.",
    welcome: [
      "Have you ever gone from calm to blowing up with nothing in between, or so it felt?",
      "The trigger hits and the reaction is already out of your mouth.",
      "There's actually a gap there, it's just short, and it can be widened.",
    ],
    checklist: [
      "I go from calm to furious with no warning.",
      "I say things before I've thought about them.",
      "I feel like there's no space between the trigger and my reaction.",
      "I regret what I said within minutes.",
      "I want more time to think before I react.",
      "Six seconds sounds impossible when I'm heated.",
    ],
    normalizing: "Feeling like there's no gap at all is common under stress. The gap is still there, it's just short and hard to notice yet. Training it is a real skill, not a personality fix.",
    whyHard: {
      heading: "Why the gap feels like it disappears",
      body: "Under stress, your body reacts before your thinking brain catches up. That gap between a trigger and your reaction can feel like zero, but it's there, usually a few seconds. Slow breathing is one of the fastest ways to bring your thinking brain back online.",
      bullets: ["Reacting before thinking", "Feeling like it happened instantly", "Regret right after", "Shaky hands or racing heart", "Wishing you had a second chance"],
    },
    reframe: {
      heading: "You can't stop the spark, but you can widen the gap",
      body: "Six slow breaths, in for four and out for six, is usually enough for the thinking part of your brain to come back online. Every time you use it, the gap gets a little wider.",
    },
    checkIn: [
      { id: "struggle", label: "How short does the gap feel between a trigger and your reaction?", left: "Wide open", right: "No gap at all", higherIsHarder: true },
      { id: "confidence", label: "How able are you to slow down before reacting?", left: "Not able", right: "Very able", higherIsHarder: false },
      { id: "support", label: "How much do you believe the gap can get wider with practice?", left: "Not much", right: "A lot", higherIsHarder: false },
    ],
    adelQuestions: [
      "What usually happens in your gap right now?",
      "What's the last thing that happened right before you reacted?",
    ],
    skillSteps: [
      {"id": "what", "title": "Step 1 — What happened", "instruction": "Pick one.", "maxPicks": 1, "options": ["Someone disrespected me", "Someone yelled at me", "I got blamed", "Someone cut me off", "Bad news", "Someone touched my stuff", "I felt cornered", "Someone talked down to me"], "feeds": "cue"},
      {"id": "thought", "title": "Step 2 — What I thought", "instruction": "Pick one.", "maxPicks": 1, "options": ["\"They're trying to play me.\"", "\"I'm not going to take this.\"", "\"They think I'm weak.\"", "\"This isn't fair.\"", "\"Here we go again.\"", "\"I have to stand up for myself.\""]},
      {"id": "body", "title": "Step 3 — What my body did", "instruction": "Choose up to 3.", "maxPicks": 3, "options": ["Face got hot", "Fists clenched", "Heart raced", "Voice got loud", "Chest got tight", "Shaking", "Couldn't think straight"]},
      {"id": "did", "title": "Step 4 — What I did", "instruction": "Pick one.", "maxPicks": 1, "options": ["Yelled", "Said something I regret", "Broke something", "Walked off", "Shut down", "Wanted to use", "Got physical", "Held it in"]},
      {"id": "instead", "title": "Step 5 — What I'll do instead next time", "instruction": "Choose up to 2.", "maxPicks": 2, "options": ["Use the Hand Brake", "Walk away", "Say \"give me a second\"", "Lower my voice", "Take a time-out", "Call someone", "Count to six", "Ask a question"], "feeds": "move"},
    ],
  },

  pause: {
    exerciseId: "time-out-done-right",
    toolName: "Pause Button",
    toolIntro: "Your plan for stepping away before it blows up. No using, and no driving while angry.",
    welcome: [
      "Have you ever wanted to hit pause on a moment before you said or did something you'd regret?",
      "\"Calm down\" never works in the moment. What works is having a plan already built.",
      "A pause button is just a sentence and a move, decided ahead of time.",
    ],
    checklist: [
      "I don't have anything specific to do when I'm heated.",
      "\"Calm down\" doesn't work for me.",
      "I need something I can actually say out loud.",
      "I forget my plan the moment I need it.",
      "I've reacted first and thought later, more than once.",
      "I want a move that works even when I'm mad.",
    ],
    normalizing: "Wanting a real plan instead of vague advice makes sense. A pause button, one line plus one action, works because you don't have to think of it in the moment. You just use it.",
    whyHard: {
      heading: "Why \"calm down\" doesn't work",
      body: "Telling yourself to calm down gives your brain nothing to actually do. A pause button gives you a specific sentence and a specific move, like \"give me ten minutes\" plus walking outside. Practiced ahead of time, it works even when you're hot.",
      bullets: ["Vague advice doesn't stick under stress", "Forgetting your plan in the moment", "Needing something concrete", "Wanting your mouth to have a job", "Needing a physical move, not just words"],
    },
    reframe: {
      heading: "A line plus a move",
      body: "Decide your line and your move now, while you're calm. \"Not worth it\" plus slowing down. \"Give me ten minutes\" plus walking outside. The words give your mouth something to do while your body moves you away.",
    },
    checkIn: [
      { id: "struggle", label: "How often do you wish you'd paused before reacting?", left: "Rarely", right: "Almost every time", higherIsHarder: true },
      { id: "confidence", label: "How confident are you that you could use a pause button?", left: "Not confident", right: "Very confident", higherIsHarder: false },
      { id: "support", label: "How ready do you feel to try one this week?", left: "Not ready", right: "Very ready", higherIsHarder: false },
    ],
    adelQuestions: [
      "What's your line going to be?",
      "What's the physical move that goes with it?",
    ],
    skillSteps: [
      {"id": "line", "title": "Step 1 — My time-out line", "instruction": "Pick one.", "maxPicks": 1, "options": ["\"I need 20 minutes. I'll be back.\"", "\"I'm getting too heated. Let's pause.\"", "\"I want to finish this, but not like this.\"", "\"Give me a minute. I'm coming back.\""]},
      {"id": "where", "title": "Step 2 — Where I go", "instruction": "Choose up to 2.", "maxPicks": 2, "options": ["Outside", "A walk around the block", "My room", "The porch", "A friend's place", "A meeting"], "shared": "safePlaces"},
      {"id": "do", "title": "Step 3 — What I do while I'm out", "instruction": "Choose up to 3.", "maxPicks": 3, "options": ["Walk", "Breathe", "Call someone", "Listen to music", "Drink water", "Pray", "Write it down", "Use the Hand Brake"], "feeds": "move"},
      {"id": "long", "title": "Step 4 — How long", "instruction": "Pick one.", "maxPicks": 1, "options": ["10 minutes", "20 minutes", "30 minutes", "An hour", "Until tomorrow"]},
      {"id": "back", "title": "Step 5 — How I come back", "instruction": "Pick one.", "maxPicks": 1, "options": ["\"I'm ready to talk now.\"", "\"Thanks for waiting.\"", "\"Can we try again?\"", "\"I'm calmer. Here's what I want to say.\"", "\"Can we start over?\""]},
    ],
  },

  "choose-response": {
    exerciseId: "two-timelines",
    toolName: "React or Respond",
    toolIntro: "Know what sets you off and the response you want instead.",
    welcome: [
      "Have you ever reacted fast, then spent the whole week fixing what you said?",
      "A reaction protects your pride for a moment. A response protects what you actually want.",
      "There's a simple question that can help you tell them apart.",
    ],
    checklist: [
      "I react first and think about it later.",
      "I've said things I had to walk back.",
      "In the moment, winning feels more important than the outcome.",
      "I lose sight of what I actually want when I'm upset.",
      "I want to protect my job, relationship, or freedom more than my pride.",
      "I need a quick question to ask myself in the moment.",
    ],
    normalizing: "Reacting fast is common, especially if reacting once kept you safe. Choosing a response instead is a skill you build with one question at a time, not something you either have or don't.",
    whyHard: {
      heading: "Reaction is fast. Response is chosen.",
      body: "A reaction protects your pride right now. A response protects the thing you actually want, like the job, the relationship, or your freedom. In the heat of the moment, pride usually shouts louder than your longer-term goals.",
      bullets: ["Reacting before thinking", "Protecting pride over goals", "Regret after the moment passes", "Losing sight of what matters", "Wanting a fast way to check yourself"],
    },
    reframe: {
      heading: "What do I want to be true in an hour?",
      body: "Asking \"what do I want to be true in an hour?\" is the fastest way to pick a response over a reaction. It pulls your focus off the moment and onto the outcome you actually care about.",
    },
    checkIn: [
      { id: "struggle", label: "How often do you react in a way you regret later?", left: "Rarely", right: "Very often", higherIsHarder: true },
      { id: "confidence", label: "How confident are you that you can pause and choose your response?", left: "Not confident", right: "Very confident", higherIsHarder: false },
      { id: "support", label: "How clear are you on what you actually want in these moments?", left: "Not clear", right: "Very clear", higherIsHarder: false },
    ],
    adelQuestions: [
      "What do you usually want to be true an hour after a conflict?",
      "Tell me about a time you chose a response instead of a reaction. What helped?",
    ],
    skillSteps: [
      {"id": "situations", "title": "Step 1 — Situations that set me off", "instruction": "Choose up to 3.", "maxPicks": 3, "options": ["Being disrespected in front of people", "Being blamed", "Someone lying to me", "Family drama", "Being told what to do", "Waiting in lines", "Texts that sting", "Someone bringing up my past"], "feeds": "cue"},
      {"id": "usual", "title": "Step 2 — My usual reaction", "instruction": "Choose up to 2.", "maxPicks": 2, "options": ["Yelling", "Cussing someone out", "Shutting down", "Leaving angry", "Sending a text I regret", "Getting physical", "Holding a grudge", "Wanting to use"]},
      {"id": "cost", "title": "Step 3 — What it costs me", "instruction": "Choose up to 3.", "maxPicks": 3, "options": ["Relationships", "My job", "Trouble with my PO", "My peace", "My recovery", "Respect", "Sleep", "My kids seeing it"]},
      {"id": "want", "title": "Step 4 — The response I want", "instruction": "Choose up to 2.", "maxPicks": 2, "options": ["Say one calm line", "Walk away", "Ask what they meant", "Wait before I answer", "Write the text, then wait", "Laugh it off", "Let it go", "Talk later"], "feeds": "move"},
    ],
  },

  "managing-conflict": {
    exerciseId: "reflect-first",
    toolName: "Fair Fight Rules",
    toolIntro: "Rules that keep disagreements from turning into fights.",
    welcome: [
      "Have you ever watched a small disagreement turn into a full-blown fight in minutes?",
      "Disagreement itself isn't the problem. What damages things is escalation.",
      "Raising your voice, bringing up the past, going for the weak spot, all of that adds fuel.",
    ],
    checklist: [
      "Disagreements turn into fights fast for me.",
      "I raise my voice to be heard.",
      "I bring up old stuff during a new argument.",
      "I go for the weak spot when I'm cornered.",
      "Fights end up about three things instead of one.",
      "I want to stay on one topic without it blowing up.",
    ],
    normalizing: "Escalation is a habit, not a character flaw, and habits can change. Staying on one topic, at one volume, is a skill you can actually practice.",
    whyHard: {
      heading: "Conflict isn't the problem, escalation is",
      body: "Disagreement is normal in every relationship that matters. What damages things is escalation: raising volume, bringing up the past, going for the weak spot. Once it escalates, you're often fighting about more than the original issue.",
      bullets: ["Raising your voice", "Bringing up old issues", "Going for the weak spot", "Fighting about several things at once", "Feeling like it spiraled fast"],
    },
    reframe: {
      heading: "One topic, one volume",
      body: "Lowering your voice forces the other person to lower theirs to hear you. Staying on the one thing you started with, instead of adding more, keeps a disagreement from turning into a war.",
    },
    checkIn: [
      { id: "struggle", label: "How fast do your disagreements escalate?", left: "They stay calm", right: "Very fast", higherIsHarder: true },
      { id: "confidence", label: "How able are you to stay on one topic during conflict?", left: "Not able", right: "Very able", higherIsHarder: false },
      { id: "support", label: "How hopeful are you that this can change?", left: "Not hopeful", right: "Very hopeful", higherIsHarder: false },
    ],
    adelQuestions: [
      "Who do you escalate with most, and what usually starts it?",
      "What does it sound like right before a disagreement turns into a fight?",
    ],
    skillSteps: [
      {"id": "rules", "title": "Step 1 — My rules", "instruction": "Choose up to 4.", "maxPicks": 4, "options": ["One topic at a time", "No bringing up the past", "No name-calling", "Take breaks", "No yelling", "No threats", "Listen before I answer", "No fighting in front of the kids"]},
      {"id": "signal", "title": "Step 2 — My time-out signal", "instruction": "Pick one.", "maxPicks": 1, "options": ["A hand signal", "\"Pause.\"", "\"Time-out.\"", "\"I need 20 minutes.\"", "A code word we pick together"]},
      {"id": "calm", "title": "Step 3 — Topics that need a calm time", "instruction": "Choose up to 3.", "maxPicks": 3, "options": ["Money", "The kids", "The past", "Trust", "My recovery", "Family", "Chores", "Jealousy"], "feeds": "cue"},
      {"id": "share", "title": "Step 4 — Who I'll share the rules with", "instruction": "Choose up to 2.", "maxPicks": 2, "options": ["My partner", "A family member", "My roommate", "My kids' other parent", "A friend", "My counselor"]},
    ],
  },

  "communicating-upset": {
    exerciseId: "fact-feeling-ask",
    toolName: "Say-It Script",
    toolIntro: "Your words, ready for a conversation you've been dreading.",
    welcome: [
      "Have you ever been upset and had something totally different come out of your mouth than what you meant?",
      "When emotions are high, words come out messy, sharp, or sideways.",
      "A simple shape can help you say what actually needs to be said.",
    ],
    checklist: [
      "What comes out isn't what I meant.",
      "I blame instead of asking for what I need.",
      "I get cut off before I say the real thing.",
      "I forget to say what I actually need.",
      "I talk in circles when I'm upset.",
      "I want a simple way to say hard things.",
    ],
    normalizing: "Getting tangled up when you're upset is common, not a communication failure. A simple three-part shape can carry you through even the hardest conversations.",
    whyHard: {
      heading: "Why upset communication comes out messy",
      body: "When you're upset, your brain is focused on the feeling, not the words. Without a shape to follow, it's easy to slide into blame or circle the same point without ever saying what you need.",
      bullets: ["Sliding into blame", "Circling the same point", "Forgetting the actual ask", "Getting cut off", "Feeling unheard afterward"],
    },
    reframe: {
      heading: "Facts, feeling, request",
      body: "Say what happened (just the facts), how it landed (one feeling word), and what you're asking for (one specific request). Then stop talking and listen. That last part is where most of the repair happens.",
    },
    checkIn: [
      { id: "struggle", label: "How hard is it to say what you actually need when you're upset?", left: "Easy", right: "Very hard", higherIsHarder: true },
      { id: "confidence", label: "How confident are you using the facts, feeling, request shape?", left: "Not confident", right: "Very confident", higherIsHarder: false },
      { id: "support", label: "How willing are you to try it with someone this week?", left: "Not willing", right: "Very willing", higherIsHarder: false },
    ],
    adelQuestions: [
      "Who do you need to say three sentences to?",
      "What gets in the way of you saying what you actually need?",
    ],
    skillSteps: [
      {"id": "who", "title": "Step 1 — Who", "instruction": "Pick one.", "maxPicks": 1, "options": ["Partner", "Mom", "Dad", "Brother or sister", "Roommate", "Friend", "Boss or coworker", "My kids' other parent"]},
      {"id": "fact", "title": "Step 2 — The fact", "instruction": "Pick one.", "maxPicks": 1, "options": ["When plans get canceled", "When I'm interrupted", "When my things get used", "When I'm not told about changes", "When my past gets brought up", "When you don't call back", "When I get blamed"]},
      {"id": "feeling", "title": "Step 3 — My feeling", "instruction": "Pick one.", "maxPicks": 1, "options": ["Frustrated", "Hurt", "Worried", "Disrespected", "Overwhelmed", "Left out", "Angry", "Sad"]},
      {"id": "ask", "title": "Step 4 — My ask", "instruction": "Pick one.", "maxPicks": 1, "options": ["Please ask me first", "Let me finish talking", "Tell me ahead of time", "Call me back when you can", "Talk to me, not about me", "Give me a little space"]},
      {"id": "when", "title": "Step 5 — When and where I'll say it", "instruction": "Pick one.", "maxPicks": 1, "options": ["Today, when we're both calm", "In person", "By text", "On the phone", "At a family meeting", "With my counselor there"]},
    ],
  },

  repair: {
    exerciseId: "three-part-repair",
    toolName: "Repair Kit",
    toolIntro: "Plan your repair so it lands.",
    welcome: [
      "Have you ever said something you regret and had no idea how to come back from it?",
      "Every relationship has ruptures. What matters more is how fast you repair them.",
      "A real repair names what happened, without excuses attached.",
    ],
    checklist: [
      "I've said something I regret and didn't know how to fix it.",
      "I avoid the person instead of repairing it.",
      "My apologies come with a \"but\" attached.",
      "I wait too long to make things right.",
      "I feel stuck between pride and wanting to repair.",
      "I want a repair that actually lands.",
    ],
    normalizing: "Feeling stuck after you've hurt someone is common, and it doesn't mean the relationship is broken. A real, no-excuses repair usually matters more to people than the rupture ever did.",
    whyHard: {
      heading: "Why repair matters more than never messing up",
      body: "Every relationship has ruptures. What separates strong relationships isn't fewer fights, it's faster repair. A real repair names what you did, doesn't explain it away, and says what you'll do differently. No \"but\".",
      bullets: ["Avoiding the person instead of repairing", "Apologies that come with an excuse", "Waiting too long to say anything", "Feeling shame instead of taking action", "Wanting to fix it but not knowing how"],
    },
    reframe: {
      heading: "Named, owned, no excuse",
      body: "\"I yelled and that wasn't okay. It wasn't about you. I'm working on it.\" That's a full repair: it names the action, owns it, and offers no excuse. Perfect isn't available. Repair is the skill.",
    },
    checkIn: [
      { id: "struggle", label: "How often do you avoid repairing something you regret?", left: "Rarely", right: "Very often", higherIsHarder: true },
      { id: "confidence", label: "How confident are you giving a repair without an excuse attached?", left: "Not confident", right: "Very confident", higherIsHarder: false },
      { id: "support", label: "How safe would it feel to make that repair today?", left: "Not safe", right: "Safe", higherIsHarder: false },
    ],
    adelQuestions: [
      "Is there a repair you've been putting off?",
      "What's stopped you from saying it so far?",
    ],
    skillSteps: [
      {"id": "who", "title": "Step 1 — Who", "instruction": "Pick one.", "maxPicks": 1, "options": ["Mom", "Dad", "Partner", "My kids", "Brother or sister", "A friend", "Someone at work", "My sponsor"]},
      {"id": "did", "title": "Step 2 — What I did", "instruction": "Pick one.", "maxPicks": 1, "options": ["Yelled", "Said something hurtful", "Didn't show up", "Lied", "Broke a promise", "Ignored them", "Blamed them", "Embarrassed them"]},
      {"id": "affected", "title": "Step 3 — How it affected them", "instruction": "Choose up to 2.", "maxPicks": 2, "options": ["Hurt their feelings", "Scared them", "Made them feel unimportant", "Broke their trust", "Made them worry", "Embarrassed them", "Not sure, I'll ask"]},
      {"id": "words", "title": "Step 4 — My repair words", "instruction": "Pick one.", "maxPicks": 1, "options": ["\"I'm sorry I ___. That wasn't okay. Next time I'll ___.\"", "\"I was wrong to ___. I want to make it right.\"", "\"I owe you an apology for ___.\""]},
      {"id": "when", "title": "Step 5 — When I'll say it", "instruction": "Pick one.", "maxPicks": 1, "options": ["Today", "Tomorrow", "This week", "Next time I see them", "In a letter", "With my counselor's help"]},
    ],
  },

  "emotional-strength": {
    exerciseId: "please-check",
    toolName: "Fuel Gauge",
    toolIntro: "A quick daily check on what you're running on.",
    welcome: [
      "Have you ever noticed a small thing knocking you sideways way more than it should?",
      "Emotional strength isn't just attitude. It's capacity, and capacity runs on sleep, food, and connection.",
      "Most \"overreactions\" are really a body running on empty.",
    ],
    checklist: [
      "Small things knock me over more than they should.",
      "I'm running on little sleep.",
      "I skip meals more than I'd like.",
      "I feel disconnected from people.",
      "I judge myself for reacting so strongly to small stuff.",
      "I don't check in with my own tank before the day starts.",
    ],
    normalizing: "If small things feel huge lately, that's often your body's tank running low, not a character issue. Filling one tank can change how the whole day lands.",
    whyHard: {
      heading: "Why capacity comes first",
      body: "Emotional strength isn't attitude, it's capacity, and capacity runs on sleep, food, movement, and connection. Most overreactions are a body running on empty. Fill the tank and the same events stop landing as hard.",
      bullets: ["Running on little sleep", "Skipping meals", "Feeling disconnected from people", "Small things feeling huge", "Blaming yourself instead of your tank"],
    },
    reframe: {
      heading: "Fill the tank before you judge the reaction",
      body: "You don't have a temper problem on a full tank. Before deciding something's wrong with you, check sleep, food, and connection first. Often, filling one tank changes the whole day.",
    },
    checkIn: [
      { id: "struggle", label: "How empty does your tank feel today?", left: "Full", right: "Empty", higherIsHarder: true },
      { id: "confidence", label: "How able do you feel to fill one tank today?", left: "Not able", right: "Very able", higherIsHarder: false },
      { id: "support", label: "How connected do you feel to people right now?", left: "Disconnected", right: "Connected", higherIsHarder: false },
    ],
    adelQuestions: [
      "Which tank is easiest to top off today: sleep, food, or connection?",
      "What does a full-tank day usually look like for you?",
    ],
    skillSteps: [
      {"id": "sleep", "title": "Step 1 — Sleep last night", "instruction": "Pick one.", "maxPicks": 1, "options": ["Good", "Okay", "Rough", "Barely slept"]},
      {"id": "food", "title": "Step 2 — Food today", "instruction": "Pick one.", "maxPicks": 1, "options": ["Real meals", "Snacks only", "Skipped meals", "Haven't eaten"]},
      {"id": "move", "title": "Step 3 — Movement today", "instruction": "Pick one.", "maxPicks": 1, "options": ["Got moving", "A little", "None yet"]},
      {"id": "subs", "title": "Step 4 — Meds and substances", "instruction": "Choose up to 2.", "maxPicks": 2, "options": ["Took my meds", "Missed my meds", "No alcohol or drugs", "Had a drink or used", "Too much caffeine"]},
      {"id": "refuel", "title": "Step 5 — My refuel move", "instruction": "Pick one.", "maxPicks": 1, "options": ["Eat a real meal", "Take a nap", "Drink water", "Take my meds", "Go for a walk", "Go to bed early", "Call someone", "Skip the caffeine"], "feeds": "move"},
    ],
  },

  "grief-loss": {
    exerciseId: "a-place-for-the-loss",
    toolName: "Carrying the Loss",
    toolIntro: "A way to carry what you've lost, and help for when it's too heavy.",
    welcome: [
      "While you were away, life kept moving. Maybe someone you loved died, and you couldn't be there.",
      "Maybe it's years you can't get back, or a kid who grew up without you.",
      "Those are real losses, and they deserve to be grieved.",
    ],
    checklist: [
      "Someone important to me died while I was away.",
      "I couldn't go to a funeral or say goodbye.",
      "I grieve the years I lost.",
      "I push the sadness down because it feels too big.",
      "Grief sometimes turns into anger or wanting to use.",
      "I don't have anyone I can talk to about it.",
    ],
    normalizing: "Grief after time away is common, and it often gets missed. Losses that happen while you're inside can stay frozen until you come home. Feeling it now doesn't mean you're falling apart. It means you're finally able to.",
    whyHard: {
      heading: "Why grief hits hard after release",
      body: "Inside, there was often no time, privacy, or safety to grieve. Coming home can bring it all back at once: empty chairs, changed families, missed goodbyes. Grief can show up as sadness, anger, numbness, or cravings, and it comes in waves, not in a straight line.",
      bullets: ["Missed goodbyes and funerals", "Years and milestones you can't get back", "Grief showing up as anger or numbness", "Cravings tied to loss", "No one to talk to about it"],
    },
    reframe: {
      heading: "Give the loss a place",
      body: "You don't have to get over it. You can give it a place: say their name, visit a grave or a favorite spot, write them a letter, or tell someone what you miss. Grief gets lighter when it's shared. If it stays heavy for weeks, a counselor can help.",
    },
    checkIn: [
      { id: "struggle", label: "How heavy does grief feel today?", left: "Light", right: "Very heavy", higherIsHarder: true },
      { id: "confidence", label: "How able are you to let yourself feel it, a little at a time?", left: "Not able", right: "Very able", higherIsHarder: false },
      { id: "support", label: "How many people could you talk to about this loss?", left: "No one", right: "A few", higherIsHarder: false },
    ],
    adelQuestions: [
      "Who or what are you missing most right now?",
      "Has grief ever shown up for you as anger or a craving?",
    ],
    skillSteps: [
      {"id": "lost", "title": "Step 1 — Who or what I lost", "instruction": "Choose up to 3.", "maxPicks": 3, "options": ["A person who died", "Years of my life", "Time with my kids", "My freedom", "A relationship", "My health", "A home", "Who I used to be"]},
      {"id": "shows", "title": "Step 2 — How grief shows up for me", "instruction": "Choose up to 3.", "maxPicks": 3, "options": ["Sadness", "Anger", "Numbness", "Can't sleep", "Wanting to use", "Pulling away", "Crying out of nowhere", "Guilt"], "feeds": "cue"},
      {"id": "honor", "title": "Step 3 — A way to honor it", "instruction": "Choose up to 2.", "maxPicks": 2, "options": ["Say their name", "Write them a letter", "Visit a place", "Light a candle", "Look at photos", "Do something they loved", "Pray", "Tell their story"], "feeds": "move"},
      {"id": "who", "title": "Step 4 — Who I can share it with", "instruction": "Choose up to 2.", "maxPicks": 2, "options": ["Sponsor", "Peer specialist", "Counselor", "A family member", "A friend", "Someone who knew them", "A pastor or faith leader"], "shared": "supportPeople"},
      {"id": "heavy", "title": "Step 5 — When it's too heavy", "instruction": "Pick one.", "maxPicks": 1, "options": ["Book a teletherapy visit", "Call my counselor", "Go to a grief group", "Tell my peer specialist", "Open my safety plan", "Call or text 988"], "crisisLink": true},
    ],
  },
};
