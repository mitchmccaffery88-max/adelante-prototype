import type { TopicContent } from "./types";

// Train My Mind — topic-specific content (batch 2).
export const TRAIN_MIND: Record<string, TopicContent> = {
  "thoughts-wont-stop": {
    exerciseId: "solving-or-spinning",
    toolName: "Loop Breaker",
    toolIntro: "Your plan for when the same thoughts keep circling.",
    welcome: [
      "Have you ever replayed the same moment in your head so many times it started to feel like a movie stuck on repeat?",
      "You go over what happened, what you should have said, what it means, and then you start again from the top.",
      "It can feel like you're solving something, but the loop just keeps running.",
    ],
    checklist: [
      "I replay the same conversation or moment over and over.",
      "I can't seem to land on an answer, even after thinking about it for hours.",
      "The loop gets louder the more I try to think my way out.",
      "I lose time to a thought I can't put down.",
      "I feel wound up after a loop, even if nothing changed.",
      "I use my phone or something else to try to drown it out.",
    ],
    normalizing: "If this sounds familiar, your brain isn't broken. Repetition makes a thought feel important, so it keeps circling back. The way out isn't inside your head — it's in what you do next.",
    whyHard: {
      heading: "Why the loop feels impossible to stop",
      body: "Your brain treats a repeated thought as urgent business, so it keeps handing it back to you. Trying to think your way out just gives it more attention, which feeds the loop instead of closing it.",
      bullets: ["The same scene playing again and again", "Feeling like you're close to an answer that never comes", "Losing track of time", "A tight or buzzing feeling in your body", "Reaching for a screen to shut it up"],
    },
    reframe: {
      heading: "Notice it, don't win it",
      body: "You don't have to argue the thought down or finish the loop. Naming it — \"that's a loop\" — and moving your hands or your feet for a couple of minutes gives your attention somewhere else to go.",
    },
    checkIn: [
      { id: "struggle", label: "How much has a thought been looping today?", left: "Barely", right: "Nonstop", higherIsHarder: true },
      { id: "confidence", label: "How able do you feel to step out of a loop once you notice it?", left: "Not able", right: "Very able", higherIsHarder: false },
      { id: "support", label: "How hopeful are you that this thought will lose its grip with practice?", left: "Not hopeful", right: "Very hopeful", higherIsHarder: false },
    ],
    adelQuestions: [
      "What does the loop usually start with?",
      "What's one thing you could do with your hands the next time it fires up?",
    ],
    skillSteps: [
      {"id": "loops", "title": "Step 1 — My usual loops", "instruction": "Choose up to 3.", "maxPicks": 3, "options": ["Past mistakes", "What people think of me", "Money", "My case", "Family", "Things I said", "What could go wrong", "Old memories"], "feeds": "cue"},
      {"id": "when", "title": "Step 2 — When they hit", "instruction": "Choose up to 2.", "maxPicks": 2, "options": ["Lying in bed", "Late at night", "After a call or visit", "When I'm alone", "In the morning", "When I'm bored", "After seeing old friends"]},
      {"id": "switch", "title": "Step 3 — My switch activities", "instruction": "Choose up to 3.", "maxPicks": 3, "options": ["Dishes or cleaning", "Cards or a puzzle", "Cooking", "Fixing something", "Drawing", "Folding laundry", "A game on my phone", "Working out"], "shared": "copingTools", "feeds": "move"},
      {"id": "line", "title": "Step 4 — The line I'll use", "instruction": "Pick one.", "maxPicks": 1, "options": ["\"If I'm spinning, I switch.\"", "\"That's a loop.\"", "\"I've thought about this enough for today.\"", "\"I'll solve it tomorrow at a set time.\"", "\"Hands busy, head quiet.\""]},
    ],
  },

  "fact-story": {
    exerciseId: "camera-test",
    toolName: "Fact Check",
    toolIntro: "Sort what happened from the story your mind added.",
    welcome: [
      "Have you ever been sure of something that turned out to be a story your mind made up?",
      "Someone doesn't text back and suddenly you're certain they're done with you.",
      "A thought can arrive feeling like proof, even when it's really just a guess.",
    ],
    checklist: [
      "I treat my thoughts like they're automatically true.",
      "I fill in the blanks with the worst explanation.",
      "I've been sure of something that turned out wrong.",
      "I struggle to tell what actually happened from what I assumed happened.",
      "My mood shifts fast based on a guess, not a fact.",
      "I rarely check a story before I believe it.",
    ],
    normalizing: "This happens to almost everyone. Your brain fills gaps fast so you can react quickly. Slowing down enough to separate fact from story is a skill, and it gets easier with practice.",
    whyHard: {
      heading: "Why a guess can feel like the truth",
      body: "Your brain doesn't like blanks, so it fills them in fast, using old fears and old experiences. That filled-in version arrives feeling certain, even though only part of it is actually fact.",
      bullets: ["Jumping straight to the worst meaning", "Feeling certain about something you can't confirm", "Mood dropping over a guess", "Arguing with someone in your head who isn't there", "Rarely asking \"is this proven, or assumed?\""],
    },
    reframe: {
      heading: "Split it in two",
      body: "Write or say the bare fact — what a camera would have caught. Then say the story you built on top of it. You can act on the fact today. The story needs more information before it's worth trusting.",
    },
    checkIn: [
      { id: "struggle", label: "How hard is it right now to tell fact from story?", left: "Easy", right: "Very hard", higherIsHarder: true },
      { id: "confidence", label: "How confident are you that you can catch a story as it forms?", left: "Not confident", right: "Very confident", higherIsHarder: false },
      { id: "support", label: "How hopeful are you that this gets easier with practice?", left: "Not hopeful", right: "Very hopeful", higherIsHarder: false },
    ],
    adelQuestions: [
      "What's a story your mind has told you this week?",
      "What's the actual fact underneath that story?",
    ],
    skillSteps: [
      {"id": "what", "title": "Step 1 — What happened", "instruction": "Just what a camera would see.", "maxPicks": 1, "options": ["Someone didn't text back", "I got a short reply", "Someone looked at me a certain way", "I wasn't invited", "I got bad news", "I made a mistake", "Someone criticized me", "Plans got canceled"]},
      {"id": "thought", "title": "Step 2 — The thought I had", "instruction": "Pick one.", "maxPicks": 1, "options": ["\"They're done with me.\"", "\"I'm a failure.\"", "\"Everyone's against me.\"", "\"I'll never get this right.\"", "\"They think I'm going to relapse.\"", "\"Something bad is going to happen.\""]},
      {"id": "for", "title": "Step 3 — Facts that support it", "instruction": "Choose up to 2.", "maxPicks": 2, "options": ["Something like this happened before", "They said something unkind", "Nothing yet, it's just a feeling", "They've been distant lately", "I really did make a mistake", "Not sure"]},
      {"id": "against", "title": "Step 4 — Facts that don't", "instruction": "Choose up to 2.", "maxPicks": 2, "options": ["They've been there for me before", "They might be busy", "I've done well at this before", "Other people still care about me", "There could be another reason", "I'm still showing up"]},
      {"id": "fair", "title": "Step 5 — A fairer thought", "instruction": "Pick one.", "maxPicks": 1, "options": ["\"I don't know yet.\"", "\"One thing went wrong, not everything.\"", "\"I can ask instead of guessing.\"", "\"I made a mistake, and I can fix it.\"", "\"This is hard, and I'm handling it.\"", "\"They might just be busy.\""]},
    ],
  },

  "thinking-traps": {
    exerciseId: "name-that-trap",
    toolName: "Trap Spotter",
    toolIntro: "Know your traps and have a comeback ready.",
    welcome: [
      "Have you ever caught your mind jumping straight to the worst possible outcome before anything even happened?",
      "One late text becomes \"they're leaving,\" one mistake becomes \"I always mess up.\"",
      "These jumps have names, and once you can name them, they start to lose their speed.",
    ],
    checklist: [
      "I think in all-or-nothing terms — perfect or a total failure.",
      "I assume I know what people are thinking about me.",
      "I picture the worst-case outcome first.",
      "I tell myself I \"should\" be further along.",
      "I call myself names when I mess up.",
      "I only notice what went wrong, even on a good day.",
    ],
    normalizing: "These patterns aren't a character flaw. They're shortcuts your brain built for speed, often during a time when speed mattered more than accuracy. You can slow them down on purpose.",
    whyHard: {
      heading: "Why these traps feel so automatic",
      body: "A thinking trap fires before you notice it, because it's a shortcut your brain has used many times. Slowing down enough to name the trap is what breaks its speed and gives you a real choice.",
      bullets: ["Reacting before you've thought it through", "Assuming instead of asking", "One bad moment coloring the whole day", "Harsh self-talk after a mistake", "Missing the parts that went okay"],
    },
    reframe: {
      heading: "Name it to slow it down",
      body: "You don't have to fight a thinking trap head-on. Just naming it — \"that's all-or-nothing thinking\" — creates a half-second of space. In that space, you get to pick a more accurate thought.",
    },
    checkIn: [
      { id: "struggle", label: "How often are thinking traps showing up today?", left: "Rarely", right: "Constantly", higherIsHarder: true },
      { id: "confidence", label: "How confident are you that you can catch one when it fires?", left: "Not confident", right: "Very confident", higherIsHarder: false },
      { id: "support", label: "How hopeful are you that naming these will help?", left: "Not hopeful", right: "Very hopeful", higherIsHarder: false },
    ],
    adelQuestions: [
      "Which thinking trap shows up the most for you?",
      "What's a more accurate thought you could try in its place?",
    ],
    skillSteps: [
      {"id": "traps", "title": "Step 1 — My top three traps", "instruction": "Choose up to 3.", "maxPicks": 3, "options": ["Always/Never", "Mind Reading", "Crystal Ball", "Name-Calling", "Should-ing", "All or nothing", "Blowing it out of proportion", "Blaming myself for everything"]},
      {"id": "sound", "title": "Step 2 — How they sound in my head", "instruction": "Choose up to 3.", "maxPicks": 3, "options": ["\"I always mess up.\"", "\"They think I'm a loser.\"", "\"This is going to go bad.\"", "\"I'm an idiot.\"", "\"I should be further along.\"", "\"One slip and it's all over.\"", "\"It's all my fault.\""]},
      {"id": "when", "title": "Step 3 — When they show up most", "instruction": "Choose up to 2.", "maxPicks": 2, "options": ["After a mistake", "Around family", "At appointments", "When I'm tired", "When I'm alone", "On social media", "When I'm stressed", "Around my PO or court"], "feeds": "cue"},
      {"id": "comeback", "title": "Step 4 — My comeback lines", "instruction": "Choose up to 2.", "maxPicks": 2, "options": ["\"Name the trap, lose the grip.\"", "\"That's a thought, not a fact.\"", "\"What would I tell a friend?\"", "\"What's the evidence?\"", "\"One bad moment, not a bad life.\"", "\"I'm learning. That's allowed.\""]},
    ],
  },

  "inner-voice": {
    exerciseId: "best-friend-test",
    toolName: "Coach's Corner",
    toolIntro: "Swap the critic's lines for a coach's.",
    welcome: [
      "Have you ever noticed the voice in your head is harsher to you than any person you know?",
      "It calls you names for things a friend would barely mention.",
      "That voice may have come from somewhere real, but it doesn't have to keep running the show.",
    ],
    checklist: [
      "I call myself names when I mess up.",
      "I talk to myself in a way I'd never talk to someone I love.",
      "My inner voice focuses on what's wrong with me.",
      "I expect harshness to keep me in line.",
      "I've noticed the voice sounds like someone from my past.",
      "Being hard on myself hasn't actually changed my behavior.",
    ],
    normalizing: "A harsh inner voice usually came from somewhere real. It doesn't mean it's right, and it doesn't mean it's the only way to talk to yourself. Honesty and kindness can live in the same sentence.",
    whyHard: {
      heading: "Why harshness feels necessary",
      body: "Many people learned that being hard on themselves was the only way to stay in line. But harshness usually leads to avoidance and shame, not real change. Change comes more often from being told the truth kindly.",
      bullets: ["Calling yourself names after a mistake", "Expecting the worst from yourself", "Avoiding things because you're afraid of failing again", "Believing kindness would make you soft", "Hearing an old voice from your past in your own head"],
    },
    reframe: {
      heading: "Honest, not harsh",
      body: "Try saying what's true the way you'd say it to someone you care about. \"I messed that up and I can fix part of it\" holds you accountable without tearing you down.",
    },
    checkIn: [
      { id: "struggle", label: "How harsh has your inner voice been today?", left: "Gentle", right: "Very harsh", higherIsHarder: true },
      { id: "confidence", label: "How able are you to catch a harsh thought and soften it?", left: "Not able", right: "Very able", higherIsHarder: false },
      { id: "support", label: "How hopeful are you that this voice can change?", left: "Not hopeful", right: "Very hopeful", higherIsHarder: false },
    ],
    adelQuestions: [
      "What does your inner voice usually say after a mistake?",
      "What would you say instead to someone you cared about in your exact situation?",
    ],
    skillSteps: [
      {"id": "harsh", "title": "Step 1 — Harsh things I tell myself", "instruction": "Choose up to 3.", "maxPicks": 3, "options": ["\"I'm useless.\"", "\"I'm worthless.\"", "\"I ruin everything.\"", "\"I'll never change.\"", "\"Nobody wants me around.\"", "\"I'm stupid.\"", "\"I deserve this.\"", "\"I'm a screw-up.\""]},
      {"id": "source", "title": "Step 2 — Where that voice came from (optional)", "instruction": "Skip this one if you want.", "maxPicks": 1, "options": ["A parent", "Someone who hurt me", "Years inside", "School", "The streets", "My own fear", "I'm not sure", "I'd rather not say"]},
      {"id": "coach", "title": "Step 3 — The coach version", "instruction": "Choose up to 3.", "maxPicks": 3, "options": ["\"I messed up, and I can fix it.\"", "\"I'm learning.\"", "\"I'm doing hard things.\"", "\"I'm more than my worst day.\"", "\"I'm still here, and that counts.\"", "\"Progress, not perfect.\"", "\"A friend would tell me I'm doing okay.\""]},
      {"id": "keep", "title": "Step 4 — The one line I'll keep handy", "instruction": "Pick one.", "maxPicks": 1, "options": ["\"I messed up, and I can fix it.\"", "\"I'm learning.\"", "\"I'm doing hard things.\"", "\"I'm more than my worst day.\"", "\"I'm still here, and that counts.\"", "\"Progress, not perfect.\"", "\"A friend would tell me I'm doing okay.\""], "optionsFrom": "coach"},
      {"id": "who", "title": "Step 5 — Who reminds me what's true", "instruction": "Choose up to 2.", "maxPicks": 2, "options": ["Sponsor", "Peer specialist", "Counselor", "A family member", "A friend in recovery", "Someone from church"], "shared": "supportPeople", "crisisLink": true},
    ],
  },

  "worry-cycle": {
    exerciseId: "worst-best-likely",
    toolName: "Odds Check",
    toolIntro: "Put a big worry back to its real size.",
    welcome: [
      "Have you ever spent a whole evening worrying about something and ended up no closer to an answer?",
      "Worry can feel like preparing for the worst, but mostly it just keeps you up.",
      "There's a way to hear a worry out without letting it run your whole day.",
    ],
    checklist: [
      "I worry about the same things over and over.",
      "Worrying keeps me from falling asleep.",
      "I feel like worrying keeps me prepared, even when it doesn't change anything.",
      "My worries don't have a stopping point.",
      "I worry about things I can't do anything about today.",
      "I feel tired from thinking so much.",
    ],
    normalizing: "Worry expands to fill however much time you give it. That doesn't mean something is wrong with you. It means worry needs a container, not a ban.",
    whyHard: {
      heading: "Why worry keeps expanding",
      body: "Worry never gets a real ending, so it just keeps running. Your brain treats it like unfinished work. Giving it a set time and a real stopping point is what finally lets it close.",
      bullets: ["The same worry returning again and again", "Trouble falling or staying asleep", "Feeling like stopping would mean being unprepared", "No clear end to the worrying", "Worrying about things outside your control"],
    },
    reframe: {
      heading: "Give worry a window",
      body: "Instead of trying to stop worrying altogether, set a short window — 10 minutes, same time each day. Outside that window, tell the worry, \"not now, I'll look at you later,\" and mean it.",
    },
    checkIn: [
      { id: "struggle", label: "How much of your day is worry taking up?", left: "Barely any", right: "Most of it", higherIsHarder: true },
      { id: "confidence", label: "How able do you feel to set a worry aside until later?", left: "Not able", right: "Very able", higherIsHarder: false },
      { id: "support", label: "How hopeful are you that a worry window could help?", left: "Not hopeful", right: "Very hopeful", higherIsHarder: false },
    ],
    adelQuestions: [
      "What worry has been the loudest for you lately?",
      "What time of day could work as your worry window?",
    ],
    skillSteps: [
      {"id": "worry", "title": "Step 1 — The worry", "instruction": "Pick one.", "maxPicks": 1, "options": ["Getting in trouble with my PO or court", "Losing my housing", "Money running out", "Relapsing", "My family giving up on me", "My health", "Losing my job", "Something happening to someone I love"]},
      {"id": "odds", "title": "Step 2 — How likely is the worst case?", "instruction": "Pick one.", "maxPicks": 1, "options": ["Very unlikely", "Unlikely", "Could go either way", "Likely", "I don't know"]},
      {"id": "likely", "title": "Step 3 — Most likely", "instruction": "Pick one.", "maxPicks": 1, "options": ["Nothing big happens", "It's a hassle, but I handle it", "I need to make a call", "I need help from someone", "I'll find out soon and deal with it then", "Not sure"]},
      {"id": "handle", "title": "Step 4 — If the worst happened, I'd...", "instruction": "Choose up to 3.", "maxPicks": 3, "options": ["Call my case manager", "Call legal aid", "Call 211", "Talk to my peer specialist", "Go to a meeting", "Lean on family", "Make a plan with my counselor", "Take it one step at a time"], "feeds": "move"},
      {"id": "who", "title": "Step 5 — Who I'd call first", "instruction": "Pick one.", "maxPicks": 1, "options": ["Case manager", "Peer specialist", "Sponsor", "Counselor", "A family member", "A friend", "Legal aid"], "shared": "supportPeople"},
    ],
  },

  "bigger-picture": {
    exerciseId: "three-other-reasons",
    toolName: "Wide Angle",
    toolIntro: "Zoom out on something that's bugging you.",
    welcome: [
      "Have you ever had one bad moment ruin an entire day that had good parts in it too?",
      "A hard conversation happens at 9 a.m. and by 9 p.m. it feels like nothing else even occurred.",
      "Under stress, your attention narrows to the one hard thing and everything else disappears.",
    ],
    checklist: [
      "One bad thing colors my whole day.",
      "I struggle to notice anything good once something goes wrong.",
      "I forget the parts of the day that went fine.",
      "My mood gets stuck on the worst moment.",
      "I rarely look back and count what actually went okay.",
      "I feel like the bad part is the only part that counts.",
    ],
    normalizing: "This is a normal response to stress, not a flaw in how you think. Your attention narrows to protect you from threat. Widening it back out on purpose is a skill you can build.",
    whyHard: {
      heading: "Why the bad part takes over",
      body: "Under stress, your brain narrows in on the threat, because that used to keep you safe. That narrowing is useful in real danger, but it makes ordinary days feel worse than they were.",
      bullets: ["A hard moment overshadowing the rest of the day", "Trouble remembering anything good happened", "Mood staying low long after the moment passed", "Feeling like the whole day was a loss", "Rarely zooming back out on purpose"],
    },
    reframe: {
      heading: "What else is also true?",
      body: "Zooming out doesn't erase the hard thing. It puts it next to everything else that also happened — the meal you ate, the person who was decent to you, the fact that you're still here.",
    },
    checkIn: [
      { id: "struggle", label: "How much is one hard moment coloring your whole day right now?", left: "Not at all", right: "Completely", higherIsHarder: true },
      { id: "confidence", label: "How able are you to name something else that also went okay today?", left: "Not able", right: "Very able", higherIsHarder: false },
      { id: "support", label: "How hopeful are you that this gets easier with practice?", left: "Not hopeful", right: "Very hopeful", higherIsHarder: false },
    ],
    adelQuestions: [
      "What's the hard thing that's taking up most of your attention today?",
      "What's one other thing that's also true about today, even something small?",
    ],
    skillSteps: [
      {"id": "situation", "title": "Step 1 — The situation bugging me", "instruction": "Pick one.", "maxPicks": 1, "options": ["Someone didn't text back", "A bad day at work", "A fight with family", "A mistake I made", "Bad news", "Someone was rude", "Plans fell through", "A setback in my recovery"]},
      {"id": "first", "title": "Step 2 — My first take", "instruction": "Pick one.", "maxPicks": 1, "options": ["\"They don't care.\"", "\"I'm a failure.\"", "\"Everything's going wrong.\"", "\"It's all my fault.\"", "\"Nothing ever works out.\"", "\"People are against me.\""]},
      {"id": "other", "title": "Step 3 — Other possible explanations", "instruction": "Choose up to 3.", "maxPicks": 3, "options": ["They're busy", "They're dealing with their own stuff", "It was bad timing", "It's not about me", "It's one bad day, not my whole life", "I'm tired and seeing it darker", "There's something I don't know yet", "It's fixable"]},
      {"id": "true", "title": "Step 4 — What else is true", "instruction": "Choose up to 3.", "maxPicks": 3, "options": ["I've handled worse", "Some things went okay today", "People still care about me", "I'm still sober", "I'm showing up", "I'm learning", "I have a plan", "Tomorrow is a new day"]},
      {"id": "forward", "title": "Step 5 — The view that helps me move forward", "instruction": "Pick one.", "maxPicks": 1, "options": ["They're busy", "They're dealing with their own stuff", "It was bad timing", "It's not about me", "It's one bad day, not my whole life", "I'm tired and seeing it darker", "There's something I don't know yet", "It's fixable"], "optionsFrom": "other"},
    ],
  },

  "confidence-decisions": {
    exerciseId: "ten-ten-ten",
    toolName: "Decision Playbook",
    toolIntro: "Make a choice you can stand behind.",
    welcome: [
      "Have you ever gone back and forth on a choice so many times that you ended up deciding nothing at all?",
      "Second-guessing can feel like being careful, but it often just leaves you stuck.",
      "Confidence in decisions doesn't come from always being right. It comes from having a way to decide.",
    ],
    checklist: [
      "I go back and forth until I run out of time to decide.",
      "I avoid deciding because I'm afraid of getting it wrong.",
      "I ask everyone I know before I trust my own choice.",
      "I replay decisions after I've already made them.",
      "Small decisions feel just as heavy as big ones.",
      "I freeze when I have more than one option.",
    ],
    normalizing: "Struggling to decide doesn't mean you're indecisive as a person. It usually means you don't yet have a process you trust. A repeatable process can fix that more than confidence alone.",
    whyHard: {
      heading: "Why deciding feels so heavy",
      body: "Without a clear process, every decision feels like it needs total certainty before you can move. That certainty rarely comes, so you stay stuck weighing options that don't resolve.",
      bullets: ["Weighing the same choice for a long time", "Avoiding decisions altogether", "Needing everyone else's opinion first", "Regret or doubt after deciding", "Feeling like every choice is permanent"],
    },
    reframe: {
      heading: "A process beats a feeling",
      body: "Name the actual choice, list what matters most, pick between the two real options, and set a date to check back in. Most decisions are more reversible than they feel in the moment.",
    },
    checkIn: [
      { id: "struggle", label: "How stuck do you feel on a decision right now?", left: "Not stuck", right: "Completely stuck", higherIsHarder: true },
      { id: "confidence", label: "How confident do you feel using a step-by-step process to decide?", left: "Not confident", right: "Very confident", higherIsHarder: false },
      { id: "support", label: "How hopeful are you that this gets easier with practice?", left: "Not hopeful", right: "Very hopeful", higherIsHarder: false },
    ],
    adelQuestions: [
      "What decision have you been sitting on the longest?",
      "What would it look like to check back in on that decision in a week instead of deciding forever right now?",
    ],
    skillSteps: [
      {"id": "choice", "title": "Step 1 — The choice", "instruction": "Pick one.", "maxPicks": 1, "options": ["A job offer", "Where to live", "Whether to reach out to someone", "A relationship", "Going back to school", "Money", "Moving", "Something someone offered me"]},
      {"id": "options", "title": "Step 2 — My options", "instruction": "Choose up to 3.", "maxPicks": 3, "options": ["Say yes", "Say no", "Wait and get more information", "Ask for something different", "Talk it over first", "Try it for a short time"]},
      {"id": "matters", "title": "Step 3 — What matters most to me", "instruction": "Choose up to 3.", "maxPicks": 3, "options": ["Family", "Freedom", "Staying sober", "Money", "Health", "Peace", "Respect", "My future"], "shared": "values"},
      {"id": "pick", "title": "Step 4 — The option I can stand behind in 10 years", "instruction": "Pick one.", "maxPicks": 1, "options": ["Say yes", "Say no", "Wait and get more information", "Ask for something different", "Talk it over first", "Try it for a short time"], "optionsFrom": "options"},
      {"id": "check", "title": "Step 5 — When I'll check back", "instruction": "Pick one.", "maxPicks": 1, "options": ["Tomorrow", "In 3 days", "In a week", "In two weeks", "After I talk to someone", "In a month"]},
    ],
  },

  "letting-go-shame": {
    exerciseId: "did-not-am",
    toolName: "Shame to Repair",
    toolIntro: "Turn shame into something you can do.",
    welcome: [
      "Have you ever felt like something you did says who you are, instead of just something you did?",
      "Guilt says \"I did something wrong.\" Shame says \"I am something wrong.\"",
      "Only one of those points anywhere useful.",
    ],
    checklist: [
      "I feel like my past defines who I am.",
      "I avoid people because of what I've done.",
      "I believe I'm unfixable.",
      "I keep things secret out of shame, not privacy.",
      "I feel like I don't deserve good things because of my history.",
      "Shame keeps me from repairing what I could actually repair.",
    ],
    normalizing: "Shame is common, especially after time spent being defined by mistakes. But shame isolates, and isolation is where relapse and depression grow. You are not the worst thing you've done.",
    whyHard: {
      heading: "Why shame keeps you stuck",
      body: "Guilt points you toward a repair — something you can actually do. Shame just says you're broken, with nothing to do about it. That difference is why shame keeps people isolated instead of moving forward.",
      bullets: ["Avoiding people out of shame", "Believing you're unfixable", "Keeping secrets that grow heavier over time", "Feeling like you don't deserve good things", "Guilt and shame blurring into one feeling"],
    },
    reframe: {
      heading: "Guilt has somewhere to go",
      body: "Sort what you're carrying: is it \"I did something\" or \"I am something\"? Guilt can lead to a repair — an apology, a changed behavior. Shame just needs to be said out loud to someone safe so it loses its grip.",
    },
    checkIn: [
      { id: "struggle", label: "How much shame are you carrying right now?", left: "None", right: "A lot", higherIsHarder: true },
      { id: "confidence", label: "How able do you feel to tell one safe person the hard thing?", left: "Not able", right: "Very able", higherIsHarder: false },
      { id: "support", label: "How hopeful are you that this shame can loosen its grip?", left: "Not hopeful", right: "Very hopeful", higherIsHarder: false },
    ],
    adelQuestions: [
      "What's a shame thought you've been carrying?",
      "Who's one safe person you could say it out loud to?",
    ],
    skillSteps: [
      {"id": "carrying", "title": "Step 1 — What I'm carrying (optional)", "instruction": "This stays private. Skip it if you want.", "maxPicks": 2, "options": ["Something I did to family", "Something I did while using", "Time I lost with my kids", "Hurting someone", "Things that happened inside", "Letting people down", "Lying or stealing", "I'd rather not say"]},
      {"id": "shame", "title": "Step 2 — The shame line", "instruction": "Pick one.", "maxPicks": 1, "options": ["\"I'm a bad person.\"", "\"I'm unforgivable.\"", "\"I'm broken.\"", "\"I'll never be more than this.\"", "\"Everyone would leave if they knew.\"", "\"I don't deserve good things.\""]},
      {"id": "guilt", "title": "Step 3 — The guilt line", "instruction": "Pick one.", "maxPicks": 1, "options": ["\"I did something I regret, and I'm doing the work.\"", "\"I made choices that hurt people. I'm making different ones.\"", "\"I can own it without being it.\"", "\"What I did matters. So does what I do now.\""]},
      {"id": "repair", "title": "Step 4 — One repair or living amends", "instruction": "Choose up to 2.", "maxPicks": 2, "options": ["Apologize to someone", "Show up every time I said I would", "Pay something back", "Write a letter I may not send", "Help someone else", "Stay sober today", "Be honest when it's hard", "Keep a promise"], "feeds": "move"},
      {"id": "who", "title": "Step 5 — Who I can tell", "instruction": "Choose up to 2.", "maxPicks": 2, "options": ["Sponsor", "Counselor", "Peer specialist", "A friend in recovery", "A pastor or faith leader", "Someone from my meeting"], "shared": "supportPeople", "crisisLink": true},
    ],
  },

  "solving-problems": {
    exerciseId: "say-it-list-three-take-one",
    toolName: "Problem Breaker",
    toolIntro: "Turn a problem into a first step you can take today.",
    welcome: [
      "Have you ever looked at a huge problem and just frozen, because you didn't even know where to start?",
      "\"Fix my housing\" or \"get my life together\" isn't really a task. It's a whole category of things.",
      "The way through is shrinking it down until it's something you could actually do today.",
    ],
    checklist: [
      "A big problem feels too large to even start on.",
      "I freeze instead of taking a first step.",
      "I try to plan everything before I do anything.",
      "I feel behind because the problem hasn't gone away yet.",
      "I don't know what the actual next action is.",
      "I avoid a problem because it feels too big to touch.",
    ],
    normalizing: "Feeling frozen in front of a big problem doesn't mean you're avoiding it out of laziness. It usually means the problem hasn't been broken down small enough yet to act on.",
    whyHard: {
      heading: "Why big problems freeze you",
      body: "A category like \"fix my housing\" has no clear first move, so your brain can't act on it. Problem-solving only works once you've turned that category into one specific action you could finish in under 20 minutes.",
      bullets: ["Staring at a problem without starting", "Feeling like nothing is small enough to do today", "Trying to solve everything at once", "Avoiding a call or a form because the whole thing feels huge", "Waiting for a perfect plan before moving"],
    },
    reframe: {
      heading: "Shrink it to 20 minutes",
      body: "Take the big category and ask, \"what's one call, one form, or one question I could handle in the next 20 minutes?\" That's the whole job for right now. The rest can wait its turn.",
    },
    checkIn: [
      { id: "struggle", label: "How big and stuck does your problem feel right now?", left: "Manageable", right: "Overwhelming", higherIsHarder: true },
      { id: "confidence", label: "How confident are you that you could find one 20-minute step?", left: "Not confident", right: "Very confident", higherIsHarder: false },
      { id: "support", label: "How hopeful are you that this problem can move, piece by piece?", left: "Not hopeful", right: "Very hopeful", higherIsHarder: false },
    ],
    adelQuestions: [
      "What's the big problem that's been sitting there unsolved?",
      "What's the smallest possible next action on it, something under 20 minutes?",
    ],
    skillSteps: [
      {"id": "problem", "title": "Step 1 — The problem", "instruction": "Pick one.", "maxPicks": 1, "options": ["Phone shut off", "No ride", "Money short", "Paperwork I don't understand", "A bill I can't pay", "A housing problem", "A missed appointment", "A fight with someone"]},
      {"id": "options", "title": "Step 2 — My options", "instruction": "Choose up to 3.", "maxPicks": 3, "options": ["Ask my case manager", "Call 211", "Ask family or a friend", "Look it up", "Call the office directly", "Ask my peer specialist", "Wait and save up", "Call legal aid"]},
      {"id": "pick", "title": "Step 3 — My pick", "instruction": "Pick one.", "maxPicks": 1, "options": ["Ask my case manager", "Call 211", "Ask family or a friend", "Look it up", "Call the office directly", "Ask my peer specialist", "Wait and save up", "Call legal aid"], "optionsFrom": "options"},
      {"id": "first", "title": "Step 4 — My first 20-minute step", "instruction": "Pick one.", "maxPicks": 1, "options": ["Make one call", "Fill out one form", "Send one text", "Find one document", "Look up one number", "Go in person"], "feeds": "move"},
      {"id": "when", "title": "Step 5 — When I'll do it", "instruction": "Pick one.", "maxPicks": 1, "options": ["Right now", "This morning", "This afternoon", "Tomorrow morning", "Before my next appointment"]},
    ],
  },

  "resilient-mindset": {
    exerciseId: "comeback-story",
    toolName: "Comeback Kit",
    toolIntro: "Your plan for bouncing back, built from the tools in this module.",
    welcome: [
      "Have you ever had one setback knock you all the way back down, like none of your progress had happened?",
      "It's easy to think resilient people just don't fall. Really, they've just practiced getting back up fast.",
      "Bounce-back speed isn't something you're born with. It's something you can train.",
    ],
    checklist: [
      "One setback makes me feel like I'm back at zero.",
      "I struggle to get back to my routine after a hard day.",
      "I isolate instead of telling someone when things go wrong.",
      "I exaggerate how bad a setback is once it happens.",
      "I don't have a go-to move for bouncing back.",
      "I forget how many times I've already recovered from something hard.",
    ],
    normalizing: "Struggling to bounce back doesn't mean you're not resilient. Resilience is a set of practiced habits, not a personality trait, and you can build those habits starting today.",
    whyHard: {
      heading: "Why setbacks can feel like total failure",
      body: "Without a practiced way to respond, a setback can feel bigger than it is, and it's easy to slide into isolation right when connection matters most. Resilient people don't avoid setbacks — they've just rehearsed what to do next.",
      bullets: ["Feeling wiped out by one hard moment", "Avoiding people after a setback", "Skipping your routine \"just for today\"", "Exaggerating how bad things are", "Forgetting past comebacks"],
    },
    reframe: {
      heading: "Resilience is a habit, not a feeling",
      body: "Name what actually happened without exaggerating it, get back to one piece of your routine, and tell someone. Those three moves are trainable, and they get faster every time you use them.",
    },
    checkIn: [
      { id: "struggle", label: "How knocked down do you feel by a recent setback?", left: "Steady", right: "Knocked down", higherIsHarder: true },
      { id: "confidence", label: "How confident are you in your ability to bounce back?", left: "Not confident", right: "Very confident", higherIsHarder: false },
      { id: "support", label: "How hopeful are you about your ability to keep growing this skill?", left: "Not hopeful", right: "Very hopeful", higherIsHarder: false },
    ],
    adelQuestions: [
      "What's one setback you've already bounced back from before?",
      "Which bounce-back move is easiest for you to reach for on a hard day?",
    ],
    skillSteps: [
      {"id": "traps", "title": "Step 1 — My top thinking traps", "instruction": "Choose up to 3.", "maxPicks": 3, "options": ["Always/Never", "Mind Reading", "Crystal Ball", "Name-Calling", "Should-ing", "All or nothing", "Blowing it out of proportion", "Blaming myself for everything"]},
      {"id": "coach", "title": "Step 2 — My coach line", "instruction": "Pick one.", "maxPicks": 1, "options": ["\"I messed up, and I can fix it.\"", "\"I'm learning.\"", "\"I'm more than my worst day.\"", "\"I'm still here, and that counts.\"", "\"Progress, not perfect.\"", "\"I've come back before.\""]},
      {"id": "moves", "title": "Step 3 — My comeback moves", "instruction": "Choose up to 3.", "maxPicks": 3, "options": ["Solving or Spinning?", "The Camera Test", "Name That Trap", "The Best Friend Test", "Worst, Best, Most Likely", "Three Other Reasons", "10-10-10", "Say It, List Three, Take One"], "shared": "copingTools", "feeds": "move"},
      {"id": "who", "title": "Step 4 — Who I tell", "instruction": "Choose up to 2.", "maxPicks": 2, "options": ["Sponsor", "Peer specialist", "Counselor", "A family member", "A friend in recovery", "Case manager"], "shared": "supportPeople", "crisisLink": true},
      {"id": "proof", "title": "Step 5 — My proof: a time I came back before", "instruction": "Pick one.", "maxPicks": 1, "options": ["I got through my time inside", "I got sober before", "I rebuilt a relationship", "I got a job after a setback", "I got through a loss", "I made it through my first days out", "I've survived things most people haven't"]},
    ],
  },
};
