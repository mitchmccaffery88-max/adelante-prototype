// Topic-specific content written for one submodule. Replaces the shared
// stock text that derive() otherwise fills in. Every field is optional —
// anything left out keeps the existing (already topic-specific) content.

import type { IfThenConfig, RatingDimension, ToolFlowStep } from "../module-schema";
import type { LessonCareNotes } from "../care-notes";

export type TopicContent = {
  related?: string[];
  careNote?: LessonCareNotes;
  /** Part A — id of a plug-and-play exercise in the shared Exercise Library. */
  exerciseId: string;
  /** Understand My Challenge — opening "Have you ever…" lines. */
  welcome?: string[];
  checklist?: string[];
  normalizing?: string;
  /** Replaces the generic "why this is hard" section. */
  whyHard?: { heading: string; body: string; bullets?: string[] };
  /** Replaces only the generic bullets (when the body is already specific). */
  whyBullets?: string[];
  /** Replaces the generic reframe. */
  reframe?: { heading: string; body: string };
  /** Check In With Myself (also used for Check My Progress re-rating). Keep ids stable. */
  checkIn?: RatingDimension[];
  /** Talk It Through With Adel — library: questions 2 & 3; recovery: all 3. */
  adelQuestions?: string[];
  /** My Insight statement (recovery). */
  insight?: string;
  /** Part B — customizable tool steps. */
  skillSteps?: ToolFlowStep[];
  /** Part B — tool name (heading and My Toolkit label). */
  toolName?: string;
  /** Part B — short intro under the tool name. */
  toolIntro?: string;
  /** Part B — use this Exercise Library tool instead of chip steps. */
  partBExerciseId?: string;
  /** Library — My If–Then Plan content. */
  ifThen?: IfThenConfig;
  /** Recovery only — peer story + practice scene. */
  story?: { name: string; text: string };
  scenario?: string;
};
