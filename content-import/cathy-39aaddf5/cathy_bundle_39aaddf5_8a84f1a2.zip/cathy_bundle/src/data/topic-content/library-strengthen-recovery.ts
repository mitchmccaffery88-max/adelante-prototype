import type { TopicContent } from "./types";

// Strengthen My Recovery — topic-specific content (batch 2).
export const STRENGTHEN_RECOVERY: Record<string, TopicContent> = {
  "want-to-use": {
    exerciseId: "count-by-sevens",
    toolName: "Urge Profile",
    toolIntro: "Learn how your cravings work so they stop catching you off guard.",
    welcome: [
      "Have you ever felt a craving hit so hard your whole body seemed to want it?",
      "Your chest gets tight, your mind fixates, and it feels like it will never let up.",
      "It can feel like an order you have to obey, but it isn't.",
    ],
    checklist: [
      "My cravings come on fast and strong.",
      "I feel the craving in my body, not just my head.",
      "I think a craving will keep getting worse forever.",
      "I've given in just to make it stop.",
      "I don't know what to do in the first minute.",
      "Cravings catch me off guard.",
    ],
    normalizing: "If this sounds familiar, your brain learned a fast way to feel relief, and it's calling that number again. A craving is a wave, not a command, and waves crest.",
    whyHard: {
      heading: "Why a craving feels so urgent",
      body: "Your brain built a strong shortcut between pain and relief. When that shortcut gets triggered, it floods you with urgency so you'll act fast. But urgency isn't truth — most cravings peak and start dropping within 20 to 30 minutes.",
      bullets: ["Tight chest or stomach", "Racing thoughts about using", "Feeling like it will never stop", "Wanting to act right now", "Trouble thinking about anything else"],
    },
    reframe: {
      heading: "Outlast it, don't obey it",
      body: "You don't have to make a craving disappear. You only have to get through the peak. Every craving you ride out without using makes the shortcut in your brain a little weaker.",
    },
    checkIn: [
      { id: "struggle", label: "How strong does a craving feel when it hits?", left: "Mild", right: "Overpowering", higherIsHarder: true },
      { id: "confidence", label: "How confident are you that you can ride one out?", left: "Not confident", right: "Very confident", higherIsHarder: false },
      { id: "support", label: "How hopeful are you that cravings get weaker over time?", left: "Not hopeful", right: "Very hopeful", higherIsHarder: false },
    ],
    adelQuestions: [
      "What does a craving feel like in your body, exactly?",
      "What's usually going on right before one shows up?",
    ],
    skillSteps: [
      {"id": "when", "title": "Step 1 — When cravings hit", "instruction": "Choose up to 3.", "maxPicks": 3, "options": ["Late at night", "Payday", "Weekends", "When I'm alone", "After a fight", "When I'm bored", "After work", "Around certain people"], "feeds": "cue"},
      {"id": "sets", "title": "Step 2 — What sets them off", "instruction": "Choose up to 3.", "maxPicks": 3, "options": ["Stress", "Old friends", "Certain places", "Money in my pocket", "Arguments", "Boredom", "Loneliness", "Celebrating"], "shared": "triggers"},
      {"id": "body", "title": "Step 3 — Where I feel them", "instruction": "Choose up to 2.", "maxPicks": 2, "options": ["Chest", "Stomach", "Mouth or throat", "Hands", "Head", "All over"]},
      {"id": "long", "title": "Step 4 — How long they usually last", "instruction": "Pick one.", "maxPicks": 1, "options": ["A few minutes", "10 to 20 minutes", "About 30 minutes", "About an hour", "On and off all day", "I don't know yet"]},
      {"id": "helped", "title": "Step 5 — What's helped before", "instruction": "Choose up to 3.", "maxPicks": 3, "options": ["Count By Sevens", "Leaving the place", "Calling someone", "A meeting", "Walking", "Cold water", "Eating", "Sleeping it off"], "shared": "copingTools", "feeds": "move"},
    ],
  },

  triggers: {
    exerciseId: "turn-walk-call",
    toolName: "Trigger Clean Sweep",
    toolIntro: "Clear out what pulls you back, one piece at a time.",
    welcome: [
      "Have you ever been going about your day and suddenly a craving hits out of nowhere?",
      "Later you realize it wasn't out of nowhere — it followed a certain street, a certain person, a certain time of day.",
      "Triggers feel random until you write them down.",
    ],
    checklist: [
      "Cravings seem to come out of nowhere.",
      "Certain people set me off.",
      "Certain places make me want to use.",
      "Nighttime or being alone is harder for me.",
      "I get blindsided by the same things over and over.",
      "I don't have a plan for my top triggers.",
    ],
    normalizing: "Almost everyone has a short list of real triggers, not a long, scary one. Once you name yours, they stop feeling random, and you can plan for them instead of being surprised.",
    whyHard: {
      heading: "Why triggers sneak up on you",
      body: "Your brain linked certain people, places, times, and feelings to using, sometimes without you noticing. Those links fire fast, before you've had a chance to think. Naming them slows that reaction down.",
      bullets: ["Feeling ambushed by a craving", "Avoiding whole parts of your day", "The same few things setting you off", "Not seeing the pattern until after", "Feeling caught off guard in public"],
    },
    reframe: {
      heading: "Five, not fifty",
      body: "Most people don't have an endless list of triggers — they have about five. A short list is something you can actually plan around, one at a time.",
    },
    checkIn: [
      { id: "struggle", label: "How often do triggers catch you off guard?", left: "Rarely", right: "All the time", higherIsHarder: true },
      { id: "confidence", label: "How clear are you on your top triggers?", left: "Not clear", right: "Very clear", higherIsHarder: false },
      { id: "support", label: "How prepared do you feel for your hardest trigger?", left: "Not prepared", right: "Very prepared", higherIsHarder: false },
    ],
    adelQuestions: [
      "Which trigger shows up for you the most?",
      "Is there a time of day that's harder for you than others?",
    ],
    skillSteps: [
      {"id": "numbers", "title": "Step 1 — Numbers and apps to delete or block", "instruction": "Choose up to 3.", "maxPicks": 3, "options": ["An old dealer's number", "People I used with", "Group chats", "Dating apps", "Cash apps", "Social media accounts", "Nothing to delete"]},
      {"id": "places", "title": "Step 2 — Places to avoid, and my new route", "instruction": "Choose up to 3.", "maxPicks": 3, "options": ["My old block", "Certain stores", "Bars or parties", "A friend's house", "Old hangout spots", "Take a different bus", "A new way to work", "Go at a different time"], "feeds": "move"},
      {"id": "things", "title": "Step 3 — Things to clear out of my space", "instruction": "Choose up to 3.", "maxPicks": 3, "options": ["Paraphernalia", "Alcohol", "Old pill bottles", "Lighters", "Pictures that pull me back", "Music that pulls me back", "Nothing left to clear"]},
      {"id": "money", "title": "Step 4 — Cash and payday triggers", "instruction": "Choose up to 2.", "maxPicks": 2, "options": ["Payday", "Cash in my pocket", "Getting benefits", "A tax refund", "Selling something", "Someone paying me back"], "shared": "triggers", "feeds": "cue"},
      {"id": "done", "title": "Step 5 — What I've done so far", "instruction": "Choose up to 6.", "maxPicks": 6, "options": ["Deleted numbers", "Blocked contacts", "Changed my route", "Cleared my space", "Set up direct deposit", "Asked someone to hold my cash", "Told my support person", "Still working on it"]},
    ],
  },

  surfing: {
    exerciseId: "urge-surfing",
    toolName: "Surf Log",
    toolIntro: "Log each craving you ride out. Over time you'll see them get shorter.",
    welcome: [
      "Have you ever known a craving would pass but felt stuck right in the middle of it?",
      "The beginning is manageable and the end is a relief, but the middle feels like it lasts forever.",
      "Urge surfing is a way to stay on the board through that middle part.",
    ],
    checklist: [
      "I know cravings pass, but the middle is hard.",
      "I fight the feeling instead of watching it.",
      "I feel like I have to do something the second it starts.",
      "I lose track of where a craving lives in my body.",
      "I don't have a set of steps to follow.",
      "I give in right when it peaks.",
    ],
    normalizing: "The middle of a craving is the hardest part for almost everyone, not just you. Urge surfing gives you steps to follow instead of white-knuckling it.",
    whyHard: {
      heading: "Why the middle feels endless",
      body: "Fighting a craving or feeding it both keep it running. Staying with the sensation instead — noticing it, breathing, describing it — lets it move through its natural rise and fall.",
      bullets: ["Fighting the urge", "Feeling like time is standing still", "Wanting instant relief", "Losing track of the steps mid-craving", "Giving in right before it would have dropped"],
    },
    reframe: {
      heading: "Stay on the board",
      body: "You don't have to stop the wave. You just have to stay on your board while it moves under you. It will drop on its own if you let it run its course.",
    },
    checkIn: [
      { id: "struggle", label: "How hard is the middle of a craving for you?", left: "Manageable", right: "Very hard", higherIsHarder: true },
      { id: "confidence", label: "How confident are you in the surf steps?", left: "Not confident", right: "Very confident", higherIsHarder: false },
      { id: "support", label: "How much do you believe a craving will actually drop?", left: "Not much", right: "A lot", higherIsHarder: false },
    ],
    adelQuestions: [
      "Where does a craving usually sit in your body?",
      "What happens for you right at the peak?",
    ],
    skillSteps: [
      {"id": "when", "title": "Step 1 — When it hit", "instruction": "Pick one.", "maxPicks": 1, "options": ["Morning", "Afternoon", "Evening", "Late night", "Right after a trigger", "Out of nowhere"]},
      {"id": "peak", "title": "Step 2 — How strong at the peak", "instruction": "Pick one.", "maxPicks": 1, "options": ["1–2", "3–4", "5–6", "7–8", "9–10"]},
      {"id": "long", "title": "Step 3 — How long it lasted", "instruction": "Pick one.", "maxPicks": 1, "options": ["Under 5 minutes", "5 to 10 minutes", "10 to 20 minutes", "20 to 30 minutes", "Over 30 minutes"]},
      {"id": "helped", "title": "Step 4 — What helped", "instruction": "Choose up to 3.", "maxPicks": 3, "options": ["Urge Surfing", "Breathing", "Walking", "Calling someone", "Leaving", "Water", "A distraction", "Just waiting it out"], "shared": "copingTools", "feeds": "move"},
      {"id": "learned", "title": "Step 5 — What I learned", "instruction": "Pick one.", "maxPicks": 1, "options": ["It passed", "It peaked and dropped", "I can ride it", "Something specific set it off", "I need a better plan for that time", "I did better than last time"]},
    ],
  },

  "recovery-choices": {
    exerciseId: "spot-the-small-choice",
    toolName: "Chain Breaker",
    toolIntro: "Find your earliest link and decide there.",
    welcome: [
      "Have you ever looked back and realized a hard moment started with a small choice way earlier?",
      "The ride you took, the number you kept, the meeting you skipped — none of them felt like a big deal at the time.",
      "Recovery is mostly made of small, early choices, not one big moment.",
    ],
    checklist: [
      "I don't notice small choices adding up.",
      "I wait until the last moment to decide.",
      "I keep numbers or contacts I know aren't good for me.",
      "I skip meetings without thinking much of it.",
      "I only see the pattern after something's gone wrong.",
      "I want to catch choices earlier.",
    ],
    normalizing: "Many relapses start with small choices well before the moment of use. That's actually good news, because it means you have more chances to choose differently than it feels like.",
    whyHard: {
      heading: "Why the early choices are easy to miss",
      body: "Early choices feel small and safe, so they don't set off any alarms. By the time you notice you're in a risky spot, the choices left are harder. Catching it early is cheaper every time.",
      bullets: ["Small choices not feeling like a big deal", "Only seeing the chain after it's played out", "Keeping contacts \"just in case\"", "Skipping steps that felt optional", "Feeling like the moment came out of nowhere"],
    },
    reframe: {
      heading: "Decide early, where it's cheap",
      body: "Every chain has a first link — the one where saying no costs you the least. Find that link, and make your decision there instead of waiting until it's harder.",
    },
    checkIn: [
      { id: "struggle", label: "How often do small choices sneak up on you?", left: "Rarely", right: "Often", higherIsHarder: true },
      { id: "confidence", label: "How well can you spot your earliest link?", left: "Not well", right: "Very well", higherIsHarder: false },
      { id: "support", label: "How hopeful are you that early choices are easier?", left: "Not hopeful", right: "Very hopeful", higherIsHarder: false },
    ],
    adelQuestions: [
      "Where's the earliest link in a chain that's given you trouble before?",
      "What would it look like to decide there instead of later?",
    ],
    skillSteps: [
      {"id": "slip", "title": "Step 1 — A past slip or close call", "instruction": "Pick one.", "maxPicks": 1, "options": ["Ran into old friends", "Went to the old block", "Got paid and had cash", "A fight at home", "A party", "Felt bored and alone", "Stopped going to meetings", "A bad day at work"]},
      {"id": "chain", "title": "Step 2 — The chain of small choices", "instruction": "Choose up to 4.", "maxPicks": 4, "options": ["Skipped a meeting", "Kept a number", "Took a ride", "Took the long way", "Didn't eat or sleep", "Stopped calling my sponsor", "Told myself \"just to see\"", "Kept cash on me"]},
      {"id": "earliest", "title": "Step 3 — My earliest link", "instruction": "Pick one.", "maxPicks": 1, "options": ["Skipped a meeting", "Kept a number", "Took a ride", "Took the long way", "Didn't eat or sleep", "Stopped calling my sponsor", "Told myself \"just to see\"", "Kept cash on me"], "optionsFrom": "chain", "feeds": "cue"},
      {"id": "instead", "title": "Step 4 — The choice I'll make instead", "instruction": "Choose up to 2.", "maxPicks": 2, "options": ["Go to my meeting anyway", "Delete the number", "Say no to the ride", "Take my usual route", "Eat and sleep", "Call my sponsor", "Give my cash to someone I trust", "Tell someone what I'm thinking"], "feeds": "move"},
    ],
  },

  "stress-without-using": {
    exerciseId: "tipp",
    toolName: "Relief Menu",
    toolIntro: "Relief that doesn't cost you your recovery, sorted by how much time you have.",
    welcome: [
      "Have you ever felt so stressed that using was the only relief you fully trusted?",
      "Other things might help a little, but they don't feel like enough.",
      "That's not a character flaw. It means you need a menu of replacements, not just willpower.",
    ],
    checklist: [
      "Stress makes me want to use.",
      "I don't fully trust other ways to feel better.",
      "I don't have a go-to list when stress hits.",
      "I decide from scratch every time, which takes too long.",
      "I've tried something that helped, but forgot about it later.",
      "I want relief that doesn't cost me my recovery.",
    ],
    normalizing: "Substances worked, at least for a while. That's exactly why they're hard to leave behind. The fix isn't to have no relief — it's to build a menu of relief you've actually tested.",
    whyHard: {
      heading: "Why willpower alone doesn't hold up",
      body: "Quitting without replacements leaves a gap, and stress will always try to fill that gap with whatever is fastest. Real relief comes from things you've tried before and know work, even a little.",
      bullets: ["Feeling like nothing else works as well", "Deciding from scratch under pressure", "Forgetting what's helped before", "Stress building until it feels urgent", "Reaching for the old shortcut out of habit"],
    },
    reframe: {
      heading: "Replace it, don't just resist it",
      body: "You don't have to quit relief. You get to replace it with a short menu: movement, cold, calling someone, food, sleep, a meeting. Read the menu instead of deciding cold.",
    },
    checkIn: [
      { id: "struggle", label: "How much does stress push you toward using?", left: "Not much", right: "A lot", higherIsHarder: true },
      { id: "confidence", label: "How confident are you in your relief menu?", left: "Not confident", right: "Very confident", higherIsHarder: false },
      { id: "support", label: "How ready do you feel to try one today?", left: "Not ready", right: "Very ready", higherIsHarder: false },
    ],
    adelQuestions: [
      "What has actually given you relief before, even a little?",
      "What could you do in the next ten minutes when stress hits?",
    ],
    skillSteps: [
      {"id": "five", "title": "Step 1 — Five-minute relief", "instruction": "Choose up to 3.", "maxPicks": 3, "options": ["TIPP", "Cold water", "Walk around the block", "Slow breathing", "Music", "Text someone", "Stretch", "Step outside"], "shared": "copingTools", "feeds": "move"},
      {"id": "thirty", "title": "Step 2 — Thirty-minute relief", "instruction": "Choose up to 3.", "maxPicks": 3, "options": ["A real walk", "A meeting", "Call someone", "A shower", "Cook something", "Work out", "Clean or organize", "A nap"]},
      {"id": "week", "title": "Step 3 — Bigger relief this week", "instruction": "Choose up to 2.", "maxPicks": 2, "options": ["Time with family", "A hobby", "Church", "Fishing or the park", "Play a sport", "A movie", "Coffee with a sober friend", "Volunteer"]},
      {"id": "free", "title": "Step 4 — Free and nearby", "instruction": "Choose up to 2.", "maxPicks": 2, "options": ["A park", "The library", "A community center", "Church", "A meeting hall", "A walking trail", "A friend's place"]},
      {"id": "tonight", "title": "Step 5 — My pick for tonight", "instruction": "Pick one.", "maxPicks": 1, "options": ["A real walk", "A meeting", "Call someone", "A shower", "Cook something", "Work out", "Clean or organize", "A nap"], "optionsFrom": "thirty"},
    ],
  },

  "one-bad-day": {
    exerciseId: "comeback-rehearsal",
    toolName: "Setback Debrief",
    toolIntro: "Look at what happened without judgment, and get back on track.",
    welcome: [
      "Have you ever slipped and felt like everything you built was suddenly gone?",
      "The shame can hit so fast it feels bigger than the slip itself.",
      "What happens in the next 24 hours matters more than the slip did.",
    ],
    checklist: [
      "I feel like a slip erases everything I've done.",
      "I want to hide it if it happens.",
      "I think about giving up completely after a slip.",
      "I don't have a plan for the next 24 hours.",
      "I wait too long to tell someone.",
      "I want to know how to come back fast.",
    ],
    normalizing: "A slip doesn't erase your recovery. What turns a slip into a longer relapse is usually shame and silence, not the substance itself. Coming back fast is a real, learnable skill.",
    whyHard: {
      heading: "Why shame makes a slip worse",
      body: "Shame tells you to hide, and hiding removes the exact support that would help you recover fastest. The people who bounce back quickest tell someone, look at what led to it, and return to their routine the same day.",
      bullets: ["Wanting to disappear after a slip", "Believing it's all been for nothing", "Hiding it out of shame", "Waiting for a fresh start date", "Feeling frozen about what to do next"],
    },
    reframe: {
      heading: "Data, not identity",
      body: "A slip tells you something about what led up to it. It isn't a verdict on who you are. Get safe, get honest, and get back to your routine the same day. If you used after time away, your tolerance is lower now. Don't use alone, and keep naloxone close.",
    },
    checkIn: [
      { id: "struggle", label: "How much shame comes up after a setback for you?", left: "A little", right: "A lot", higherIsHarder: true },
      { id: "confidence", label: "How sure are you what to do in the first 24 hours?", left: "Not sure", right: "Very sure", higherIsHarder: false },
      { id: "support", label: "How safe would it feel to tell someone right away?", left: "Not safe", right: "Safe", higherIsHarder: false },
    ],
    adelQuestions: [
      "If a slip happened, who would you want to tell first?",
      "What usually leads up to a hard day for you?",
    ],
    skillSteps: [
      {"id": "what", "title": "Step 1 — What happened", "instruction": "No judgment here.", "maxPicks": 1, "options": ["I used once", "I used for a few days", "I almost used", "I drank", "I went somewhere risky", "I stopped following my plan", "I'd rather not say"]},
      {"id": "before", "title": "Step 2 — What led up to it", "instruction": "Choose up to 4.", "maxPicks": 4, "options": ["Hungry", "Angry", "Lonely", "Tired", "Old friends", "A risky place", "Stress", "Bad news"], "shared": "triggers"},
      {"id": "learned", "title": "Step 3 — What I learned", "instruction": "Choose up to 2.", "maxPicks": 2, "options": ["My warning signs came early", "I waited too long to reach out", "I need more support at night", "Payday is a risk", "I can come back from this", "I'm stronger than I thought"]},
      {"id": "change", "title": "Step 4 — What I'll change", "instruction": "Choose up to 2.", "maxPicks": 2, "options": ["Go to more meetings", "Call my sponsor every day", "Change my route", "Hand off my cash", "Keep naloxone with me", "Never use alone", "Tell my treatment team", "Fix my sleep"], "feeds": "move"},
      {"id": "told", "title": "Step 5 — Who I told or will tell", "instruction": "Choose up to 2.", "maxPicks": 2, "options": ["Sponsor", "Peer specialist", "Counselor", "Treatment team", "A friend in recovery", "A family member"], "shared": "supportPeople", "crisisLink": true},
    ],
  },

  "recovery-toolbox": {
    exerciseId: "run-the-toolbox",
    toolName: "3-2-1 Toolbox",
    toolIntro: "Three tools, two people, one place. Short enough to use when your mind goes blank.",
    welcome: [
      "Have you ever been in a hard moment and completely blanked on anything that helps?",
      "You know you have tools, but under pressure your mind goes empty.",
      "A written toolbox works when your memory won't.",
    ],
    checklist: [
      "I blank out in the moment even though I know tools that help.",
      "I've never written my tools down anywhere.",
      "I have too many ideas and no short list.",
      "I don't know which tools to reach for first.",
      "I forget to check my toolbox until after a hard moment passes.",
      "I want something I can read instead of remember.",
    ],
    normalizing: "Under stress, the thinking part of your brain goes quiet, so that's the worst time to invent a plan from scratch. A short written toolbox solves that, because you read it instead of remembering it.",
    whyHard: {
      heading: "Why memory fails you under pressure",
      body: "Stress shifts your brain toward fast, automatic reactions and away from careful thinking. That's exactly when a long mental list disappears. A short written list, though, still works, because reading takes less effort than remembering.",
      bullets: ["Blanking out under stress", "Having tools but not using them", "Too many options to choose fast", "Forgetting your toolbox exists", "Wanting something simple and ready"],
    },
    reframe: {
      heading: "Keep it short enough to open",
      body: "A toolbox with twenty things in it is a toolbox nobody opens. Three tools, two people, one place is enough. Short lists get used.",
    },
    checkIn: [
      { id: "struggle", label: "How often do you blank on your tools in the moment?", left: "Rarely", right: "Often", higherIsHarder: true },
      { id: "confidence", label: "How confident are you in your toolbox right now?", left: "Not confident", right: "Very confident", higherIsHarder: false },
      { id: "support", label: "How ready do you feel to write it down today?", left: "Not ready", right: "Very ready", higherIsHarder: false },
    ],
    adelQuestions: [
      "Which tool has actually worked for you before?",
      "Where will you keep your toolbox so you'll actually see it?",
    ],
    skillSteps: [
      {"id": "tools", "title": "Step 1 — Three tools", "instruction": "Choose up to 3.", "maxPicks": 3, "options": ["Urge Surfing", "Count By Sevens", "TIPP", "Turn, Walk, Call", "5-4-3-2-1", "Slow breathing", "A walk", "My reasons list"], "shared": "copingTools"},
      {"id": "people", "title": "Step 2 — Two people", "instruction": "Choose up to 2.", "maxPicks": 2, "options": ["Sponsor", "Peer specialist", "Counselor", "A friend in recovery", "A family member", "Case manager"], "shared": "supportPeople"},
      {"id": "place", "title": "Step 3 — One safe place", "instruction": "Pick one.", "maxPicks": 1, "options": ["My room", "A meeting hall", "A family member's home", "A library", "A church", "My peer specialist's office", "A park in daylight"], "shared": "safePlaces"},
      {"id": "save", "title": "Step 4 — Where I'll keep it", "instruction": "Pick one.", "maxPicks": 1, "options": ["My lock screen", "Phone notes", "A card in my wallet", "My toolkit here", "Taped by my door"]},
    ],
  },

  motivation: {
    exerciseId: "readiness-ruler",
    toolName: "Reasons Why",
    toolIntro: "Your reasons, ranked, where you'll see them.",
    welcome: [
      "Have you ever had a day where you couldn't remember why you're even doing this?",
      "The feeling of motivation comes and goes, and that can feel scary.",
      "A written 'why' works even on the days the feeling doesn't show up.",
    ],
    checklist: [
      "Some days I forget why I started.",
      "I wait to feel motivated before I act.",
      "My reasons for recovery aren't written down anywhere.",
      "Low motivation feels like a warning sign to me.",
      "I don't reread my reasons very often.",
      "I want something steady to hold onto.",
    ],
    normalizing: "Motivation rising and falling is normal, not a sign something's wrong. What actually holds you up is a written list of your real reasons, ready to read on the days the feeling isn't there.",
    whyHard: {
      heading: "Why waiting to feel motivated backfires",
      body: "Motivation is a mood, and moods move on their own schedule. If you wait to feel it before you act, you'll skip the very days you need your recovery habits the most.",
      bullets: ["Motivation coming and going", "Forgetting your reasons on hard days", "Waiting to feel ready", "Treating a low day as a bad sign", "Not having anything written down"],
    },
    reframe: {
      heading: "A list, not a mood",
      body: "Your 'why' is the specific people, freedoms, and futures you're doing this for. Reading that list on a low day works better than waiting to feel motivated.",
    },
    checkIn: [
      { id: "struggle", label: "How often do you lose track of why you started?", left: "Rarely", right: "Often", higherIsHarder: true },
      { id: "confidence", label: "How clear is your list of reasons?", left: "Not clear", right: "Very clear", higherIsHarder: false },
      { id: "support", label: "How hopeful do you feel about today?", left: "Not hopeful", right: "Very hopeful", higherIsHarder: false },
    ],
    adelQuestions: [
      "What's one reason you're doing this that's real for you?",
      "When was the last time you felt proud of your progress?",
    ],
    skillSteps: [
      {"id": "reasons", "title": "Step 1 — My reasons", "instruction": "Choose up to 5.", "maxPicks": 5, "options": ["My kids", "Staying out", "My health", "Being trusted again", "A job I want", "Peace of mind", "My family", "Self-respect"], "shared": "reasons"},
      {"id": "top", "title": "Step 2 — My top three", "instruction": "Choose up to 3.", "maxPicks": 3, "options": ["My kids", "Staying out", "My health", "Being trusted again", "A job I want", "Peace of mind", "My family", "Self-respect"], "optionsFrom": "reasons"},
      {"id": "photo", "title": "Step 3 — A picture for my number one", "instruction": "Pick one.", "maxPicks": 1, "options": ["A photo of my kids", "A family photo", "A place I want to go", "My recovery chip", "A photo of me now", "Something I'm working toward"]},
      {"id": "where", "title": "Step 4 — Where I'll keep it", "instruction": "Pick one.", "maxPicks": 1, "options": ["My lock screen", "My wallet", "By my bed", "On the fridge", "My toolkit here", "My car"]},
    ],
  },

  "recovery-support-system": {
    exerciseId: "reverse-the-roles",
    toolName: "Support Lineup",
    toolIntro: "One person for each job, and one gap to fill.",
    welcome: [
      "Have you ever felt like you're carrying your recovery mostly by yourself?",
      "It's heavy, and it isn't supposed to be a solo job.",
      "A support system doesn't need to be big. It needs to be reachable.",
    ],
    checklist: [
      "I'm doing most of this alone.",
      "I don't have someone I could call at 2am.",
      "I don't have a regular meeting or group.",
      "I haven't connected with a counselor or peer specialist.",
      "I don't have a sober person I see regularly.",
      "I want to build my team but don't know where to start.",
    ],
    normalizing: "Connection is one of the strongest supports for staying in recovery, often more than willpower. You don't need a huge team, you need a few reachable layers of support.",
    whyHard: {
      heading: "Why going it alone feels normal but isn't",
      body: "If you've had to rely mostly on yourself for a long time, asking for backup can feel unfamiliar or even risky. But recovery holds up better with layers: someone for right now, a group that expects you, and a professional who knows your history.",
      bullets: ["Feeling like it's all on you", "Not knowing who to call in a crunch", "No regular group or meeting", "Missing a professional connection", "Feeling isolated even around people"],
    },
    reframe: {
      heading: "Reachable, not many",
      body: "You don't need dozens of people. You need one person for 2am, one group that expects you, and one professional who knows your story. That's a real team.",
    },
    checkIn: [
      { id: "struggle", label: "How alone does your recovery feel right now?", left: "Not alone", right: "Very alone", higherIsHarder: true },
      { id: "confidence", label: "How clear are you on who's on your team?", left: "Not clear", right: "Very clear", higherIsHarder: false },
      { id: "support", label: "How reachable is your support right now?", left: "Not reachable", right: "Very reachable", higherIsHarder: false },
    ],
    adelQuestions: [
      "Who is already part of your support, even a little?",
      "Which gap in your team would help the most to close?",
    ],
    skillSteps: [
      {"id": "late", "title": "Step 1 — My 2 a.m. person", "instruction": "Pick one.", "maxPicks": 1, "options": ["Sponsor", "Peer specialist", "A family member", "A friend in recovery", "Someone from my meeting"], "shared": "supportPeople"},
      {"id": "group", "title": "Step 2 — My recovery group", "instruction": "Pick one.", "maxPicks": 1, "options": ["AA", "NA", "SMART Recovery", "Celebrate Recovery", "A church group", "An outpatient group", "A peer support group", "Still looking"]},
      {"id": "pro", "title": "Step 3 — My professional", "instruction": "Pick one.", "maxPicks": 1, "options": ["Counselor", "Peer specialist", "Case manager", "Prescriber", "Teletherapist", "Still looking"], "shared": "careTeam"},
      {"id": "friend", "title": "Step 4 — My sober friend", "instruction": "Pick one.", "maxPicks": 1, "options": ["Someone from my meeting", "An old friend who's sober", "A coworker", "A family member", "Someone from church", "Still looking"]},
      {"id": "gap", "title": "Step 5 — My gap and one action", "instruction": "Pick one.", "maxPicks": 1, "options": ["Ask someone for their number", "Try a new meeting", "Book a counseling visit", "Ask someone sober to hang out", "Message my peer specialist", "Ask my sponsor to introduce me to people"], "feeds": "move"},
    ],
  },

  "who-i-want": {
    exerciseId: "toward-or-away",
    toolName: "True North",
    toolIntro: "Your direction, built from the tools in this module.",
    welcome: [
      "Have you ever been clear on what you're moving away from, but not what you're moving toward?",
      "Quitting something is only half of recovery.",
      "Naming who you want to become makes daily choices simpler.",
    ],
    checklist: [
      "I know what I don't want, more than what I do want.",
      "Fear has been my main motivator so far.",
      "I haven't named my values in a clear way.",
      "I want a direction, not just a warning.",
      "I don't check my day against what matters to me.",
      "I want daily choices to feel simpler.",
    ],
    normalizing: "Fear-based recovery can work for a while, but it's exhausting to run on. Naming what you actually value gives you something to walk toward, which tends to last longer.",
    whyHard: {
      heading: "Why fear alone runs out",
      body: "Avoiding something bad takes constant energy, because the goal is always behind you. Walking toward something you value pulls you forward instead, and that's a lot lighter to carry.",
      bullets: ["Feeling driven mostly by fear", "Not having named your values", "Choices feeling harder than they should", "Missing a clear direction", "Wanting something to build toward"],
    },
    reframe: {
      heading: "Direction, not just distance",
      body: "Naming what matters — being reliable, present, honest — gives you a way to check your day. It's not a wish list. It's a compass you can use today.",
    },
    checkIn: [
      { id: "struggle", label: "How much does fear alone drive your recovery right now?", left: "A little", right: "A lot", higherIsHarder: true },
      { id: "confidence", label: "How clear are you on your values?", left: "Not clear", right: "Very clear", higherIsHarder: false },
      { id: "support", label: "How hopeful do you feel about who you're becoming?", left: "Not hopeful", right: "Very hopeful", higherIsHarder: false },
    ],
    adelQuestions: [
      "Which value did you already live out this week, even a little?",
      "Who is someone you admire, and what do they value?",
    ],
    skillSteps: [
      {"id": "values", "title": "Step 1 — My top three values", "instruction": "Choose up to 3.", "maxPicks": 3, "options": ["Family", "Freedom", "Honesty", "Faith", "Health", "Respect", "Being reliable", "Peace"], "shared": "values"},
      {"id": "looks", "title": "Step 2 — What they look like on a normal day", "instruction": "Choose up to 3.", "maxPicks": 3, "options": ["Showing up on time", "Calling my kids", "Telling the truth", "Taking my meds", "Going to meetings", "Helping someone", "Keeping my word", "Taking care of my body"]},
      {"id": "pulls", "title": "Step 3 — What pulls me away", "instruction": "Choose up to 3.", "maxPicks": 3, "options": ["Old friends", "Boredom", "Money stress", "Anger", "Loneliness", "Shame", "Feeling disrespected", "Being tired"], "shared": "triggers", "feeds": "cue"},
      {"id": "toward", "title": "Step 4 — One toward move this week", "instruction": "Pick one.", "maxPicks": 1, "options": ["Call someone I've been avoiding", "Go to an extra meeting", "Do something with my kids", "Help someone", "Keep a promise", "Start something I've been putting off"], "feeds": "move"},
      {"id": "reasons", "title": "Step 5 — My reasons", "instruction": "Choose up to 3.", "maxPicks": 3, "options": ["My kids", "Staying out", "My health", "Being trusted again", "A job I want", "Peace of mind", "My family", "Self-respect"], "shared": "reasons"},
    ],
  },
};
