import type { TopicContent } from "./types";
import { ANY_TIME_HELP } from "../care-notes";

// Understanding My Diagnosis — topic-specific content (batch 2).
export const UNDERSTANDING_DIAGNOSIS: Record<string, TopicContent> = {
  sud: {
    exerciseId: "break-the-link",
    toolName: "Craving Compass",
    toolIntro: "Find your way through a craving, step by step.",
    welcome: [
      "Have you ever wondered if using is just a bad habit, a weak choice, or something else going on?",
      "Maybe someone called you an addict, and the word stuck harder than any explanation.",
      "It helps to know what's actually happening in your brain, because it isn't what most people assume.",
    ],
    checklist: [
      "I've been told this is just about willpower.",
      "I wonder why I can't just stop when I want to.",
      "I feel ashamed when I think about my past use.",
      "I don't fully understand what a substance use disorder is.",
      "I want to know why cravings feel so strong.",
      "I need a way to explain this to people who judge me.",
    ],
    normalizing: "If this sounds familiar, you're not the only one who was never given a real explanation. Understanding what's happening in your brain can take some of the shame out of the picture.",
    whyHard: {
      heading: "Why it isn't just about willpower",
      body: "Substance use disorder changes the part of the brain that decides what feels rewarding. Over time, using stops being about pleasure and becomes about relief from feeling awful. That rewiring doesn't undo itself just because you decide to stop.",
      bullets: ["Cravings that show up out of nowhere", "Feeling pulled toward using even when you don't want to", "Shame about not \"just stopping\"", "Old triggers still setting things off", "Wanting to understand your own brain better"],
    },
    reframe: {
      heading: "A brain that learned, not a person who's broken",
      body: "Your brain learned a shortcut to feel okay. Brains can learn new paths too, with time, support, and practice. Every day you build a new routine, you're laying down a different road.",
    },
    checkIn: [
      { id: "struggle", label: "How much does shame about your past use weigh on you today?", left: "Not much", right: "A lot", higherIsHarder: true },
      { id: "confidence", label: "How well do you understand what's happening in your brain?", left: "Not well", right: "Very well", higherIsHarder: false },
      { id: "support", label: "How hopeful do you feel that this can keep changing?", left: "Not hopeful", right: "Very hopeful", higherIsHarder: false },
    ],
    adelQuestions: [
      "Where in the craving cycle do you usually notice it first?",
      "What's one thing you wish people understood about this?",
    ],
    skillSteps: [{"id": "signal", "title": "Step 1 — My craving signals", "maxPicks": 3, "instruction": "Choose up to 3.", "options": ["Tight chest", "Racing thoughts about using", "Restless hands", "Dry mouth", "Sweating", "Thinking \"just once\"", "Irritable", "Can't stop thinking about it"]}, {"id": "cue", "title": "Step 2 — My cues", "maxPicks": 3, "instruction": "Choose up to 3.", "options": ["Payday or cash", "Being alone at night", "Stress", "Seeing old friends", "Certain places", "Boredom", "Arguments", "Celebrating"], "shared": "triggers", "feeds": "cue"}, {"id": "story", "title": "Step 3 — The story the craving tells", "maxPicks": 2, "instruction": "Choose up to 2.", "options": ["\"Just once won't hurt.\"", "\"I deserve it.\"", "\"I can't handle this without it.\"", "\"Nobody will know.\"", "\"I've already blown it.\"", "\"It's the only thing that helps.\""]}, {"id": "moves", "title": "Step 4 — My two moves", "maxPicks": 2, "instruction": "Choose up to 2.", "options": ["Break the Link", "Leave where I am", "Set a 20-minute timer", "Call someone", "Drink water", "Go for a walk", "Go to a meeting", "Urge Surfing"], "shared": "copingTools", "feeds": "move"}, {"id": "person", "title": "Step 5 — My support people", "maxPicks": 2, "instruction": "Choose up to 2.", "options": ["Sponsor", "Peer specialist", "Counselor", "A friend in recovery", "A family member", "Case manager", "Someone from my meeting"], "shared": "supportPeople"}],
  },

  depression: {
    exerciseId: "change-the-channel",
    toolName: "Mood Momentum Plan",
    toolIntro: "Small actions that keep a low mood from taking over.",
    welcome: [
      "Have you ever felt so flat that nothing sounded worth doing, not even things you used to like?",
      "Maybe you've been told to just cheer up, as if it were that simple.",
      "Depression isn't sadness you can just shake off — it's a real flattening of energy and hope.",
    ],
    checklist: [
      "Nothing sounds fun anymore.",
      "I'm tired even after resting.",
      "I feel like a burden to people.",
      "I have trouble concentrating.",
      "I believe nothing will help before I even try.",
      "I've stopped doing things I used to enjoy.",
    ],
    normalizing: "If several of these fit, that's depression talking, not the truth about you. It lies with confidence, which is exactly why it's worth learning to see through.",
    whyHard: {
      heading: "Why depression is so convincing",
      body: "Depression tells you that trying won't help, and that belief keeps you still. But movement usually has to come first — motivation tends to show up after you've already started, not before.",
      bullets: ["Feeling too tired to do basic things", "Believing you're a burden", "Losing interest in things you liked", "Trouble focusing", "Thinking nothing will help"],
    },
    reframe: {
      heading: "Symptom, not personality",
      body: "\"I'm lazy\" is a story. \"I'm too tired to shower\" is a symptom. Learning to sort the two apart takes the blame off you and puts the focus on treatment that actually works.",
    },
    checkIn: [
      { id: "struggle", label: "How flat or heavy do you feel today?", left: "Light", right: "Very heavy", higherIsHarder: true },
      { id: "confidence", label: "How able are you to tell a symptom apart from a story about yourself?", left: "Not able", right: "Very able", higherIsHarder: false },
      { id: "support", label: "How hopeful do you feel that small steps can help?", left: "Not hopeful", right: "Very hopeful", higherIsHarder: false },
    ],
    adelQuestions: [
      "Which story does your depression tell you the most?",
      "What's one small thing you could do today before you feel like it?",
    ],
    skillSteps: [{"id": "signals", "title": "Step 1 — My low-mood signals", "maxPicks": 3, "instruction": "Choose up to 3.", "options": ["Staying in bed", "Skipping meals or showers", "Canceling plans", "Feeling flat", "Sleeping too much or too little", "Thinking I'm a burden", "Can't concentrate", "Not answering my phone"], "shared": "warningSigns", "feeds": "cue"}, {"id": "boosters", "title": "Step 2 — My mood boosters", "maxPicks": 4, "instruction": "Choose up to 4.", "options": ["A short walk", "Texting or calling someone", "One small task", "Music, TV or a game", "A meeting", "Time outside", "A shower", "A real meal"]}, {"id": "small", "title": "Step 3 — Make it small", "maxPicks": 2, "instruction": "Choose up to 2.", "options": ["Walk to the corner and back", "Text one person \"hey\"", "Wash my face", "Eat one thing", "Sit outside for 5 minutes", "Make my bed", "Listen to one song", "Open the blinds"], "feeds": "move"}, {"id": "minimum", "title": "Step 4 — My hard-day minimum", "maxPicks": 2, "instruction": "Choose up to 2.", "options": ["Take my meds", "Eat one meal", "Drink water", "Get out of bed once", "Text one person", "Step outside", "Shower or wash up", "Keep my appointment"], "crisisLink": true}],
  },

  anxiety: {
    exerciseId: "fact-or-forecast",
    toolName: "Alarm Decoder",
    toolIntro: "Figure out whether your alarm means danger or discomfort.",
    welcome: [
      "Have you ever felt on edge and couldn't tell if something was actually wrong or if it was just anxiety?",
      "Maybe your heart races in situations that seem fine to everyone else.",
      "Anxiety isn't lying to hurt you — it's an alarm that's overprotective.",
    ],
    checklist: [
      "I feel on edge without a clear reason.",
      "My body reacts before my mind catches up.",
      "I avoid things that make me anxious.",
      "I can't always tell if the danger is real.",
      "Avoiding things seems to make the anxiety louder later.",
      "I want to understand why my alarm goes off so easily.",
    ],
    normalizing: "If this sounds like you, your alarm system just has the sensitivity turned up too high. That's common after stress and hard experiences, and it can be turned back down.",
    whyHard: {
      heading: "Why the alarm won't quiet down",
      body: "Anxiety once protected you from real danger. Now it can go off for things that aren't actually threats. Avoiding what scares you teaches the alarm that the fear was right, so it gets louder over time.",
      bullets: ["Body feeling wired for no clear reason", "Racing heart in safe situations", "Avoiding places or tasks", "Trouble telling real danger from false alarms", "Wanting relief but not knowing where to start"],
    },
    reframe: {
      heading: "Turn the volume down slowly",
      body: "Facing what scares you in small, manageable doses is what actually turns the alarm down. Avoiding it feels better today but keeps the volume high tomorrow.",
    },
    checkIn: [
      { id: "struggle", label: "How loud is your alarm today?", left: "Quiet", right: "Very loud", higherIsHarder: true },
      { id: "confidence", label: "How well can you tell false alarms from real danger?", left: "Not well", right: "Very well", higherIsHarder: false },
      { id: "support", label: "How hopeful do you feel that the alarm can turn down?", left: "Not hopeful", right: "Very hopeful", higherIsHarder: false },
    ],
    adelQuestions: [
      "What's one thing you've been avoiding because of the alarm?",
      "When has your alarm been wrong about danger before?",
    ],
    skillSteps: [{"id": "signals", "title": "Step 1 — My alarm signals", "maxPicks": 3, "instruction": "Choose up to 3.", "options": ["Tight chest", "Racing heart", "Fast breathing", "Stomach in knots", "Can't sit still", "Wanting to leave", "Thoughts racing", "Can't sleep"], "shared": "warningSigns", "feeds": "cue"}, {"id": "type", "title": "Step 2 — Danger or discomfort?", "maxPicks": 1, "instruction": "Most alarms are discomfort: it feels bad, but you're safe.", "options": ["Discomfort: it feels bad, but I'm safe", "Real danger: I need to act now", "Not sure yet"]}, {"id": "control", "title": "Step 3 — What I can control", "maxPicks": 2, "instruction": "Choose up to 2.", "options": ["Showing up", "Preparing ahead", "My breathing", "Asking a question", "Taking a break", "Who I bring with me", "How I talk to myself", "Nothing right now, and that's okay"]}, {"id": "response", "title": "Step 4 — My response", "maxPicks": 2, "instruction": "Choose up to 2.", "options": ["Fact or Forecast?", "Slow breathing", "Do two minutes of what I'm avoiding", "5-4-3-2-1", "Take a walk", "Talk to someone", "Stay and let it pass", "Go anyway"], "shared": "copingTools", "feeds": "move"}],
  },

  bipolar: {
    exerciseId: "find-your-anchor",
    toolName: "Mood Map",
    toolIntro: "Know your baseline and early signs, and who you'll tell.",
    careNote: ANY_TIME_HELP,
    welcome: [
      "Have you ever felt your mood swing so far, in either direction, that you couldn't predict yourself?",
      "Maybe the high times felt amazing at first, before things got out of hand.",
      "Bipolar disorder means mood moves in two directions, and both are worth understanding.",
    ],
    checklist: [
      "My mood swings hard, up or down.",
      "I've had times of big energy and big plans that later worried me.",
      "I've had low stretches that felt impossible to move through.",
      "I don't always notice a swing until it's already big.",
      "People close to me have noticed changes before I did.",
      "I want to catch my warning signs earlier.",
    ],
    normalizing: "If this sounds familiar, learning your own early warning signs is the single most useful skill. Catching a swing early keeps it from becoming a big one.",
    whyHard: {
      heading: "Why the up side is easy to miss",
      body: "The elevated side of bipolar disorder can feel like confidence, energy, or excitement at first, which makes it easy to miss as a warning sign. By the time it's obvious to you, it may already be affecting sleep, spending, or relationships.",
      bullets: ["Sleeping much less and not feeling tired", "Talking faster than usual", "Big spending or big plans", "Irritability with everyone", "Withdrawing during low stretches"],
    },
    reframe: {
      heading: "Reading the sky, not controlling the weather",
      body: "You can't stop moods from moving. You can learn to read the early signs, the way you'd read a change in the sky, and act before the storm gets big.",
    },
    checkIn: [
      { id: "struggle", label: "How unpredictable has your mood felt lately?", left: "Steady", right: "Very unpredictable", higherIsHarder: true },
      { id: "confidence", label: "How well do you know your own early warning signs?", left: "Not well", right: "Very well", higherIsHarder: false },
      { id: "support", label: "How willing are you to let someone flag your signs?", left: "Not willing", right: "Very willing", higherIsHarder: false },
    ],
    adelQuestions: [
      "Who in your life notices your signs before you do?",
      "What's your earliest warning sign, up or down?",
    ],
    skillSteps: [{"id": "baseline", "title": "Step 1 — My usual baseline", "maxPicks": 3, "instruction": "Choose up to 3.", "options": ["Sleep 7 to 9 hours", "Steady energy", "Talk at my normal speed", "Spend what I planned", "Get along with people", "Keep my routine", "Interested in things", "Think clearly"]}, {"id": "up", "title": "Step 2 — Signs my energy is going up", "maxPicks": 3, "instruction": "Choose up to 3.", "options": ["Sleeping less and not tired", "Talking fast", "Making big plans", "Spending money", "Irritable", "Racing thoughts", "Taking risks", "Starting lots of things"], "feeds": "cue"}, {"id": "down", "title": "Step 3 — Signs my mood is going down", "maxPicks": 3, "instruction": "Choose up to 3.", "options": ["Sleeping a lot", "No energy", "Pulling away from people", "Losing interest", "Feeling hopeless", "Skipping meals", "Can't focus"], "shared": "warningSigns", "crisisLink": true}, {"id": "people", "title": "Step 4 — My support people", "maxPicks": 2, "instruction": "Choose up to 2.", "options": ["A family member", "Peer specialist", "Case manager", "Counselor", "Prescriber", "A friend I trust", "Sponsor"], "shared": "supportPeople"}, {"id": "ask", "title": "Step 5 — What I want them to do", "maxPicks": 3, "instruction": "Choose up to 3.", "options": ["Check in on me", "Remind me to sleep", "Hold my cards or cash", "Call my prescriber with me", "Drive me to an appointment", "Tell me what they're noticing", "Sit with me", "Call 988 with me"], "feeds": "move"}],
  },

  ptsd: {
    exerciseId: "here-not-there",
    toolName: "Now & Then Safety Check",
    toolIntro: "A five-step check for when the past pulls you back.",
    welcome: [
      "Have you ever had a memory or reaction hit you out of nowhere, like your body went somewhere your mind didn't choose?",
      "Maybe a smell, a voice, or a hallway dropped you right back into a hard moment.",
      "Trauma isn't stored like a regular memory, and that's not a flaw in you.",
    ],
    checklist: [
      "Certain triggers bring me right back to a bad memory.",
      "My body reacts before I understand why.",
      "I feel far away or numb sometimes.",
      "I get angry fast without knowing the full reason.",
      "I've been told I'm \"stuck in the past.\"",
      "I want to understand why this happens.",
    ],
    normalizing: "If this sounds familiar, your survival system is doing its job a little too well. It hasn't gotten the message that the danger is over, and that can change with the right support.",
    whyHard: {
      heading: "Why your body reacts before your mind does",
      body: "Trauma gets stored in a way that skips straight to your body's alarm system. That's why a smell or sound can trigger a full reaction before you've even had a conscious thought about it. It's a survival response, not weakness.",
      bullets: ["Chest tightening out of nowhere", "Going numb or feeling far away", "Getting angry fast", "Needing to leave a room suddenly", "Losing track of what happened right after"],
    },
    reframe: {
      heading: "It's not happening again",
      body: "Your body remembers like the danger is happening right now, even though it isn't. Grounding tools help your body catch up to the truth: you're here, and it's over.",
    },
    checkIn: [
      { id: "struggle", label: "How often are old memories hitting you right now?", left: "Rarely", right: "Very often", higherIsHarder: true },
      { id: "confidence", label: "How able are you to come back after a hard moment?", left: "Not able", right: "Very able", higherIsHarder: false },
      { id: "support", label: "How safe do you feel telling someone when this happens?", left: "Not safe", right: "Safe", higherIsHarder: false },
    ],
    adelQuestions: [
      "What helps you come back after one of those moments?",
      "Is there a place or sound that tends to trigger this?",
    ],
    skillSteps: [{"id": "notice", "title": "Step 1 — What I notice", "maxPicks": 3, "instruction": "Choose up to 3.", "options": ["Heart pounding", "Feeling far away", "On guard", "Snapping fast", "Images or flashbacks", "A smell or sound pulls me back", "Can't catch my breath", "Wanting to use to make it stop"], "shared": "warningSigns", "feeds": "cue"}, {"id": "check", "title": "Step 2 — Am I safe right now?", "maxPicks": 1, "instruction": "Pick one.", "options": ["Yes, I'm safe right now", "I'm not sure", "No, I need to get somewhere safe"], "crisisLink": true}, {"id": "now", "title": "Step 3 — What tells me it's now", "maxPicks": 3, "instruction": "Choose up to 3.", "options": ["Today's date", "Where I am", "Who's with me", "What I'm wearing", "My phone", "The weather", "The sounds around me", "My own hands"]}, {"id": "ground", "title": "Step 4 — How I'll ground in the present", "maxPicks": 2, "instruction": "Choose up to 2.", "options": ["Here, Not There", "5-4-3-2-1", "Press my feet down", "Cold water", "Hold something solid", "Slow breathing", "Take a walk", "Call someone"], "shared": "copingTools", "feeds": "move"}, {"id": "statement", "title": "Step 5 — My safety statement", "maxPicks": 1, "instruction": "Pick one.", "options": ["\"That was then. This is now.\"", "\"I'm here, and I'm getting through this.\"", "\"This is a memory. It's not happening now.\"", "\"I survived it. I'm okay right now.\"", "\"My body is remembering. I'm here.\""]}],
  },

  psychosis: {
    exerciseId: "whats-my-brain-up-to",
    toolName: "Reality Check",
    toolIntro: "A way to check strong experiences with someone you trust.",
    welcome: [
      "Have you ever heard or seen something others didn't, or been told your mind was playing tricks?",
      "That experience can be confusing and scary, especially without a real explanation.",
      "Psychosis is a medical experience, not a moral failing, and it responds to treatment.",
    ],
    checklist: [
      "I've experienced things others said weren't there.",
      "I worry about what people think if they find out.",
      "I'm not always sure what makes it louder or quieter.",
      "I've skipped sleep and noticed it got worse.",
      "I want to know who to tell if things get loud again.",
      "I want to protect the routines that help me.",
    ],
    normalizing: "If this sounds like your experience, you're dealing with a health condition, not a character flaw. Sleep, routine, and staying connected to your care team all help keep things steady.",
    whyHard: {
      heading: "Why the filter can slip",
      body: "Psychosis happens when the brain's filter between inside and outside thoughts gets thin. Stress, poor sleep, and substances can make that filter slip further. None of that says anything about who you are as a person.",
      bullets: ["Thoughts that feel like voices", "Patterns that feel like hidden meaning", "Trouble sleeping", "Stress making things louder", "Wanting to protect your routine"],
    },
    reframe: {
      heading: "A treatment plan, not a verdict",
      body: "This is a condition with real treatment options: medication, routine, and a team that knows your history. Keeping your sleep and routine steady protects the filter that keeps things clear.",
    },
    checkIn: [
      { id: "struggle", label: "How loud or unsettled do things feel today?", left: "Quiet", right: "Very loud", higherIsHarder: true },
      { id: "confidence", label: "How well do you know what helps versus what makes it worse?", left: "Not well", right: "Very well", higherIsHarder: false },
      { id: "support", label: "How connected do you feel to your treatment team?", left: "Not connected", right: "Very connected", higherIsHarder: false },
    ],
    adelQuestions: [
      "Who's the first person you'd tell if things got loud again?",
      "What's one routine that's been helping your filter stay steady?",
    ],
    skillSteps: [{"id": "experiencing", "title": "Step 1 — What I'm experiencing", "maxPicks": 3, "instruction": "Choose up to 3.", "options": ["Hearing voices or sounds others don't", "Feeling watched", "Thoughts feel loud or fast", "Things feel unreal", "Not sleeping", "Feeling confused", "Suspicious of people", "Seeing things others don't"], "shared": "warningSigns", "feeds": "cue"}, {"id": "sure", "title": "Step 2 — What I know for sure", "maxPicks": 3, "instruction": "Choose up to 3.", "options": ["Where I am", "The date and time", "Who's with me", "I took my meds today", "I'm at home", "My phone works", "I can call someone", "I'm not sure right now"]}, {"id": "possibility", "title": "Step 3 — Another possibility", "maxPicks": 1, "instruction": "\"Not sure\" is a fine answer.", "options": ["It might be stress", "It might be lack of sleep", "It might be my illness", "It might be a misunderstanding", "I'm not sure, and that's okay"]}, {"id": "who", "title": "Step 4 — Who I'll check with", "maxPicks": 2, "instruction": "Choose up to 2.", "options": ["Case manager", "Prescriber", "Counselor", "Peer specialist", "A family member", "A friend I trust", "My care team's after-hours line"], "shared": "supportPeople"}, {"id": "next", "title": "Step 5 — My next safe step", "maxPicks": 1, "instruction": "Pick one.", "options": ["Call my care team", "Stay near someone I trust", "Protect my sleep tonight", "Take my meds as prescribed", "Go somewhere calm", "Don't act on it until I check with someone"], "crisisLink": true, "feeds": "move"}],
  },

  "my-triggers-2": {
    exerciseId: "cool-the-reaction",
    toolName: "Trigger Radar",
    toolIntro: "Map one trigger so you see it coming next time.",
    welcome: [
      "Have you ever gotten set off and only understood why afterward?",
      "It can feel random in the moment, like it came from nowhere.",
      "Most triggers are actually patterns your brain learned, and patterns can be spotted ahead of time.",
    ],
    checklist: [
      "Something sets me off before I realize what happened.",
      "I only figure out the trigger after the fact.",
      "I feel caught off guard often.",
      "I haven't written my triggers down before.",
      "I think I have more triggers than I really do.",
      "I want to plan ahead instead of reacting.",
    ],
    normalizing: "If this sounds like you, that's normal — triggers fire fast, before your thinking brain catches up. Once you write them down, most people find they have a short, plannable list.",
    whyHard: {
      heading: "Why triggers feel random",
      body: "A trigger is anything your brain has linked to a strong feeling or an old behavior. Because the link fires quickly, it can feel like it came out of nowhere, even though it's actually a pattern repeating.",
      bullets: ["Feeling caught off guard", "Reacting before thinking", "Assuming there are too many triggers to track", "Not noticing the pattern until later", "Wanting a plan instead of a surprise"],
    },
    reframe: {
      heading: "A short list, not an endless one",
      body: "Written down, most people find four or five triggers, not fifty. A short list is something you can actually plan around, instead of something that keeps surprising you.",
    },
    checkIn: [
      { id: "struggle", label: "How often do triggers catch you off guard?", left: "Rarely", right: "Very often", higherIsHarder: true },
      { id: "confidence", label: "How well do you know your top triggers?", left: "Not well", right: "Very well", higherIsHarder: false },
      { id: "support", label: "How ready do you feel to plan around them?", left: "Not ready", right: "Very ready", higherIsHarder: false },
    ],
    adelQuestions: [
      "Which one is most likely to show up this week?",
      "What usually happens right after a trigger hits you?",
    ],
    skillSteps: [{"id": "what", "title": "Step 1 — What happened", "maxPicks": 2, "instruction": "Choose up to 2.", "options": ["Payday", "Alone at night", "A fight with family", "Seeing an old friend", "A certain street or house", "Feeling disrespected", "Boredom", "Bad news"], "shared": "triggers", "feeds": "cue"}, {"id": "body", "title": "Step 2 — What I noticed in my body", "maxPicks": 3, "instruction": "Choose up to 3.", "options": ["Hot face", "Tight chest", "Fists clenched", "Heart racing", "Stomach drop", "Shaky", "Craving", "Numb"]}, {"id": "urge", "title": "Step 3 — What I wanted to do", "maxPicks": 2, "instruction": "Choose up to 2.", "options": ["Use", "Yell or fight", "Leave", "Shut down", "Be alone", "Call someone", "Eat or sleep", "Nothing, I just felt it"]}, {"id": "early", "title": "Step 4 — My early signal", "maxPicks": 2, "instruction": "Choose up to 2.", "options": ["Feeling restless", "Getting irritable", "Thinking about old times", "Skipping meals", "Not sleeping", "Avoiding people", "Cash in my pocket", "Driving past old places"], "shared": "warningSigns"}, {"id": "need", "title": "Step 5 — What I need", "maxPicks": 2, "instruction": "Choose up to 2.", "options": ["Cool the Reaction", "Leave and go somewhere safe", "Call my support person", "Go to a meeting", "Rest", "Eat", "Talk it out", "Stay away from that place for now"], "feeds": "move"}],
  },

  "my-strengths": {
    exerciseId: "look-for-the-strength",
    toolName: "Strengths Profile",
    toolIntro: "Your strengths, the proof, and where they can take you.",
    welcome: [
      "Have you ever been able to list everything wrong with you faster than anything right?",
      "It's easy to forget the skills you built just surviving hard things.",
      "Recovery gets built on what already works, not just what's broken.",
    ],
    checklist: [
      "I focus more on my flaws than my strengths.",
      "I forget what I've survived.",
      "I don't think of myself as resourceful.",
      "I struggle to name a skill I have.",
      "I've helped people but don't count it as a strength.",
      "I want to see myself more fairly.",
    ],
    normalizing: "If this sounds like you, you're not alone — it's common to remember every mistake and forget the skills that got you through. Naming your strengths is inventory, not bragging.",
    whyHard: {
      heading: "Why strengths are hard to see in yourself",
      body: "Shame has a way of drowning out the good evidence. Surviving hard things actually builds real skills, like reading a room, handling pressure, and staying loyal, but those skills can feel invisible when shame is loud.",
      bullets: ["Focusing only on mistakes", "Forgetting what you've survived", "Not counting quiet strengths", "Comparing yourself to others", "Needing proof you're capable"],
    },
    reframe: {
      heading: "Experience, not zero",
      body: "You're not starting from nothing. You're starting from real experience, including the hard parts. That experience is the toolkit you already own.",
    },
    checkIn: [
      { id: "struggle", label: "How hard is it to name your own strengths right now?", left: "Easy", right: "Very hard", higherIsHarder: true },
      { id: "confidence", label: "How well do you see yourself as capable?", left: "Not well", right: "Very well", higherIsHarder: false },
      { id: "support", label: "How much do the people around you see your strengths?", left: "Not much", right: "A lot", higherIsHarder: false },
    ],
    adelQuestions: [
      "Where could you use one of your strengths this week?",
      "What's a strength someone else has pointed out in you?",
    ],
    skillSteps: [{"id": "strengths", "title": "Step 1 — My strengths", "maxPicks": 4, "instruction": "Choose up to 4.", "options": ["Hard-working", "Loyal", "Funny", "Good with my hands", "Caring", "Resilient", "Honest", "Good at reading people", "Creative", "Determined"]}, {"id": "evidence", "title": "Step 2 — The evidence", "maxPicks": 2, "instruction": "Choose up to 2.", "options": ["Got through something hard", "Took care of someone", "Learned a skill", "Kept a promise", "Showed up when it counted", "Helped someone in recovery", "Finished something", "Made someone laugh on a hard day"]}, {"id": "overlooked", "title": "Step 3 — One I overlooked", "maxPicks": 1, "instruction": "Pick one.", "options": ["Patience", "Courage to ask for help", "Staying calm under pressure", "Being a good listener", "Surviving", "Starting over", "Street smarts", "Faith"]}, {"id": "goal", "title": "Step 4 — Where I'll use it", "maxPicks": 1, "instruction": "Pick one.", "options": ["Finding work", "Rebuilding family", "Staying sober", "Getting housing", "Helping others", "Going back to school", "Getting healthy", "Being a good parent"], "shared": "values"}],
  },

  "treatment-team": {
    exerciseId: "get-the-support-i-need",
    toolName: "Who Do I Call? Guide",
    toolIntro: "Know who handles what before you need them.",
    welcome: [
      "Have you ever sat in an appointment full of titles and names and had no idea who actually does what?",
      "Prescriber, therapist, case manager, peer specialist — it can blur together fast.",
      "Knowing who's who means you stop waiting for the wrong person to help.",
    ],
    checklist: [
      "I get confused about who does what on my team.",
      "I don't know who to call for a specific problem.",
      "I've waited on the wrong person before.",
      "I don't feel like part of my own plan.",
      "I don't have everyone's contact info saved.",
      "I want to understand my team better.",
    ],
    normalizing: "If this sounds like you, that confusion is common — nobody hands you a manual. Learning each role, and remembering you're on the team too, changes how much you can use it.",
    whyHard: {
      heading: "Why the roles get confusing",
      body: "A treatment team usually includes a prescriber for medication, a therapist or counselor for talking work, a case manager for the practical stuff, and a peer specialist who's been where you are. Without clear roles, it's easy to call the wrong person or nobody at all.",
      bullets: ["Not knowing who to call", "Confusing roles", "Feeling like a case instead of a person", "Missing saved contact info", "Waiting instead of asking"],
    },
    reframe: {
      heading: "You're on the team too",
      body: "The plan doesn't work without your input. When you know who does what, you can bring the right question to the right person, and speak up as a full member of your own team.",
    },
    checkIn: [
      { id: "struggle", label: "How confusing does your treatment team feel right now?", left: "Clear", right: "Very confusing", higherIsHarder: true },
      { id: "confidence", label: "How well do you know who to call for what?", left: "Not well", right: "Very well", higherIsHarder: false },
      { id: "support", label: "How much do you feel like part of your own plan?", left: "Not much", right: "A lot", higherIsHarder: false },
    ],
    adelQuestions: [
      "Which of your team members do you know the least?",
      "What's one question you've been wanting to ask your team?",
    ],
    skillSteps: [{"id": "team", "title": "Step 1 — Who's on my team", "maxPicks": 6, "instruction": "Choose up to 6.", "options": ["Prescriber", "Counselor or therapist", "Case manager", "Peer specialist", "Primary care doctor", "Pharmacist", "Sponsor", "PO"], "shared": "careTeam"}, {"id": "meds", "title": "Step 2 — For medicine or side effects, I call", "maxPicks": 1, "instruction": "Pick one.", "options": ["Prescriber", "Counselor or therapist", "Case manager", "Peer specialist", "Primary care doctor", "Pharmacist", "Sponsor", "PO"], "optionsFrom": "team"}, {"id": "practical", "title": "Step 3 — For housing, benefits or paperwork, I call", "maxPicks": 1, "instruction": "Pick one.", "options": ["Prescriber", "Counselor or therapist", "Case manager", "Peer specialist", "Primary care doctor", "Pharmacist", "Sponsor", "PO"], "optionsFrom": "team"}, {"id": "hard", "title": "Step 4 — For a hard day or cravings, I call", "maxPicks": 1, "instruction": "Pick one.", "options": ["Prescriber", "Counselor or therapist", "Case manager", "Peer specialist", "Primary care doctor", "Pharmacist", "Sponsor", "PO"], "optionsFrom": "team"}, {"id": "after", "title": "Step 5 — After hours, I call", "maxPicks": 1, "instruction": "Pick one.", "options": ["My clinic's after-hours line", "My sponsor", "My peer specialist", "A family member", "988", "911 for an emergency"], "crisisLink": true}],
  },

  "recovery-journey-2": {
    exerciseId: "walk-the-stages",
    toolName: "You Are Here",
    toolIntro: "Mark where you are, how far you've come and what keeps you moving.",
    welcome: [
      "Have you ever wondered what recovery is actually supposed to look like over time?",
      "Maybe you pictured it as a straight line, and any setback felt like proof you'd failed.",
      "Recovery moves in stages, and going back a stage doesn't erase what you've learned.",
    ],
    checklist: [
      "I'm not sure what stage of recovery I'm in.",
      "I think of recovery as a straight line.",
      "A setback has made me feel like I started over.",
      "I don't have a clear picture of what's ahead.",
      "I want to know what to expect over time.",
      "I want to notice progress I've already made.",
    ],
    normalizing: "If this sounds like you, that's a common misunderstanding — recovery isn't a straight line for anyone. Knowing the stages can help you see exactly where you stand.",
    whyHard: {
      heading: "Why it doesn't feel like a road",
      body: "Recovery moves through stages: getting stable, building routines, reconnecting with people, growing into goals, and eventually helping others. Movement isn't a straight line, and going back a stage isn't starting over — you keep everything you learned.",
      bullets: ["Expecting a straight line", "Feeling like setbacks erase progress", "Not knowing what stage you're in", "Losing sight of how far you've come", "Wanting a clearer picture of what's next"],
    },
    reframe: {
      heading: "A direction, not a finish line",
      body: "Recovery isn't a day you arrive at. It's a direction you keep facing, even when the road curves back on itself for a while.",
    },
    checkIn: [
      { id: "struggle", label: "How unclear does your path forward feel right now?", left: "Clear", right: "Very unclear", higherIsHarder: true },
      { id: "confidence", label: "How well can you name your current stage?", left: "Not well", right: "Very well", higherIsHarder: false },
      { id: "support", label: "How hopeful do you feel about continuing forward?", left: "Not hopeful", right: "Very hopeful", higherIsHarder: false },
    ],
    adelQuestions: [
      "What would moving one step forward look like for you?",
      "What's one thing that would help you hold your current stage steady?",
    ],
    skillSteps: [{"id": "where", "title": "Step 1 — Where I am", "maxPicks": 1, "instruction": "Pick one.", "options": ["Getting stable", "Building strength", "Reconnecting", "Growing", "Thriving", "Not sure"]}, {"id": "done", "title": "Step 2 — What I've already done", "maxPicks": 4, "instruction": "Choose up to 4.", "options": ["Got out and stayed out", "Stayed sober for days or weeks", "Started treatment", "Took my meds", "Made a plan", "Reconnected with someone", "Learned my triggers", "Found my strengths"]}, {"id": "step", "title": "Step 3 — What moves me one step", "maxPicks": 2, "instruction": "Choose up to 2.", "options": ["Keep my appointments", "Go to meetings", "Use my coping tools", "Call my support person", "Take my meds", "Work on my sleep", "Ask for help sooner", "Track my mood"], "feeds": "move"}, {"id": "hold", "title": "Step 4 — What helps me hold my ground", "maxPicks": 3, "instruction": "Choose up to 3.", "options": ["Break the Link", "Change the Channel", "Fact or Forecast?", "Find Your Anchor", "Here, Not There", "Cool the Reaction", "Look for the Strength", "Walk the Stages"], "shared": "copingTools"}, {"id": "people", "title": "Step 5 — Who's walking with me", "maxPicks": 3, "instruction": "Choose up to 3.", "options": ["Sponsor", "Peer specialist", "Counselor", "Case manager", "A family member", "A friend in recovery", "My prescriber"], "shared": "supportPeople"}],
  },
};
