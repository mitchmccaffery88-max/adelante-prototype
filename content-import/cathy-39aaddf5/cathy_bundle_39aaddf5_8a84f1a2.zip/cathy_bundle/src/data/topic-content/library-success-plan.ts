import type { TopicContent } from "./types";

// My Success Plan — topic-specific content (batch 2).
export const SUCCESS_PLAN: Record<string, TopicContent> = {
  "my-vision": {
    exerciseId: "best-possible-self",
    toolName: "Future Snapshot",
    toolIntro: "A picture of your life a year from now.",
    welcome: [
      "Have you ever tried to picture your life in a year and come up blank?",
      "Survival mode trains you to look at today, not a year out.",
      "A vision isn't a fantasy. It's one ordinary day, imagined on purpose.",
      "Once you can see it, you can start walking toward it.",
    ],
    checklist: [
      "I haven't thought past this week in a long time.",
      "Picturing my future feels pointless or scary.",
      "I don't let myself want things.",
      "When I imagine a year ahead, it's blurry or empty.",
      "I focus on getting through today, not building toward anything.",
      "I'm not sure what an ordinary good day would even look like for me.",
    ],
    normalizing: "If picturing your future feels hard, that makes sense after surviving day to day for so long. A vision doesn't need to be big or perfect. It just needs to be specific enough to walk toward.",
    whyHard: {
      heading: "Why the future feels hard to picture",
      body: "When you've had to focus on getting through each day, your mind stops practicing the skill of looking ahead. That skill comes back with use, the same way any other one does.",
      bullets: ["Future feels blank or scary", "Hard to imagine wanting anything", "Only thinking day to day", "Afraid to hope in case it doesn't happen", "Not sure what \"good\" looks like for you"],
    },
    reframe: {
      heading: "One ordinary day, not a whole life",
      body: "You don't have to plan your whole future today. Picture one normal day a year out: where you wake up, what you do, who's around. That small, clear picture is enough to start pulling you forward.",
    },
    checkIn: [
      { id: "struggle", label: "How hard is it right now to picture your future?", left: "Easy", right: "Very hard", higherIsHarder: true },
      { id: "confidence", label: "How confident do you feel that a better day ahead is possible?", left: "Not confident", right: "Very confident", higherIsHarder: false },
      { id: "support", label: "How much hope do you feel about where things are headed?", left: "Little hope", right: "A lot of hope", higherIsHarder: false },
    ],
    adelQuestions: [
      "What's one small piece of your future that you actually let yourself want?",
      "Whose life, even one part of it, makes you think \"I want that for myself\"?",
    ],
    skillSteps: [
      { id: "home", title: "Step 1 — Home", instruction: "Pick one.", maxPicks: 1, options: ["My own place", "A room I rent", "With family", "Sober living", "A place for my kids", "Still figuring it out"] },
      { id: "work", title: "Step 2 — Work or purpose", instruction: "Choose up to 2.", maxPicks: 2, options: ["A steady job", "A trade", "School or training", "My own business", "Helping others in recovery", "Volunteering", "Caring for family"] },
      { id: "people", title: "Step 3 — People", instruction: "Choose up to 3.", maxPicks: 3, options: ["My kids", "My partner", "My parents", "Friends in recovery", "A sponsor", "A church family", "Coworkers"] },
      { id: "health", title: "Step 4 — Health and recovery", instruction: "Choose up to 2.", maxPicks: 2, options: ["Sober a year", "Steady on my meds", "Sleeping well", "Working out", "At meetings every week", "Sponsoring someone", "Feeling calm most days"] },
      { id: "sentence", title: "Step 5 — A year from now, I'm...", instruction: "Pick one.", maxPicks: 1, shared: "values", options: ["Stable and sober", "Working and paying my own way", "Back in my kids' lives", "Proud of myself", "Helping others", "Living my values"] },
    ],
  },

  "goals-that-matter": {
    exerciseId: "woop",
    toolName: "Goal Card",
    toolIntro: "One clear goal with a reason, an obstacle and a date.",
    welcome: [
      "Have you ever set a goal like \"do better\" and never touched it again?",
      "It sounded good for about a day, then it just faded.",
      "A wish and a goal look similar but they work completely differently.",
    ],
    checklist: [
      "My goals are things like \"be better\" with no details.",
      "I set goals other people wanted for me, not ones I chose.",
      "I forget my goals within a few days.",
      "I don't put a date on anything.",
      "My goals feel too big to actually start.",
      "I've stopped trusting myself to follow through.",
    ],
    normalizing: "Vague goals aren't a character flaw. They're just missing a couple of pieces. Add a number and a date, and a wish turns into something you can actually chase.",
    whyHard: {
      heading: "Why vague goals go nowhere",
      body: "Your brain can't act on \"be healthier.\" It has nothing to grab onto. A goal that names exactly what, by when, and why it matters to you gives your brain something real to work with.",
      bullets: ["No clear finish line", "No date attached", "Borrowed from someone else's expectations", "Too big to picture starting", "Easy to forget by the end of the week"],
    },
    reframe: {
      heading: "What, by when, and why it's mine",
      body: "Take any wish and answer three questions: what exactly am I doing, by when, and why does this matter to me, not just to someone watching me. That's a real goal.",
    },
    checkIn: [
      { id: "struggle", label: "How vague do your current goals feel?", left: "Very clear", right: "Very vague", higherIsHarder: true },
      { id: "confidence", label: "How confident are you that you could write one real goal today?", left: "Not confident", right: "Very confident", higherIsHarder: false },
      { id: "support", label: "How much does this goal feel like it's actually yours?", left: "Not mine", right: "Fully mine", higherIsHarder: false },
    ],
    adelQuestions: [
      "What's a wish you've had for a while that you haven't turned into a real goal yet?",
      "Whose expectations, if anyone's, are mixed into your goals right now?",
    ],
    skillSteps: [
      { id: "area", title: "Step 1 — Goal area", instruction: "Pick one.", maxPicks: 1, options: ["Recovery", "Housing", "Work", "Family", "Health", "Money", "Education", "Legal"] },
      { id: "goal", title: "Step 2 — My goal", instruction: "Make it specific. Edit it in the box.", maxPicks: 1, options: ["Get my GED", "Find a steady job", "Move into my own place", "See my kids every week", "Save $500", "Finish probation", "Get my license back", "90 days sober"] },
      { id: "why", title: "Step 3 — Why it matters", instruction: "Choose up to 2.", maxPicks: 2, shared: "reasons", options: ["My kids", "Freedom", "Self-respect", "My health", "Being trusted again", "A better life", "Peace of mind"] },
      { id: "obstacle", title: "Step 4 — My main obstacle inside", instruction: "Pick one.", maxPicks: 1, options: ["Putting it off", "Fear of failing", "Doubting myself", "Getting overwhelmed", "Giving up when it's hard", "Not asking for help"] },
      { id: "by", title: "Step 5 — By when", instruction: "Pick one.", maxPicks: 1, options: ["30 days", "60 days", "90 days", "6 months", "A year"] },
    ],
  },

  "breaking-goals": {
    exerciseId: "smallest-step",
    toolName: "Step Ladder",
    toolIntro: "Turn a goal into five steps and start on the first.",
    welcome: [
      "Have you ever known your goal clearly and still couldn't make yourself start?",
      "The goal isn't the problem. Step one might just be too big.",
      "A first step should feel almost too easy to skip.",
    ],
    checklist: [
      "My goal feels clear but I still don't start.",
      "The first step in my head is actually a huge task.",
      "I put things off because I don't know where to begin.",
      "I feel behind before I even start.",
      "I've abandoned goals because the first move felt overwhelming.",
      "I do better when a task is broken into small pieces.",
    ],
    normalizing: "Stalling isn't laziness. It usually means the first step is too big to picture doing today. Shrinking it down is the fix, not trying harder.",
    whyHard: {
      heading: "Why a big first step stops you cold",
      body: "When step one feels like a mountain, your brain avoids it entirely. Momentum comes from finishing something small, not from staring at something huge.",
      bullets: ["First step actually contains five steps", "No clear starting point", "Feeling overwhelmed before beginning", "Waiting for a \"good time\" that never comes", "Abandoning the goal instead of shrinking it"],
    },
    reframe: {
      heading: "Shrink it until it's ten minutes",
      body: "If your first step takes more than ten minutes or one phone call, it's not actually step one. Keep breaking it down until it's small enough that skipping it feels silly.",
    },
    checkIn: [
      { id: "struggle", label: "How stuck do you feel on your first step?", left: "Not stuck", right: "Very stuck", higherIsHarder: true },
      { id: "confidence", label: "How confident are you that you could finish today's tiny step?", left: "Not confident", right: "Very confident", higherIsHarder: false },
      { id: "support", label: "How doable does your goal feel once it's broken down?", left: "Not doable", right: "Very doable", higherIsHarder: false },
    ],
    adelQuestions: [
      "What's one goal where you know the destination but not the first step?",
      "What would the ten-minute version of that first step look like?",
    ],
    skillSteps: [
      { id: "goal", title: "Step 1 — My goal", instruction: "Pick one.", maxPicks: 1, options: ["Get my GED", "Find a steady job", "Move into my own place", "See my kids every week", "Save money", "Finish probation", "Get my license back", "Stay sober"] },
      { id: "steps", title: "Step 2 — My steps", instruction: "Pick up to five, or type your own.", maxPicks: 5, options: ["Make a call", "Look something up", "Fill out a form", "Get a document", "Ask for help", "Sign up", "Set an appointment", "Save a little"] },
      { id: "first", title: "Step 3 — My first step", instruction: "Pick one.", maxPicks: 1, optionsFrom: "steps", feeds: "move", options: ["Make a call", "Look something up", "Fill out a form", "Get a document", "Ask for help", "Sign up", "Set an appointment", "Save a little"] },
      { id: "by", title: "Step 4 — By when", instruction: "Pick one.", maxPicks: 1, options: ["Today", "Tomorrow", "This week", "Next week"] },
      { id: "who", title: "Step 5 — Who can help", instruction: "Pick one.", maxPicks: 1, shared: "supportPeople", options: ["Case manager", "Peer specialist", "Sponsor", "A family member", "A friend", "211"] },
    ],
  },

  "action-plan": {
    exerciseId: "step-day-time",
    toolName: "Action Board",
    toolIntro: "This week's steps, each with a day and a time.",
    welcome: [
      "Have you ever known exactly what to do but the week slipped by anyway?",
      "Steps that float without a day attached tend to disappear.",
      "Giving each step a place to live changes whether it actually happens.",
    ],
    checklist: [
      "I know my steps but the week goes by without doing them.",
      "My plans live in my head, not on paper or my phone.",
      "I say \"sometime this week\" instead of picking a day.",
      "I forget steps I meant to do.",
      "I take on too many steps and finish none.",
      "I do better when something has a specific time attached.",
    ],
    normalizing: "A list without days on it is easy to lose. This isn't about willpower. It's about giving each step somewhere specific to happen.",
    whyHard: {
      heading: "Why a floating step disappears",
      body: "\"Sometime this week\" competes with everything else that shows up. A step tied to a real day and time doesn't have to compete, because it already has a place.",
      bullets: ["Steps with no day attached", "Too many steps planned at once", "Vague timing like \"soon\"", "Plans only in your head", "Days filling up with other things first"],
    },
    reframe: {
      heading: "Three steps, three real slots",
      body: "Pick three steps for the week, no more. Attach each one to a real slot in your week that already exists, like after an appointment or on a lunch break. A step with a slot is far more likely to happen.",
    },
    checkIn: [
      { id: "struggle", label: "How often do your planned steps slip through the week?", left: "Rarely", right: "Almost always", higherIsHarder: true },
      { id: "confidence", label: "How confident are you that you can follow through this week?", left: "Not confident", right: "Very confident", higherIsHarder: false },
      { id: "support", label: "How clear is your plan for this week right now?", left: "Not clear", right: "Very clear", higherIsHarder: false },
    ],
    adelQuestions: [
      "What time slot in your week is actually free and reliable?",
      "What's the one step that would matter most if you did it this week?",
    ],
    skillSteps: [
      { id: "steps", title: "Step 1 — This week's three steps", instruction: "Choose up to 3.", maxPicks: 3, options: ["Make a call", "Fill out a form", "Get a document", "Go to an appointment", "Apply for something", "Ask for help", "Look something up", "Save money"] },
      { id: "days", title: "Step 2 — The days", instruction: "Choose up to 3.", maxPicks: 3, options: ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"] },
      { id: "time", title: "Step 3 — The time of day", instruction: "Pick one.", maxPicks: 1, options: ["Morning", "Right after breakfast", "Midday", "Afternoon", "Evening"] },
      { id: "ready", title: "Step 4 — What I need ready", instruction: "Choose up to 3.", maxPicks: 3, options: ["Phone charged", "ID", "Paperwork", "A ride", "Numbers saved", "Money", "Someone with me"] },
    ],
  },

  "habits-goals": {
    exerciseId: "habit-rehearsal",
    toolName: "Never Miss Twice",
    toolIntro: "A habit that supports your goal, with one rule.",
    welcome: [
      "Have you ever done great for a week and then watched it all fall apart?",
      "Effort runs out, but a habit doesn't ask you to decide every time.",
      "A habit needs a cue, a small action, and a way to see it's happening.",
    ],
    checklist: [
      "I do well for a while and then it falls apart.",
      "I rely on willpower instead of routine.",
      "I don't attach new habits to anything already happening.",
      "I don't track or mark what I've done.",
      "I try to change too many things at once.",
      "I lose momentum after a few days off.",
    ],
    normalizing: "Falling off after a strong week doesn't mean you failed. It usually means the habit wasn't built into a loop yet. Loops hold up when effort runs out.",
    whyHard: {
      heading: "Why effort alone doesn't last",
      body: "Effort takes energy you don't always have. A habit takes almost none once it's linked to something you already do every day. That's the difference between trying hard and building a loop.",
      bullets: ["Relying on willpower", "No clear daily cue", "Nothing to mark progress", "Trying to change everything at once", "Missing one day and giving up entirely"],
    },
    reframe: {
      heading: "Cue, action, mark",
      body: "Pick something that already happens every day as your cue. Attach one small action to it. Mark it somewhere you can see. That loop, repeated, becomes automatic.",
    },
    checkIn: [
      { id: "struggle", label: "How often do your good habits fall apart?", left: "Rarely", right: "Almost always", higherIsHarder: true },
      { id: "confidence", label: "How confident are you that you could build one small habit loop this week?", left: "Not confident", right: "Very confident", higherIsHarder: false },
      { id: "support", label: "How clear is the cue you'd attach a new habit to?", left: "Not clear", right: "Very clear", higherIsHarder: false },
    ],
    adelQuestions: [
      "What's something you already do every single day, no matter what?",
      "What's one small habit you'd like to attach to that daily moment?",
    ],
    skillSteps: [
      { id: "habit", title: "Step 1 — The habit", instruction: "Pick one.", maxPicks: 1, shared: "dailyHabits", options: ["Check job listings", "Study for 15 minutes", "Save a little each day", "Walk", "Read", "Call my kids", "Go to a meeting", "Go to bed on time"] },
      { id: "when", title: "Step 2 — When I'll do it", instruction: "Pick one.", maxPicks: 1, options: ["After breakfast", "After my meds", "At lunch", "After work", "After dinner", "Before bed"] },
      { id: "tiny", title: "Step 3 — The bad-day version", instruction: "Pick one.", maxPicks: 1, feeds: "move", options: ["Two minutes", "Just open the app", "One page", "One dollar", "Around the block", "A short text"] },
      { id: "track", title: "Step 4 — How I'll track 14 days", instruction: "One rule: never miss twice in a row.", maxPicks: 1, options: ["Check it off in my toolkit", "Calendar on the wall", "Phone notes", "Tell Adel each day", "Tell my sponsor"] },
    ],
  },

  "staying-motivated": {
    exerciseId: "shrink-it",
    toolName: "Hard-Day Minimum",
    toolIntro: "The smallest version of your goals for the days you don't feel like it.",
    welcome: [
      "Have you ever felt your motivation drain out somewhere in the middle of a goal?",
      "The start feels exciting and the finish feels far away, but the middle is quiet.",
      "Motivation usually follows action, not the other way around.",
    ],
    checklist: [
      "I lose steam once the excitement of starting wears off.",
      "I wait to feel motivated before I do anything.",
      "I skip my goal entirely on hard days instead of shrinking it.",
      "I judge myself hard for slow progress.",
      "I compare my pace to other people.",
      "One skipped day often turns into several.",
    ],
    normalizing: "Losing steam in the middle is one of the most common parts of working toward any goal. It doesn't mean the goal was wrong. It means today needs a smaller version, not a skipped one.",
    whyHard: {
      heading: "Why waiting to feel motivated backfires",
      body: "Motivation often shows up after you start moving, not before. Waiting to feel ready can mean waiting a long time. Starting small, even without motivation, is what brings the feeling back.",
      bullets: ["Waiting to feel ready", "All-or-nothing thinking", "Skipping instead of shrinking", "Harsh self-judgment on slow days", "Comparing your pace to someone else's"],
    },
    reframe: {
      heading: "Shrink it, don't skip it",
      body: "On a low day, don't skip. Do the five-minute version instead of the thirty-minute one, or one call instead of five. Doing something small matters more than how big it is.",
    },
    checkIn: [
      { id: "struggle", label: "How much steam have you lost on your goal lately?", left: "Still going strong", right: "Almost stopped", higherIsHarder: true },
      { id: "confidence", label: "How confident are you that you could do a small version today?", left: "Not confident", right: "Very confident", higherIsHarder: false },
      { id: "support", label: "How okay do you feel doing a smaller version instead of quitting?", left: "Not okay", right: "Very okay", higherIsHarder: false },
    ],
    adelQuestions: [
      "What's the goal where your motivation has dropped the most right now?",
      "What would the five-minute version of that goal look like today?",
    ],
    skillSteps: [
      { id: "minimum", title: "Step 1 — My hard-day versions", instruction: "Choose up to 3.", maxPicks: 3, feeds: "move", options: ["Five minutes of the job search", "One page of studying", "Put $1 aside", "A short walk", "One text to my kids", "Take my meds", "Go to a meeting", "Get out of bed and get dressed"] },
      { id: "reasons", title: "Step 2 — My reasons", instruction: "Choose up to 3.", maxPicks: 3, shared: "reasons", options: ["My kids", "Staying out", "My health", "Being trusted again", "A job I want", "Peace of mind", "My family", "Self-respect"] },
      { id: "text", title: "Step 3 — Who I'll text", instruction: "Pick one.", maxPicks: 1, shared: "supportPeople", options: ["Sponsor", "Peer specialist", "A friend in recovery", "A family member", "Counselor"] },
      { id: "tell", title: "Step 4 — What I'll tell myself", instruction: "Pick one.", maxPicks: 1, crisisLink: true, options: ["\"Shrink it, don't skip it.\"", "\"Something beats nothing.\"", "\"Hard days count too.\"", "\"I don't have to feel it to do it.\"", "\"Tomorrow can be bigger.\""] },
    ],
  },

  setbacks: {
    exerciseId: "cope-ahead",
    toolName: "Cope-Ahead Card",
    toolIntro: "Get ready for a hard situation before it happens.",
    welcome: [
      "Have you ever had a solid plan get knocked over by something you didn't see coming?",
      "A ride falls through, bad news lands, and the whole week wobbles.",
      "Deciding what you'll do before the obstacle shows up changes everything.",
    ],
    checklist: [
      "Something always seems to knock my plan over.",
      "I don't decide what I'll do until I'm already stressed.",
      "One obstacle can derail my whole week.",
      "I don't have backup plans for common problems.",
      "I feel caught off guard by things that happen fairly often.",
      "I want to plan ahead but don't know where to start.",
    ],
    normalizing: "Plans getting knocked over isn't a sign you planned wrong. Life throws in predictable obstacles. Deciding your response ahead of time, while you're calm, is what protects the plan.",
    whyHard: {
      heading: "Why deciding in the moment is so hard",
      body: "Stress narrows your thinking right when you need it most. Deciding what you'll do while calm means you're not trying to think clearly and solve a problem at the same time.",
      bullets: ["Getting caught off guard", "Deciding while already stressed", "No backup plan in place", "One obstacle spiraling into a lost week", "Feeling like setbacks mean failure"],
    },
    reframe: {
      heading: "If this happens, then I do this",
      body: "Pick your most likely obstacle and write one sentence: \"If ___ happens, then I ___.\" You only have to decide once, while you're calm, and then just follow it later.",
    },
    checkIn: [
      { id: "struggle", label: "How often do setbacks knock your plans over?", left: "Rarely", right: "Very often", higherIsHarder: true },
      { id: "confidence", label: "How confident are you that you could handle your most likely setback?", left: "Not confident", right: "Very confident", higherIsHarder: false },
      { id: "support", label: "How ready do you feel with a backup plan?", left: "Not ready", right: "Very ready", higherIsHarder: false },
    ],
    adelQuestions: [
      "What obstacle is most likely to show up for you in the next thirty days?",
      "Who or what could be your backup plan when that obstacle happens?",
    ],
    skillSteps: [
      { id: "coming", title: "Step 1 — What's coming", instruction: "Pick one.", maxPicks: 1, feeds: "cue", options: ["A court date", "A family visit", "A holiday", "A job interview", "An anniversary", "Payday", "Seeing an old friend", "A medical appointment"] },
      { id: "wrong", title: "Step 2 — What could go wrong", instruction: "Choose up to 2.", maxPicks: 2, options: ["I get angry", "I get a craving", "I shut down", "Someone pushes my buttons", "Bad news", "I feel left out", "I panic"] },
      { id: "skills", title: "Step 3 — Skills I'll use", instruction: "Choose up to 3.", maxPicks: 3, shared: "copingTools", feeds: "move", options: ["STOP", "Hand Brake", "Time-Out Done Right", "Turn, Walk, Call", "5-4-3-2-1", "Urge Surfing", "Slow breathing", "Call someone"] },
      { id: "who", title: "Step 4 — Who's in my corner that day", instruction: "Choose up to 2.", maxPicks: 2, shared: "supportPeople", crisisLink: true, options: ["Sponsor", "Peer specialist", "A family member", "A friend in recovery", "Counselor", "Case manager"] },
      { id: "reward", title: "Step 5 — How I'll reward myself after", instruction: "Pick one.", maxPicks: 1, options: ["A good meal", "A movie", "Call someone I love", "Rest", "Something I've been wanting", "Share it at a meeting"] },
    ],
  },

  "success-system": {
    exerciseId: "daily-ritual-run",
    toolName: "Success System",
    toolIntro: "Your daily, weekly and bad-day routines in one place.",
    welcome: [
      "Have you ever had tools scattered everywhere but nothing that ties them together?",
      "A breathing exercise here, a goal there, a plan for bad days somewhere else.",
      "A system just puts all of it in one place, in one order.",
    ],
    checklist: [
      "I have tools and plans scattered in different places.",
      "I don't have one clear daily routine.",
      "I don't have a set weekly commitment I count on.",
      "I don't have a plan for what to do on a bad day.",
      "Nobody checks in on how I'm doing regularly.",
      "I've never written all of this down in one place.",
    ],
    normalizing: "Having pieces scattered around isn't a failure. Most people build tools one at a time. Putting them in one simple system just makes them easier to use when you actually need them.",
    whyHard: {
      heading: "Why scattered tools are hard to use",
      body: "A tool you have to hunt for isn't a tool you'll use in the moment. A system written in one place, in a clear order, is something you can hand to yourself, a counselor, or a sponsor on any given day.",
      bullets: ["Tools spread across different places", "No clear daily routine", "No named check-in person", "No written bad-day plan", "Nothing to hand a counselor or sponsor"],
    },
    reframe: {
      heading: "Daily, weekly, people, bad-day",
      body: "A system is four short lists: what I do daily, what I do weekly, who checks on me, and what I do when it goes sideways. Written on one page, it works even on days you're not thinking clearly.",
    },
    checkIn: [
      { id: "struggle", label: "How scattered do your tools and plans feel right now?", left: "Organized", right: "Very scattered", higherIsHarder: true },
      { id: "confidence", label: "How confident are you that you could write your system on one page?", left: "Not confident", right: "Very confident", higherIsHarder: false },
      { id: "support", label: "How supported would you feel with this written down?", left: "Not supported", right: "Very supported", higherIsHarder: false },
    ],
    adelQuestions: [
      "What tool or habit have you built that deserves a spot in your system?",
      "Who checks on you regularly enough that they belong in your system?",
    ],
    skillSteps: [
      { id: "daily", title: "Step 1 — Every day", instruction: "Choose up to 3.", maxPicks: 3, shared: "dailyHabits", options: ["Morning breath tool", "Look at my plan", "Take my meds", "Check in with someone", "A meeting", "Track my mood", "Wind down at night"] },
      { id: "weekly", title: "Step 2 — Every week", instruction: "Choose up to 3.", maxPicks: 3, options: ["Sunday planning", "A counseling visit", "Meetings", "Call my sponsor", "Review my goals", "Budget check", "Laundry and groceries"] },
      { id: "people", title: "Step 3 — My people", instruction: "Choose up to 3.", maxPicks: 3, shared: "supportPeople", options: ["Sponsor", "Peer specialist", "Counselor", "Case manager", "A family member", "A friend in recovery"] },
      { id: "badday", title: "Step 4 — My bad-day plan", instruction: "Choose up to 3.", maxPicks: 3, shared: "copingTools", feeds: "move", options: ["Shrink it, don't skip it", "Call my 2 a.m. person", "Go to a meeting", "Use my coping tools", "Rest and eat", "Read my reasons"] },
    ],
  },

  "celebrating-progress": {
    exerciseId: "savor-the-win",
    toolName: "Wins Wall",
    toolIntro: "See your progress and mark it, sober.",
    welcome: [
      "Have you ever looked back at a week and only noticed what you didn't get done?",
      "Your brain is wired to remember misses more than wins.",
      "Counting your wins on purpose is part of the work, not extra credit.",
    ],
    checklist: [
      "I only notice what I haven't done yet.",
      "I forget the hard things I've already gotten through.",
      "I brush off compliments or good news about myself.",
      "I don't tell anyone when I do something well.",
      "I feel like nothing counts unless it's a big accomplishment.",
      "I've been in this program longer than I give myself credit for.",
    ],
    normalizing: "Focusing on what's missing instead of what's done isn't a flaw. It's how most brains work under stress. Naming your wins out loud is a skill you can build like any other.",
    whyHard: {
      heading: "Why wins are easy to miss",
      body: "Your brain records failures more strongly than successes, because failures once felt more urgent to remember. That means progress has to be counted on purpose, or it slips by unnoticed.",
      bullets: ["Only noticing what's undone", "Dismissing small wins as \"not enough\"", "Forgetting hard days you got through", "Rarely telling anyone about a win", "Feeling like nothing counts unless it's huge"],
    },
    reframe: {
      heading: "Small wins are still wins",
      body: "Kept an appointment. Asked for help. Told the truth when it was hard. None of those are small when you add them up over a month. Read the list back — that's your life moving forward.",
    },
    checkIn: [
      { id: "struggle", label: "How much do you focus on what's missing instead of what's done?", left: "Rarely", right: "Almost always", higherIsHarder: true },
      { id: "confidence", label: "How confident are you that you could name three wins right now?", left: "Not confident", right: "Very confident", higherIsHarder: false },
      { id: "support", label: "How proud do you feel of your progress lately?", left: "Not proud", right: "Very proud", higherIsHarder: false },
    ],
    adelQuestions: [
      "What's a win from the last month you haven't told anyone about?",
      "Who would be glad to hear about that win if you told them?",
    ],
    skillSteps: [
      { id: "wins", title: "Step 1 — My wins this month", instruction: "Choose up to 4.", maxPicks: 4, options: ["Lessons I finished", "Plans I made", "Days sober", "Appointments I kept", "A paycheck", "Time with my kids", "A hard day I got through", "A promise I kept"] },
      { id: "own", title: "Step 2 — My own wins", instruction: "Choose up to 2.", maxPicks: 2, options: ["Got my ID", "Found housing", "Got a job", "Made amends", "Helped someone", "Stayed out of trouble", "Asked for help"] },
      { id: "mark", title: "Step 3 — How I'll mark them", instruction: "Choose up to 2.", maxPicks: 2, feeds: "move", options: ["A good meal", "New shoes", "A day at the lake", "Call my kids", "Share at a meeting", "A movie", "A sober get-together"] },
      { id: "tell", title: "Step 4 — Who I'll tell", instruction: "Choose up to 2.", maxPicks: 2, shared: "supportPeople", options: ["Sponsor", "Peer specialist", "A family member", "A friend in recovery", "My counselor", "My meeting"] },
    ],
  },

  "future-roadmap": {
    exerciseId: "walk-the-horizon",
    toolName: "The Roadmap",
    toolIntro: "Your plan past day 90, built from the tools in this module.",
    welcome: [
      "Have you ever wanted one clear picture of where all your effort is actually headed?",
      "Small steps matter, but sometimes you need to see the bigger shape too.",
      "A roadmap holds the next thirty days, six months, and year together in one place.",
    ],
    checklist: [
      "I don't have a clear picture of where I'm headed past this week.",
      "My goals feel disconnected from each other.",
      "I've written plans before but never looked at them again.",
      "I want to see how today connects to a year from now.",
      "I don't review my plans regularly.",
      "I feel like I'm working hard without a clear direction.",
    ],
    normalizing: "Not having a clear roadmap doesn't mean you're behind. Most plans fall apart from being too big, not from being written poorly. A roadmap works when it stays simple and gets checked regularly.",
    whyHard: {
      heading: "Why big plans fall apart",
      body: "A plan that tries to hold everything becomes too heavy to actually use. A roadmap works in layers, a few items each, so you always know what belongs to right now and what belongs to later.",
      bullets: ["Trying to plan everything at once", "No layers between now and later", "Writing a plan and never reviewing it", "Losing sight of the bigger picture", "Feeling busy without feeling like you're going anywhere"],
    },
    reframe: {
      heading: "Three horizons, reviewed monthly",
      body: "Next 30 days is about staying stable. Next 6 months is about building something. The next year is your vision. Each layer only needs two or three items, and a monthly look keeps the whole map alive.",
    },
    checkIn: [
      { id: "struggle", label: "How unclear does your path forward feel right now?", left: "Very clear", right: "Very unclear", higherIsHarder: true },
      { id: "confidence", label: "How confident are you that you could write a simple roadmap today?", left: "Not confident", right: "Very confident", higherIsHarder: false },
      { id: "support", label: "How connected does today feel to where you want to be in a year?", left: "Not connected", right: "Very connected", higherIsHarder: false },
    ],
    adelQuestions: [
      "What's one thing you want finished in the next 90 days?",
      "What would \"building something\" look like for you over the next six months?",
    ],
    skillSteps: [
      { id: "thirty", title: "Step 1 — In 30 days", instruction: "Choose up to 2.", maxPicks: 2, options: ["Steady routine", "Keep my appointments", "Start a job search", "A meeting every week", "Stay sober", "Get my documents"] },
      { id: "ninety", title: "Step 2 — In 90 days", instruction: "Choose up to 2.", maxPicks: 2, options: ["A steady job", "Stable housing", "Off a waitlist", "90 days sober", "Back in touch with family", "Done with a class"] },
      { id: "year", title: "Step 3 — In one year", instruction: "Choose up to 2.", maxPicks: 2, shared: "values", options: ["My own place", "A career started", "My kids in my life", "A year sober", "Off probation", "Helping others"] },
      { id: "share", title: "Step 4 — Who I'll share it with", instruction: "Choose up to 2.", maxPicks: 2, shared: "supportPeople", options: ["Sponsor", "Peer specialist", "Counselor", "Case manager", "A family member", "A friend in recovery"] },
      { id: "review", title: "Step 5 — When I'll review it", instruction: "Pick one.", maxPicks: 1, options: ["First Sunday of every month", "At my monthly counseling visit", "On my sober anniversary each month", "With my case manager each month"] },
    ],
  },
};
