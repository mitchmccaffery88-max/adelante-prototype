import type { CanonicalModule } from "../module-schema";
import type { TopicContent } from "./types";
import { STARTING_STRONG } from "./library-starting-strong";
import { UNDERSTANDING_DIAGNOSIS } from "./library-understanding";
import { TREATMENT } from "./library-treatment";
import { TRAIN_MIND } from "./library-train-mind";
import { STRENGTHEN_RECOVERY } from "./library-strengthen-recovery";
import { BIG_EMOTIONS } from "./library-big-emotions";
import { SUPPORT_TEAM } from "./library-support-team";
import { BACK_ON_FEET } from "./library-back-on-feet";
import { SUCCESS_PLAN } from "./library-success-plan";
import { FIRST_DAYS } from "./recovery-first-days";
import { MY_PEOPLE } from "./recovery-my-people";
import { UNDERSTANDING_ADDICTION } from "./recovery-understanding";
import { EVERYDAY_LIFE } from "./recovery-everyday-life";
import { RELATIONSHIPS } from "./recovery-relationships";
import { LIFE_THAT_WORKS } from "./recovery-life-that-works";
import { WHEN_HARD } from "./recovery-when-hard";
import { SOMEONE_NEW } from "./recovery-someone-new";
import { LIVING_RECOVERY } from "./recovery-living-recovery";
import { LIBRARY_CARE_NOTES, RECOVERY_CARE_NOTES } from "../care-notes";
import { RELATED_LESSONS } from "../related-lessons";

export type { TopicContent } from "./types";

export const LIBRARY_TOPICS: Record<string, TopicContent> = {
  ...STARTING_STRONG, ...UNDERSTANDING_DIAGNOSIS, ...TREATMENT, ...TRAIN_MIND,
  ...STRENGTHEN_RECOVERY, ...BIG_EMOTIONS, ...SUPPORT_TEAM, ...BACK_ON_FEET, ...SUCCESS_PLAN,
};
export const RECOVERY_TOPICS: Record<string, TopicContent> = {
  ...FIRST_DAYS, ...MY_PEOPLE, ...UNDERSTANDING_ADDICTION, ...EVERYDAY_LIFE,
  ...RELATIONSHIPS, ...LIFE_THAT_WORKS, ...WHEN_HARD, ...SOMEONE_NEW, ...LIVING_RECOVERY,
};

for (const topics of [LIBRARY_TOPICS, RECOVERY_TOPICS]) {
  for (const [id, related] of Object.entries(RELATED_LESSONS)) {
    const topic = topics[id];
    if (topic) topics[id] = { ...topic, related: [...new Set([...(topic.related ?? []), ...related])] };
  }
}

for (const [topics, notes] of [[LIBRARY_TOPICS, LIBRARY_CARE_NOTES], [RECOVERY_TOPICS, RECOVERY_CARE_NOTES]] as const) {
  for (const [id, careNote] of Object.entries(notes)) {
    const topic = topics[id];
    if (topic) topics[id] = { ...topic, careNote };
  }
}

/** Overlay topic-specific content onto a canonical module. Library: Adel Q1 is kept. */
export function applyTopic(mod: CanonicalModule, t: TopicContent | undefined, keepFirstAdel: boolean): CanonicalModule {
  if (!t) return mod;
  const learn = { ...mod.learn };
  if (t.whyHard) learn.whyHard = { ...t.whyHard, bullets: t.whyHard.bullets ?? mod.learn.whyHard.bullets };
  else if (t.whyBullets) learn.whyHard = { ...learn.whyHard, bullets: t.whyBullets };
  if (t.reframe) learn.reframe = t.reframe;
  if (t.story && learn.stages) {
    const [s0, ...rest] = learn.stages.stages;
    learn.stages = { heading: `A peer's story — ${t.story.name}`, stages: [{ ...s0!, body: t.story.text }, ...rest] };
  }
  const qs = t.adelQuestions
    ? (keepFirstAdel ? [mod.adel.questions[0], ...t.adelQuestions] : t.adelQuestions).slice(0, 3)
    : mod.adel.questions;
  return {
    ...mod,
    related: t.related ?? mod.related,
    careNote: t.careNote ?? mod.careNote,
    challenge: {
      ...mod.challenge,
      welcome: t.welcome ?? mod.challenge.welcome,
      checklist: t.checklist ?? mod.challenge.checklist,
      normalizing: t.normalizing ?? mod.challenge.normalizing,
    },
    checkIn: t.checkIn ? { ...mod.checkIn, dimensions: t.checkIn } : mod.checkIn,
    learn,
    adel: { ...mod.adel, questions: qs as [string, string, string] },
    skill: {
      ...mod.skill,
      steps: t.skillSteps ?? mod.skill.steps,
      ...(t.toolName ? { toolName: t.toolName } : {}),
      ...(t.toolIntro ? { toolIntro: t.toolIntro } : {}),
      ...(t.partBExerciseId ? { partBExerciseId: t.partBExerciseId } : {}),
      reminder: t.insight ?? mod.skill.reminder,
      ...(t.ifThen ? { ifThen: t.ifThen } : {}),
    },
    practice: t.scenario ? { ...mod.practice, scenario: t.scenario } : mod.practice,
    insight: t.insight ?? mod.insight,
    exerciseId: t.exerciseId,
  };
}
