import test from "node:test";
import assert from "node:assert/strict";
import { COURT_ORDER, ASSOCIATION, DV, CWS, SUPERVISION_SLIP, STOPPING_SAFELY, ANY_TIME_HELP, MEDICINE_CONTINUITY, LIBRARY_CARE_NOTES, RECOVERY_CARE_NOTES } from "./care-notes";
import { LIBRARY_TOPICS, RECOVERY_TOPICS } from "./topic-content";
import { getSelfHelpModule, getCanonicalModule } from "./module-schema";
import { getRecoveryCanonicalModule, getRecoverySixStepModule } from "./recovery-module-schema";
import { findResourceCategory } from "@/lib/resource-aliases";

const placements = [
  [COURT_ORDER, ["repair", "rebuild-trust", "difficult-relationships"], ["relationships-1", "relationships-4", "relationships-8", "relationships-10"]],
  [ASSOCIATION, ["positive-connections", "recovery-choices"], ["relationships-6", "relationships-7", "living-recovery-6"]],
  [DV, ["boundaries", "managing-conflict", "difficult-relationships"], ["relationships-2", "relationships-3"]],
  [CWS, ["rebuild-trust"], ["relationships-5"]],
  [SUPERVISION_SLIP, ["one-bad-day"], ["first-days-5", "when-hard-5", "when-hard-6"]],
  [STOPPING_SAFELY, ["sud", "one-bad-day"], ["first-days-5", "when-hard-6"]],
  [ANY_TIME_HELP, [], ["first-days-8"]],
  [MEDICINE_CONTINUITY, [], ["first-days-1", "first-days-5"]],
] as const;
for (const [note, library, recovery] of placements) {
  test(`${note.title} is attached to every requested lesson`, () => {
    for (const [topics, ids] of [[LIBRARY_TOPICS, library], [RECOVERY_TOPICS, recovery]] as const) {
      for (const id of ids) {
        const notes = topics[id]?.careNote;
        assert.ok(notes, id);
        assert.ok((Array.isArray(notes) ? notes : [notes]).includes(note), id);
      }
    }
  });
}
test("notes preserve order with all medicine and stopping-safely notes stacked", () => {
  assert.deepEqual(LIBRARY_TOPICS["rebuild-trust"]?.careNote, [COURT_ORDER, CWS]);
  assert.deepEqual(LIBRARY_TOPICS["difficult-relationships"]?.careNote, [COURT_ORDER, DV]);
  assert.equal(Object.keys(LIBRARY_CARE_NOTES).length, 9);
  assert.equal(Object.keys(RECOVERY_CARE_NOTES).length, 15);
  for (const topic of [...Object.values(LIBRARY_TOPICS), ...Object.values(RECOVERY_TOPICS)]) {
    if (Array.isArray(topic.careNote)) {
      assert.ok(topic.careNote.length <= (topic.careNote.includes(STOPPING_SAFELY) ? 3 : 2));
    }
  }
});
test("stopping safely follows supervision notes and calls the SUD Access Line", () => {
  assert.equal(STOPPING_SAFELY.links?.[0]?.action, "tel:18667324114");
  assert.deepEqual(getSelfHelpModule("understanding", "sud")?.careNote, STOPPING_SAFELY);
  assert.deepEqual(LIBRARY_TOPICS["one-bad-day"]?.careNote, [SUPERVISION_SLIP, STOPPING_SAFELY]);
  for (const [module, id] of [["first-days", "first-days-5"], ["when-hard", "when-hard-6"]]) {
    assert.deepEqual(getRecoverySixStepModule(module, id)?.careNote, id === "first-days-5" ? [SUPERVISION_SLIP, STOPPING_SAFELY, MEDICINE_CONTINUITY] : [SUPERVISION_SLIP, STOPPING_SAFELY]);
  }
});
test("amends note survives both Recovery schema boundaries", () => {
  assert.equal(getRecoveryCanonicalModule("relationships", "relationships-8")?.careNote, COURT_ORDER);
  assert.equal(getRecoverySixStepModule("relationships", "relationships-8")?.careNote, COURT_ORDER);
});
test("boundaries note survives both Library schema boundaries", () => {
  assert.equal(getCanonicalModule("support-team", "boundaries")?.careNote, DV);
  assert.equal(getSelfHelpModule("support-team", "boundaries")?.careNote, DV);
});
test("DV hotline and shared resource destinations are the requested ones", () => {
  assert.equal(DV.links?.[0]?.action, "tel:18007997233");
  assert.equal(findResourceCategory("Emergency Shelter")?.id, "shelter");
  assert.equal(findResourceCategory("Legal Services")?.id, "legal");
  assert.equal(findResourceCategory("Family & Reunification")?.id, "family");
});
test("officer option is specifically requirements and referrals", () => {
  const pro = LIBRARY_TOPICS["count-on"]?.skillSteps?.find((step) => step.id === "pro");
  assert.ok(pro?.options.includes("Probation or parole officer (for requirements and referrals)"));
  assert.equal(pro?.options.includes("Probation or parole officer"), false);
});