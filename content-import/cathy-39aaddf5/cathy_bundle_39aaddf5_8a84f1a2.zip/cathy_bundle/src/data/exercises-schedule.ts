import type { Exercise } from "./exercises";

export const SCHEDULE_EXERCISES: Exercise[] = [
  {
    id: "therapy-prep", title: "What I want to bring up today", subtitle: "One or two things for your session",
    minutes: 2, type: "worksheet", tags: ["communication", "support"],
    purpose: "Your session can start with what matters to you.",
    content: { kind: "worksheet", prompt: "Pick or write one thing. Add a second only if you want to.", fields: [
      { id: "topic-one", label: "One thing I want to bring up:", placeholder: "Something I want help with…", options: ["How I've been feeling", "Cravings or triggers", "A relationship", "Something that went well"] },
      { id: "topic-two", label: "A second thing (optional):", placeholder: "Anything else I want to talk about…", options: ["Sleep", "Medication questions", "What I need next"] },
    ] },
  },
  {
    id: "tough-meeting-prep", title: "Stay steady in a tough meeting", subtitle: "A move, a sentence, a question",
    minutes: 2, type: "worksheet", tags: ["communication", "anxiety"],
    purpose: "You can prepare what you want to say without having to predict the whole meeting.",
    content: { kind: "worksheet", prompt: "Choose or write what works for you.", fields: [
      { id: "steady", label: "One calming move:", placeholder: "What helps me stay steady…", options: ["Feel my feet on the floor", "Pause before answering", "Ask for a moment"] },
      { id: "say", label: "One thing to say:", placeholder: "What I want them to understand…", options: ["I'm working on my next steps", "I'd like to explain what happened"] },
      { id: "ask", label: "One question to ask:", placeholder: "What I need to know…", options: ["What do I need to do next?", "When is the deadline?", "Who can help me with that?"] },
    ] },
  },
];
