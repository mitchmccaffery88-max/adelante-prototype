import test from "node:test";
import assert from "node:assert/strict";
import { RECOVERY_IF_THEN_CONTENT } from "./recovery-if-then-content";
import { BACKUP_ACTIONS } from "./if-then-content";
import { CRISIS_BACKUP, resolveIfThen, RECOVERY_IF_THEN_DEFAULTS } from "./if-then-defaults";
import { ifThenSentence } from "@/components/module/if-then-step";
import { RECOVERY_MODULES } from "./recovery";

test("every SUD lesson in RECOVERY_MODULES has an entry, with no extra ids", () => {
  const expected = RECOVERY_MODULES.flatMap((m) => m.lessons.map((l) => l.id));
  assert.equal(expected.length, 90);
  assert.deepEqual(Object.keys(RECOVERY_IF_THEN_CONTENT).sort(), expected.sort());
});

test("every SUD entry is high risk", () => {
  for (const [id, c] of Object.entries(RECOVERY_IF_THEN_CONTENT)) assert.equal(c.risk, "high", id);
});

test("SUD entries have 5 cues, 5 moves, at least 3 backups and 2 small moves", () => {
  for (const [id, c] of Object.entries(RECOVERY_IF_THEN_CONTENT)) {
    assert.equal(c.cues.length, 5, `${id}: cues`);
    assert.equal(c.moves.length, 5, `${id}: moves`);
    assert.ok((c.backups?.length ?? 0) >= 3, `${id}: backups`);
    assert.equal(c.smallMoves?.length, 2, `${id}: smallMoves`);
  }
});

test("every SUD cue/move/backup combination has no blanks or doubled words", () => {
  for (const [id, c] of Object.entries(RECOVERY_IF_THEN_CONTENT))
    for (const cue of c.cues)
      for (const move of c.moves)
        for (const backup of c.backups ?? []) {
          const sentence = ifThenSentence({ cue, move, backup });
          assert.ok(!sentence.includes("___"), `${id}: ${sentence}`);
          const words = sentence.toLowerCase().replace(/[^a-z0-9' ]/g, " ").split(/\s+/);
          for (let i = 1; i < words.length; i++)
            assert.notEqual(words[i - 1], words[i], `${id}: ${sentence}`);
        }
});

test("SUD backups include a non-911 action and never the crisis chip", () => {
  for (const [id, c] of Object.entries(RECOVERY_IF_THEN_CONTENT)) {
    assert.ok(c.backups?.some((b) => b !== BACKUP_ACTIONS.emergency), id);
    assert.ok(!c.backups?.includes(CRISIS_BACKUP), id);
  }
});

test("first-days-2 lesson cues win over the SUD module default", () => {
  const resolved = resolveIfThen("recovery:first-days", "first-days-2");
  assert.deepEqual(resolved.cues, RECOVERY_IF_THEN_CONTENT["first-days-2"]?.cues);
  assert.equal(resolved.cues[0], "A craving hits my whole body");
  assert.notDeepEqual(resolved.cues, RECOVERY_IF_THEN_DEFAULTS["first-days"]?.cues);
});

const MODULE_BACKUPS = {
  "first-days": [BACKUP_ACTIONS.craving, BACKUP_ACTIONS.people, BACKUP_ACTIONS.peer, BACKUP_ACTIONS.neverUseAlone],
  "my-people": [BACKUP_ACTIONS.meeting, BACKUP_ACTIONS.people, BACKUP_ACTIONS.peer],
  understanding: [BACKUP_ACTIONS.craving, BACKUP_ACTIONS.basics, BACKUP_ACTIONS.sponsor, BACKUP_ACTIONS.naloxone],
  "everyday-life": [BACKUP_ACTIONS.smaller, BACKUP_ACTIONS.basics, BACKUP_ACTIONS.peer],
  relationships: [BACKUP_ACTIONS.stepAway, BACKUP_ACTIONS.sleepOnIt, BACKUP_ACTIONS.sponsor],
  "life-that-works": [BACKUP_ACTIONS.callTomorrow, BACKUP_ACTIONS.resources211, BACKUP_ACTIONS.caseManager],
  "when-hard": [BACKUP_ACTIONS.readPlan, BACKUP_ACTIONS.people, BACKUP_ACTIONS.sponsor, BACKUP_ACTIONS.neverUseAlone],
  "someone-new": [BACKUP_ACTIONS.writeDown, BACKUP_ACTIONS.smaller, BACKUP_ACTIONS.peer],
  "living-recovery": [BACKUP_ACTIONS.meeting, BACKUP_ACTIONS.readPlan, BACKUP_ACTIONS.sponsor],
};
for (const [moduleId, backups] of Object.entries(MODULE_BACKUPS)) {
  test(`${moduleId} defaults and all ten lessons use the supplied ordered backups`, () => {
    assert.deepEqual(RECOVERY_IF_THEN_DEFAULTS[moduleId]?.backups, backups);
    for (let i = 1; i <= 10; i++) {
      const id = `${moduleId}-${i}`;
      const lessonBackups = id === "understanding-3"
        ? [BACKUP_ACTIONS.neverUseAlone, BACKUP_ACTIONS.naloxone, BACKUP_ACTIONS.peer]
        : id === "when-hard-9"
          ? [BACKUP_ACTIONS.people, BACKUP_ACTIONS.peer, BACKUP_ACTIONS.legalAid, BACKUP_ACTIONS.neverUseAlone]
          : backups;
      assert.deepEqual(RECOVERY_IF_THEN_CONTENT[id]?.backups, lessonBackups);
    }
  });
}