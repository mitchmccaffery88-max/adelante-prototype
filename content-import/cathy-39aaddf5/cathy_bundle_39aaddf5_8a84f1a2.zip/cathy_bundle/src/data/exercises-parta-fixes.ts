// Replacements for Part A exercises that the final audit found too similar
// to another lesson's exercise. Tap Start, follow timed steps, nothing to type.
import type { Exercise } from "./exercises";

type G = Omit<Exercise, "type" | "content"> & { steps: [string, number][]; closing: string; why?: string; scene?: string; tagline?: string };
const g = ({ steps, closing, why, scene, tagline, ...rest }: G): Exercise => ({
  ...rest,
  type: "guided",
  content: { kind: "guided", why, scene, tagline, steps: steps.map(([say, secs]) => ({ say, secs })), closing },
});

export const PARTA_FIXES: Exercise[] = [
  g({
    id: "a-place-for-the-loss",
    title: "A Place for the Loss",
    subtitle: "Make room for what you've lost",
    minutes: 2,
    tags: ["emotions"],
    why: "Grief needs room. Naming a loss and sitting with it for a minute is how it starts to soften.",
    closing: "Grief comes in waves. If it gets too heavy, reach out to your counselor or call 988.",
    tagline: "It hurts because it mattered.",
    purpose: "Grief needs room. Naming a loss and sitting with it for a minute is how it starts to soften.",
    steps: [
      ["This one is gentle. Skip any step you need to.", 6],
      ["Think of who or what you've lost: a person, years, time with your kids, your freedom.", 15],
      ["Just name it to yourself.", 10],
      ["Sit with it for a moment. You don't have to do anything with it.", 20],
      ["If tears come, let them. If nothing comes, that's okay too.", 12],
      ["Say: \"It makes sense this hurts.\"", 10],
      ["Breathe out slowly.", 8],
    ],
    adel: { skill: "Giving a loss a place", needs: ["someone died while I was locked up", "I missed the funeral", "I miss my mom", "I lost so many years", "my grandma passed"], states: ["sad", "grieving", "numb", "angry"], when: "When a member talks about a death, a missed goodbye, or lost years." },
  }),
  {"id": "steady-before-the-call", "title": "Steady Before the Call", "subtitle": "Face a positive test honestly", "minutes": 1, "tags": ["relapse-prevention"], "purpose": "Hiding a positive test usually makes things worse. Talking first gives you the most options.", "adel": {"skill": "Getting ready to tell someone about a slip", "needs": ["I have a drug test coming", "my test came back dirty", "I'm scared my PO will find out", "should I skip my test", "I used and I'm on probation"], "states": ["scared", "ashamed", "panicked"], "when": "When a member is worried about a test or a positive result."}, "type": "guided", "content": {"kind": "guided", "why": "Hiding a positive test usually makes things worse. Talking first gives you the most options.", "tagline": "Talk first. Don't hide it.", "closing": "Call your counselor or Devon before anything else. You don't have to face it alone.", "steps": [{"say": "Feet flat on the floor.", "secs": 6}, {"say": "Three slow breaths, out longer than in.", "secs": 15}, {"say": "Your first sentence: \"I need to tell you something.\"", "secs": 10}, {"say": "Then: \"My test came back positive. I want to be honest and figure out next steps.\"", "secs": 12}, {"say": "Picture saying it to your counselor, your peer or your PO.", "secs": 10}, {"say": "Say: \"Talk first. Don't hide it.\"", "secs": 6}]}},
  g({
    id: "their-side-of-the-table",
    title: "Their Side of the Table",
    subtitle: "See trust from the other side",
    minutes: 1, tags: ["support"],
    purpose: "Trust comes back faster when you understand what the other person went through.",
    why: "Trust comes back faster when you understand what the other person went through.",
    steps: [
      ["Think of someone whose trust you want back.", 8],
      ["Picture sitting in their chair, looking at you across a table.", 12],
      ["What did they go through while things were bad? Worry, broken promises, calls at night?", 15],
      ["What are they scared will happen again?", 12],
      ["What would they need to see from you, over and over, to trust you again?", 15],
      ["Say: \"Trust comes back in actions, not words.\"", 8],
    ],
    closing: "You can't make someone trust you. You can keep giving them reasons to.",
    tagline: "Trust comes back in actions, not words.",
    adel: {
      skill: "Seeing trust from the other person's side",
      needs: ["my family doesn't trust me anymore", "nobody believes I've changed", "how do I get people to trust me again", "they keep bringing up the past", "I said sorry and it didn't fix anything"],
      states: ["frustrated", "hurt", "hopeful", "guilty"],
      when: "When a member is frustrated that someone still doesn't trust them after they've changed.",
    },
  }),
  g({
    id: "three-question-pocket-card",
    title: "Three Questions in My Pocket",
    subtitle: "Three questions for any health visit",
    minutes: 1, tags: ["communication"],
    purpose: "Three questions at every visit help you understand your care and what to do next.",
    why: "Three questions at every visit help you understand your care and what to do next.",
    steps: [
      ["Touch your thumb to your first finger: \"What is this for?\"", 10],
      ["Thumb to your second finger: \"What should I watch for?\"", 10],
      ["Thumb to your third finger: \"What if it doesn't work?\"", 10],
      ["Run all three again, faster.", 12],
      ["Picture asking them at your next doctor or clinic visit.", 12],
      ["Say: \"Three fingers, three questions.\"", 6],
    ],
    closing: "Use these at any visit: doctor, dentist, pharmacy or clinic. Nobody will notice your fingers.",
    tagline: "Three fingers, three questions.",
    adel: {
      skill: "Remembering what to ask at a health visit",
      needs: ["I have a doctor's appointment coming up", "I never know what to ask the doctor", "I go blank at appointments", "I need to get my health checked", "doctors make me nervous"],
      states: ["nervous", "unprepared", "overwhelmed"],
      when: "When a member has a medical visit coming up or feels lost getting healthcare.",
    },
  }),
  g({
    id: "reverse-the-roles",
    title: "If They Asked Me",
    subtitle: "Flip the \"I'm a burden\" thought",
    minutes: 1,
    tags: ["support"],
    why: "Imagining a friend asking you for help makes it easier to ask for yourself.",
    closing: "When you feel like a burden, flip it. You'd want them to call you.",
    tagline: "They'd want you to ask.",
    purpose: "Imagining a friend asking you for help makes it easier to ask for yourself.",
    steps: [
      ["Picture a friend in recovery calling you late at night. They're struggling.", 12],
      ["Would you pick up? Would you help?", 10],
      ["Notice you don't think they're a burden. You're glad they called.", 12],
      ["Now flip it. You're the one struggling, and they're the one you'd call.", 12],
      ["They'd want the same for you.", 10],
      ["Say: \"They'd want me to ask.\"", 8],
    ],
    adel: {
      skill: "Seeing asking for help from the helper's side",
      needs: ["I hate asking for help", "I don't want to be a burden", "I feel weak asking people for things", "I always try to do it myself", "people are busy and I don't want to bother them"],
      states: ["ashamed", "proud", "stuck", "alone"],
      when: "When a member avoids asking for help because they feel like a burden or weak.",
    },
  }),
  {"id": "slip-signal-sort", "title": "Early Signal Sort", "subtitle": "Bad day or warning sign?", "minutes": 2, "tags": ["relapse-prevention"], "purpose": "Everyone has bad days. A warning sign is a pattern, especially one you're hiding.", "adel": {"skill": "Telling early slip signals from a normal bad day", "needs": ["I think I'm slipping", "I've been skipping meetings", "I don't feel like myself lately", "I keep thinking about my old friends", "how do I know if I'm heading toward relapse"], "states": ["uneasy", "drifting", "isolated", "worried"], "when": "When a member notices changes in their routine or mood and wonders if they're heading toward a slip."}, "type": "guided", "content": {"kind": "guided", "why": "Everyone has bad days. A warning sign is a pattern, especially one you're hiding.", "tagline": "Pattern plus secret means tell someone.", "closing": "When you notice a pattern you'd rather not tell anyone about, that's exactly when to tell someone.", "steps": [{"say": "The coach will read some signs. In your head, call each one \"bad day\" or \"warning sign.\"", "secs": 10}, {"say": "\"I skipped one meeting because I was sick.\"", "secs": 10}, {"say": "Probably a bad day. One time, with a reason.", "secs": 8}, {"say": "\"I've skipped three meetings and haven't told my sponsor.\"", "secs": 10}, {"say": "Warning sign. A pattern, and a secret.", "secs": 8}, {"say": "\"I was cranky today after a long shift.\"", "secs": 10}, {"say": "Bad day.", "secs": 5}, {"say": "\"I've been texting an old friend I used with, and I deleted the messages.\"", "secs": 10}, {"say": "Warning sign.", "secs": 5}, {"say": "Pattern plus secret means tell someone.", "secs": 8}]}},
];
