import test from "node:test";
import assert from "node:assert/strict";
import { EXERCISES, getExercise } from "./exercises";
import { LIBRARY_TOPICS } from "./topic-content";
import { IF_THEN_CONTENT } from "./if-then-content";
import { namedLessonTarget } from "@/lib/lesson-tools";
import { ANY_TIME_HELP } from "./care-notes";

const lessons = [
  {
    "id": "finding-footing",
    "exerciseId": "feet",
    "toolName": "Reentry Compass",
    "limits": [
      3,
      3,
      3,
      1,
      3
    ]
  },
  {
    "id": "daily-rhythm",
    "exerciseId": "five-minute-reset",
    "toolName": "Daily Rhythm Builder",
    "limits": [
      1,
      3,
      1,
      3,
      1
    ]
  },
  {
    "id": "mind-wont-slow",
    "exerciseId": "snow-globe",
    "toolName": "Calm Mind Card",
    "limits": [
      3,
      2,
      3,
      2,
      1
    ]
  },
  {
    "id": "overwhelmed",
    "exerciseId": "stop-skill",
    "toolName": "Overwhelm Reset",
    "limits": [
      8,
      2,
      2,
      2,
      1
    ]
  },
  {
    "id": "managing-worry",
    "exerciseId": "leaves-on-a-stream",
    "toolName": "Worry Workbench",
    "limits": [
      5,
      1,
      1,
      1
    ]
  },
  {
    "id": "grounding",
    "exerciseId": "senses-5-4-3-2-1",
    "toolName": "Ground Control",
    "limits": [
      3,
      3,
      2,
      2,
      3
    ]
  },
  {
    "id": "big-feelings",
    "exerciseId": "rain",
    "toolName": "Emotion Navigator",
    "limits": [
      2,
      2,
      2,
      2
    ]
  },
  {
    "id": "safe-now",
    "exerciseId": "wise-mind",
    "toolName": "Safety Net",
    "limits": [
      3,
      3,
      3,
      3,
      1
    ]
  },
  {
    "id": "healthy-sleep",
    "exerciseId": "cognitive-shuffle",
    "toolName": "Lights-Out Plan",
    "limits": [
      3,
      3,
      3,
      1
    ]
  },
  {
    "id": "stability-plan",
    "exerciseId": "stable",
    "toolName": "Stability Plan",
    "limits": [
      4,
      4,
      4,
      4,
      1
    ]
  },
  {
    "id": "sud",
    "exerciseId": "break-the-link",
    "toolName": "Craving Compass",
    "limits": [
      3,
      3,
      2,
      2,
      2
    ]
  },
  {
    "id": "depression",
    "exerciseId": "change-the-channel",
    "toolName": "Mood Momentum Plan",
    "limits": [
      3,
      4,
      2,
      2
    ]
  },
  {
    "id": "anxiety",
    "exerciseId": "fact-or-forecast",
    "toolName": "Alarm Decoder",
    "limits": [
      3,
      1,
      2,
      2
    ]
  },
  {
    "id": "bipolar",
    "exerciseId": "find-your-anchor",
    "toolName": "Mood Map",
    "limits": [
      3,
      3,
      3,
      2,
      3
    ]
  },
  {
    "id": "ptsd",
    "exerciseId": "here-not-there",
    "toolName": "Now & Then Safety Check",
    "limits": [
      3,
      1,
      3,
      2,
      1
    ]
  },
  {
    "id": "psychosis",
    "exerciseId": "whats-my-brain-up-to",
    "toolName": "Reality Check",
    "limits": [
      3,
      3,
      1,
      2,
      1
    ]
  },
  {
    "id": "my-triggers-2",
    "exerciseId": "cool-the-reaction",
    "toolName": "Trigger Radar",
    "limits": [
      2,
      3,
      2,
      2,
      2
    ]
  },
  {
    "id": "my-strengths",
    "exerciseId": "look-for-the-strength",
    "toolName": "Strengths Profile",
    "limits": [
      4,
      2,
      1,
      1
    ]
  },
  {
    "id": "treatment-team",
    "exerciseId": "get-the-support-i-need",
    "toolName": "Who Do I Call? Guide",
    "limits": [
      6,
      1,
      1,
      1,
      1
    ]
  },
  {
    "id": "recovery-journey-2",
    "exerciseId": "walk-the-stages",
    "toolName": "You Are Here",
    "limits": [
      1,
      4,
      2,
      3,
      3
    ]
  },
  {
    "id": "why-meds",
    "exerciseId": "two-sides",
    "toolName": "The Weigh-In",
    "limits": [
      4,
      3,
      3,
      2,
      1
    ]
  },
  {
    "id": "med-routine",
    "exerciseId": "stack-spot-signal",
    "toolName": "Lock-In Routine",
    "limits": [
      1,
      1,
      2,
      1,
      3
    ]
  },
  {
    "id": "tracking-feelings",
    "exerciseId": "ten-second-check-in",
    "toolName": "Signal Tracker",
    "limits": [
      3,
      1,
      2,
      2
    ]
  },
  {
    "id": "side-effects",
    "exerciseId": "know-your-red-flags",
    "toolName": "Side Effect Log",
    "limits": [
      2,
      3,
      1,
      1,
      2
    ]
  },
  {
    "id": "talking-provider",
    "exerciseId": "dont-say-fine",
    "toolName": "Speak-Up Script",
    "limits": [
      2,
      1,
      1,
      1,
      1
    ]
  },
  {
    "id": "missed-dose",
    "exerciseId": "pause-check-call",
    "toolName": "Missed-Dose Card",
    "limits": [
      2,
      1,
      3,
      2
    ]
  },
  {
    "id": "habits-treatment",
    "exerciseId": "cue-routine-reward",
    "toolName": "Treatment Teammates",
    "limits": [
      1,
      1,
      1,
      1,
      1
    ]
  },
  {
    "id": "treatment-goals",
    "exerciseId": "miracle-question",
    "toolName": "Progress Markers",
    "limits": [
      3,
      3,
      1,
      1,
      1
    ]
  },
  {
    "id": "prep-appointments",
    "exerciseId": "five-ts",
    "toolName": "Game-Day Prep",
    "limits": [
      1,
      2,
      5,
      3
    ]
  },
  {
    "id": "ownership",
    "exerciseId": "bran",
    "toolName": "Treatment Playbook",
    "limits": [
      3,
      4,
      3,
      3,
      2
    ]
  }
];

for (const expected of lessons) {
  test(`${expected.id}: guided tagline, under 120 seconds, and complete tool configuration`, () => {
    const topic = LIBRARY_TOPICS[expected.id];
    assert.ok(topic);
    assert.equal(topic.exerciseId, expected.exerciseId);
    const exercise = getExercise(topic.exerciseId);
    assert.ok(exercise);
    assert.equal(EXERCISES.filter(e => e.id === exercise.id).length, 1);
    assert.equal(exercise.type, "guided");
    assert.equal(exercise.content.kind, "guided");
    if (exercise.content.kind !== "guided") return;
    assert.ok(exercise.content.tagline);
    assert.equal(exercise.purpose, exercise.content.why);
    assert.ok(exercise.content.steps.reduce((total, step) => total + step.secs, 0) <= 120);
    assert.equal(topic.toolName, expected.toolName);
    assert.ok(topic.toolIntro);
    const steps = topic.skillSteps;
    assert.ok(steps);
    assert.ok(steps.length >= 3 && steps.length <= 5);
    assert.deepEqual(steps.map(step => step.maxPicks), expected.limits);
    for (const step of steps) {
      if (step.optionsFrom) assert.deepEqual(step.options, steps.find(s => s.id === step.optionsFrom)?.options);
      else assert.ok(step.options.length >= 3, `${expected.id}/${step.id}`);
    }
  });
  test(`${expected.id}: first move resolves to its Part A exercise`, () => {
    const topic = LIBRARY_TOPICS[expected.id];
    const plan = IF_THEN_CONTENT[expected.id];
    assert.ok(topic && plan);
    const target = namedLessonTarget(plan.moves[0] ?? "", { ...topic, lessonId: expected.id });
    assert.equal(target?.kind, "exercise");
    if (target?.kind === "exercise") assert.equal(target.exercise.id, expected.exerciseId);
  });
}

test("Safety Net and Mood Map retain fixed care notes instead of selectable self-harm", () => {
  for (const id of ["safe-now", "bipolar"]) {
    const topic = LIBRARY_TOPICS[id];
    assert.equal(topic?.careNote, ANY_TIME_HELP);
    assert.ok(topic?.skillSteps?.every(step => step.options.every(option => !/hurting myself|thinking about death/i.test(option))));
    assert.ok(topic?.skillSteps?.some(step => step.crisisLink));
  }
});
test("Ground Control routine resolves by tool name", () => {
  const topic = LIBRARY_TOPICS.grounding;
  assert.ok(topic);
  assert.equal(namedLessonTarget("Run my Ground Control routine", { ...topic, lessonId: "grounding" })?.kind, "tool");
});
test("The Weigh-In resolves without its leading The", () => {
  const topic = LIBRARY_TOPICS["why-meds"];
  assert.ok(topic);
  assert.equal(namedLessonTarget("Read my Weigh-In", { ...topic, lessonId: "why-meds" })?.kind, "tool");
});
