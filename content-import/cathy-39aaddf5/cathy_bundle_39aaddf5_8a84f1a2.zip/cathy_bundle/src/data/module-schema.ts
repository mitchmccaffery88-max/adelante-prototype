// Canonical 10-step Adelante module schema.
//
// "Finding My Footing" is the reference implementation. Every module in the
// self-help library is expressed as a `CanonicalModule` — either hand-authored
// in OVERRIDES, or derived from the legacy LibraryItem + enrichment content by
// `buildCanonicalModule`. The renderer (components/module-template.tsx) only
// ever reads this schema, so all 90 modules render the identical 10 steps.

import { LIBRARY, type LibraryCategory, type LibraryItem, type Activity } from "./library";
import { getEnrichment } from "./enrich";
import { LIBRARY_TOPICS, applyTopic } from "./topic-content";
import type { LessonCareNotes } from "./care-notes";

// ---------------------------------------------------------------- step types

/** Step 1 — Understand My Challenge */
export type ChallengeStep = {
  welcome: string[];          // 2-4 relatable "Have you ever…" lines
  checklistTitle: string;
  checklist: string[];        // 5-8 selectable statements
  normalizing: string;        // reframe + preview of the path forward
};

/** Step 2 / 9 — rating dimensions (1-10) */
export type RatingDimension = {
  id: string;
  label: string;
  left: string;               // 1 = …
  right: string;              // 10 = …
  /** true when a higher number means a harder day (overwhelm, craving) */
  higherIsHarder: boolean;
};

export type CheckInStep = {
  intro: string;
  dimensions: RatingDimension[];  // 2-3
  reflectionPrompt: string;       // optional short open text
};

/** Step 3 — Learn What's Happening */
export type LearnSection = { heading: string; body: string; bullets?: string[] };

export type LearnStep = {
  whyHappening: LearnSection;   // brain/body science, plain language
  whyHard: LearnSection;        // science → lived reentry experience
  stages?: { heading: string; stages: { name: string; quote: string; body: string }[] };
  reframe: LearnSection;        // smaller, workable question
  didYouKnow: string;
  keyTakeaway: string;          // first-person quotable
};

/** Answers shared across lesson tools, per member. */
export type SharedKey =
  | "supportPeople" | "copingTools" | "warningSigns" | "safePlaces" | "dailyHabits"
  | "medications" | "pharmacy" | "careTeam" | "values" | "reasons" | "triggers";

/** Step 4 — Build My Skills */
export type ToolFlowStep = {
  id: string;
  title: string;
  instruction: string;
  options: string[];
  maxPicks: number;             // 1 = single-select, >1 = multi-select chips
  /** Library: show only what was picked in this earlier step (plus write-in). */
  optionsFrom?: string;
  /** Library: hide what was picked in this earlier step. */
  excludeFrom?: string;
  /** Pre-fill from / write back to the member's shared answers. */
  shared?: SharedKey;
  /** This step's answer pre-fills the If–Then IF ("cue") or THEN ("move") line. */
  feeds?: "cue" | "move";
  /** Show "Open my safety plan" and 988 with this step. */
  crisisLink?: boolean;
};

/** Library: optional "My If–Then Plan" content. Absent = category defaults. */
export type IfThenConfig = {
  risk: "standard" | "high";
  cues: string[];
  moves: string[];
  backups?: string[];
  cantLeave?: string[];
  smallMoves?: string[];
};

export type SkillStepConfig = {
  toolName: string;
  /** One or two lines under the Part B heading. */
  toolIntro?: string;
  /** Part B uses this Exercise Library tool instead of chip steps. */
  partBExerciseId?: string;
  purpose: string;
  steps: ToolFlowStep[];        // 3-5
  saveLabel: string;
  reminder: string;
  ifThen?: IfThenConfig;
};

/** Step 5 — Practice in Real Life */
export type PracticeStep = {
  scenarioTitle: string;
  scenario: string;
  prompt: string;
  choices: { label: string; feedback: string }[];
  closing: string;
  ifOptions: string[];
  thenOptions: string[];
  confidencePrompt: string;
};

/** Step 6 — Talk It Through With Adel */
export type AdelStep = {
  intro: string;
  questions: [string, string, string];
  /** ACTION tag convention already used elsewhere for module recommendations */
  recommends: { label: string; action: string }[];
};

/** Optional Adel thread routing for Self-Help Step 3, keyed off Step 1 picks. */
export type ModuleThread = {
  id: string;
  label: string;
  /** EXACT checklist strings that feed this thread. */
  statements: string[];
  stance: string;
  firstQuestion: string;
  chips: string[];
  /** ACTION tag, e.g. "exercise:one-step-shrink". */
  offer?: string;
  /** Exact option text from the Build My Skill "next" step. */
  suggestedNextStep?: string;
};

export type CanonicalModule = {
  related?: string[];
  careNote?: LessonCareNotes;
  id: string;
  categoryId: string;
  categoryName: string;
  title: string;
  subtitle: string;
  minutes: number;
  challenge: ChallengeStep;      // 1
  checkIn: CheckInStep;          // 2 & 9
  learn: LearnStep;              // 3
  skill: SkillStepConfig;        // 4
  practice: PracticeStep;        // 5
  adel: AdelStep;                // 6
  insight: string;               // 7
  nextSteps: string[];           // 8 (4-5)
  progressNote: string;          // 9 framing
  toolkitKey: string;            // 10 persistence key
  /** Step 4 Part A — id of an exercise in the shared Exercise Library.
   *  Optional: when absent the template matches one by theme. */
  exerciseId?: string;
  /** Legacy interactive activity kept as an optional extra inside step 4. */
  activity?: Activity;
  threads?: ModuleThread[];
};

export const MODULE_STEP_LABELS = [
  "Understand My Challenge",
  "Check In With Myself",
  "Learn What's Happening",
  "Build My Skills",
  "Practice in Real Life",
  "Talk It Through With Adel",
  "My Insight",
  "My Next Step Today",
  "Check My Progress",
  "Save to My Toolkit",
] as const;

// ------------------------------------------------------------------
// Self-Help Library 6-step variant (keeps Recovery Journey on 10-step)
// ------------------------------------------------------------------

/** Step 1 of the 6-step Self-Help flow: merged challenge + condensed learn. */
export type UnderstandingStep = {
  welcome: string[];
  checklistTitle: string;
  checklist: string[];
  normalizing: string;
  /** 2–3 essential ideas, 1–2 plain sentences each. */
  essentials: { heading: string; body: string; bullets?: string[] }[];
  /** Kept only when it is core to the module's idea. */
  stages?: { heading: string; stages: { name: string; quote: string; body: string }[] };
};

export type SelfHelpModule = {
  related?: string[];
  careNote?: LessonCareNotes;
  id: string;
  categoryId: string;
  categoryName: string;
  title: string;
  subtitle: string;
  minutes: number;
  understanding: UnderstandingStep; // 1
  checkIn: CheckInStep;             // 2
  adel: AdelStep;                   // 3
  skill: SkillStepConfig;           // 4
  insight: string;                  // 5
  progressNote: string;             // 6 framing
  toolkitKey: string;
  exerciseId?: string;
  activity?: Activity;
  threads?: ModuleThread[];
  /** SUD Recovery Journey only — peer story card shown above the Part A exercise. */
  peerStory?: { name: string; text: string };
};

export const SELF_HELP_STEP_LABELS = [
  "Welcome",
  "Check In",
  "Talk It Through",
  "Build My Skill",
  "Wrap up",
] as const;

// -------------------------------------------------------------- gap fillers

const GENERIC_CHECKLIST = [
  "I don't know where to start.",
  "I feel like I have too many things to handle at once.",
  "I feel overwhelmed by everything I need to do.",
  "I worry about what comes next.",
  "I have trouble making decisions.",
  "I feel stuck.",
  "I want to feel more confident about moving forward.",
];

const GENERIC_NEXT_STEPS = [
  "Complete one important task.",
  "Reach out to someone I trust.",
  "Practice one coping skill.",
  "Make one phone call.",
  "Plan tomorrow.",
];

const GENERIC_IF = [
  "I feel overwhelmed by everything I need to do.",
  "I don't know where to start.",
  "I notice the old pattern showing up.",
  "I start avoiding what matters.",
];

const GENERIC_THEN = [
  "Choose one next step.",
  "Write down what needs to happen first.",
  "Ask someone I trust for help.",
  "Use the tool I just built.",
  "Remind myself, \"I only need to focus on what comes next.\"",
];

function activityOptions(a?: Activity): string[] {
  if (!a) return [];
  return [
    ...(a.cards ?? []),
    ...(a.items ?? []),
    ...(a.steps ?? []),
    ...(a.choices?.map((c) => c.label) ?? []),
  ].slice(0, 8);
}

function sentences(text: string): string[] {
  return text.split(/(?<=\.)\s+/).filter(Boolean);
}

// -------------------------------------------------------------- the derive

function derive(cat: LibraryCategory, item: LibraryItem): CanonicalModule {
  const e = getEnrichment(item.id);
  const s = sentences(item.learnBody);
  const half = Math.ceil(s.length / 2);
  const opts = activityOptions(item.activity);
  const themeWord = item.title.replace(/^(My|I|Understanding|Creating|Finding|Building)\s+/i, "").toLowerCase();

  const checklist = opts.length >= 5
    ? opts.slice(0, 7).map((o) => (/[.?!]$/.test(o) ? o : `${o}.`))
    : GENERIC_CHECKLIST;

  const toolOptionsFor = (i: number): string[] => {
    const fromSlots = e.buildTool?.slots?.[i]?.options;
    if (fromSlots?.length) return fromSlots;
    if (i === 0) return opts.length ? opts : ["Housing", "Work or school", "Recovery", "Relationships", "Mental health", "Daily responsibilities"];
    if (i === 1) return ["My routine has changed.", "I have more decisions to make.", "I feel pressure to succeed.", "Relationships feel different.", "I feel behind.", "I miss having structure."];
    if (i === 2) return ["Stability", "Recovery", "Family", "Independence", "Health", "Purpose", "Peace", "Trust"];
    return [item.action, "Call someone for support.", "Attend an appointment.", "Create tomorrow's plan.", "Practice a coping skill."];
  };

  const skillSteps: ToolFlowStep[] = e.buildTool?.slots?.length
    ? e.buildTool.slots.map((slot, i) => ({
        id: slot.id,
        title: `Step ${i + 1} — ${slot.label}`,
        instruction: slot.hint ?? "Choose what fits you best.",
        options: slot.options,
        maxPicks: slot.pickMax ?? 1,
      }))
    : [
        { id: "where", title: "Step 1 — Where am I right now?", instruction: "Select what feels most true today.", options: toolOptionsFor(0), maxPicks: 3 },
        { id: "changed", title: "Step 2 — What has changed?", instruction: "Choose the statements that fit.", options: toolOptionsFor(1), maxPicks: 3 },
        { id: "matters", title: "Step 3 — What matters most right now?", instruction: "Choose your top three.", options: toolOptionsFor(2), maxPicks: 3 },
        { id: "next", title: "Step 4 — My next right step", instruction: "Choose one action.", options: toolOptionsFor(3), maxPicks: 1 },
      ];

  const practiceChoices = e.practice?.choices?.map((c) => ({ label: c.label, feedback: c.consequence }))
    ?? item.activity?.choices?.map((c) => ({ label: c.label, feedback: c.feedback }))
    ?? [
      { label: "Try to handle everything at once.", feedback: "That's a common move. It usually costs energy fast — notice what it does to your body." },
      { label: "Pick the one thing that would help me feel more settled.", feedback: "That's momentum. One settled thing makes the next one easier." },
      { label: "Wait and hope it gets easier later.", feedback: "Sometimes waiting is rest, sometimes it's avoidance. Only you can tell which one this is." },
      { label: "Reach out and say, \"I'm trying to figure out my next step.\"", feedback: "Asking early keeps you connected, and connection is a skill — not a weakness." },
    ];

  return {
    id: item.id,
    categoryId: cat.id,
    categoryName: cat.name,
    title: item.title,
    subtitle: cat.clinicalTarget,
    minutes: item.minutes,
    challenge: {
      welcome: [
        `Have you ever felt like ${item.problem.replace(/^You(r)?\s/, (m) => (m.includes("r") ? "your " : "you "))}`,
        "When everything feels important, it can be hard to know what to do first.",
        "That doesn't mean you're failing. It means you're handling a lot of change at once.",
        "You don't have to have this figured out today. You only need your next right step.",
      ],
      checklistTitle: "Which of these sound like you?",
      checklist,
      normalizing: "If you checked several of these, you're not alone. This is common during big life change — and it can shift one step at a time. This module will walk you through it.",
    },
    checkIn: {
      intro: "Rate how you're feeling right now. This is just for you.",
      dimensions: [
        { id: "overwhelm", label: `How much is "${themeWord}" weighing on you right now?`, left: "Not at all", right: "A lot", higherIsHarder: true },
        { id: "confidence", label: "How confident do you feel handling it?", left: "Not confident", right: "Very confident", higherIsHarder: false },
        { id: "hope", label: "How hopeful do you feel about this changing?", left: "Not hopeful", right: "Very hopeful", higherIsHarder: false },
      ],
      reflectionPrompt: "Describe how you're feeling in one word.",
    },
    learn: {
      whyHappening: {
        heading: e.learnParts?.happening.headline ?? item.learnTitle,
        body: e.learnParts?.happening.body ?? s.slice(0, half).join(" "),
      },
      whyHard: {
        heading: e.learnParts?.why.headline ?? "Why this feels so hard",
        body: e.learnParts?.why.body ?? s.slice(half).join(" ") ??
          "After long stretches of stress, your brain stays on alert even when you're safe. That makes ordinary decisions feel heavier than they should.",
        bullets: ["Racing thoughts", "Feeling stuck", "Worrying about what's next", "Avoiding hard tasks", "Feeling like giving up"],
      },
      reframe: {
        heading: "A smaller question",
        body: e.learnParts?.canChange.body ??
          "Instead of asking \"How do I fix all of this?\", try asking \"What is the next right step?\" Small actions build momentum, and momentum builds confidence.",
      },
      didYouKnow: "Big life transitions temporarily raise stress because your brain is learning new routines and expectations. With practice and support, your brain adapts and builds new patterns.",
      keyTakeaway: e.learnParts?.takeaway ?? item.insight,
    },
    skill: {
      toolName: e.buildTool?.name ?? `My ${item.toolkitLabel.replace(/^My\s+/i, "")} Plan`,
      purpose: e.buildTool?.intro ?? `Help you name where you are today, what matters most, and one next step for "${item.title}".`,
      steps: skillSteps,
      saveLabel: e.buildTool?.saveAs ?? item.toolkitLabel,
      reminder: item.insight,
    },
    practice: {
      scenarioTitle: e.practice?.title ?? "A real moment",
      scenario: e.practice?.scene ?? item.problem,
      prompt: e.practice?.prompt ?? "What's your first move?",
      choices: practiceChoices,
      closing: "There isn't one perfect answer. Trying different responses helps you learn what actually moves you forward.",
      ifOptions: e.practice?.ifOptions ?? GENERIC_IF,
      thenOptions: e.practice?.thenOptions ?? GENERIC_THEN,
      confidencePrompt: "How confident do you feel using this plan if this happens today?",
    },
    adel: {
      intro: "Adel is a recovery coach, not a therapist. Nothing you say here gets you in trouble.",
      questions: [
        item.adelQuestion,
        "What strengths have already helped you make it this far?",
        "If someone believed in you today, what would they encourage you to do next?",
      ],
      recommends: [{ label: `More in ${cat.name}`, action: `ACTION:library:${cat.id}` }],
    },
    insight: item.insight,
    nextSteps: [item.action, ...GENERIC_NEXT_STEPS].slice(0, 5),
    progressNote: "Adel looks at the change between your first and second ratings — effort counts more than the number.",
    toolkitKey: `library:${item.id}`,
    activity: item.activity,
  };
}

// --------------------------------------------------- hand-authored reference

const OVERRIDES: Record<string, Partial<CanonicalModule>> = {
  "finding-footing": {
    subtitle: "Transitioning Back Into Life",
    challenge: {
      welcome: [
        "Have you ever felt like your life has changed so much that you're not sure where to begin?",
        "Maybe you're trying to figure out your next steps while also dealing with everyday responsibilities.",
        "You may have questions about housing, work, appointments, relationships, or simply how to move forward.",
        "When everything feels important, it can be hard to know what to do first.",
      ],
      checklistTitle: "Which of these sound like you?",
      checklist: [
        "I don't know where to start.",
        "I feel like I have too many problems to solve.",
        "I feel overwhelmed by everything I need to do.",
        "I worry about what comes next.",
        "I have trouble making decisions.",
        "I feel stuck.",
        "I want to feel more confident about moving forward.",
      ],
      normalizing: "If you checked several of these, you're not alone. Major life changes can make it difficult to know where to begin — but you can regain your footing one step at a time.",
    },
    checkIn: {
      intro: "Rate how you're feeling right now.",
      dimensions: [
        { id: "overwhelm", label: "How overwhelmed do you feel?", left: "Calm", right: "Completely overwhelmed", higherIsHarder: true },
        { id: "confidence", label: "How confident do you feel about handling your next steps?", left: "Not confident", right: "Very confident", higherIsHarder: false },
        { id: "hope", label: "How hopeful do you feel about your future?", left: "Not hopeful", right: "Very hopeful", higherIsHarder: false },
      ],
      reflectionPrompt: "Describe how you're feeling in one word.",
    },
    learn: {
      whyHappening: {
        heading: "Your brain is adjusting to a major life change",
        body: "Coming home is more than changing where you live. It's a major transition that affects your mind, body, emotions, relationships, routines, and sense of identity. Many people expect to feel only relief. Instead they may feel confusion, stress, loneliness, worry, pressure, and uncertainty about what comes next. That doesn't mean something is wrong with you — it means your brain is adapting to a completely new environment.",
      },
      whyHard: {
        heading: "Why this feels so hard",
        body: "For a long time, many parts of your daily life may have been decided for you — where you needed to be, when you woke up, when you ate, what choices were available. Now you may suddenly have many big decisions at once. Having many important decisions at the same time can overload your brain, and an overloaded brain has a harder time focusing, planning, and taking action.",
        bullets: ["Racing thoughts", "Feeling stuck", "Worrying about the future", "Avoiding difficult tasks", "Feeling frustrated", "Feeling like giving up"],
      },
      stages: {
        heading: "The Reentry Adjustment Curve",
        stages: [
          { name: "Stage 1: Learning", quote: "I am figuring out what has changed.", body: "You're learning new routines, responsibilities, and expectations." },
          { name: "Stage 2: Challenges", quote: "I am facing problems and building new skills.", body: "This is where you practice asking for help, making decisions, and solving problems." },
          { name: "Stage 3: Growth", quote: "I am becoming more confident and building my future.", body: "Over time, small steps create new patterns. Progress is not a straight line — what matters is continuing forward." },
        ],
      },
      reframe: {
        heading: "The power of one next step",
        body: "When everything feels important, everything can feel impossible. Instead of asking \"How do I fix my whole life?\", try asking \"What is the next right step?\" One phone call. One appointment. One healthy choice. One conversation. Small actions create momentum, momentum builds confidence, and confidence helps you keep moving.",
      },
      didYouKnow: "Major life transitions can temporarily increase stress because your brain is learning new routines, responsibilities, and expectations. With support and practice, your brain can adapt and create new patterns.",
      keyTakeaway: "I don't have to rebuild my whole life today. I only need to take the next right step.",
    },
    skill: {
      toolName: "My Reentry Compass",
      purpose: "Identify where you are today, what matters most, and the one next step that moves you forward.",
      saveLabel: "My Reentry Compass",
      reminder: "I only need to take the next right step.",
      steps: [
        { id: "where", title: "Step 1 — Where am I right now?", instruction: "Select the areas that feel most challenging.", maxPicks: 4, options: ["Housing", "Work or school", "Recovery", "Relationships", "Mental health", "Physical health", "Daily responsibilities", "Feeling overwhelmed"] },
        { id: "changed", title: "Step 2 — What has changed?", instruction: "Choose the statements that fit.", maxPicks: 3, options: ["My routine has changed.", "I have more decisions to make.", "I feel pressure to succeed.", "Relationships feel different.", "I feel behind.", "I miss having structure."] },
        { id: "matters", title: "Step 3 — What matters most right now?", instruction: "Choose your top three values.", maxPicks: 3, options: ["Stability", "Recovery", "Family", "Independence", "Health", "Purpose", "Peace", "Trust"] },
        { id: "next", title: "Step 4 — My next right step", instruction: "Choose one action.", maxPicks: 1, options: ["Call someone for support.", "Attend an appointment.", "Create tomorrow's plan.", "Complete one important task.", "Practice a coping skill.", "Work on my recovery."] },
      ],
    },
    practice: {
      scenarioTitle: "The Morning List",
      scenario: "You wake up and immediately remember everything you need to handle. You need to make an appointment, respond to a message, figure out transportation, handle a bill, and start planning what comes next. The more you think about everything, the harder it feels to begin.",
      prompt: "What's your first move?",
      choices: [
        { label: "Try to solve everything at once.", feedback: "That's the most common move — and usually the fastest way to burn out before 10 a.m." },
        { label: "Pick the one thing that would help me feel more settled.", feedback: "That's your compass working. Settled first, then the rest gets easier to see." },
        { label: "Avoid thinking about it and hope it gets easier later.", feedback: "Sometimes that's rest, sometimes it's avoidance. Naming which one it is puts you back in control." },
        { label: "Reach out and say, \"I'm trying to figure out my next step.\"", feedback: "Asking early is a skill. It keeps you connected while you sort out the order." },
      ],
      closing: "There isn't one perfect answer. Trying different responses helps you discover what helps you move forward.",
      ifOptions: ["I feel overwhelmed by everything I need to do.", "I don't know where to start.", "I feel stuck thinking about my future."],
      thenOptions: ["Choose one next step.", "Write down what needs to happen first.", "Ask someone I trust for help prioritizing.", "Remind myself, \"I only need to focus on what comes next.\""],
      confidencePrompt: "How confident do you feel using this plan if this happens today?",
    },
    adel: {
      intro: "Adel is a recovery coach, not a therapist. Answer as much or as little as you want.",
      questions: [
        "What part of returning home has been the biggest adjustment for you?",
        "What strengths have already helped you make it this far?",
        "If someone believed in you today, what would they encourage you to do next?",
      ],
      recommends: [
        { label: "Creating My Daily Rhythm", action: "ACTION:library:starting-strong:daily-rhythm" },
        { label: "More in Starting Strong", action: "ACTION:library:starting-strong" },
      ],
    },
    insight: "Stability isn't created all at once. It's built one decision at a time.",
    nextSteps: [
      "Complete one important task.",
      "Reach out to someone I trust.",
      "Practice one coping skill.",
      "Make one phone call.",
      "Plan tomorrow.",
    ],
    threads: [
      {
        id: "overload", label: "Too much at once",
        statements: ["I don't know where to start.", "I feel like I have too many problems to solve.", "I feel overwhelmed by everything I need to do."],
        stance: "Too many open tabs, not a character flaw. Shrink the frame to one thing.",
        firstQuestion: "If we shrink it to one thing for today, would you rather start with the easiest one, or the one that would give the most relief?",
        chips: ["The easiest", "Most relief", "I'm not sure"],
        offer: "exercise:one-step-shrink",
        suggestedNextStep: "Complete one important task.",
      },
      {
        id: "worry", label: "Worry about what's next",
        statements: ["I worry about what comes next."],
        stance: "Thinking ahead means they care about their future. Separate specific worries from general what-ifs.",
        firstQuestion: "Is the worry about something specific, like housing or work, or more of a general \"what if\"?",
        chips: ["Something specific", "General what-if", "Not sure"],
        offer: "exercise:worry-shelf",
        suggestedNextStep: "Call someone for support.",
      },
      {
        id: "decisions", label: "Hard to decide",
        statements: ["I have trouble making decisions."],
        stance: "Many choices after years of others deciding is heavy. Most early choices can be undone. No exercise: walk a quick decide in chat (name the choice, two options, can it be undone, what matters most, good enough for now, pick a day to check back).",
        firstQuestion: "Is there one decision on your mind today?",
        chips: ["Yes, one", "A few", "Not sure"],
        suggestedNextStep: "Create tomorrow's plan.",
      },
      {
        id: "stuck", label: "Feeling stuck",
        statements: ["I feel stuck."],
        stance: "\"Stuck\" can mean too many roads or no energy for any of them. Find out which. Too many roads: continue as the overload thread. No energy: smallest possible step, ask what has been hardest, offer Devon as one choice.",
        firstQuestion: "Is it more that there are too many roads, or that you have no energy for any of them?",
        chips: ["Too many roads", "No energy", "Not sure"],
        suggestedNextStep: "Practice a coping skill.",
      },
      {
        id: "confidence", label: "Wanting more confidence",
        statements: ["I want to feel more confident about moving forward."],
        stance: "This is a strength signal. Build confidence from evidence of what they have already handled.",
        firstQuestion: "What's one thing you've already handled since coming home?",
        chips: ["Something small", "Something big", "Hard to think of one"],
        offer: "exercise:what-holds-me",
        suggestedNextStep: "Attend an appointment.",
      },
    ],
  },
};

// ---------------------------------------------------------------- public API

export function buildCanonicalModule(cat: LibraryCategory, item: LibraryItem): CanonicalModule {
  const base = derive(cat, item);
  const o = OVERRIDES[item.id];
  return applyTopic(o ? { ...base, ...o } : base, LIBRARY_TOPICS[item.id], true);
}

export function getCanonicalModule(categoryId: string, itemId: string): CanonicalModule | null {
  const cat = LIBRARY.find((c) => c.id === categoryId);
  const item = cat?.items.find((i) => i.id === itemId);
  if (!cat || !item) return null;
  return buildCanonicalModule(cat, item);
}

// ---------------------------------------------------------------- self-help 6-step API

export function toSelfHelpModule(mod: CanonicalModule): SelfHelpModule {
  const essentials: UnderstandingStep["essentials"] = [
    { heading: mod.learn.whyHappening.heading, body: mod.learn.whyHappening.body },
  ];
  if (mod.learn.whyHard.body) {
    essentials.push({
      heading: mod.learn.whyHard.heading,
      body: mod.learn.whyHard.body,
      bullets: mod.learn.whyHard.bullets,
    });
  }
  if (mod.learn.reframe.body) {
    essentials.push({ heading: mod.learn.reframe.heading, body: mod.learn.reframe.body });
  }

  return {
    id: mod.id,
    related: mod.related,
    careNote: mod.careNote,
    categoryId: mod.categoryId,
    categoryName: mod.categoryName,
    title: mod.title,
    subtitle: mod.subtitle,
    minutes: mod.minutes,
    understanding: {
      welcome: mod.challenge.welcome,
      checklistTitle: mod.challenge.checklistTitle,
      checklist: mod.challenge.checklist,
      normalizing: mod.challenge.normalizing,
      essentials,
      stages: mod.learn.stages,
    },
    checkIn: mod.checkIn,
    adel: mod.adel,
    skill: mod.skill,
    insight: mod.insight,
    progressNote: mod.progressNote,
    toolkitKey: mod.toolkitKey,
    exerciseId: mod.exerciseId,
    activity: mod.activity,
    threads: mod.threads,
  };
}

const SELF_HELP_OVERRIDES: Record<string, Partial<SelfHelpModule>> = {};

function applySelfHelpOverride(mod: SelfHelpModule): SelfHelpModule {
  const o = SELF_HELP_OVERRIDES[mod.id];
  return o ? { ...mod, ...o } : mod;
}

export function buildSelfHelpModule(cat: LibraryCategory, item: LibraryItem): SelfHelpModule {
  return applySelfHelpOverride(toSelfHelpModule(buildCanonicalModule(cat, item)));
}

export function getSelfHelpModule(categoryId: string, itemId: string): SelfHelpModule | null {
  const cat = LIBRARY.find((c) => c.id === categoryId);
  const item = cat?.items.find((i) => i.id === itemId);
  if (!cat || !item) return null;
  return buildSelfHelpModule(cat, item);
}

/** Threads with the highest (>0) count of matching member picks. */
export function leadThreads(threads: ModuleThread[] | undefined, picks: string[]): ModuleThread[] {
  if (!threads?.length) return [];
  const scored = threads.map((t) => ({ t, n: t.statements.filter((s) => picks.includes(s)).length }));
  const max = Math.max(0, ...scored.map((x) => x.n));
  return max > 0 ? scored.filter((x) => x.n === max).map((x) => x.t) : [];
}
