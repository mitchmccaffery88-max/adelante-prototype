/**
 * Phone numbers used in Welcome to Adelante safety screens and the 24-hour plan.
 *
 * CONFIRM BEFORE LAUNCH — every number below must be re-checked by phone
 * before a real member sees it.
 */
export const LINES = {
  /** 988 Suicide & Crisis Lifeline — call or text. Also helps with drug and alcohol use. */
  crisis988: { label: "988", tel: "988", sms: "988" },
  tulareCrisis: { label: "Tulare County crisis line (24/7)", number: "1-800-320-1616", tel: "18003201616", verified: false },
  /** 211 — Tulare County help line (shelter, food, rides). */
  help211: { label: "211", tel: "211" },
  /** Never Use Alone — someone stays on the line while you use. */
  neverUseAlone: { label: "800-484-3731", tel: "18004843731" },
  neverUseAloneSpanish: { label: "800-928-5330", tel: "18009285330" },
  /**
   * California Peer-Run Warm Line. Also listed as 855-845-7415 —
   * CONFIRM BEFORE LAUNCH which number is current.
   */
  warmLine: { label: "855-600-9276", tel: "18556009276", altLabel: "855-845-7415" },
  /** Prototype peer specialist number (matches the Peer page). */
  peer: { label: "Devon", tel: "5555550111" },
} as const;
