// Public Assistance category (Tulare County, CA).
// DATA RULE: only details confirmed from an official/government source are filled in.
// Anything not confirmed is left blank ("") — never guessed. No prices or income limits.
import type { Resource } from "./mock";

export const PA_SECTIONS = [
  { id: "food", name: "Food" },
  { id: "shelter", name: "Shelter and Housing" },
  { id: "phone", name: "Phone (Free LifeLine Phones)" },
  { id: "cash", name: "Cash Aid and Health Coverage" },
] as const;

export const PA_INTRO =
  "In California, a past drug felony conviction does not by itself block CalFresh or CalWORKs, as long as you otherwise qualify and follow your parole or probation terms. A county eligibility worker can confirm what applies to you.";

export const LIFELINE_EXPLAINER = [
  "You can get LifeLine if you're on a program like Medi-Cal, CalFresh, SSI, WIC, CalWORKs, or Section 8 — or based on household income.",
  "Only one LifeLine benefit per household.",
  "You renew every year.",
  "You apply through a phone company (provider) and the California LifeLine administrator.",
  "The companies below are listed as options, not endorsements.",
];

const TODAY = "2026-09-24";

function pa(p: Pick<Resource, "id" | "name" | "description" | "section" | "tag"> & Partial<Resource>): Resource {
  return {
    category: "assistance",
    address: "",
    city: "",
    phone: "",
    website: "",
    hours: "",
    distanceMi: 0,
    isOpen: true,
    level: "state",
    source: "verified-web-search",
    ...p,
    verified: false,
  };
}

const carrier = (id: string, name: string, website: string, checked: boolean) =>
  pa({
    id, name, website, section: "phone", tag: "Free phone carrier", level: "state",
    description: "A phone company that offers California LifeLine service.",
    whoQualifies: "People on a program like Medi-Cal, CalFresh, SSI, WIC, CalWORKs, or Section 8, or with low household income.",
    howToApply: "Apply online on their website. They send your application to the California LifeLine administrator.",
    lastVerified: checked ? TODAY : undefined,
  });

export const PUBLIC_ASSISTANCE: Resource[] = [
  // ---------- Phone ----------
  pa({ id: "pa-ca-lifeline", name: "California LifeLine (official portal)", section: "phone", tag: "California (statewide)",
    website: "https://californialifeline.com/en",
    description: "The official state starting point for a free or low-cost phone. Start here to see providers.",
    whoQualifies: "People on a public assistance program or with low household income. One per household.",
    howToApply: "Online. Use the provider search to pick a phone company, then apply through them." }),
  pa({ id: "pa-ca-lifeline-search", name: "California LifeLine – Provider search", section: "phone", tag: "California (statewide)",
    website: "https://www.californialifeline.com/en/provider_search",
    description: "Look up which LifeLine phone companies serve your area.",
    howToApply: "Online." }),
  pa({ id: "pa-prn", name: "Prisoner Reentry Network – PRN resources", section: "phone", tag: "California (statewide)", level: "regional",
    website: "https://prisonerreentrynetwork.org/resources/prn-produced", lastVerified: TODAY,
    description: "Free guides made for people coming home, including how to get a phone." }),
  carrier("pa-truconnect", "TruConnect", "https://www.truconnect.com/states/california", false),
  carrier("pa-genmobile", "Gen Mobile", "https://www.genmobile.com/pages/ca-state-california-lifeline-program", true),
  carrier("pa-assurance", "Assurance Wireless", "https://www.assurancewireless.com/lifeline-services/states/california-lifeline-free-government-phone-service", false),
  carrier("pa-lifewireless", "Life Wireless", "https://lifewireless.com/plans/california-lifeline-free-phone-service", false),
  carrier("pa-access", "Access Wireless", "https://www.accesswireless.com/", true),
  carrier("pa-safelink", "SafeLink Wireless", "https://www.safelinkwireless.com/", false),

  // ---------- Food ----------
  pa({ id: "pa-211-food", name: "211 Tulare County", section: "food", tag: "Tulare County", level: "county",
    phone: "211", website: "https://www.211tularecounty.org", hours: "24/7", lastVerified: TODAY,
    description: "Free, 24/7 referral line for food, shelter, housing, transportation, and other help in Tulare County.",
    whoQualifies: "Anyone.", howToApply: "Call or text 2-1-1." }),
  pa({ id: "pa-calfresh", name: "CalFresh (Tulare County HHSA)", section: "food", tag: "Tulare County", level: "county",
    website: "https://tchhsa.org/eng/human-services",
    description: "Monthly money for food on an EBT card.",
    whoQualifies: "Based on household income and size. A past drug felony does not by itself block you.",
    howToApply: "Online, by phone, or in person at a county office." }),
  pa({ id: "pa-getcalfresh", name: "GetCalFresh (apply online)", section: "food", tag: "California (statewide)",
    website: "https://www.getcalfresh.org", lastVerified: TODAY,
    description: "A simple online CalFresh application you can do on your phone.",
    howToApply: "Online, about 10 minutes." }),
  pa({ id: "pa-benefitscal", name: "BenefitsCal", section: "food", tag: "California (statewide)",
    website: "https://benefitscal.com",
    description: "The state website to apply for CalFresh, Medi-Cal, CalWORKs, and General Assistance.",
    howToApply: "Online." }),
  pa({ id: "pa-wic", name: "WIC (Tulare County HHSA)", section: "food", tag: "Tulare County", level: "county",
    website: "https://tchhsa.org/eng/human-services",
    description: "Healthy food and nutrition help for pregnant women, new moms, babies, and kids under 5.",
    howToApply: "Contact Tulare County HHSA." }),
  pa({ id: "pa-foodlink", name: "FoodLink for Tulare County", section: "food", tag: "Tulare County", level: "county",
    website: "https://foodlinktc.org", lastVerified: TODAY,
    description: "The county food bank. They can point you to a pantry near where you're staying." }),

  // ---------- Shelter and Housing ----------
  pa({ id: "pa-kth-alliance", name: "Kings/Tulare Homeless Alliance – Every Door Open", section: "shelter", tag: "Tulare County", level: "regional",
    website: "https://www.kthomelessalliance.org", lastVerified: TODAY,
    description: "The front door to housing help (Coordinated Entry). Any access point below can get you started.",
    howToApply: "Go to or call any Coordinated Entry access point." }),
  pa({ id: "pa-vrm", name: "Visalia Rescue Mission (access point)", section: "shelter", tag: "Tulare County", level: "city",
    website: "https://www.vrm.org", description: "Coordinated Entry access point and shelter services in Visalia." }),
  pa({ id: "pa-cset", name: "CSET (access point)", section: "shelter", tag: "Tulare County", level: "county",
    website: "https://www.cset.org", lastVerified: TODAY, description: "Coordinated Entry access point and housing services." }),
  pa({ id: "pa-fstc", name: "Family Services of Tulare County (access point)", section: "shelter", tag: "Tulare County", level: "county",
    website: "https://www.fstc.net", lastVerified: TODAY, description: "Coordinated Entry access point and housing support." }),
  pa({ id: "pa-ccfcc", name: "Central California Family Crisis Center (access point)", section: "shelter", tag: "Tulare County", level: "county",
    website: "https://www.ccfcc.org", lastVerified: TODAY, description: "Coordinated Entry access point, based in Porterville." }),
  pa({ id: "pa-champions", name: "Champions Recovery (access point)", section: "shelter", tag: "Tulare County", level: "county",
    website: "https://www.championsrecovery.org", lastVerified: TODAY, description: "Coordinated Entry access point with recovery support." }),
  pa({ id: "pa-porterville-nav", name: "Porterville Navigation Center (access point)", section: "shelter", tag: "Tulare County", level: "city",
    description: "Coordinated Entry access point in Porterville. Call 2-1-1 for current details." }),
  pa({ id: "pa-hatc", name: "Housing Authority of the County of Tulare", section: "shelter", tag: "Tulare County", level: "county",
    website: "https://www.hatc.net", lastVerified: TODAY,
    description: "Section 8 vouchers and public housing.", howToApply: "Check their website for open waiting lists." }),

  // ---------- Cash Aid and Health Coverage ----------
  pa({ id: "pa-calworks", name: "CalWORKs / TulareWORKs", section: "cash", tag: "Tulare County", level: "county",
    website: "https://tchhsa.org/eng/human-services",
    description: "Cash aid and job help for families with children.",
    whoQualifies: "Families with children, based on income. A past drug felony does not by itself block you.",
    howToApply: "Online on BenefitsCal, or in person at a county office." }),
  pa({ id: "pa-ga", name: "General Assistance", section: "cash", tag: "Tulare County", level: "county",
    website: "https://tchhsa.org/eng/human-services",
    description: "County cash aid for eligible adults with no other support.",
    howToApply: "Contact Tulare County HHSA." }),
  pa({ id: "pa-medi-cal", name: "Medi-Cal", section: "cash", tag: "Tulare County", level: "county",
    website: "https://tchhsa.org/eng/human-services",
    description: "No-cost or low-cost health coverage — doctors, medications, and recovery treatment.",
    howToApply: "Online on BenefitsCal, by phone, or in person." }),
  pa({ id: "pa-ssi", name: "SSI Advocacy", section: "cash", tag: "Tulare County", level: "county",
    website: "https://tchhsa.org/eng/human-services",
    description: "Help applying for Supplemental Security Income if you have a disability." }),
  pa({ id: "pa-liheap", name: "LIHEAP utility bill help", section: "cash", tag: "California (statewide)",
    website: "https://www.csd.ca.gov/Pages/LIHEAPProgram.aspx", lastVerified: TODAY,
    description: "Help paying gas and electric bills. The state site lists the local agency for Tulare County." }),
];
