import test from "node:test";
import assert from "node:assert/strict";
import { RESOURCES } from "./mock";
import { getEmploymentSections } from "./resource-additions";
import { BACK_ON_FEET } from "./topic-content/library-back-on-feet";

test("Employment groups fair-chance programs first, job centers second, rights third", () => {
  const sections = getEmploymentSections(RESOURCES);
  assert.deepEqual(sections.map((section) => section.name), [
    "Find work with a record", "Job centers", "Know your rights and tell employers", "More job help",
  ]);
  const ids = (index: number) => sections[index]?.resources.map((resource) => resource.id).sort();
  assert.deepEqual(ids(0), ["add-honest-jobs", "reset-probation", "cset-employment", "proteus-inc"].sort());
  assert.deepEqual(ids(1), ["add-tulare-wib", "add-caljobs", "edd-california"].sort());
  assert.deepEqual(ids(2), ["add-fair-chance", "add-federal-bonding", "add-wotc"].sort());
});

test("unassigned and unknown-section Employment entries appear in the last group only", () => {
  const resource = RESOURCES.find((entry) => entry.id === "add-honest-jobs");
  assert.ok(resource);
  const sections = getEmploymentSections([
    { ...resource, id: "other", section: undefined },
    { ...resource, id: "unknown", section: "other section" },
    { ...resource, id: "not-employment", category: "housing" },
  ]);
  assert.deepEqual(sections.slice(0, 3).flatMap((section) => section.resources), []);
  assert.deepEqual(sections[3]?.resources.map((entry) => entry.id), ["other", "unknown"]);
});

for (const [id, limit] of [["answer", 1], ["skills", 3], ["proof", 3], ["refs", 2], ["where", 2]] as const) {
  test(`Work skill step ${id} allows ${limit} picks`, () => {
    assert.equal(BACK_ON_FEET.work.skillSteps?.find((step) => step.id === id)?.maxPicks, limit);
  });
}