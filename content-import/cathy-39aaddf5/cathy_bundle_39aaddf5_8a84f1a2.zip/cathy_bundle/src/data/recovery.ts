// Recovery Journey — a second, independent learning vertical alongside the
// Mental Health Journey. Same design language, separate progress + toolkit + badges.

export type RecoveryLesson = {
  id: string;
  title: string;
  /** The one simple question this lesson answers. */
  focus: string;
  /** 2–4 plain-language microlearning points. */
  learn: string[];
  /** Peer recovery story. */
  story: { name: string; text: string };
  /** Build My Tool step. */
  build: { label: string; prompt: string; placeholder: string; chips: string[] };
  /** Practice in Real Life step. */
  practice: { scenario: string; choices: string[]; thenPlaceholder: string };
  /** One simple action for today. */
  action: string;
  /** Name of the tool saved to the Recovery Toolkit. */
  tool: string;
  minutes: number;
};

export type RecoveryModule = {
  id: string;
  order: number;
  name: string;
  subtitle: string;
  mission: string;
  badge: string;
  icon: string;
  lessons: RecoveryLesson[];
};

type Seed = [title: string, focus: string, learn: string[], action: string, tool: string];

function build(
  moduleId: string,
  seeds: Seed[],
  story: (title: string) => { name: string; text: string },
  buildStep: (tool: string) => RecoveryLesson["build"],
  practice: (title: string) => RecoveryLesson["practice"],
): RecoveryLesson[] {
  return seeds.map(([title, focus, learn, action, tool], i) => ({
    id: `${moduleId}-${i + 1}`,
    title,
    focus,
    learn,
    story: story(title),
    build: buildStep(tool),
    practice: practice(title),
    action,
    tool,
    minutes: (moduleId === "understanding" && i === 2) || (moduleId === "when-hard" && i === 8) ? 8 : 5 + (i % 3),
  }));
}

const peerNames = ["Marcus", "Rosa", "Danny", "Tasha", "Luis", "Kim", "Ray", "Yolanda", "Andre", "Bea"];

function storyFor(theme: string) {
  let n = 0;
  return (title: string) => {
    const name = peerNames[(title.length + n++) % peerNames.length];
    return {
      name: `${name}, ${20 + ((title.length * 3) % 40)} months in recovery`,
      text: `"${theme} I didn't believe it would work for me either. I started small — one honest answer, one phone call, one day. That's all it took to start turning things around. If I can do it, you can too."`,
    };
  };
}

function buildFor(prompt: string, placeholder: string, chips: string[]) {
  return (tool: string): RecoveryLesson["build"] => ({
    label: tool,
    prompt,
    placeholder,
    chips,
  });
}

function practiceFor(choices: string[], thenPlaceholder: string) {
  return (title: string): RecoveryLesson["practice"] => ({
    scenario: `It's later today and the moment this lesson is about shows up for real — "${title}" It catches you off guard. What do you do first?`,
    choices,
    thenPlaceholder,
  });
}

export const RECOVERY_MODULES: RecoveryModule[] = [
  {
    id: "first-days",
    order: 1,
    name: "My First Days Out",
    subtitle: "Getting through today",
    mission: "Survive and Stabilize",
    badge: "First Week Strong",
    icon: "Compass",
    lessons: build(
      "first-days",
      [
        ["Take a Breath. You're Here.", "How do I settle down right now?", ["Your body is still on high alert. That's normal.", "Slow breathing tells your nervous system you're safe.", "Four in, six out, ten times."], "Do 10 slow breaths.", "My Calm-Down Steps"],
        ["What Should I Do If I Want to Use?", "What's my plan for a craving?", ["Cravings peak and pass in about 20 minutes.", "Change your place, your people, or your position.", "Reach out before you decide anything."], "Save your craving plan to your phone.", "My Craving Rescue Plan"],
        ["How Do I Find My First Meeting?", "Where do I even start?", ["Meetings are free and you don't have to talk.", "Look for a beginner or newcomer meeting.", "Going once counts."], "Pick one meeting to attend this week.", "My Meeting Plan"],
        ["Who Can Help Me Today?", "Who do I reach out to first?", ["Help today is better than a perfect plan tomorrow.", "Peer specialists have been where you are.", "One text is enough to start."], "Send one text asking for help.", "My Today Helpers"],
        ["What If I Already Used?", "Am I starting over from zero?", ["A slip is information, not failure.", "Get safe first, then get honest.", "Coming back fast is the whole skill."], "Tell one safe person what happened.", "My Come-Back Plan"],
        ["What's the Next Right Thing?", "How do I stop feeling frozen?", ["When everything feels big, shrink it.", "Ask: what's the next 10-minute thing?", "Momentum builds from tiny wins."], "Do one 10-minute task.", "My Next Right Thing"],
        ["Why Is Asking for Help So Hard?", "Why does asking feel dangerous?", ["Inside, asking could cost you. Out here, it saves you.", "People want to help more than you expect.", "Practice makes it easier."], "Ask one small favor today.", "My Ask-For-Help Script"],
        ["Why Do I Feel Like This?", "Why am I so up and down?", ["Your brain and body are healing. Mood swings are part of that.", "Sleep, food, and water change how you feel more than you think.", "Feelings pass faster when you name them."], "Name what you feel three times today.", "My Mood Notes"],
        ["How Can I End Today Strong?", "How do I close out a hard day?", ["An evening routine protects tomorrow.", "Three good things beats replaying the bad ones.", "Set out one thing for the morning."], "Write down three good things.", "My Evening Routine"],
        ["I Made It Through My First Week.", "What did I learn about myself?", ["Look back on purpose — proof builds confidence.", "Keep what worked. Drop what didn't.", "One week done is a real milestone."], "Tell someone you made it a week.", "My Week One Review"],
      ],
      storyFor("My first week out was the hardest week of my life."),
      buildFor("Build your plan. Tap a chip or type your own.", "Type here…", ["Call my sponsor", "Leave the room", "Cold water on my face", "Go for a walk", "Open my toolkit"]),
      practiceFor(["Leave the situation", "Call someone on my list", "Use urge surfing for 5 minutes", "Go to a meeting"], "…then I will…"),
    ),
  },
  {
    id: "my-people",
    order: 2,
    name: "Finding My People",
    subtitle: "You can't do this alone",
    mission: "Build My Support System",
    badge: "Connected",
    icon: "Users",
    lessons: build(
      "my-people",
      [
        ["Why Can't I Do This Alone?", "Why does connection matter so much?", ["Isolation feeds relapse. Connection protects recovery.", "You don't need many people — you need real ones.", "Being known is the point."], "Reach out to one person today.", "My Connection Plan"],
        ["Which Recovery Meeting Is Right for Me?", "Which meeting should I try?", ["AA, NA, SMART, Celebrate Recovery, Recovery Dharma — all valid.", "Try three before you decide.", "Online meetings count."], "Try one new meeting type.", "My Meeting Match"],
        ["What Really Happens at a Meeting?", "What should I expect?", ["People share, you listen. You can pass.", "No dues, no test, no judgment.", "Arriving early makes it easier."], "Show up 10 minutes early somewhere.", "My Meeting Prep"],
        ["How Do I Find a Sponsor?", "How do I ask someone?", ["Look for someone with what you want.", "Ask directly: 'Will you sponsor me?'", "A temporary sponsor counts."], "Ask one person to be a temporary sponsor.", "My Sponsor Ask"],
        ["What Does a Peer Recovery Specialist Do?", "How can a peer help me?", ["They've lived it and they're trained.", "They can go with you to appointments.", "They're free through your care team."], "Message your peer specialist.", "My Peer Support Plan"],
        ["Who Should Be on My Recovery Team?", "Who belongs on my team?", ["A team can include peer, sponsor, therapist, CHW, doctor, family.", "Everyone has one clear role.", "Write down how to reach each one."], "Fill in one empty spot on your team.", "My Recovery Team"],
        ["How Do I Learn to Trust Again?", "How do I let people in?", ["Trust is built in small, repeated proofs.", "Start with low-risk honesty.", "Trust yourself first by keeping small promises."], "Keep one small promise today.", "My Trust Steps"],
        ["How Do I Ask for Help?", "What do I actually say?", ["Name the need, name the size, name the timeline.", "Short and specific gets a yes.", "'I need a ride Thursday at 2' works."], "Use the script once today.", "My Ask Script"],
        ["What Does Recovery Look Like This Week?", "What's my week going to look like?", ["Recovery lives in your calendar, not your intentions.", "Two meetings, one check-in, one healthy thing.", "Write it where you'll see it."], "Put one recovery event in your week.", "My Weekly Rhythm"],
        ["My Weekly Recovery Plan.", "How do I keep this going?", ["Plan the week on the same day each week.", "Include people, not just tasks.", "Review it Sunday night."], "Plan next week now.", "My Weekly Recovery Plan"],
      ],
      storyFor("I thought I could white-knuckle it by myself."),
      buildFor("Who's in your corner? Add names and how to reach them.", "Name and phone…", ["Sponsor", "Peer specialist", "Case manager", "Sister", "Friend from meeting"]),
      practiceFor(["Text my sponsor", "Go to a meeting", "Call my peer specialist", "Show up somewhere in person"], "…then I will…"),
    ),
  },
  {
    id: "understanding",
    order: 3,
    name: "Understanding My Addiction",
    subtitle: "Why my brain does this",
    mission: "Know My Patterns",
    badge: "Self-Aware",
    icon: "Brain",
    lessons: build(
      "understanding",
      [
        ["Why Can't I Stop Thinking About Using?", "Why won't these thoughts leave?", ["Your brain learned using = relief. That memory is strong.", "Thoughts aren't orders.", "Naming a thought weakens it."], "Say 'that's a using thought' out loud once.", "My Thought Plan"],
        ["Why Are My Cravings So Strong?", "What's happening in my body?", ["Cravings are a wave — they rise, peak, and fall.", "Most peak within 20 minutes.", "You can ride one without acting on it."], "Time one craving instead of acting.", "My Urge Surfing Plan"],
        ["Medicine, Tolerance, and Staying Alive", "How medicine for addiction works, why tolerance drops after time away, and how naloxone saves lives.", ["Being on medicine is recovery, not cheating.", "After time away, your tolerance drops.", "Keep naloxone where you and others can grab it."], "Make a naloxone plan and ask one medicine question.", "My Medicine and Naloxone Plan"],
        ["What Is HALT Trying to Tell Me?", "Why do I feel off?", ["Hungry, Angry, Lonely, Tired.", "HALT states make cravings much stronger.", "Fixing the basic need often fixes the craving."], "Run a HALT check twice today.", "My HALT Check"],
        ["Why Does Stress Make Me Want to Use?", "Why does stress hit so hard?", ["Stress hormones push your brain toward fast relief.", "Slow breathing turns the alarm down.", "A stress plan beats willpower."], "Use one stress tool today.", "My Stress Plan"],
        ["How Are My Mental Health and Recovery Connected?", "Why do both need care?", ["Depression, anxiety, and trauma often ride along with SUD.", "Treating both together works better.", "Medication for either is not cheating."], "Book or confirm one appointment.", "My Whole-Health Plan"],
        ["Why Do I Keep Repeating the Same Pattern?", "Why does this keep happening?", ["Patterns have a trigger, a habit, and a payoff.", "Change the middle, not the whole life.", "Seeing the pattern is half of breaking it."], "Map one pattern you noticed.", "My Pattern Map"],
        ["What Happens While My Brain Is Healing?", "Will I ever feel normal?", ["Healing is real and measurable — weeks to months.", "Flat, foggy days are part of it.", "Sleep and routine speed it up."], "Protect your sleep tonight.", "My Healing Plan"],
        ["What Am I Really Running From?", "What's underneath this?", ["Substances often cover pain, not create it.", "Naming the real thing takes its power.", "You don't have to fix it alone."], "Write one honest sentence.", "My Honest Page"],
        ["Understanding My Recovery Story.", "What's my story so far?", ["Your story includes strength, not just damage.", "Telling it helps someone else.", "You get to write the next chapter."], "Tell one piece of your story to someone safe.", "My Recovery Story"],
      ],
      storyFor("For years I thought I was just weak."),
      buildFor("Write the parts that fit your life.", "Type here…", ["Old friends", "Payday", "Boredom", "Arguments", "That neighborhood", "Feeling alone"]),
      practiceFor(["Name it as a craving and wait it out", "Run a HALT check", "Leave the trigger behind", "Call for backup"], "…then I will…"),
    ),
  },
  {
    id: "everyday-life",
    order: 4,
    name: "Changing My Everyday Life",
    subtitle: "Small routines, big protection",
    mission: "Create Healthy Routines",
    badge: "Routine Builder",
    icon: "Sun",
    lessons: build(
      "everyday-life",
      [
        ["How Do I Build a Better Daily Routine?", "What should my day look like?", ["Routine removes decisions you can't afford to make.", "Anchor three times: morning, midday, night.", "Same time beats perfect time."], "Set one alarm for a daily anchor.", "My Daily Routine"],
        ["Why Is Sleep So Important?", "Why does sleep matter this much?", ["Poor sleep raises cravings the next day.", "Same bedtime, dark room, no screen for 30 min.", "Naps are fine, all-nighters aren't."], "Go to bed at the same time tonight.", "My Sleep Plan"],
        ["How Can Food Help My Recovery?", "What should I eat?", ["Low blood sugar feels a lot like a craving.", "Eat something every 4–5 hours.", "Protein and water first."], "Eat three times today.", "My Food Plan"],
        ["How Can Exercise Help Me Feel Better?", "Do I really have to work out?", ["Ten minutes of movement changes your mood chemistry.", "Walking counts. Stairs count.", "Doing it with someone helps you keep it."], "Walk for 10 minutes.", "My Movement Plan"],
        ["What Can I Do Instead of Using?", "What fills the space?", ["Boredom is a real relapse risk.", "Keep a list of 10 replacements ready.", "Cheap and nearby beats perfect."], "Do one thing off your list.", "My Instead-Of List"],
        ["How Do I Calm My Emotions?", "How do I settle myself down?", ["Big feelings pass faster when you don't fight them.", "Cold water, slow breath, movement.", "Talk it out before you act it out."], "Use one calming tool today.", "My Calm Plan"],
        ["How Do I Break Old Habits?", "How do I change a habit?", ["Habits need a cue, a routine, and a reward.", "Swap the routine, keep the reward.", "Make the old habit harder to reach."], "Swap one habit today.", "My Habit Swap"],
        ["Why Should I Take My Medication?", "Does medication really help?", ["MAT and mental health meds cut relapse risk a lot.", "Taking medication is recovery, not a shortcut.", "Side effects can usually be adjusted — ask."], "Take your meds on time today.", "My Medication Routine"],
        ["How Do I Have Fun Without Using?", "Can life still be fun?", ["Fun is a relapse-prevention skill.", "Try three new things this month.", "Sober fun feels flat at first, then better."], "Plan one fun thing this week.", "My Sober Fun List"],
        ["Building My Daily Recovery Plan.", "How do I put it all together?", ["One page. Morning, day, night.", "Include one person and one tool.", "Post it where you'll see it."], "Post your plan somewhere visible.", "My Daily Recovery Plan"],
      ],
      storyFor("Nobody told me routine was the thing that saved me."),
      buildFor("Design it your way — mornings, meals, bedtime.", "Type here…", ["Wake 7am", "Coffee + check-in", "Walk", "Meeting 6pm", "Lights out 10pm"]),
      practiceFor(["Follow my routine anyway", "Do the 10-minute version", "Ask someone to do it with me", "Reset tomorrow, no shame"], "…then I will…"),
    ),
  },
  {
    id: "relationships",
    order: 5,
    name: "Healing My Relationships",
    subtitle: "Rebuilding trust, one step",
    mission: "Repair and Protect",
    badge: "Bridge Builder",
    icon: "Heart",
    lessons: build(
      "relationships",
      [
        ["Can People Trust Me Again?", "Is trust even possible?", ["Trust returns through consistency, not apologies.", "Small kept promises add up fast.", "Some people will take longer. That's allowed."], "Keep one promise today.", "My Trust Plan"],
        ["How Do I Communicate Better?", "How do I say what I mean?", ["Use 'I feel… when… I need…'", "Say it before you're boiling.", "Listening is half of talking."], "Use one 'I' statement today.", "My Talking Tool"],
        ["How Do I Set Healthy Boundaries?", "How do I say no?", ["A boundary protects the relationship, not attacks it.", "Short and kind: 'I can't do that.'", "You don't owe a long reason."], "Set one boundary today.", "My Boundary Script"],
        ["How Can I Repair Family Relationships?", "How do I start fixing things?", ["Lead with change, not promises.", "Let them set the pace.", "Show up when it's boring, not just when it's big."], "Reach out to one family member.", "My Repair Plan"],
        ["How Can I Be the Parent I Want to Be?", "How do I show up for my kids?", ["Kids need present, not perfect.", "Small consistent time beats big gestures.", "Own your part in age-appropriate words."], "Spend 15 focused minutes with your child.", "My Parenting Plan"],
        ["What Makes a Healthy Friendship?", "Who is safe to be around?", ["Safe people respect your recovery.", "Watch actions over words.", "It's okay to outgrow people."], "Text one healthy friend.", "My Safe People List"],
        ["When Should I Walk Away?", "How do I know it's time?", ["If being around them puts your recovery at risk, that's your answer.", "Walking away can be temporary.", "Your life comes first."], "Mute or block one risky contact.", "My Walk-Away Plan"],
        ["How Do I Make Things Right?", "How do I make amends?", ["Amends means changed behavior, not just sorry.", "Don't make amends that hurt someone more.", "Talk it through with your sponsor first."], "List one amends you could make.", "My Amends List"],
        ["How Do I Forgive Myself?", "Can I let go of the guilt?", ["Guilt says 'I did bad.' Shame says 'I am bad.' Only one is useful.", "You can hold accountability and compassion together.", "Self-forgiveness makes relapse less likely."], "Write yourself one kind sentence.", "My Self-Forgiveness Note"],
        ["Building My Relationship Plan.", "How do I keep relationships healthy?", ["Name who you're rebuilding with and how.", "Include boundaries and check-ins.", "Review it monthly."], "Share one part of your plan with someone.", "My Relationship Plan"],
      ],
      storyFor("My family didn't believe me the first three times."),
      buildFor("Write it how you'd actually say it out loud.", "Type here…", ["I feel…", "I need…", "I can't do that", "Can we talk later?", "I'm working on it"]),
      practiceFor(["Take a pause before responding", "Use my 'I' statement", "Set the boundary out loud", "Step away and come back"], "…then I will…"),
    ),
  },
  {
    id: "life-that-works",
    order: 6,
    name: "Building a Life That Works",
    subtitle: "Housing, work, money, health",
    mission: "Get Stable",
    badge: "Ground Under Me",
    icon: "Building2",
    lessons: build(
      "life-that-works",
      [
        ["Where Am I Going to Live?", "How do I get stable housing?", ["Housing is a recovery issue, not a side issue.", "Ask about reentry and recovery housing first.", "Bring your ID and paperwork to every appointment."], "Call one housing resource.", "My Housing Plan"],
        ["How Do I Find a Job?", "Who will hire me?", ["Fair-chance employers exist and are growing.", "Start with staffing agencies and trades.", "Practice how you'll talk about your record."], "Apply to one job.", "My Job Search Plan"],
        ["How Do I Manage My Money?", "How do I stay on top of money?", ["Cash in your pocket can be a trigger. Plan for it.", "Split money: needs, savings, small joy.", "A simple budget beats no budget."], "Write down what you spent today.", "My Money Plan"],
        ["Should I Go Back to School?", "Is school worth it for me?", ["Short certificates can pay fast.", "Community colleges have reentry support.", "Financial aid may be available to you."], "Look up one program.", "My Education Plan"],
        ["How Do I Get Where I Need to Go?", "How do I solve transportation?", ["Missed rides cause missed appointments and setbacks.", "Bus passes and ride vouchers exist — ask.", "Plan the ride when you book the appointment."], "Set up a ride for your next appointment.", "My Transportation Plan"],
        ["How Do I Take Care of My Health?", "How do I get healthcare?", ["Medi-Cal covers most reentry needs.", "Pick one primary doctor and stick with them.", "Dental and vision count too."], "Confirm your insurance is active.", "My Health Plan"],
        ["What Resources Can Help Me?", "What's out there for me?", ["Food, clothing, phones, IDs — most are free.", "One agency often connects you to five more.", "Ask your community health worker."], "Contact one resource today.", "My Resource List"],
        ["What Can I Do Instead of Using?", "How do I fill my time well?", ["Purpose is protection.", "Volunteering builds a résumé and a network.", "Structure your free time before it structures you."], "Sign up for one activity.", "My Purpose List"],
        ["What Kind of Life Do I Want?", "What am I building?", ["Picture a normal Tuesday one year from now.", "Write it in detail.", "Work backward into steps."], "Describe your future Tuesday.", "My Life Vision"],
        ["Building My Stability Plan.", "How do I keep it all standing?", ["Housing, income, health, transport — one action each.", "Deadlines beat wishes.", "Review with your case manager."], "Do one action off your stability plan.", "My Stability Plan"],
      ],
      storyFor("Getting an ID felt impossible until someone walked me through it."),
      buildFor("Write the real next step — small and specific.", "Type here…", ["Call the housing office", "Get my ID", "Update résumé", "Bus pass", "Set up Medi-Cal"]),
      practiceFor(["Make the call anyway", "Ask my case manager for help", "Break it into one 10-minute step", "Bring someone with me"], "…then I will…"),
    ),
  },
  {
    id: "when-hard",
    order: 7,
    name: "When Recovery Gets Hard",
    subtitle: "Slips, setbacks, and coming back",
    mission: "Strengthen My Recovery",
    badge: "Comeback Ready",
    icon: "ShieldCheck",
    lessons: build(
      "when-hard",
      [
        ["How Do I Know I'm Slipping?", "What are my warning signs?", ["Relapse starts long before the first use.", "Watch for isolating, skipping meetings, secret-keeping.", "Warning signs are a chance, not a verdict."], "List your top 3 warning signs.", "My Warning Signs"],
        ["What Happens Before a Relapse?", "What's the chain of events?", ["Emotional → mental → physical relapse.", "You can break the chain at any link.", "Earlier is easier."], "Name where you usually get stuck.", "My Relapse Chain"],
        ["What Should I Do When My Thoughts Change?", "What if I start romanticizing using?", ["Play the tape all the way forward.", "Tell on the thought — say it out loud to someone.", "Thoughts lose power in daylight."], "Tell someone about one using thought.", "My Play-the-Tape Tool"],
        ["How Do I Get Through High-Risk Situations?", "How do I handle risky places?", ["Avoid what you can, plan for what you can't.", "Have an exit and a ride before you go.", "Bring a sober person."], "Plan an exit for one event.", "My High-Risk Plan"],
        ["What If I Slip?", "What do I do right after?", ["Get safe. Then get honest. Then get support.", "One slip is not a relapse unless you hide it.", "Nobody here is going to shame you."], "Save your slip-response steps.", "My Slip Response"],
        ["How Do I Start Again?", "How do I come back?", ["Return to basics: meeting, sleep, food, call.", "Day one is a decision, not a punishment.", "Coming back fast protects everything you built."], "Do one basics thing today.", "My Restart Plan"],
        ["When Should I Ask for Help?", "How do I know it's time?", ["Sooner than you think.", "If you're debating it, that's the sign.", "Asking early is a strength move."], "Reach out before you 'need' to.", "My Early-Ask Rule"],
        ["Which Recovery Tools Work Best for Me?", "What actually works for me?", ["Track what helps, drop what doesn't.", "Your top 3 tools should be one tap away.", "Tools change over time — that's fine."], "Pick your top 3 tools.", "My Top Tools"],
        ["After a Positive Test", "What to do if a slip shows up on a test, or you're afraid it will.", ["A positive test is serious, not the end.", "Talk before you decide.", "Don't skip the test."], "Plan who you'll talk to first and what you'll say.", "My Positive-Test Plan"],
        ["Building My Relapse Prevention Plan.", "What's my full plan?", ["Triggers, warning signs, tools, people, emergency steps.", "Share it with two people.", "Update it after every hard week."], "Share your plan with one person.", "My Relapse Prevention Plan"],
      ],
      storyFor("I slipped at four months and thought it was over."),
      buildFor("Be honest here — this plan only works if it's real.", "Type here…", ["Isolating", "Skipping meetings", "Not sleeping", "Old friends texting", "Feeling resentful"]),
      practiceFor(["Call my sponsor immediately", "Leave and go somewhere safe", "Open my relapse prevention plan", "Get to a meeting today"], "…then I will…"),
    ),
  },
  {
    id: "someone-new",
    order: 8,
    name: "Becoming Someone New",
    subtitle: "Identity, meaning, and hope",
    mission: "Grow Into Who I'm Becoming",
    badge: "New Chapter",
    icon: "Star",
    lessons: build(
      "someone-new",
      [
        ["What Am I Good At?", "What are my strengths?", ["Everyone in recovery has survival skills worth reusing.", "Loyalty, hustle, reading people — those count.", "Strengths are proof you can change."], "Name three strengths out loud.", "My Strengths List"],
        ["How Do I Believe in Myself Again?", "How do I rebuild confidence?", ["Confidence comes from evidence, not pep talks.", "Collect small proof daily.", "Do the thing before you feel ready."], "Write one piece of proof.", "My Confidence Log"],
        ["What Gives My Life Meaning?", "Why am I doing this?", ["Meaning is the strongest relapse protection there is.", "It can be people, purpose, faith, or service.", "Meaning grows when you act on it."], "Do one meaningful thing today.", "My Meaning Statement"],
        ["What Kind of Person Do I Want to Become?", "Who am I becoming?", ["Describe the person, not the goals.", "Ask: what would that person do today?", "Identity change makes habits stick."], "Act like that person once today.", "My Future Self"],
        ["How Can Gratitude Help Me?", "Does gratitude actually work?", ["Gratitude changes what your brain looks for.", "Three specific things beats one general one.", "Do it at the same time daily."], "Write three gratitudes.", "My Gratitude Practice"],
        ["How Do I Find Peace?", "How do I quiet my mind?", ["Peace is practiced, not found.", "Stillness feels uncomfortable at first.", "Five minutes counts."], "Sit quietly for five minutes.", "My Peace Practice"],
        ["What Does Spiritual Recovery Mean to Me?", "Do I need to be religious?", ["Spiritual can mean nature, service, music, or faith.", "It's about connection to something bigger.", "You define it."], "Do one spiritual practice.", "My Spiritual Plan"],
        ["How Can I Help Other People?", "What do I have to give?", ["Helping others strengthens your own recovery.", "Start small: a ride, a chair, a listen.", "Your experience is valuable."], "Help one person today.", "My Service Plan"],
        ["What Future Am I Building?", "Where is this going?", ["Write a one-year and five-year picture.", "Name one step for each.", "Read it when it gets hard."], "Write your one-year picture.", "My Future Plan"],
        ["Creating My Vision for Life.", "What's my vision?", ["Vision = values + picture + steps.", "Keep it short enough to remember.", "Share it with someone who believes you."], "Read your vision out loud.", "My Life Vision Card"],
      ],
      storyFor("I didn't know who I was without using."),
      buildFor("Dream a little here. Write what you actually want.", "Type here…", ["Be a good parent", "Steady job", "My own place", "Help others", "Peace of mind"]),
      practiceFor(["Ask what my future self would do", "Do one small brave thing", "Write it down", "Tell someone my goal"], "…then I will…"),
    ),
  },
  {
    id: "living-recovery",
    order: 9,
    name: "Living Recovery",
    subtitle: "Keeping what you built",
    mission: "Protect My Recovery for Life",
    badge: "Long Road Walker",
    icon: "Infinity",
    lessons: build(
      "living-recovery",
      [
        ["How Do I Stay in Recovery?", "How do I keep this going long-term?", ["Recovery is maintained, not finished.", "Keep three anchors: people, routine, purpose.", "Complacency is the quiet risk."], "Check your three anchors.", "My Maintenance Plan"],
        ["Why Should I Keep Going to Meetings?", "Do I still need meetings?", ["Meetings keep you honest and connected.", "You start becoming the person newcomers need.", "One a week protects a lot."], "Go to one meeting this week.", "My Meeting Commitment"],
        ["How Does Sponsorship Change Recovery?", "What changes with a sponsor?", ["A sponsor gives you structure and truth.", "Sponsoring others deepens your own recovery.", "Both directions help."], "Talk to your sponsor this week.", "My Sponsorship Plan"],
        ["How Can Helping Others Help Me?", "Why does service work?", ["Service pulls you out of your own head.", "It rebuilds self-respect fast.", "You keep it by giving it away."], "Do one act of service.", "My Service Commitment"],
        ["How Do I Give Back?", "What can I offer my community?", ["Share your story where it's welcome.", "Mentor, drive, cook, set up chairs.", "Give what you can sustain."], "Volunteer for one thing.", "My Give-Back Plan"],
        ["How Do I Protect Everything I've Built?", "How do I not lose this?", ["Protect sleep, people, and your schedule.", "Say no to what threatens it.", "Review your plan monthly."], "Say no to one risky thing.", "My Protection Plan"],
        ["What Do I Do When Life Gets Hard Again?", "What about the next crisis?", ["Hard times come. A plan makes them survivable.", "Use the same basics that worked before.", "Ask for help early."], "Write your crisis basics.", "My Hard-Times Plan"],
        ["How Should I Celebrate My Progress?", "How do I mark milestones?", ["Milestones make progress real.", "Celebrate sober and with people.", "30, 60, 90, one year — all count."], "Plan your next milestone.", "My Milestone Plan"],
        ["How Far Have I Come?", "What have I actually done?", ["Look back at where you started.", "Count tools, days, and relationships.", "Progress you can see keeps you going."], "Read your first lesson notes.", "My Progress Review"],
        ["My Lifelong Recovery Plan.", "What's my forever plan?", ["One page: people, routine, warning signs, purpose.", "Update it every 90 days.", "Give a copy to someone you trust."], "Finish your lifelong plan.", "My Lifelong Recovery Plan"],
      ],
      storyFor("Three years later, the basics are still the basics."),
      buildFor("This is your long game. Keep it simple and real.", "Type here…", ["Weekly meeting", "Sponsor call", "Service work", "Monthly review", "Family time"]),
      practiceFor(["Go back to the basics", "Call my people", "Review my plan", "Get to a meeting"], "…then I will…"),
    ),
  },
];

/** Same-day stabilization ("Welcome to Adelante" / PRE-MODULE: I Just Got Out)
 * now lives on the home dashboard at /start — see src/data/reentry.ts. */

/** The 9 recovery missions shown on the Recovery Journey dashboard. */
export const RECOVERY_JOURNEY_MODULES = RECOVERY_MODULES;

export const RECOVERY_LESSON_COUNT = RECOVERY_JOURNEY_MODULES.reduce((n, m) => n + m.lessons.length, 0);

export function findRecoveryLesson(moduleId: string, lessonId: string) {
  const mod = RECOVERY_MODULES.find((m) => m.id === moduleId);
  const lesson = mod?.lessons.find((l) => l.id === lessonId);
  if (!mod || !lesson) return null;
  const idx = mod.lessons.indexOf(lesson);
  return { mod, lesson, idx, next: mod.lessons[idx + 1] ?? null };
}

export const RECOVERY_SUPPORT = {
  "Recovery Support": [
    { label: "Find a meeting", to: "/community-resources/recovery" },
    { label: "Virtual meetings", to: "/community-resources/recovery" },
    { label: "My sponsor", to: "/toolkit", search: { tab: "tools" } },
    { label: "Peer recovery specialist", to: "/peer" },
    { label: "Community health worker", to: "/peer" },
    { label: "Therapist", to: "/appointments" },
    { label: "Teletherapy", to: "/appointments" },
    { label: "My plans", to: "/toolkit", search: { tab: "plans" } },
  ],
  "Community resources": [
    { label: "Housing", to: "/community-resources/housing" },
    { label: "Food", to: "/community-resources/food" },
    { label: "Transportation", to: "/community-resources/transportation" },
    { label: "Employment", to: "/community-resources/employment" },
  ],
  "Immediate help": [
    { label: "Use my plan now", to: "/my-plans" },
    { label: "My safety plan", to: "/safety-plan" },
    { label: "Call or text 988", to: "/crisis" },
    { label: "Call 911", to: "/crisis" },
  ],
  "Daily recovery": [
    { label: "Daily check-in", to: "/checkin" },
    { label: "Mood tracker", to: "/checkin" },
    { label: "Craving tracker", to: "/craving" },
    { label: "Recovery journal", to: "/toolkit", search: { tab: "tools" } },
  ],
} as const;
