// Additional Community Resources (Tulare County, CA) — ADDITIVE ONLY.
// DATA RULE: only details confirmed on the organization's own site or a government
// source are filled in. Anything not confirmed is left blank ("") — never guessed.
// No prices, fees, income limits, or meeting days/times.
import type { Resource } from "./mock";

const TODAY = "2026-09-24";

type Tag = "Tulare County" | "California (statewide)" | "National";

function add(
  p: Pick<Resource, "id" | "name" | "category" | "description"> & { tag: Tag } & Partial<Resource>,
  checked = true,
): Resource {
  return {
    address: "",
    city: "",
    phone: "",
    website: "",
    hours: "",
    distanceMi: 0,
    isOpen: true,
    level: p.tag === "Tulare County" ? "county" : p.tag === "National" ? "federal" : "state",
    source: "verified-web-search",
    lastVerified: checked ? TODAY : undefined,
    ...p,
    verified: false,
  };
}

export const RESOURCE_ADDITIONS: Resource[] = [
  // ---------------- Housing ----------------
  add({ id: "add-kt-homeless-alliance", name: "Kings/Tulare Homeless Alliance – Every Door Open", category: "housing", tag: "Tulare County",
    website: "https://www.kthomelessalliance.org", phone: "559-738-8733", city: "Visalia, CA",
    description: "The front door to housing help in Tulare County. They add you to the Coordinated Entry list for housing programs.",
    howToApply: "Call or visit their website to find an Every Door Open access point." }),
  add({ id: "add-turning-point-housing", name: "Turning Point of Central California", category: "housing", tag: "Tulare County",
    website: "https://www.tpocc.org", phone: "(559) 732-8086", city: "Visalia, CA",
    description: "Transitional housing and reentry services, plus mental health and recovery programs." }),
  add({ id: "add-champions-recovery", name: "Champions Recovery Alternative Programs", category: "housing", tag: "Tulare County",
    website: "https://www.championsrecovery.org", phone: "(559) 583-9300",
    description: "Recovery-focused housing and services for people with substance use and co-occurring needs in Kings and Tulare Counties." }),

  // ---------------- Emergency Shelter ----------------
  add({ id: "add-kt-ce-shelter", name: "Coordinated Entry Access Points (Every Door Open)", category: "shelter", tag: "Tulare County",
    website: "https://www.kthomelessalliance.org", phone: "559-738-8733",
    description: "Get on the county list for shelter and housing programs through an access point." }),
  add({ id: "add-salvation-army-tulare", name: "The Salvation Army – Tulare Corps Community Center", category: "shelter", tag: "Tulare County",
    website: "https://tulare.salvationarmy.org", phone: "559-687-2520", city: "Tulare, CA",
    description: "Helps people in the Tulare area. Call to ask what shelter and emergency help is available now." }),
  add({ id: "add-ccfcc", name: "Central California Family Crisis Center", category: "shelter", tag: "Tulare County",
    website: "https://www.ccfcc.org",
    description: "Safe shelter and support for people leaving domestic violence." }),

  // ---------------- Employment ----------------
  add({ id: "add-honest-jobs", name: "Honest Jobs", category: "employment", tag: "National", section: "Find work with a record",
    website: "https://www.honestjobs.com",
    description: "A free job board just for people with records. Every employer on it is open to fair-chance hiring.",
    howToApply: "Make a free profile on the website, then search jobs near Tulare County." }),
  add({ id: "add-tulare-wib", name: "Workforce Investment Board of Tulare County (Employment Connection)", category: "employment", tag: "Tulare County",
    section: "Job centers",
    website: "https://www.tularewib.org", phone: "559-713-5200", city: "Visalia, CA",
    description: "Free job search help, training, and job fairs. Runs the Employment Connection centers and the Tulare County Job Fair." }),
  add({ id: "add-caljobs", name: "CalJOBS (America's Job Center of California)", category: "employment", tag: "California (statewide)",
    section: "Job centers",
    website: "https://www.caljobs.ca.gov",
    description: "The state's free job board. Search jobs, build a resume, and find your nearest job center." }, false),
  add({ id: "add-federal-bonding", name: "Federal Bonding Program", category: "employment", tag: "National",
    section: "Know your rights and tell employers",
    website: "https://bonds4jobs.com",
    description: "Free bonds that protect employers who hire people with a record. Tell employers about it." }),
  add({ id: "add-wotc", name: "Work Opportunity Tax Credit (WOTC)", category: "employment", tag: "National",
    section: "Know your rights and tell employers",
    website: "https://www.dol.gov/agencies/eta/wotc",
    description: "A tax credit for employers who hire people with a past conviction. Good to mention in interviews." }, false),
  add({ id: "add-fair-chance", name: "California Fair Chance Act (Civil Rights Department)", category: "employment", tag: "California (statewide)",
    section: "Know your rights and tell employers",
    website: "https://calcivilrights.ca.gov/fair-chance-act/",
    description: "Know your rights. Most employers can't ask about your record until after a job offer." }),

  // ---------------- Education ----------------
  add({ id: "add-tc-library-edu", name: "Tulare County Library", category: "education", tag: "Tulare County",
    website: "https://www.tularecountylibrary.org", address: "200 W Oak Ave", city: "Visalia, CA",
    description: "Free library card, computers, internet, and adult literacy help at branches across the county." }),
  add({ id: "add-fafsa", name: "FAFSA – Federal Student Aid", category: "education", tag: "National",
    website: "https://studentaid.gov",
    description: "Apply for free money for college or trade school. Many people with a record can qualify." }),
  add({ id: "add-ca-dream-act", name: "California Dream Act Application", category: "education", tag: "California (statewide)",
    website: "https://dream.csac.ca.gov",
    description: "State financial aid application for students who can't use the FAFSA." }, false),
  add({ id: "add-khan-academy", name: "Khan Academy", category: "education", tag: "National",
    website: "https://www.khanacademy.org",
    description: "Free lessons you can start on your phone — math, reading, and GED prep." }),

  // ---------------- Legal Services ----------------
  add({ id: "add-crla", name: "California Rural Legal Assistance (CRLA)", category: "legal", tag: "California (statewide)",
    website: "https://crla.org", phone: "800-337-0690",
    description: "Free legal help for low-income people in rural California — housing, work, and benefits." }),
  add({ id: "add-courts-clean-record", name: "California Courts – Clean Your Record", category: "legal", tag: "California (statewide)",
    website: "https://selfhelp.courts.ca.gov/clean-your-record",
    description: "Official step-by-step guide and forms to clear or reduce a past conviction." }),
  add({ id: "add-ca-child-support-legal", name: "California Child Support Services", category: "legal", tag: "California (statewide)",
    website: "https://childsupport.ca.gov",
    description: "Questions about a child support order, or asking to change it after release." }),
  add({ id: "add-dmv-id-card", name: "California DMV – ID Cards", category: "legal", tag: "California (statewide)",
    website: "https://www.dmv.ca.gov/portal/driver-licenses-identification-cards/identification-id-cards/",
    description: "How to get a California ID card, including reduced-cost and no-cost options. Check the page for what applies to you." }),

  // ---------------- Transportation ----------------
  add({ id: "add-sud-access-rides", name: "Tulare County SUD Access Line – Rides to Treatment", category: "transportation", tag: "Tulare County",
    website: "https://tchhsa.org/eng/behavioral-health/programs-services/substance-use-disorder-services/substance-use-disorder-sud-access-line",
    phone: "1-866-732-4114", hours: "24/7",
    description: "Free and confidential. They can tell you how to get transportation to treatment." }, false),
  add({ id: "add-greyhound", name: "Greyhound", category: "transportation", tag: "National",
    website: "https://www.greyhound.com",
    description: "Long-distance buses to Fresno, Bakersfield, and beyond. Look up stops and times on their site." }),
  add({ id: "add-porterville-city", name: "City of Porterville (Porterville Transit info)", category: "transportation", tag: "Tulare County",
    website: "https://www.cityofporterville.com",
    description: "City site for Porterville, including local transit information." }),

  // ---------------- Food Assistance ----------------
  add({ id: "add-salvation-army-tulare-food", name: "The Salvation Army – Tulare Corps (food help)", category: "food", tag: "Tulare County",
    website: "https://tulare.salvationarmy.org", phone: "559-687-2520", city: "Tulare, CA",
    description: "Call to ask about food pantry help and meals in Tulare." }),
  add({ id: "add-united-way-food", name: "United Way of Tulare County", category: "food", tag: "Tulare County",
    website: "https://www.unitedwaytc.org",
    description: "Connects people to local food programs and other help across the county." }),
  add({ id: "add-vrm-meals", name: "Visalia Rescue Mission – Meals", category: "food", tag: "Tulare County",
    website: "https://www.vrmhope.org", city: "Visalia, CA",
    description: "Call or visit their site to ask about free meals." }, false),

  // ---------------- Financial Assistance ----------------
  add({ id: "add-united-way-financial", name: "United Way of Tulare County – Community Help", category: "financial", tag: "Tulare County",
    website: "https://www.unitedwaytc.org",
    description: "Local programs and referrals when money is tight." }),
  add({ id: "add-vita", name: "Free Tax Help (IRS VITA)", category: "financial", tag: "National",
    website: "https://www.irs.gov/individuals/free-tax-return-preparation-for-qualifying-taxpayers",
    description: "Free tax filing help from trained volunteers. Find a site near you on the IRS page." }),
  add({ id: "add-caleitc", name: "California Earned Income Tax Credit (CalEITC)", category: "financial", tag: "California (statewide)",
    website: "https://www.ftb.ca.gov/file/personal/credits/california-earned-income-tax-credit.html",
    description: "Money back at tax time for people who work. Check the state page to see if you qualify." }),
  add({ id: "add-bank-on", name: "Bank On – Safe Bank Accounts", category: "financial", tag: "National",
    website: "https://joinbankon.org",
    description: "Find a safe, low-cost bank account, even if you've had trouble with banks before." }),
  add({ id: "add-annual-credit-report", name: "AnnualCreditReport.com", category: "financial", tag: "National",
    website: "https://www.annualcreditreport.com",
    description: "The official free site to check your credit reports." }),
  add({ id: "add-nfcc", name: "National Foundation for Credit Counseling (NFCC)", category: "financial", tag: "National",
    website: "https://www.nfcc.org",
    description: "Nonprofit credit counselors who can help you make a plan for debt." }),

  // ---------------- Healthcare ----------------
  add({ id: "add-tc-crisis-access-line", name: "Tulare County Mental Health Access and Crisis Line", category: "healthcare", tag: "Tulare County",
    website: "https://tchhsa.org/eng/behavioral-health/programs-services/24-hour-crisis-and-access-line",
    phone: "1-800-320-1616", hours: "24/7",
    description: "Free, confidential, English and Spanish. Call for mental health help or a crisis, any time." }, false),
  add({ id: "add-tc-sud-access-line", name: "Tulare County Substance Use Disorder (SUD) Access Line", category: "healthcare", tag: "Tulare County",
    website: "https://tchhsa.org/eng/behavioral-health/programs-services/substance-use-disorder-services/substance-use-disorder-sud-access-line",
    phone: "1-866-732-4114", hours: "24/7",
    description: "Free, confidential, English and Spanish. An information line that connects you to treatment near you. Not counseling. TTY: 1-800-735-2922." }, false),
  add({ id: "add-988", name: "988 Suicide & Crisis Lifeline", category: "healthcare", tag: "National",
    website: "https://988lifeline.org", phone: "988", hours: "24/7",
    description: "Call or text 988 any time to talk to someone." }),
  add({ id: "add-anthem-medi-cal", name: "Anthem Blue Cross Medi-Cal", category: "healthcare", tag: "California (statewide)",
    website: "https://www.anthem.com/ca/medi-cal",
    description: "One of the Medi-Cal health plans. Members can find doctors and the member phone number on the site." }),
  add({ id: "add-health-net-medi-cal", name: "Health Net Medi-Cal", category: "healthcare", tag: "California (statewide)",
    website: "https://www.healthnet.com/content/healthnet/en_us/members/medi-cal.html",
    description: "One of the Medi-Cal health plans. Members can find doctors and the member phone number on the site." }),

  // ---------------- Recovery Meetings ----------------
  add({ id: "add-aa-tulare-county", name: "Alcoholics Anonymous – Tulare County Central Office", category: "recovery", tag: "Tulare County",
    website: "https://aa-tulareco.org",
    description: "The local AA meeting finder. New people are welcome at open meetings. Check the finder for current times." }),
  add({ id: "add-celebrate-recovery", name: "Celebrate Recovery (faith-based)", category: "recovery", tag: "National",
    website: "https://celebraterecovery.com",
    description: "Christ-centered recovery groups. Use their finder for local groups." }),
  add({ id: "add-cocaine-anonymous", name: "Cocaine Anonymous", category: "recovery", tag: "National",
    website: "https://ca.org",
    description: "Meetings for people recovering from cocaine and other drugs. Includes online meetings." }),
  add({ id: "add-marijuana-anonymous", name: "Marijuana Anonymous", category: "recovery", tag: "National",
    website: "https://marijuana-anonymous.org",
    description: "In-person and online meetings for people recovering from marijuana." }),
  add({ id: "add-crystal-meth-anonymous", name: "Crystal Meth Anonymous", category: "recovery", tag: "National",
    website: "https://www.crystalmeth.org",
    description: "Meetings for people recovering from meth, in person and online." }),
  add({ id: "add-recovery-dharma", name: "Recovery Dharma", category: "recovery", tag: "National",
    website: "https://recoverydharma.org",
    description: "Peer recovery using mindfulness and meditation. Not religious. Online meetings available." }),
  add({ id: "add-in-the-rooms", name: "In The Rooms (online meetings)", category: "recovery", tag: "National",
    website: "https://www.intherooms.com",
    description: "Free online recovery meetings — good if you don't have a ride." }),

  // ---------------- Support Groups ----------------
  add({ id: "add-nami-tulare-local", name: "NAMI Tulare County (local chapter)", category: "support", tag: "Tulare County",
    website: "https://namitularecounty.org", phone: "(559) 732-6264", city: "Visalia, CA",
    description: "Free peer support and family groups for people living with mental health challenges." }),
  add({ id: "add-al-anon", name: "Al-Anon and Alateen", category: "support", tag: "National",
    website: "https://al-anon.org",
    description: "Support for family and friends of people with drinking problems. Use their meeting finder." }),
  add({ id: "add-nar-anon", name: "Nar-Anon", category: "support", tag: "National",
    website: "https://nar-anon.org",
    description: "Support for family and friends of people with drug use. Use their meeting finder." }),
  add({ id: "add-ca-warm-line", name: "California Peer-Run Warm Line", category: "support", tag: "California (statewide)",
    website: "https://www.mentalhealthsf.org/peer-run-warmline/",
    description: "Talk with a peer who gets it when you need someone to listen. Check the site for the number and hours." }),
  add({ id: "add-prn-support", name: "Prisoner Reentry Network", category: "support", tag: "California (statewide)",
    website: "https://prisonerreentrynetwork.org",
    description: "Reentry guides and resources made for people coming home." }),

  // ---------------- Family & Reunification ----------------
  add({ id: "add-cws-family-advocate", name: "Tulare County CWS Family Advocate", category: "family", tag: "Tulare County",
    website: "https://tchhsa.org/eng/human-services",
    description: "Help for parents and relatives involved with Child Welfare Services." }, false),
  add({ id: "add-child-support-family", name: "California Child Support Services", category: "family", tag: "California (statewide)",
    website: "https://childsupport.ca.gov",
    description: "Payment questions or asking to change an order after release." }),
  add({ id: "add-ccfcc-family", name: "Central California Family Crisis Center", category: "family", tag: "Tulare County",
    website: "https://www.ccfcc.org",
    description: "Support for families dealing with domestic violence." }),
  add({ id: "add-courts-family", name: "California Courts – Families and Children", category: "family", tag: "California (statewide)",
    website: "https://selfhelp.courts.ca.gov",
    description: "Official self-help for custody, visitation, and family court forms." }),
  add({ id: "add-prn-family", name: "Prisoner Reentry Network – Guides", category: "family", tag: "California (statewide)",
    website: "https://prisonerreentrynetwork.org/resources/prn-produced",
    description: "Guides for coming home, including reconnecting with family." }),

  // ---------------- Parenting ----------------
  add({ id: "add-hhsa-parent-ed", name: "Tulare County HHSA – In-Home Parent Education", category: "parenting", tag: "Tulare County",
    website: "https://tchhsa.org/eng/human-services",
    description: "Parenting support that comes to your home. Ask HHSA if you qualify." }, false),
  add({ id: "add-wic-link", name: "WIC (see Public Assistance)", category: "parenting", tag: "California (statewide)",
    website: "https://myfamily.wic.ca.gov",
    description: "Food and support for pregnant people, new parents, and young kids. Full details are in Public Assistance." }),

  // ---------------- Life Skills ----------------
  add({ id: "add-tc-library-skills", name: "Tulare County Library – Computers & Digital Help", category: "lifeskills", tag: "Tulare County",
    website: "https://www.tularecountylibrary.org", address: "200 W Oak Ave", city: "Visalia, CA",
    description: "Free computers, internet, and help with basic tech." }),
  add({ id: "add-prn-guides", name: "Prisoner Reentry Network – Phone, ID & Bank Guides", category: "lifeskills", tag: "California (statewide)",
    website: "https://prisonerreentrynetwork.org/resources/prn-produced",
    description: "Step-by-step guides for getting a phone, ID, and bank account after release." }),
  add({ id: "add-dmv-license", name: "California DMV – Driver's Licenses", category: "lifeskills", tag: "California (statewide)",
    website: "https://www.dmv.ca.gov/portal/driver-licenses-identification-cards/",
    description: "Official info on getting or renewing a driver's license." }),
  add({ id: "add-mymoney", name: "MyMoney.gov", category: "lifeskills", tag: "National",
    website: "https://www.mymoney.gov",
    description: "Free government tools to learn budgeting and saving." }),
  add({ id: "add-gcf", name: "GCFLearnFree", category: "lifeskills", tag: "National",
    website: "https://edu.gcfglobal.org",
    description: "Free lessons on computers, email, job skills, and money." }),
  add({ id: "add-digitallearn", name: "DigitalLearn", category: "lifeskills", tag: "National",
    website: "https://www.digitallearn.org",
    description: "Short free videos on using a phone, computer, and staying safe online." }),
];

const EMPLOYMENT_SECTIONS = [
  "Find work with a record",
  "Job centers",
  "Know your rights and tell employers",
  "More job help",
];

export function getEmploymentSections(resources: Resource[]) {
  return EMPLOYMENT_SECTIONS.map((name) => ({
    id: name,
    name,
    resources: resources.filter((resource) => resource.category === "employment" && (
      name === "More job help"
        ? !EMPLOYMENT_SECTIONS.slice(0, 3).includes(resource.section ?? "")
        : resource.section === name
    )),
  }));
}

/** Short intent → category hints for Adel. Additive; does not change existing matching. */
export const ADDITIONS_INTENTS = `NEW RESOURCE MATCHING (use the exact category names below in ACTION: resource:<name>):
- I need a job, nobody will hire me, my record is holding me back, who hires people with a record -> Employment (the "Find work with a record" section has a fair-chance job board and reentry job programs). You may say: in California most employers can't ask about convictions until after a job offer. Never name an employer that isn't in the app.
- clear my record, expunge, court, child support order, ID → Legal Services
- ride to treatment, bus, get to my appointment → Transportation (the SUD Access Line can arrange rides to treatment)
- find a meeting, meeting tonight, AA/NA/online meeting → Recovery Meetings (point to the finder; never state a day or time)
- see a doctor, need treatment, detox, mental health → Healthcare (lead with the Tulare County SUD Access Line 1-866-732-4114 or Mental Health Access Line 1-800-320-1616)
- electric bill, taxes, bank account, credit → Financial Assistance
- GED, school, college → Education
- missing my kids, custody, visitation → Family & Reunification; parenting classes → Parenting
- no bed tonight → Emergency Shelter (lead with 2-1-1); computer, budgeting, license → Life Skills`;
