// Content checks for lesson-level If–Then plans (node:test, run with `bun test`).
import test from "node:test";
import assert from "node:assert/strict";
import { IF_THEN_CONTENT, BACKUP_ACTIONS } from "./if-then-content";
import { CRISIS_BACKUP, resolveIfThen, DEFAULT_BACKUPS } from "./if-then-defaults";
import { ifThenSentence } from "@/components/module/if-then-step";
import { LIBRARY } from "./library";

const entries = Object.entries(IF_THEN_CONTENT);
const LESSONS = LIBRARY.flatMap((c) => c.items.map((i) => ({ id: i.id, categoryId: c.id })));

test("every library lesson has an If–Then content entry", () => {
  const missing = LESSONS.map((l) => l.id).filter((id) => !IF_THEN_CONTENT[id]);
  assert.deepEqual(missing, []);
  const extra = entries.map(([id]) => id).filter((id) => !LESSONS.some((l) => l.id === id));
  assert.deepEqual(extra, []);
});

test("each entry has risk, 5 cues, 5 moves, at least 3 backups, 2 smallMoves", () => {
  for (const [id, c] of entries) {
    assert.ok(c.risk === "standard" || c.risk === "high", `${id}: risk`);
    assert.equal(c.cues.length, 5, `${id}: cues`);
    assert.equal(c.moves.length, 5, `${id}: moves`);
    assert.ok((c.backups?.length ?? 0) >= 3, `${id}: backups`);
    assert.equal(c.smallMoves?.length, 2, `${id}: smallMoves`);
  }
});

test("every cue/move/backup combination reads cleanly: no blanks, no doubled words", () => {
  for (const [id, c] of entries) {
    const backups = c.backups ?? [];
    for (const cue of c.cues)
      for (const move of c.moves)
        for (const backup of backups) {
          const s = ifThenSentence({ cue, move, backup });
          assert.ok(!s.includes("___"), `${id}: blank in "${s}"`);
          // A colon may introduce an intentional acronym expansion (FEET: feet).
          const words = s.toLowerCase().replace(/:/g, " separator ").replace(/[^a-z0-9' ]/g, " ").split(/\s+/);
          for (let i = 1; i < words.length; i++)
            if (!/^\d+$/.test(words[i])) // "10-10-10" is a name, not a doubled word
            assert.notEqual(words[i - 1], words[i], `${id}: doubled word in "${s}"`);
        }
  }
});

test("every high-risk entry has a non-911 backup and never lists the crisis chip itself", () => {
  for (const [id, c] of entries) {
    if (c.risk !== "high") continue;
    assert.ok(
      (c.backups ?? []).some((b) => b !== BACKUP_ACTIONS.emergency),
      `${id}: needs a backup other than "${BACKUP_ACTIONS.emergency}"`,
    );
    assert.ok(!(c.backups ?? []).includes(CRISIS_BACKUP), `${id}: must not include the crisis chip text`);
  }
});

test("lesson content wins over topic ifThen and category defaults", () => {
  const lesson = LESSONS.find((l) => l.id === "finding-footing")!;
  const resolved = resolveIfThen(lesson.categoryId, lesson.id, { risk: "standard", cues: ["x"], moves: ["y"] });
  assert.deepEqual(resolved.cues, IF_THEN_CONTENT["finding-footing"]!.cues);
  const topicOnly = resolveIfThen("understanding", "no-such-lesson", { risk: "standard", cues: ["topic cue"], moves: ["topic move"] });
  assert.deepEqual(topicOnly.cues, ["topic cue"]);
});

import { resolveIfThen as resolveSud, CRISIS_BACKUP as SUD_CRISIS } from "./if-then-defaults";
test("SUD plans use recovery defaults, never Library categories", () => {
  const sud = resolveSud("recovery:understanding", "understanding-1");
  assert.equal(sud.cues[0], "A using thought pops into my head");
  assert.equal(sud.risk, "high");
  assert.ok(!sud.backups.includes(SUD_CRISIS));
  assert.equal(resolveSud("recovery:first-days", "first-days-2").cues[0], "A craving hits my whole body");
});

test("Cravings has the requested ordered backups, with no data-stored crisis choice", () => {
  assert.deepEqual(IF_THEN_CONTENT["want-to-use"]?.backups, [
    BACKUP_ACTIONS.craving, BACKUP_ACTIONS.people, BACKUP_ACTIONS.sponsor, BACKUP_ACTIONS.neverUseAlone,
  ]);
});

test("Work replaces Batch 3 backups with call tomorrow, case manager, legal aid", () => {
  assert.deepEqual(IF_THEN_CONTENT.work?.backups, [BACKUP_ACTIONS.callTomorrow, BACKUP_ACTIONS.caseManager, BACKUP_ACTIONS.legalAid]);
});

test("last-resort backups use smaller, people, peer", () => {
  assert.deepEqual(DEFAULT_BACKUPS, [BACKUP_ACTIONS.smaller, BACKUP_ACTIONS.people, BACKUP_ACTIONS.peer]);
  assert.deepEqual(resolveIfThen("missing-category", "missing-lesson").backups, DEFAULT_BACKUPS);
});

test("updated Library backups have at most two reach-out options", () => {
  const reachOut = new Set<string>([
    BACKUP_ACTIONS.peer, BACKUP_ACTIONS.supportPerson, BACKUP_ACTIONS.sponsor, BACKUP_ACTIONS.adel,
    BACKUP_ACTIONS.therapy, BACKUP_ACTIONS.caseManager, BACKUP_ACTIONS.prescriber, BACKUP_ACTIONS.pharmacist,
  ]);
  for (const [id, config] of entries) {
    if (id === "tracking-feelings") continue; // Not listed in Batch 6: preserve its existing backups.
    assert.ok((config.backups ?? []).filter((backup) => reachOut.has(backup)).length <= 2, id);
  }
});
