// New guided exercises for the "Becoming Someone New" recovery mission.
// Same shared library shape as exercises-guided.ts.
import type { Exercise } from "./exercises";

type G = Omit<Exercise, "type" | "content"> & {
  steps: [string, number][];
  closing: string;
};

const g = ({ steps, closing, ...rest }: G): Exercise => ({
  ...rest,
  type: "guided",
  content: { kind: "guided", steps: steps.map(([say, secs]) => ({ say, secs })), closing },
});

export const GUIDED_SOMEONE_NEW: Exercise[] = [
  g({
    id: "picture-one-year-out",
    title: "Picture One Year Out",
    subtitle: "See the future you're building",
    minutes: 2, tags: ["goal-setting"],
    purpose: "A future you can picture is a future you can walk toward. This practice builds that picture, one piece at a time.",
    steps: [
      ["Picture one year from now. Where are you living?", 15],
      ["Picture what a normal day looks like for you then.", 15],
      ["Notice who's around you in that picture.", 12],
      ["Say out loud one word for how you feel in that picture.", 10],
      ["Name one step, however small, that moves you toward it this week.", 15],
    ],
    closing: "That picture is a plan in disguise. You just named its first step.",
  }),
];
