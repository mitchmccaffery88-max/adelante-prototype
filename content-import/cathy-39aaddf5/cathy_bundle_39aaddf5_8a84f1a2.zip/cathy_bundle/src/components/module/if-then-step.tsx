// Library only: "My If–Then Plan" sub-step of Build My Toolkit (Part B).
import { useEffect, useRef, useState } from "react";
import { Link } from "@tanstack/react-router";
import { Eye } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { isCrisis, isOverdoseNow } from "@/lib/adel-safety";
import { AdelCrisisResponse, AdelOverdoseResponse } from "@/components/adel-bits";
import { VoiceInputButton, appendTranscript } from "@/components/voice-input-button";
import { SliderRow } from "./activities";
import { CRISIS_BACKUP, IF_THEN_IDS, type resolveIfThen } from "@/data/if-then-defaults";
import type { ToolSuggestions } from "@/lib/adel-client";

export type IfThenValues = { cue: string; move: string; backup: string };
/** confidence 0 = not rated yet. helpDeclined hides the Adel help offer for this run. */
export type IfThenState = { cantLeave: boolean; confidence: number; helpDeclined?: boolean };

/** The chosen value for one line: the member's own words win over a chip. */
export function ifThenValues(picks: Record<string, string[]>, own: Record<string, string>): IfThenValues {
  const v = (id: string) => (own[id] ?? "").trim() || (picks[id]?.[0] ?? "");
  return { cue: v(IF_THEN_IDS.cue), move: v(IF_THEN_IDS.move), backup: v(IF_THEN_IDS.backup) };
}

const trimEnd = (t: string) => t.trim().replace(/[.!]+$/, "");
const lower = (t: string) => (/^I\b|^I'/.test(t) ? t : t.charAt(0).toLowerCase() + t.slice(1));
/** Turn a chip or write-in into the words after "then I will". */
export function asAction(t: string) {
  let a = t.trim();
  if (/^if\b.*?, I /i.test(a)) a = a.replace(/^if\b.*?, I /i, "");
  a = a.replace(/^(then\s+)?I( will|'ll)?\s+/i, "");
  return lower(a);
}
export function ifThenSentence({ cue, move, backup }: IfThenValues) {
  const c = cue ? lower(trimEnd(cue).replace(/^if\s+/i, "")) : "___";
  return `If ${c}, then I will ${endSentence(move ? asAction(move) : "___")} If that's not enough, then I will ${endSentence(backup ? asAction(backup) : "___")}`;
}

function endSentence(text: string) {
  return /[.?!]["'”’]*$/.test(text) ? text : `${text}.`;
}

export function ifThenComplete(v: IfThenValues, risk: "standard" | "high") {
  return !!v.cue && !!v.move && (risk !== "high" || !!v.backup);
}

/** A write-in that never keeps crisis language: it shows the crisis card and stores nothing. */
export function SafeWriteIn({ id, label, value, onChange, placeholder, autoFocus, singleLine = false }: {
  id: string; label: string; value: string; onChange: (v: string) => void; placeholder?: string; autoFocus?: boolean; singleLine?: boolean;
}) {
  const [draft, setDraft] = useState(value);
  const [crisis, setCrisis] = useState<boolean | "overdose">(false);
  useEffect(() => { if (!crisis) setDraft(value); }, [value, crisis]);
  const update = (raw: string) => {
    const v = raw.slice(0, 120);
    setDraft(v);
    if (isOverdoseNow(v)) { setCrisis("overdose"); onChange(""); return; }
    if (isCrisis(v)) { setCrisis(true); onChange(""); return; }
    setCrisis(false);
    onChange(v);
  };
  return (
    <div>
      <label htmlFor={id} className="text-sm font-medium">{label}</label>
      <div className="mt-2 flex items-start gap-2">
        <textarea id={id} autoFocus={autoFocus} rows={singleLine ? 1 : 2} maxLength={120} placeholder={placeholder ?? "Type it in your own words…"}
          value={draft} onChange={(e) => update(e.target.value)}
          className="min-h-11 flex-1 resize-none rounded-xl border border-input bg-background px-3 py-2 text-base sm:text-sm" />
        <VoiceInputButton onTranscript={(t) => update(appendTranscript(draft, t))} />
      </div>
      {crisis ? <div className="mt-3">{crisis === "overdose" ? <AdelOverdoseResponse /> : <AdelCrisisResponse />}</div>
        : <p className="mt-2 text-xs text-muted-foreground">Please don't include ID, case, or Social Security numbers.</p>}
    </div>
  );
}

function Line({ n, title, hint, stepId, options, picks, own, onChip, onOwn, suggested }: {
  n: string; title: string; hint: string; stepId: string; options: string[];
  picks: Record<string, string[]>; own: Record<string, string>;
  onChip: (id: string, v: string) => void; onOwn: (id: string, v: string) => void; suggested?: string[];
}) {
  const [more, setMore] = useState(false);
  const chosen = picks[stepId]?.[0];
  const typed = (own[stepId] ?? "").trim();
  const ordered = [...options.filter((option) => suggested?.includes(option)), ...options.filter((option) => !suggested?.includes(option))];
  const visible = more ? ordered : ordered.slice(0, 4);
  return (
    <section className="rounded-2xl border border-border/60 p-4">
      <p className="text-xs font-semibold uppercase tracking-wide text-primary">{n}</p>
      <p className="mt-1 font-semibold">{title}</p>
      <p className="text-sm text-muted-foreground">{hint}</p>
      <div className="mt-3 grid gap-2 sm:grid-cols-2">
        {visible.map((o) => {
          const on = !typed && chosen === o;
          const crisisOpt = o === CRISIS_BACKUP;
          return (
            <button key={o} type="button" onClick={() => onChip(stepId, o)}
              className={cn("min-h-12 rounded-2xl border px-4 py-3 text-left text-sm transition-colors",
                on ? "border-primary bg-primary text-primary-foreground"
                  : crisisOpt ? "border-crisis/40 bg-crisis/5 text-crisis hover:border-crisis"
                  : "border-border/60 bg-card hover:border-primary/40")}>
              {o}
              {suggested?.includes(o) && (
                <span className={cn("ml-2 rounded-full px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wide",
                  on ? "bg-primary-foreground/20" : "bg-sage/30 text-sage-foreground")}>Adel suggests</span>
              )}
            </button>
          );
        })}
      </div>
      {ordered.length > 4 && <Button variant="link" onClick={() => setMore(!more)}>{more ? "Fewer options" : "More options"}</Button>}
      <details className="mt-3" open={!!typed || undefined}>
        <summary className="cursor-pointer text-sm text-primary">Say it my way</summary>
        <div className="mt-2"><SafeWriteIn id={`own-${stepId}`} label="My words" value={own[stepId] ?? ""} onChange={(v) => onOwn(stepId, v)} /></div>
      </details>
    </section>
  );
}

export function IfThenPlanStep({ config, picks, own, onChip, onOwn, state, onState, talkSuggested, onAdelHelp, prefilled }: {
  config: ReturnType<typeof resolveIfThen>;
  picks: Record<string, string[]>;
  own: Record<string, string>;
  onChip: (stepId: string, value: string) => void;
  onOwn: (stepId: string, text: string) => void;
  state: IfThenState;
  onState: (patch: Partial<IfThenState>) => void;
  talkSuggested?: ToolSuggestions;
  /** Opens Adel's compact confidence-help chat (low confidence only). */
  onAdelHelp?: () => void;
  prefilled?: { cue?: boolean; move?: boolean };
}) {
  const values = ifThenValues(picks, own);
  const ready = !!values.cue && !!values.move;
  const high = config.risk === "high";
  const lowConfidence = ready && state.confidence > 0 && state.confidence <= 5;
  const smaller = lowConfidence ? (config.smallMoves?.length ? config.smallMoves : config.moves.slice(-1)) : null;
  const moves = smaller ?? (state.cantLeave && config.cantLeave?.length ? config.cantLeave : config.moves);
  const backups = high ? [...config.backups, CRISIS_BACKUP] : config.backups;

  const [picturing, setPicturing] = useState(0);
  const timer = useRef<ReturnType<typeof setInterval> | null>(null);
  useEffect(() => () => { if (timer.current) clearInterval(timer.current); }, []);
  const startPicture = () => {
    if (timer.current) clearInterval(timer.current);
    setPicturing(15);
    timer.current = setInterval(() => setPicturing((s) => {
      if (s <= 1 && timer.current) { clearInterval(timer.current); timer.current = null; }
      return Math.max(0, s - 1);
    }), 1000);
  };

  return (
    <div className="space-y-4">
      <p className="text-base">Plan your move before the hard moment comes. Pick one for each line, or say it your way.</p>

      <Line n="Line 1 · IF" title="The moment" hint="When does this get hard for me?" stepId={IF_THEN_IDS.cue}
        options={config.cues} picks={picks} own={own} onChip={onChip} onOwn={onOwn} suggested={talkSuggested?.[IF_THEN_IDS.cue]} />
      {prefilled?.cue && <p className="text-xs text-muted-foreground">From your answer above. Change it if you want.</p>}

      {config.cantLeave?.length ? (
        <label className="flex min-h-12 cursor-pointer items-center gap-3 rounded-2xl border border-border/60 px-4 py-3 text-sm font-medium">
          <input type="checkbox" checked={state.cantLeave} onChange={(e) => onState({ cantLeave: e.target.checked })} className="h-5 w-5 accent-primary" />
          I can't leave in this moment
        </label>
      ) : null}

      {smaller && <p className="rounded-2xl bg-amber-warm/20 p-3 text-sm text-amber-warm-foreground"><span className="font-semibold">Let's make it smaller.</span> A smaller move you can really do beats a big one you can't. Pick one below.</p>}
      <Line n="Line 2 · THEN I WILL" title="My move" hint="What will I do right then?" stepId={IF_THEN_IDS.move}
        options={moves} picks={picks} own={own} onChip={onChip} onOwn={onOwn} suggested={talkSuggested?.[IF_THEN_IDS.move]} />
      {prefilled?.move && <p className="text-xs text-muted-foreground">From your answer above. Change it if you want.</p>}

      {high ? <><Line n={`Line 3 · IF THAT'S NOT ENOUGH, THEN${high ? "" : " (optional)"}`} title="My backup" hint="Who or what will I turn to next?" stepId={IF_THEN_IDS.backup}
        options={backups} picks={picks} own={own} onChip={onChip} onOwn={onOwn} suggested={talkSuggested?.[IF_THEN_IDS.backup]} /><Link to="/crisis" className="inline-flex min-h-11 items-center text-crisis underline">Get crisis support now</Link></> : <details open={!!values.backup || undefined}>
        <summary className="cursor-pointer text-sm text-primary">Add a backup (optional)</summary>
        <div className="mt-3">      <Line n={`Line 3 · IF THAT'S NOT ENOUGH, THEN${high ? "" : " (optional)"}`} title="My backup" hint="Who or what will I turn to next?" stepId={IF_THEN_IDS.backup}
        options={backups} picks={picks} own={own} onChip={onChip} onOwn={onOwn} suggested={talkSuggested?.[IF_THEN_IDS.backup]} />
</div>
      </details>}
      {values.backup === CRISIS_BACKUP && (
        <Link to="/crisis" className="inline-flex min-h-11 items-center rounded-full bg-crisis px-4 py-2 text-sm font-semibold text-crisis-foreground">Open crisis support</Link>
      )}

      <div className="rounded-2xl bg-primary/10 p-4" aria-live="polite">
        <p className="text-xs font-semibold uppercase tracking-wide text-primary">My plan</p>
        <p className="mt-1 text-lg font-semibold leading-snug">{ifThenSentence(values)}</p>
      </div>

      {ready && (
        <section className="space-y-4 rounded-2xl border border-border/60 p-4">
          <p className="font-semibold">Practice it (optional)</p>
          <div>
            <Button variant="outline" type="button" onClick={startPicture} className="inline-flex min-h-11 items-center gap-2 rounded-full border border-border px-4 py-2 text-sm font-medium">
              <Eye className="h-4 w-4" /> Picture it (15 seconds)
            </Button>
            {picturing > 0 ? (
              <p className="mt-2 text-sm">Close your eyes. See the moment. See yourself doing your move. <span className="font-semibold tabular-nums">{picturing}</span></p>
            ) : null}
          </div>
          <SliderRow label="How sure am I that I can do this?" left="Not sure" right="Very sure" value={state.confidence} emptyLabel="Tap to rate" onChange={(n) => onState({ confidence: n })} />
          {lowConfidence && !state.helpDeclined && onAdelHelp && (
            <div className="rounded-2xl border border-primary/30 bg-primary/5 p-4">
              <p className="text-sm">A {state.confidence} is honest. Want Adel's help making this plan feel more doable?</p>
              <div className="mt-3 flex flex-wrap gap-2">
                <button type="button" onClick={onAdelHelp}
                  className="inline-flex min-h-11 items-center rounded-full bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground">
                  Yes, help me
                </button>
                <button type="button" onClick={() => onState({ helpDeclined: true })}
                  className="inline-flex min-h-11 items-center rounded-full border border-border px-4 py-2 text-sm font-medium hover:bg-muted">
                  Not now
                </button>
              </div>
            </div>
          )}
        </section>
      )}
    </div>
  );
}
