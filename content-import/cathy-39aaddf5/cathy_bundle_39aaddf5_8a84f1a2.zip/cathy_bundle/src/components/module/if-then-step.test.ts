import { test } from "node:test";
import assert from "node:assert/strict";
import { ifThenSentence, ifThenComplete } from "./if-then-step";
import { backupAction } from "@/lib/plans";
import { BACKUP_ACTIONS } from "@/data/if-then-content";

test("plan sentence reads naturally from pilot chips", () => {
  assert.equal(
    ifThenSentence({ cue: "A craving hits when I'm alone at night", move: "Leave the room and go outside", backup: "If it's still strong after 20 minutes, I message my peer specialist" }),
    "If a craving hits when I'm alone at night, then I will leave the room and go outside. If that's not enough, then I will message my peer specialist.",
  );
});

test("high-risk plan requires a backup; standard does not", () => {
  assert.equal(ifThenComplete({ cue: "a", move: "b", backup: "" }, "high"), false);
  assert.equal(ifThenComplete({ cue: "a", move: "b", backup: "" }, "standard"), true);
});

for (const action of ["Ask: what would I tell a friend?", "Say stop!", "Take a breath.", 'Ask: "what do I want in an hour?"', "Ask: ‘what do I want in an hour?’"]) {
  test(`plan preserves terminal punctuation in ${action}`, () => {
    const lower = action.charAt(0).toLowerCase() + action.slice(1);
    assert.equal(ifThenSentence({ cue: "I notice a trap", move: action, backup: action }),
      `If I notice a trap, then I will ${lower} If that's not enough, then I will ${lower}`);
  });
}

test("new and legacy emergency backups both call 911", () => {
  assert.deepEqual(backupAction(BACKUP_ACTIONS.emergency), { kind: "tel", phone: "911", label: "Call 911" });
  assert.deepEqual(backupAction("Call 911 if it's an emergency"), { kind: "tel", phone: "911", label: "Call 911" });
});
