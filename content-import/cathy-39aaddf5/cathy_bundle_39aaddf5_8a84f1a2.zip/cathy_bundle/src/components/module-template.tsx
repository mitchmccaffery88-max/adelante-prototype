// Compatibility entry point: all lesson check-ins and endings use the shared six-step flow.
import { toSelfHelpModule, type CanonicalModule } from "@/data/module-schema";
import { SelfHelpModuleTemplate, type SelfHelpModuleHost } from "./self-help-module-template";

export type ModuleTemplateHost = SelfHelpModuleHost;
export function ModuleTemplate({ mod, host }: { mod: CanonicalModule; host?: ModuleTemplateHost }) {
  return <SelfHelpModuleTemplate mod={toSelfHelpModule(mod)} host={host} />;
}
