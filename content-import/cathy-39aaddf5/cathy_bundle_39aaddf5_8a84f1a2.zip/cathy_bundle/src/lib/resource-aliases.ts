// One alias map: prompt/ACTION category names → real RESOURCE_CATEGORIES ids.
import { RESOURCE_CATEGORIES, RESOURCES, type MedDose, type Obligation } from "@/data/mock";

/** Retired duplicate IDs resolve to their retained listing, including saved links. */
export const RESOURCE_ID_ALIASES: Record<string, string> = {
  "aa-central-valley": "add-aa-tulare-county",
  namilulare: "add-nami-tulare-local",
  "211-housing": "pa-211-food",
  "211-tulare": "pa-211-food",
  "add-211-shelter": "pa-211-food",
  "pa-211-shelter": "pa-211-food",
};
export function canonicalResourceId(id: string) { return RESOURCE_ID_ALIASES[id] ?? id; }
export function resolveResource(id?: string) {
  return id ? RESOURCES.find((resource) => resource.id === canonicalResourceId(id)) : undefined;
}
export function normalizeSavedResourceIds(ids: string[]) { return [...new Set(ids.map(canonicalResourceId))]; }
export function correctPrototypeMeds(meds: MedDose[]) {
  return meds.filter((med) => !(med.id === "med-pm" && med.med === "Sertraline" && med.time === "8:00 PM"));
}
export function correctPrototypeObligations(obligations: Obligation[]) {
  return obligations.map((obligation) => obligation.id === "ob-1" && obligation.location === "Tulare County Probation, 1424 Forum Dr, Visalia"
    ? { ...obligation, location: "Your officer's office (ask your officer)", phone: "(559) 713-2750" } : obligation);
}

export const RESOURCE_ALIASES: Record<string, string> = {
  housing: "housing", "emergency shelter": "shelter", shelter: "shelter",
  "food assistance": "food", food: "food", employment: "employment", transportation: "transportation",
  "recovery meetings": "recovery", "support groups": "support",
  "family & reunification": "family", "family and reunification": "family", family: "family",
  healthcare: "healthcare", education: "education",
  "parenting resources": "parenting", parenting: "parenting",
  "financial assistance": "financial", financial: "financial",
  "legal aid": "legal", "legal services": "legal", legal: "legal",
  "life skills": "lifeskills", "public assistance": "assistance",
};

/** Exact app name or alias → category; null if it doesn't resolve. */
export function findResourceCategory(name: string): { id: string; name: string } | null {
  const key = name.toLowerCase().trim();
  const id = RESOURCE_ALIASES[key] ?? RESOURCE_CATEGORIES.find((c) => c.name.toLowerCase() === key)?.id;
  const cat = RESOURCE_CATEGORIES.find((c) => c.id === id);
  return cat ? { id: cat.id, name: cat.name } : null;
}
