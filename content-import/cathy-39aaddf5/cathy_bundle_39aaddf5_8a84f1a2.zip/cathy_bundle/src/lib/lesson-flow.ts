import type { RatingDimension, SkillStepConfig } from "@/data/module-schema";

export const LESSON_CONFIDENCE: RatingDimension = {
  id: "confidence", label: "How sure am I that I can handle this when it comes up?",
  left: "Not sure", right: "Very sure", higherIsHarder: false,
};

/** Content stays untouched; every lesson reader gets the same two measures. */
export function lessonDimensions(dimensions: RatingDimension[]): RatingDimension[] {
  const struggle = dimensions.find((d) => d.id === "struggle") ?? dimensions.find((d) => d.higherIsHarder && d.id !== "confidence") ?? dimensions.find((d) => d.id !== "confidence");
  return struggle ? [struggle, LESSON_CONFIDENCE] : [LESSON_CONFIDENCE];
}

export function lessonSkill(skill: SkillStepConfig): SkillStepConfig {
  return { ...skill, steps: skill.steps.filter((s) => !/What I'll tell myself/i.test(s.title))
    .map((s, i) => ({ ...s, options: s.options.some((o) => /\b\d{1,2}(?::\d{2})?\s*(?:a\.?m\.?|p\.?m\.?)\b/i.test(o)) || (/\b(?:times?|bedtime|wake-up|winding down)\b/i.test(s.title) && s.options.some((o) => /morning|afternoon|evening|night|midday|before bed|weekend|saturday|sunday|payday/i.test(o))) ? [...new Set([...s.options, "A different time (I'll type it)", "It changes with my shifts"])] : s.options, title: `Step ${i + 1} — ${s.title.replace(/^Step\s+\d+\s*[—–-]\s*/i, "")}` })) };
}

export function lessonStep(step: number) { return Number.isFinite(step) ? Math.max(0, Math.min(4, Math.floor(step))) : 0; }

export function compactLessonSub(sub: number, skill: SkillStepConfig, version?: number): number {
  if (sub <= 0 || !Number.isFinite(sub)) return 0;
  if (version === 20) return Math.min(2, sub);
  const projected = version === 18 ? sub : migrateLessonSub(sub, skill);
  return projected <= lessonSkill(skill).steps.length ? 1 : 2;
}

/** Only answers actually chosen or written by the member are copied, never suggestions. */
export function memberPlanPrefill(skill: SkillStepConfig, picks: Record<string, string[]>, own: Record<string, string>) {
  const answer = (pattern: RegExp, key: "cue" | "move") => {
    const step = skill.steps.find((s) => s.feeds === key) ?? (skill.steps.some((s) => s.feeds === key) ? undefined : skill.steps.find((s) => !s.feeds && pattern.test(s.title.replace(/^Step\s+\d+\s*[—–-]\s*/i, ""))));
    return step ? (own[step.id] ?? "").trim() || (picks[step.id] ?? []).filter((v) => v !== "None of these fit me" && v !== "A different time (I'll type it)").join(", ") : "";
  };
  return { cue: answer(/^(?:When\b|Where I'll need\b)|(?:when (?:it|this) happens|my (?:triggers|warning signs))/i, "cue"), move: answer(/^(?:My first move|My calm-down moves|My go-to move|My stress tool)\b/i, "move") };
}

/** Map pre-Batch-18 tool pages by id, including the If–Then and save pages. */
export function migrateLessonSub(sub: number, oldSkill: SkillStepConfig): number {
  if (!Number.isFinite(sub) || sub <= 0) return 0;
  const filtered = lessonSkill(oldSkill).steps;
  const oldStep = oldSkill.steps[sub - 1];
  if (!oldStep) return Math.min(filtered.length + 2, filtered.length + (sub - oldSkill.steps.length));
  const index = filtered.findIndex((s) => s.id === oldStep.id);
  return index >= 0 ? index + 1 : Math.min(sub, filtered.length + 1);
}

export function confidenceImproved(before: number, after?: number): boolean {
  return after !== undefined && after > 0 && after > before;
}