// Lesson Part A exercises and Part B tools by name, so Adel's `ACTION: tool:<toolName>`
// and If–Then "Use it now" can open them in place. Built lazily from real lesson data.
import { LIBRARY } from "@/data/library";
import { RECOVERY_MODULES } from "@/data/recovery";
import { buildSelfHelpModule } from "@/data/module-schema";
import { getRecoverySixStepModule } from "@/data/recovery-module-schema";
import { getExercise, type Exercise } from "@/data/exercises";

export type LessonTool = {
  toolName: string;
  lessonId: string;
  lessonTitle: string;
  exerciseId?: string;
  /** Route to the lesson; add search { part: "build" } to open Part B. */
  link: { to: "/self-help-library/$category/$itemId"; params: { category: string; itemId: string } }
      | { to: "/sud-recovery-journey/$moduleId/$lessonId"; params: { moduleId: string; lessonId: string } };
};

let cache: LessonTool[] | null = null;
export function lessonTools(): LessonTool[] {
  if (cache) return cache;
  const out: LessonTool[] = [];
  for (const cat of LIBRARY) for (const item of cat.items) {
    const mod = buildSelfHelpModule(cat, item);
    out.push({ toolName: mod.skill.toolName, lessonId: mod.id, lessonTitle: mod.title, exerciseId: mod.exerciseId, link: { to: "/self-help-library/$category/$itemId", params: { category: cat.id, itemId: item.id } } });
  }
  for (const m of RECOVERY_MODULES) for (const l of m.lessons) {
    const mod = getRecoverySixStepModule(m.id, l.id);
    if (mod) out.push({ toolName: mod.skill.toolName, lessonId: mod.id, lessonTitle: mod.title, exerciseId: mod.exerciseId, link: { to: "/sud-recovery-journey/$moduleId/$lessonId", params: { moduleId: m.id, lessonId: l.id } } });
  }
  return (cache = out);
}

const norm = (s: string) => s.toLowerCase().replace(/[^a-z0-9]+/g, " ").trim();
/** Name key: case/hyphen/punctuation-insensitive, ignoring a leading "the" or "my". */
const nameKey = (s: string) => norm(s).replace(/^(?:(?:the|my) )+/, "");
const mentions = (text: string, name: string) => { const k = nameKey(name); return !!k && ` ${text} `.includes(` ${k} `); };

/** Exact (case/punctuation-insensitive) tool-name lookup, preferring the given lesson. */
export function findLessonTool(name: string, preferLessonId?: string): LessonTool | undefined {
  const key = nameKey(name);
  if (!key) return undefined;
  const hits = lessonTools().filter((t) => nameKey(t.toolName) === key);
  return hits.find((t) => t.lessonId === preferLessonId) ?? hits[0];
}

export type NamedTarget = { kind: "exercise"; exercise: Exercise } | { kind: "tool"; tool: LessonTool };

/** An If–Then move naming the lesson's Part A exercise (title) or Part B tool (toolName). */
export function namedLessonTarget(move: string, lesson: { exerciseId?: string; toolName?: string; lessonId?: string }): NamedTarget | null {
  const text = norm(move);
  if (!text) return null;
  const ex = lesson.exerciseId ? getExercise(lesson.exerciseId) : undefined;
  if (ex && mentions(text, ex.title)) return { kind: "exercise", exercise: ex };
  if (lesson.toolName && mentions(text, lesson.toolName)) {
    const tool = findLessonTool(lesson.toolName, lesson.lessonId);
    if (tool) return { kind: "tool", tool };
  }
  return null;
}
