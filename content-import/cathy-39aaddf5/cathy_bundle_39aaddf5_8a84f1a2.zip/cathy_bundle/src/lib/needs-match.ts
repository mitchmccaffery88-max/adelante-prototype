// Matches what a member says to the lessons and screens in THIS app, so Adel
// can teach and point at real content instead of giving generic tips.
// Pure functions — tested in needs-match.test.ts.

import { NEED_ENTRIES, PRIMARY_LESSONS, type NeedEntry, type NeedTag } from "@/data/needs-map";

// Synonym folding: everyday words → the fixed need tags.
const TAG_FOLDS: [RegExp, NeedTag][] = [
  [/\b(depress\w*|down|sad|low|hopeless|empty|numb|blah|no point|pointless|worthless|worthless\w*|can't get out of bed|cant get out of bed|don't want to do anything|nothing matters)\b/, "low-mood"],
  [/\b(anxi\w*|worr\w*|what if|nervous|scared|afraid|panic\w*|on edge|wound up|keyed up)\b/, "anxiety"],
  [/\b(angry|anger|mad|pissed|furious|rage|snap\w*|explod\w*|blow up|fed up)\b/, "anger"],
  [/\b(crav\w*|urges?|want(ing)? to use|wanna use|want to drink|using again|get high|relapse\w*)\b/, "craving"],
  [/\b(slip\w*|used again|messed up|drank|i used|i drank)\b/, "slip"],
  [/\b(sleep\w*|insomnia|awake|can't rest|cant rest|tired|exhausted|up all night)\b/, "sleep"],
  [/\b(lonely|alone|isolat\w*|no one|nobody|no friends|by myself)\b/, "alone"],
  [/\b(ashamed|shame|guilt\w*|embarrass\w*|humiliat\w*)\b/, "shame"],
  [/\b(family|kid|kids|son|daughter|mom|dad|mother|father|brother|sister|wife|husband|partner|parent\w*)\b/, "family"],
  [/\b(trauma|ptsd|flashback\w*|nightmare\w*|abuse\w*|molest\w*)\b/, "trauma"],
  [/\b(med\w*|medication\w*|pill\w*|dose|prescri\w*|suboxone|methadone|buprenorphine|naltrexone|side effect\w*)\b/, "meds"],
  [/\b(housing|homeless|shelter|food|hungry|phone|money|broke|bills?|rent|id card|benefits?|calfresh|medi-?cal|ride|transportation|bus)\b/, "basics"],
  [/\b(job|jobs|work|working|employ\w*|interview\w*|hired|fired|career|school|ged)\b/, "work"],
  [/\b(motivat\w*|lazy|no energy|can't start|cant start|don't care|give up|giving up|stuck|pointless)\b/, "motivation"],
  [/\b(thinking|thoughts?|racing|can't stop thinking|cant stop thinking|overthink\w*|in my head)\b/, "thoughts"],
  [/\b(overwhelm\w*|too much|drowning|so much to do|can't cope|cant cope)\b/, "overwhelm"],
  [/\b(unsafe|not safe|in danger|scared for my life|threat\w*)\b/, "safety"],
];

const STOP = new Set("i me my the a an and or to of in on is it im i'm just so but for with that this be am do dont don't can cant can't have get got at really about what when like feel feeling you your been not out up".split(" "));

function tokens(text: string): string[] {
  return ` ${text.toLowerCase()} `.replace(/[^a-z\s]/g, " ").split(/\s+/).filter((w) => w.length > 2 && !STOP.has(w));
}

/** The need tags a piece of member text points at. */
export function needTagsFor(text: string): NeedTag[] {
  const t = ` ${text.toLowerCase()} `;
  const out = new Set<NeedTag>();
  for (const [re, tag] of TAG_FOLDS) if (re.test(t)) out.add(tag);
  return [...out];
}

/** Feelings picked at check-in → need tags (labels, not ids). */
export function feelingsToTags(feelings: string[]): NeedTag[] {
  const map: Record<string, NeedTag> = {
    anxious: "anxiety", overwhelmed: "overwhelm", lonely: "alone", angry: "anger",
    depressed: "low-mood", low: "low-mood", craving: "craving", stressed: "overwhelm",
    exhausted: "sleep", rough: "low-mood",
  };
  const out = new Set<NeedTag>();
  for (const f of feelings) {
    const tag = map[f.toLowerCase().trim()];
    if (tag) out.add(tag);
  }
  return [...out];
}

type Doc = { e: NeedEntry; tagSet: Set<NeedTag>; mid: Set<string>; weak: Set<string> };

const DOCS: Doc[] = NEED_ENTRIES.map((e) => ({
  e,
  tagSet: new Set(e.needTags),
  mid: new Set(tokens([...e.soundsLike, e.problem].join(" "))),
  weak: new Set(tokens(e.title)),
}));

export type NeedMatchContext = {
  /** Today's check-in feelings (labels or ids). */
  feelings?: string[];
  /** Lessons the member already completed — skipped unless nothing else fits. */
  completedLessonIds?: string[];
};

/**
 * Top matches for what the member has been saying. `text` should be the
 * member's last few messages joined. Returns up to `limit` entries, best first.
 */
export function findNeedMatches(text: string, context: NeedMatchContext = {}, limit = 3): (NeedEntry & { primary?: boolean })[] {
  const tags = new Set<NeedTag>([...needTagsFor(text), ...feelingsToTags(context.feelings ?? [])]);
  const q = new Set(tokens(text));
  if (!tags.size && !q.size) return [];
  const completed = new Set(context.completedLessonIds ?? []);
  const primaryIds = new Set([...tags].map((tag) => PRIMARY_LESSONS[tag]?.find((id) => !completed.has(id) && DOCS.some(({ e }) => e.lessonId === id))).filter((id) => id !== undefined));

  const scored = DOCS.map(({ e, tagSet, mid, weak }) => {
    let s = 0;
    for (const t of tags) if (tagSet.has(t)) s += 3;
    for (const w of q) { if (mid.has(w)) s += 2; else if (weak.has(w)) s += 2; }
    // Screens are pointers, not teaching — lessons win ties.
    if (e.area === "Screen" && !e.actionTag.startsWith("resource:")) s = Math.min(s, 2);
    const primary = primaryIds.has(e.lessonId);
    if (primary) s += 4;
    return { e, s, primary, done: completed.has(e.lessonId) };
  }).filter((x) => x.s >= 2);

  scored.sort((a, b) => Number(b.primary) - Number(a.primary) || b.s - a.s);
  const fresh = scored.filter((x) => !x.done);
  const pool = fresh.length ? fresh : scored; // completed lessons only when nothing else fits
  const top = pool.slice(0, limit);
  // Practical needs (work / basics) always surface their best resource.
  if (tags.has("work") || tags.has("basics")) {
    const isRes = (x: { e: NeedEntry }) => x.e.actionTag.startsWith("resource:") && x.e.needTags.some((t) => tags.has(t));
    const best = pool.find(isRes);
    if (best && !top.includes(best)) top.splice(Math.max(0, Math.min(limit, top.length) - 1), 1, best);
  }
  return top.map((x) => ({ ...x.e, ...(x.primary ? { primary: true } : {}) }));
}
