import type { Exercise, ExerciseContent } from "@/data/exercises";

const safety = /988|911|suicid|overdose|hurting (?:myself|yourself)|want.*die/i;
const sayIt = /say (?:it )?(?:out loud|in (?:your|my) head)/i;
export function inclusiveExerciseText(text: string): string {
  if (safety.test(text)) return text;
  return text.replace(/Say (?:it )?out loud(?: or in your head)?\s*:?\s*/gi, "Say it out loud or in your head: ");
}
export function controlledExercise(exercise: Exercise): Exercise {
  const content = exercise.content;
  const normalize = (value: unknown): unknown => typeof value === "string" ? inclusiveExerciseText(value) : Array.isArray(value) ? value.map(normalize) : value && typeof value === "object" ? Object.fromEntries(Object.entries(value).map(([key, v]) => [key, normalize(v)])) : value;
  if (content.kind !== "guided") return { ...exercise, content: normalize(content) as ExerciseContent };
  const lastSay = content.steps.reduce((last, step, i) => sayIt.test(step.say) && !safety.test(step.say) ? i : last, -1);
  return { ...exercise, content: { ...content, steps: content.steps.filter((step, i) => i === lastSay || !sayIt.test(step.say) || safety.test(step.say)).map((step) => ({ ...step, say: inclusiveExerciseText(step.say) })), closing: inclusiveExerciseText(content.closing) } };
}
export function exerciseFeelingOutcome(feeling: "Calmer" | "About the same" | "Harder") {
  return feeling === "Calmer" ? "helped" as const : feeling === "Harder" ? "not-really" as const : undefined;
}