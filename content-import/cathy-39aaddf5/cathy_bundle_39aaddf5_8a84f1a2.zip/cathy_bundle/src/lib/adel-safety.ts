/**
 * Hardcoded crisis-language stopgap shared by every Adel surface.
 * Runs BEFORE anything is sent to the AI (client) and again on the server.
 * This is a simple keyword check, not production-grade crisis detection.
 */
export const CRISIS_PATTERNS = [
  /\bkill\s+myself\b/i,
  /\bkill\s+my\s?self\b/i,
  /\bend\s+my\s+life\b/i,
  /\bnot\s+worth\s+living\b/i,
  /\bwant\s+to\s+die\b/i,
  /\bwanna\s+die\b/i,
  /\bno\s+reason\s+to\s+(keep\s+going|live|go\s+on)\b/i,
  /\bsuicid/i,
  /\bhurt\s+myself\b/i,
  /\bharm\s+myself\b/i,
  /\b(kill|hurt|shoot|stab)\s+(him|her|them|someone|somebody|people)\b/i,
  /\bbetter\s+off\s+dead\b/i,
  /\b(don'?t|do\s+not)\s+want\s+to\s+(be\s+here|wake\s+up|be\s+alive|live)\b/i,
  /\bend\s+it\s+all\b/i,
  /\bcan'?t\s+go\s+on\b/i,
  /\bno\s+point\s+(in\s+)?(living|going\s+on|anymore)\b/i,
  /\b(cut|cutting)\s+myself\b/i,
  /\bhurting\s+myself\b/i,
  /\btake\s+all\s+(of\s+)?(my|the)\s+pills\b/i,
  /\b(going\s+to|gonna|want\s+to|wanna)\s+(hurt|kill|shoot|stab)\s+(him|her|them|someone|somebody|my\s+\w+|his\s+\w+|her\s+\w+)\b/i,
  /\bvoices?\b[^.!?]{0,60}\b(tell|telling|told|saying|want)\w*[^.!?]{0,40}\b(hurt|kill|harm)\b/i,
  /\b(want|going|gonna|trying)\s+to\s+overdose\b/i,
  /\bkms\b/i,
  /\bunalive\b/i,
  /\bhang\s+myself\b/i,
  /\bshoot\s+myself\b/i,
  /\bjump\s+off\b/i,
  /\b(better\s+off|be\s+better)\s+without\s+me\b/i,
  /\bnobody\s+would\s+(care|notice)\s+if\s+I\s+(died|was\s+gone)\b/i,
];

/** An overdose happening right now — shows the fixed 911 / naloxone card, never sent to the AI. */
export const OVERDOSE_NOW_PATTERNS = [
  /\b(is|are|he'?s|she'?s|they'?re|someone'?s)\s+(overdosing|od'?ing)\b/i,
  /\bnot\s+breathing\b/i,
  /\bwon'?t\s+wake\s+up\b/i,
  /\bi'?m\s+(overdosing|od'?ing)\b/i,
];

export function isOverdoseNow(text: string) {
  return OVERDOSE_NOW_PATTERNS.some((p) => p.test(text));
}

export const OVERDOSE_NOW_MESSAGE = "If someone won't wake up or isn't breathing, call 911 now. Give naloxone (Narcan) if you have it.";

export function isCrisis(text: string) {
  return CRISIS_PATTERNS.some((p) => p.test(text));
}

/** The one hardcoded crisis reply — same words on every Adel surface, never AI-written. */
export const CRISIS_MESSAGE = `Thank you for being honest with me — that took something.

I'm not able to be the support you need for this moment, but real help is available right now:

988 Suicide & Crisis Lifeline — call or text 988, 24/7
Crisis Text Line — text HOME to 741741

I'm also letting your care team know so a real person can follow up with you today. You're not on your own with this.`;

/** Hopeless (non-crisis) language that stops the If–Then plan confidence flow and shows the crisis card. */
// Low-mood safety check — Adel asks the question once per conversation
// (SAFETYCHECK: yes); the member answers with these fixed chips. "No" keeps
// the conversation going; anything else shows the hardcoded crisis card.
export const SAFETY_CHECK_CHIPS = ["No", "Sometimes", "Yes"] as const;

export const HOPELESS_PATTERNS = [
  /\bit\s+won'?t\s+matter\b/i,
  /\bi\s+give\s+up\b/i,
  /\bwhat'?s\s+the\s+point\b/i,
  /\bno\s+point\b/i,
  /\bwhy\s+bother\b/i,
  /\bnothing\s+(will\s+)?(ever\s+)?(change|work|help)s?\b/i,
];

export function isHopeless(text: string) {
  return HOPELESS_PATTERNS.some((p) => p.test(text));
}
