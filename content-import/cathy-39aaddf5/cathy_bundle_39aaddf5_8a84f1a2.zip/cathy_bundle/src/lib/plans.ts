// Shared helpers for saved "My If–Then Plan" toolkit entries (Library only).
import type { ToolkitItem, PlanLogEntry, RecoveryTool } from "@/data/state";
import { BACKUP_ACTIONS } from "@/data/if-then-content";
import { LIBRARY_TOPICS, RECOVERY_TOPICS } from "@/data/topic-content";
import { lessonTools, namedLessonTarget, type NamedTarget } from "@/lib/lesson-tools";

export const isPlanItem = (t: ToolkitItem) => t.plan?.type === "if-then";
export const activePlans = (toolkit: ToolkitItem[]) => toolkit.filter((t) => isPlanItem(t) && !t.retired);
export const retiredPlans = (toolkit: ToolkitItem[]) => toolkit.filter((t) => isPlanItem(t) && t.retired);

/** Update only the existing SUD copy; Library plans and unrelated tools stay untouched. */
export function syncRecoveryPlan(tools: RecoveryTool[], item: ToolkitItem): RecoveryTool[] {
  if (item.plan?.type !== "if-then" || !item.route?.startsWith("/sud-recovery-journey/")) return tools;
  return tools.map((tool) => tool.id === item.id
    ? { ...tool, content: item.label, ifThen: item.label }
    : tool);
}

/** Category id parsed from the item's route (/self-help-library/<category>/<lesson>). */
export function planCategoryId(item: ToolkitItem): string {
  const parts = item.route?.split("/") ?? [];
  // SUD Recovery Journey plans resolve against recovery module ids, never Library categories.
  if (parts[1] === "sud-recovery-journey") return parts[2] ? `recovery:${parts[2]}` : "";
  return parts[2] ?? "";
}

/** Map a plan's move text to an existing exercise, if one matches. */
export function moveExerciseId(move: string): string | null {
  const m = move.toLowerCase();
  if (/5\s*things|5-4-3-2-1|grounding/.test(m)) return "senses-5-4-3-2-1";
  if (/breath/.test(m)) return "box-breathing";
  if (/timer|20-minute|20 minute/.test(m)) return "urge-surfing-timer";
  return null;
}

/** A plan move that names its lesson's Part A exercise (title) or Part B tool (toolName). */
export function planMoveTarget(item: ToolkitItem): NamedTarget | null {
  const move = item.plan?.move ?? "";
  const lessonId = item.plan?.lessonId || item.route?.split("/")[3];
  if (!move || !lessonId) return null;
  const recovery = !!item.route?.startsWith("/sud-recovery-journey/");
  const tool = lessonTools().find((t) => t.lessonId === lessonId && (t.link.to.startsWith("/sud-recovery-journey") === recovery));
  const topics = recovery ? RECOVERY_TOPICS : LIBRARY_TOPICS;
  return namedLessonTarget(move, { exerciseId: topics[lessonId]?.exerciseId ?? tool?.exerciseId, toolName: tool?.toolName, lessonId });
}

/** Plans from these categories also show the overdose-prevention link. */
const OVERDOSE_CATEGORIES = new Set(["strengthen-recovery", "understanding"]);
export function showOverdoseLink(item: ToolkitItem): boolean {
  const cat = planCategoryId(item);
  return OVERDOSE_CATEGORIES.has(cat) || cat.startsWith("recovery:") || /trigger|want to use|craving/i.test(item.from);
}

export type BackupAction =
  | { kind: "link"; to: string; label: string }
  | { kind: "tel"; phone: string; label: string }
  | { kind: "call-contact"; label: string }
  | { kind: "text"; label: string };

/** Map the exact backup strings (and anything else) to a real place in the app. */
export function backupAction(backup: string, item?: ToolkitItem): BackupAction {
  switch (backup.trim()) {
    case BACKUP_ACTIONS.crisisLine:
      return { kind: "tel", phone: "988", label: backup.trim() };
    case BACKUP_ACTIONS.craving:
      return { kind: "link", to: "/craving", label: backup.trim() };
    case BACKUP_ACTIONS.safetyPlan:
      return { kind: "link", to: "/safety-plan", label: backup.trim() };
    case BACKUP_ACTIONS.readPlan:
      return { kind: "link", to: "/my-plans", label: backup.trim() };
    case BACKUP_ACTIONS.groundAgain: {
      const lessonId = item?.plan?.lessonId || item?.route?.split("/")[3];
      const topics = item?.route?.startsWith("/sud-recovery-journey/") ? RECOVERY_TOPICS : LIBRARY_TOPICS;
      const exerciseId = lessonId ? topics[lessonId]?.exerciseId : undefined;
      return exerciseId
        ? { kind: "link", to: `/exercise/${exerciseId}`, label: backup.trim() }
        : { kind: "text", label: backup.trim() };
    }
    case BACKUP_ACTIONS.neverUseAlone:
      return { kind: "tel", phone: "18004843731", label: backup.trim() };
    case BACKUP_ACTIONS.naloxone:
      return { kind: "link", to: "/overdose-prevention", label: backup.trim() };
    case BACKUP_ACTIONS.legalAid:
      return { kind: "link", to: "/community-resources/legal", label: backup.trim() };
    case "Message my peer specialist":
      return { kind: "link", to: "/peer", label: "Message my peer specialist" };
    case "Talk with Adel":
      return { kind: "link", to: "/adel", label: "Talk with Adel" };
    case "Book a therapy visit":
      return { kind: "link", to: "/appointments/book", label: "Book a therapy visit" };
    case "Get crisis support now":
      return { kind: "link", to: "/crisis", label: "Get crisis support now" };
    case "Call 211 for help finding a resource":
      return { kind: "tel", phone: "211", label: "Call 211" };
    case "Go to a meeting":
      return { kind: "link", to: "/community-resources/recovery", label: "Find a meeting" };
    case "Call 911 if it's an emergency":
    case "Call 911":
      return { kind: "tel", phone: "911", label: "Call 911" };
    case "Call my support person":
    case "Call my sponsor":
    case "Call my case manager":
    case "Call my prescriber's office":
    case "Call my pharmacist":
      return { kind: "call-contact", label: backup.trim() };
    default:
      return { kind: "text", label: backup.trim() };
  }
}

const THREE_DAYS = 3 * 864e5;

/** The one plan due for a check-in review: least recently reviewed, not within 3 days. */
export function planDueForReview(plans: ToolkitItem[], logs: Record<string, PlanLogEntry[]>): ToolkitItem | null {
  let best: ToolkitItem | null = null;
  let bestAt = Infinity;
  for (const p of plans) {
    const entries = logs[p.id] ?? [];
    const last = entries.length ? new Date(entries[entries.length - 1].date).getTime() : 0;
    if (Date.now() - last < THREE_DAYS) continue;
    if (last < bestAt) { bestAt = last; best = p; }
  }
  return best;
}
