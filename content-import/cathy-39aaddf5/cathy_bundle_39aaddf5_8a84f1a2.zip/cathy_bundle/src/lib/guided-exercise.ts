// Pure helpers for guided exercises (Part A). Tested in guided-exercise.test.ts.
import type { GuidedContent } from "@/data/exercises";

const HOLD = /hold|wait|stay|pause|sit|notice|picture|imagine|seconds/i;

/** "Take about N seconds" shows for any step of 10+ seconds, or a hold-style step. */
export function guidedHintSecs(step: { say: string; secs: number } | undefined): number | null {
  if (!step || !(step.secs > 0)) return null;
  return step.secs >= 10 || HOLD.test(step.say) ? step.secs : null;
}

/** Toolkit text auto-saved when a guided exercise with a tagline finishes. */
export function taglineToolkitText(title: string, c: GuidedContent): string | null {
  const t = c.tagline?.trim();
  return t ? `${title}: ${t}` : null;
}

/** What read-aloud speaks for a phase: "scene", step index, or "done". */
export function guidedSpeech(c: GuidedContent, phase: "scene" | "done" | number): string {
  if (phase === "scene") return c.scene ? `Picture this. ${c.scene}` : "";
  if (phase === "done") return [c.closing, c.tagline ? `Take it with you: ${c.tagline}` : ""].filter(Boolean).join(" ");
  return c.steps[phase]?.say ?? "";
}

/** How Adel names an exercise when offering or reopening it. */
export function adelExerciseOffer(title: string, tagline?: string): string {
  return tagline?.trim() ? `Want to do ${title}? "${tagline.trim()}"` : `Want to do ${title}?`;
}
