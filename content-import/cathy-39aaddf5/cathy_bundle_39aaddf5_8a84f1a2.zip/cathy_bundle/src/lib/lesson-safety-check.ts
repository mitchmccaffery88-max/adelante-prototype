/** Fixed question paired with the shared No / Sometimes / Yes answers. */
export const LESSON_SAFETY_QUESTION = "Have you been thinking about hurting yourself?";

export function lessonSafetyCheck(requested: boolean, alreadyAsked: boolean) {
  return requested && !alreadyAsked;
}

export function withLessonSafetyQuestion(text: string) {
  const reflection = text.replace(/\s*[^.!?\n]*\?\s*$/, "").trim();
  return reflection ? `${reflection}\n\n${LESSON_SAFETY_QUESTION}` : LESSON_SAFETY_QUESTION;
}