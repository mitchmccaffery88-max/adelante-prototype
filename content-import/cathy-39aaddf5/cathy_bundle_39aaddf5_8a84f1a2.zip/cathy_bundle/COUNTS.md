# Static counts — Cathy's Final Adelante Journey Wireframe

Project `39aaddf5-07d8-49d9-b120-56e48aecd95f`, commit `8a84f1a2cdc307c6279837bd9b1e9a0a4248cf51`.
All counts were read statically from the files in this bundle (nothing was executed). Paths are relative to the bundle root; `file:line` is 1-based.

| Item | Count | Expected | Status |
|---|---|---|---|
| Library lessons | 90 | 90 | match |
| Recovery lessons | 90 | 90 | match |
| Total lessons | 180 | 180 | match |
| If–Then plans (lesson-level) | 180 (90 + 90) | 180 | match |
| Care notes | 8 | 8 | match |
| EXERCISES length | 229 | — | static count |
| Emergency backup lists with 988 + 911 | 6, 988 directly before 911 in all 6 | 6 (per test) | match |
| Inline `tel:` links | 8 (4 in content, 4 in tests) | — | — |
| Distinct phone numbers | 23 dialable numbers (+1 SMS short code) | — | — |
| "Devon" occurrences | 147 in 25 files | — | — |

## 1. Library lessons: 90

- `src/data/library.ts:8`: `LIBRARY = [...LIBRARY_PART_A, ...LIBRARY_PART_B, ...LIBRARY_PART_C]`
- Each part file has 3 categories (lines matching `id: "...", name:`) and 30 items (lines matching `id: "...", title:`):
  - `src/data/library-part-a.ts`: starting-strong (:7), understanding (:194), treatment (:381). Items run from `finding-footing` (:12) to `ownership` (:553). 30 items.
  - `src/data/library-part-b.ts`: train-mind (:7), strengthen-recovery (:196), big-emotions (:390). Items run from `thoughts-wont-stop` (:12) to `grief-loss` (:565). 30 items.
  - `src/data/library-part-c.ts`: support-team (:7), back-on-feet (:200), success-plan (:393). Items run from `count-on` (:12) to `future-roadmap` (:560). 30 items.
- Cross-check: the 9 `src/data/topic-content/library-*.ts` files have 10 `exerciseId:` entries each, 90 in total.
- Validator: `src/data/if-then-content.test.ts:12` requires an If–Then entry for every library lesson and no extra ones.

## 2. Recovery lessons: 90

- `src/data/recovery.ts:88`: `RECOVERY_MODULES` has 9 modules: first-days (:90), my-people (:117), understanding (:144), everyday-life (:171), relationships (:198), life-that-works (:225), when-hard (:252), someone-new (:279), living-recovery (:306).
- There are 90 seed tuples (lines matching `^\s{8}\["`), from `recovery.ts:100` to `recovery.ts:325`. `build()` turns each tuple into one lesson with the id `<moduleId>-<n>`.
- `src/data/recovery.ts:340`: `RECOVERY_LESSON_COUNT` is computed at runtime. The static seed count is 90.
- Cross-check: the 9 `src/data/topic-content/recovery-*.ts` files have 10 `exerciseId:` entries each, 90 in total.
- Validator: `src/data/recovery-if-then-content.test.ts:11` asserts `expected.length === 90`.

## 3. Total lessons: 180

90 + 90. The topic-content files have 180 `exerciseId:` entries, which agrees.

## 4. If–Then plans: 180

- `src/data/if-then-content.ts:47`: `IF_THEN_CONTENT` has 90 top-level keys, from `finding-footing` (:50) to `future-roadmap` (:1843).
- `src/data/recovery-if-then-content.ts:5`: `RECOVERY_IF_THEN_CONTENT` has 90 top-level keys, from `first-days-1` (:7) to `living-recovery-10` (:658).
- No topic-content entry sets an `ifThen` field. The only `ifThen` match is code in `src/data/topic-content/index.ts:83`.
- Not counted above: the fallback defaults in `src/data/if-then-defaults.ts`. They are `IF_THEN_DEFAULTS` (9 categories), `RECOVERY_IF_THEN_DEFAULTS` (9 modules) and `GENERIC`.

## 5. Care notes: 8

`src/data/care-notes.ts` defines 8 notes with `export const X: CareNote`:

| Note | Line |
|---|---|
| COURT_ORDER | :4 |
| ASSOCIATION | :9 |
| DV | :13 |
| CWS | :18 |
| SUPERVISION_SLIP | :23 |
| STOPPING_SAFELY | :29 |
| ANY_TIME_HELP | :35 |
| MEDICINE_CONTINUITY | :40 |

The notes are assigned to lessons in two maps:
- `LIBRARY_CARE_NOTES` (:46) has 9 keys. `src/data/care-notes.test.ts:33` asserts 9.
- `RECOVERY_CARE_NOTES` (:51) has 15 keys. `src/data/care-notes.test.ts:34` asserts 15.

Some lessons also attach a note directly in topic-content:
- `safe-now`, `bipolar`: ANY_TIME_HELP
- `when-hard-9`: SUPERVISION_SLIP

## 6. EXERCISES length: 229 (static)

How it is built: `src/data/exercises.ts:144` declares `EXERCISES = ([ ... ] satisfies Exercise[]).map(controlledExercise)` (`.map` at :377). The `.map` does not change the length; `src/lib/exercise-control.ts` only rewrites text.

Top-level elements were counted with a string- and comment-aware bracket parser:

| Source | Count | Declared at |
|---|---|---|
| `...SCHEDULE_EXERCISES` | 2 | `exercises-schedule.ts:3` |
| Inline objects in `exercises.ts` (:146 to :337) | 11 | — |
| `GUIDED_EXERCISES` | 14 | `exercises-guided.ts:19` |
| `GUIDED_MY_PEOPLE` | 8 | — |
| `GUIDED_UNDERSTANDING` | 2 | — |
| `GUIDED_EVERYDAY_LIFE` | 3 | — |
| `GUIDED_RELATIONSHIPS` | 2 | — |
| `GUIDED_LIFE_THAT_WORKS` | 3 | — |
| `GUIDED_WHEN_HARD` | 5 | — |
| `GUIDED_SOMEONE_NEW` | 1 | — |
| `GUIDED_LIVING_RECOVERY` | 3 | — |
| `PARTA_A` | 3 | — |
| `PARTA_B` | 3 | — |
| `PARTA_C` | 8 | — |
| `PARTA_D` | 11 | — |
| `PARTA_EF` | 4 | — |
| `PARTA_FIXES` | 6 | — |
| `BUILD_SKILL_SH1` | 28 | — |
| `BUILD_SKILL_SH2` | 25 | — |
| `BUILD_SKILL_SH3` | 22 | — |
| `BUILD_SKILL_SUD1` | 15 | — |
| `BUILD_SKILL_SUD2` | 29 | — |
| `BUILD_SKILL_SUD3` | 21 | — |
| **Total** | **229** | — |

The spreads are on lines :145 and :356 to :376 of `exercises.ts`. The static scan also found 229 distinct exercise ids and no duplicates.

## 7. Emergency lists with 988 and 911

### (a) If–Then backup lists containing `BACKUP_ACTIONS.emergency`

The backup strings are defined in `src/data/if-then-content.ts`:
- `BACKUP_ACTIONS.crisisLine` (:24) is "Call or text 988 for a mental health crisis". `src/lib/plans.ts:64` maps it to tel 988.
- `BACKUP_ACTIONS.emergency` (:25) is "Call 911". `src/lib/plans.ts:99` maps it to tel 911.

6 backup lists contain `BACKUP_ACTIONS.emergency`. Each one also contains 988, and in each one 988 comes directly before 911:

| Location | Backups in order |
|---|---|
| `src/data/if-then-content.ts:161` | leave, people, supportPerson, crisisLine, emergency |
| `src/data/if-then-content.ts:398` | writeDown, pharmacist, prescriber, crisisLine, emergency |
| `src/data/if-then-content.ts:1081` | stepAway, walk, supportPerson, crisisLine, emergency |
| `src/data/if-then-content.ts:1263` | leave, stepAway, supportPerson, crisisLine, emergency |
| `src/data/if-then-content.ts:1312` | leave, people, supportPerson, crisisLine, emergency |
| `src/data/if-then-content.ts:1522` | callTomorrow, resources211, crisisLine, emergency |

None of these lists are in `recovery-if-then-content.ts`, topic-content or `if-then-defaults.ts`. This matches the validator `src/data/audit-safety.test.ts:24`, which asserts 988 directly before 911 (:31) and exactly 6 lists (:33).

### (b) Other option lists with both a 988 string and a 911 string

These are single-line array literals. In all 7, 988 comes before 911:

| Location | Strings |
|---|---|
| `src/data/topic-content/library-starting-strong.ts:273` (safe-now, step "If I'm in danger") | "Call or text 988", "Call 911" |
| `src/data/topic-content/library-support-team.ts:444` (support-plan, crisis step) | "Call or text 988", "Call 911" |
| `src/data/topic-content/library-back-on-feet.ts:458` (resource-plan, crisis step) | "988", "911" |
| `src/data/topic-content/library-understanding.ts:355` (treatment-team, after hours) | "988", "911 for an emergency" |
| `src/data/topic-content/recovery-when-hard.ts:479` (when-hard-10, emergency steps) | "Call or text 988", "Call 911" |
| `src/data/recovery.ts:367` (`RECOVERY_SUPPORT` "Immediate help") | "Call or text 988", "Call 911" |
| `src/data/build-skill-sud3.test.ts:12` | test fixture that mirrors when-hard-10 |

## 8. Inline `tel:` links and phone numbers

### `tel:` URIs: 8 in total

4 are inline links in content, all in `src/data/care-notes.ts`:

| Line | Link |
|---|---|
| :16 | `tel:18007997233` (DV hotline) |
| :32 | `tel:18667324114` (SUD Access Line) |
| :38 | `tel:988` |
| :43 | `tel:18667324114` |

The other 4 are assertions in validators:
- `src/data/audit-safety.test.ts:17` (`tel:988`) and :22 (`tel:18667324114`)
- `src/data/care-notes.test.ts:42` (`tel:18667324114`) and :58 (`tel:18007997233`)

These links use 3 distinct numbers: 988, 1-866-732-4114 and 1-800-799-7233.

Related numbers that are not `tel:` URIs:
- `src/data/contact-numbers.ts` has 7 `tel: "<digits>"` properties (:9, :10, :12, :14, :15, :20, :22).
- `src/lib/plans.ts` builds tel actions for 988 (:64), 1-800-484-3731 (:80), 211 (:94) and 911 (:99).

### Distinct phone numbers: 23

These come from `tel:` URIs, `tel:` and `phone:` fields, and formatted numbers in text, with the leading 1 removed:

| Group | Numbers |
|---|---|
| Short codes | 211, 911, 988 |
| Statewide and national lines | 800-320-1616, 866-732-4114, 800-799-7233, 800-484-3731, 800-928-5330, 855-600-9276, 855-845-7415 (alternate Warm Line, `contact-numbers.ts:17`), 800-337-0690, 800-735-2922 (TTY), 877-960-3426 |
| Local 559 numbers | (559) 713-2750, 559-713-5200, 559-738-8733, (559) 732-8086, (559) 583-9300, 559-687-2520, (559) 732-6264, (559) 624-8000 |
| Placeholder | 555-555-0111, Devon's prototype number (`contact-numbers.ts:22`) |
| Test fixture | 559-555-0123 (`day-plan.test.ts:5`) |

The SMS code 741741 (Crisis Text Line, `src/lib/adel-safety.ts:62`) is not in the 23.

## 9. "Devon": 147 occurrences in 25 files

All occurrences are in `src/data`. The files with the most:

| File | Count |
|---|---|
| `build-skill-sud1.test.ts` | 37 |
| `reentry.ts` | 14 |
| `topic-content/recovery-first-days.ts` | 13 |
| `topic-content/recovery-my-people.ts` | 13 |
| `build-skill-sud2.test.ts` | 10 |
| `build-skill-sud3.test.ts` | 10 |
| `topic-content/recovery-understanding.ts` | 8 |
| `topic-content/recovery-when-hard.ts` | 7 |
| `exercises-build-skill-sud1.ts` | 6 |
| `topic-content/recovery-relationships.ts` | 6 |

The remaining 15 files have 1 to 4 each, for example `care-notes.ts:26`, `contact-numbers.ts:22` and `module-schema.ts:531`.

58 of the 147 are in test files: `build-skill-sud1/2/3.test.ts` (37 + 10 + 10) and `reentry.test.ts` (1). Leaving the tests out, there are 89 occurrences in content and code.

## Needs a runtime count

These cannot be settled by reading the files alone:
- `RECOVERY_LESSON_COUNT`: computed at runtime. The static count is 90.
- The number of lessons that end up with a care note after `applyTopic` and the `topic-content/index.ts` merges.
- The final `EXERCISES` text after `controlledExercise` runs. The length is not affected.
